# Fenrir and Gleipnir phased execution plan

Version 0.1 • Naming revision 3 October 2026 • Dependency ordered implementation program

**Working names:** Fenrir is the language and overall project. Gleipnir is its deterministic harness and conformance environment. ShenCheck retains its existing name as reusable campaign, replay, and evidence infrastructure. TC0 remains the versioned identifier of the first language core. This naming revision does not change semantics or acceptance gates.

## 1 Mission and operating rules

Implement Fenrir and its Gleipnir harness according to the architecture in [01_FULL_VISION.md](01_FULL_VISION.md), beginning with the normative contract in [02_TINY_LANGUAGE_CORE.md](02_TINY_LANGUAGE_CORE.md). Continue in vertical slices: model, evaluator, candidate implementation, adversarial evidence, then the next feature. This plan includes the bootstrap and the phases after the tiny core so a fresh implementation agent has the complete dependency chain.

Do not rewrite ShenCheck without a source-grounded reason. Do not claim existing documentation proves a gate passes. Do not start with a new hypervisor, a complete surface language, or aggressive reference-count reuse. Make the semantic machine independently useful first.

Each phase ends with a gate. PASS requires current evidence bound to source and toolchain hashes. FAIL, UNKNOWN, BLOCKED and DEFERRED are distinct. Deferred optional work cannot satisfy a required gate. No dates or estimates substitute for acceptance evidence.

## 2 Dependency order

| Phase | Deliverable | Depends on |
| --- | --- | --- |
| P0 | Provenance, integration inventory, requirement ledger | None |
| P1 | Frozen TC0 schema and Shen reference machine | P0 |
| P2 | Trustworthy evaluator and exploration loop | P1 |
| P3 | Conservative executable candidate and agent repair loop | P2 |
| P4 | Deterministic Solo5 execution profile | P3 |
| P5 | Native compiler and memory correctness baseline | P3; P4 for isolated release evidence |
| P6 | Practical typed surface language and tooling | P5 |
| P7 | Production concurrency and supervised services | P4, P6 |
| P8 | Persistent services and independent history checking | P7 |
| P9 | Ownership optimization and specialization | P5; broader suites from P6–P8 |
| P10 | Interactive development and production qualification | P6–P9 |

P4 and early P5 work can proceed independently after P3 interfaces freeze. P9 experiments may begin earlier, but cannot replace the conservative compiler baseline. Optional emulation and Unikraft tracks have explicit triggers below.

## 3 Repository and ownership strategy

Begin by reading the actual repository instructions and current requirements matrix. ShenCheck's inspected AGENTS.md points implementation work to docs/AI_BUILD_WORKFLOW.md; the current file must be read in the target checkout. Respect its evidence and review requirements. This document does not authorize deployment, infrastructure mutation, or modification of unrelated adapters.

Suggested organization, subject to the actual repository layout:

```text
spec/tc0/                 versioned contract, schema and rule catalog
models/tc0/               Shen semantic machine and property definitions
fixtures/tc0/             hand-derived programs, traces and mutant cases
crates/...tc0-adapter/    ShenCheck integration and protocol validation
runtime/tc0/              conservative candidate implementation
compiler/tc0/             validation, lowering and native generation
backends/solo5/           guest bindings and tender integration
backends/process/         development execution adapter
campaigns/tc0/            smoke, exhaustive-small and nightly campaigns
evidence/                 manifests or content-addressed references
```

Keep generic campaign/history capabilities in ShenCheck. The language model, compiler and runtime may live in a separate repository if that improves ownership; use a versioned adapter package across the boundary. Do not hardwire a particular application or transport into the model kernel.

Separate semantic-authority changes from candidate implementation changes. The implementation agent's writable path set excludes frozen model rules, goldens and gate definitions. A separate review path can approve a contract change and its migration.

## 4 P0 Establish the baseline

### Work

Pin ShenCheck, Koka, Solo5, the selected Shen port, C compiler, Rust toolchain where used, and any Jepsen checker artifacts. Record exact commits, license obligations, build commands, file hashes and platform details. Keep upstream source adaptations explicit. Use a Nix flake and lockfile for reproducible dependencies where supported; provide a documented non-Nix build path if platform support requires it.

Inspect ShenCheck choices, replay, model sets, corpus/minimizer, cooperative protocol, Antithesis shim, Jepsen bridge and current tests. Classify each as reusable unchanged, requires adapter, requires repair, or unrelated. Inspect Koka's runtime assumptions before deciding whether code can be reused on Solo5. Inspect Solo5 clocks, bindings, tender, toolchain and target support.

Create a ledger with requirement ID, document section, owner component, test, evidence path, and current status. Establish protected evaluator boundaries and a clean-room task packet for the implementation agent.

### Gate G0

The existing baseline builds and its required tests run, or blockers are explicitly retained with affected work stopped. The inventory identifies actual source files and exact versions. No claim of whole-system determinism is inherited from SDK random replay. The initial target is a supported single-CPU architecture selected from demonstrated toolchain compatibility, not guessed compatibility.

## 5 P1 Build the semantic machine

### Work

Implement canonical encoding and schema validation, explicit types/effects/regions, CEK frames, pure evaluation, tail calls, tail-resumptive handlers, tasks/scopes, channels, timers, cancellation and resources in that order. Each feature lands with one-step fixtures and examples. The core is written in Shen; host code performs transport and artifact plumbing.

Resolve any remaining representation-level details before freezing the executable oracle: constructor encoding, step-frame enumeration, trap payload schemas, event field schemas, and stable source IDs. Changes must refine rather than contradict TC0's rules. Run an independent review of transition coverage and lifetime rules.

### Gate G1

Every TC0 rule has at least one positive and one distinguishing negative fixture where meaningful. All AST tags and continuation frames have explicit rules. The reference executes without environmental effects. Canonical bytes match independent fixtures. Run the corpus on two Shen ports; document any port limitation. Claim cross-port portability only for demonstrated configurations.

Deliverables: executable model, schema, fixture catalog, canonical trace examples, rule coverage report and a frozen semantic version.

## 6 P2 Make the evaluator trustworthy

### Work

Integrate the machine with ShenCheck's recorded structured choices. Add exhaustive search for very small finite configurations, seeded sampling for larger ones, semantic state hashing, strict replay, property evaluation and artifact retention. Hashing must include all future-relevant state, including pending operations, timers and continuation state; excluding a field requires a demonstrated equivalence argument.

Build the reducer in stages: remove independent program fragments, simplify values, remove tasks/operations when type/region valid, then reduce schedule decisions. Every proposed reduction is regenerated and rechecked. An invalid reduced tape is not a reproduced bug. Preserve the original and distinguish smallest-found from globally minimal.

Implement all mandatory mutants and one equivalent control mutation. Test harness failures such as truncated streams, malformed JSON, duplicate sequence IDs, wrong artifacts, oracle process failure, and exhausted replay tapes. Verify that no path turns these into PASS.

### Gate G2

Every mandatory non-equivalent mutant is detected with the expected classification. Each has a retained replayable counterexample. The equivalent control passes. A small exhaustive campaign reports the exact explored state/edge counts and completes without a cap. Larger bounded campaigns correctly report truncation. Rechecking a saved history requires no candidate execution.

## 7 P3 Implement the first candidate and repair loop

### Work

Write an independent conservative candidate using an explicit state machine. It may initially interpret TC0 in a native host process. It must not reuse the Shen transition implementation. The process adapter uses the same planned protocol as the Solo5 adapter.

Implement one vertical slice: two tasks, one channel, cancellation, and an abstract resource. Extend to the rest of TC0 after that slice passes. Make the evaluator the only authority on scheduling and verdicts. Add a first-divergence report and a reproduction command.

Give the implementation agent injected bugs and fresh generated failures. Measure whether its patches repair the defect while preserving existing behavior. Record the prompt/task packet, input revision, patch revision, evaluator revision, failure and validation result. Keep implementation and specification review separate.

### Gate G3

The candidate conforms on hand fixtures, exhaustive-small campaigns and declared sampling campaigns. The cancellation/stale-waiter bug is found, minimized, repaired and replayed end to end. A candidate that emits a fake terminal event while leaving live tasks is rejected. A candidate that never responds ends as a watchdog/infrastructure outcome, never a valid semantic completion.

This is the first useful release: a working executable contract and counterexample-driven development loop. It is not yet the full native language.

## 8 P4 Add deterministic Solo5 execution

### Work

Port only the minimum candidate/runtime support required. Establish boot parameters, allocator, bounded memory, console/debug channel and a dedicated framed semantic protocol. Audit all guest-visible time and input paths. Replace clock/readiness behavior with virtual responses. Disable unused devices. Use a single logical CPU and no uncontrolled asynchronous callbacks.

Document the protocol request fields, response fields, validation limits, startup handshake, profile hashes, termination handshake, and error behavior. Replay rejects drift. Start by restarting from initial state; do not depend on unimplemented VM snapshots.

Run host perturbation experiments: vary host load, scheduling delays, run directory, process placement and repeated cold boots while keeping the semantic profile fixed. Normalize only fields explicitly outside the semantic contract. Audit instructions/libraries that could bypass mediation. State precisely which cooperative or trusted-code assumptions remain.

### Gate G4

The same compatible artifact and tape produce identical semantic traces across a declared repeat suite, including failure cases. Guest crashes remain isolated and diagnosed. No live network/filesystem input enters replay. Boundary bypass tests fail closed where enforceable; any remaining unmediated native instruction capability limits the claim explicitly.

Repeat counts provide empirical evidence, not proof of universal determinism. Publish the supported profile and audit inventory. Do not label the profile machine-level deterministic unless an independent backend establishes that stronger claim.

### Optional instruction-control gate

If the product requires deterministic termination of non-yielding native code, prototype a compatible instruction-counted emulator or validated metering strategy. Gate it on infinite-loop termination, reproducible instruction-limit outcomes, replay of interrupts/devices where present, and integration with semantic observations. Do not claim that Solo5's isolation alone supplies this.

## 9 P5 Generate native code

### Work

Implement a conservative compiler from validated TC0 to an explicit state-machine IR and C/native code. Preserve semantic node mappings and scheduler checkpoints. Separate validation, lowering, code generation, runtime linking and execution. Compare the generated candidate against both Shen and the conservative interpreter.

Use simple safe memory management first. Pin ABI, integer representation, closure layout conventions and error propagation. Test tail calls, alias preservation and stack limits. Use available sanitizers, allocator poisoning and guarded allocations in suitable process builds; document which tools cannot run in the guest configuration.

### Gate G5

Generated programs agree with the oracle on all required campaigns. The compiler rejects invalid artifacts, traps arithmetic correctly, preserves left-to-right effects and tail-call stack behavior, and passes memory-error campaigns. Every compiler bug becomes a minimized source-level regression. Candidate optimization is disabled or minimal at this gate.

## 10 P6 Add a usable surface language

### Work

Choose surface syntax after TC0 demonstrates the contract. Investigate extending/reusing Koka versus introducing a small frontend that lowers to the defined IR; record maintenance and semantic compatibility costs. Do not assume Koka's full semantics equal TC0.

Add local type inference, polymorphism, algebraic datatypes and effect rows incrementally. Every addition has a desugaring or a new model rule. Build a formatter, package manifest/lockfile, diagnostic source mapping, language server essentials and a standard CLI. Separate compiler-internal types from stable public APIs.

### Gate G6

A new developer can install, build, run, test, explore and replay a sample with documented commands. Parser round trips and formatter stability hold. Effect diagnostics identify missing handlers and relevant call sites. Dependency resolution is reproducible. All generated surface examples reduce to validated artifacts and pass the semantic suites.

## 11 P7 Build production concurrency

### Work

Specify asynchronous I/O, deadlines, cancellation shielding if needed, realistic finalizers, bounded channels/mailboxes, supervisor restart policies and overload behavior as new versions/profiles. Keep one documented default policy for application developers.

Implement a production scheduler separately from the deterministic scheduler, sharing validated state transitions where appropriate but retaining independent checking. Capture causal histories and map them to the abstract model. Add actual parallel stress tests if multiple native threads are introduced. A serial simulator cannot establish weak-memory correctness by itself.

### Gate G7

Long-running service tests demonstrate graceful shutdown, bounded queues, cancellation completion, no leaked tasks/resources, and defined restart behavior under fault campaigns. Production histories are admitted by the model. Latency, throughput, memory and telemetry overhead are measured with reproducible workloads and hardware details. Timer behavior under CPU load is explicitly tested against the production contract.

## 12 P8 Add persistence and distributed histories

### Work

Add a versioned storage model: write visibility, flush/durability, crash loss, recovery, and allowed corruption faults. Network models distinguish channel semantics from packet loss, partitions, delayed responses and retransmission. Distinguish logical requests from retry attempts and client knowledge from internal state.

Build a small durable service, first a register or queue, then a lease/fencing or transactional workload. Use Shen domain models plus the existing Jepsen bridge for supported Elle/Knossos histories. Validate at least one history that passes, one known anomaly and one indeterminate case. Preserve each checker's distinct verdict.

### Gate G8

Crash-after-commit-before-response, retry duplication, stale fencing, partition recovery and incomplete histories all have explicit outcomes and fixtures. Independent checkers detect seeded anomalies. Replayed environmental faults are exact within the declared profile. Unmodeled external services are marked opaque rather than implied deterministic.

This is the trigger point for evaluating a Unikraft backend if a concrete library or compatibility workload justifies it. Adoption requires the same boundary inventory and conformance gates as Solo5, plus the new OS components' semantics. It does not replace the small reference backend.

## 13 P9 Optimize ownership and execution

### Work

Introduce a typed ownership/effect IR with explicit alias and lifetime information. Evaluate Perceus-inspired reference counting, borrowing, reuse, specialization, closure elimination and unboxing independently. Keep the conservative implementation available as a differential baseline.

For every optimization define preconditions, preserved observations, invalidation conditions and adversarial alias/effect examples. Test resource failure behavior separately from physical allocation performance. Use benchmarks that cover persistent sharing, array algorithms, recursion, effect-heavy tasks and real services.

### Gate G9

Optimized and baseline implementations agree over fresh generated campaigns and the regression corpus. Memory tooling finds no invalid reuse in the supported configurations. Performance changes include distributions, peak memory, compile time and code size. An optimization without a demonstrated benefit can be omitted. No universal speedup or zero-allocation claim is inferred from one benchmark.

## 14 P10 Qualify the product

### Work

Add interactive inspection, source-level suspended-task views, effect-context diagnostics and module replacement for new requests. Defer replacement of active suspended frames until a separate migration model exists. Complete package signing/provenance policy, compatibility/deprecation policy, supported-platform matrix, release documentation and operational guides.

Conduct a review of boundary enforcement, dependency updates, malformed artifacts, FFI profiles, sensitive trace data, resource exhaustion and denial-of-service behavior. Add supported real I/O libraries and independent integration tests. Retain reproducible old failure bundles across releases or publish explicit migration limits.

### Gate G10

Release qualification includes clean-machine installation, reproducible builds, compatibility fixtures, realistic long-duration services, fault recovery, performance budgets, and no unresolved required UNKNOWN rows. The product documentation states precisely which replay guarantees apply to which execution profiles.

## 15 Campaign tiers and cost controls

| Tier | Purpose | Promotion policy |
| --- | --- | --- |
| Per-change | Hand fixtures, protocol validation, smoke mutants, retained regressions | Required for every relevant patch |
| Integration | Exhaustive-small models, differential generation, replay perturbation | Required before feature promotion |
| Scheduled deep run | Larger exploration, fault schedules, optimization stress | Results bound to exact revision |
| Release | Full required matrix, real services, platform and performance qualification | Required for declared supported release |

Choose concrete budgets during P0/P2 from measured throughput. Preserve seeds and tapes for discovery, but use strict tapes for exact replay. Increasing a budget is useful only when it addresses an identified gap. Search reduction techniques such as partial-order reduction require an independence relation and comparison against unreduced exhaustive cases before they can support completeness claims.

## 16 Evidence contract

Each gate packet contains requirement IDs, source/toolchain hashes, commands, inputs, environment/profile versions, test counts, bounds, outcomes, failures, and known limitations. Required files include manifest.json, verdicts.json, program.json, choices.jsonl, trace.jsonl and replay instructions; minimized failures also retain reduction provenance and the original case identifier.

A source modification invalidates affected prior evidence until rerun. A green CI badge without the corresponding source identity is insufficient. Skipped tests and optional external-checker dependencies appear explicitly. Failed infrastructure is reported as such and never counted as a killed semantic mutant unless the expected observation was independently established.

## 17 Acceptance task template for an implementation agent

```text
Goal: Implement [component] for TC0 version [hash].
Read: exact model rules, interface schema, relevant repository instructions.
Allowed changes: [candidate paths].
Protected inputs: [oracle, goldens, catalogs, gates].
Start revision: [exact commit].
Acceptance: [bounded commands and campaign manifests].
On failure: retain first divergence, original and minimized case, and replay.
On suspected spec defect: propose a separate change; do not alter the oracle.
Completion: patch, design explanation, current evidence, remaining limitations.
Never report PASS for timeout, unknown, skipped, or truncated required work.
```

## 18 First concrete implementation assignment

Complete P0, then implement canonical TC0 artifacts and the pure Shen machine before task concurrency. Establish the evaluator's ability to reject reversed evaluation order and overflow mistakes. Add tail-resumptive handlers, then the two-task cancellation/channel/resource slice. Complete G1–G3 before allowing kernel/backend complexity to dominate development.

The first demonstration must show an actual generated implementation bug, a small deterministic counterexample, an agent patch, and current passing evidence. A diagram, proposed architecture, or manually selected happy-path run does not satisfy this milestone.
