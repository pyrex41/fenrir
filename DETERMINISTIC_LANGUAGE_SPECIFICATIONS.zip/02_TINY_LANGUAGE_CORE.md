# Fenrir tiny core and Gleipnir deterministic machine specification

Version 0.1 • Naming revision 3 October 2026 • Normative implementation target

**Working names:** Fenrir is the language and overall project. Gleipnir is its deterministic harness and conformance environment. ShenCheck retains its existing name as reusable campaign, replay, and evidence infrastructure. TC0 remains the versioned identifier of the first language core. This naming revision does not change semantics or acceptance gates.

## 1 Scope and authority

This document defines TC0, the first executable contract for Fenrir, the model-first language described in [01_FULL_VISION.md](01_FULL_VISION.md). It is intentionally an internal typed language, not the final user syntax or all of Koka. A Shen reference machine and an independently implemented candidate MUST implement these rules. The implementation sequence is in [03_PHASED_EXECUTION_PLAN.md](03_PHASED_EXECUTION_PLAN.md).

TC0 supports monomorphic functions, immutable algebraic values, lexical closures, explicit tail-resumptive user effects, structured tasks, bounded buffered channels, virtual time, cancellation, and abstract resource scopes. It excludes unrestricted continuations, shared mutable memory, FFI, real I/O, durable storage, floats, user exception handlers, and dynamic code loading.

Normative rule IDs are stable identifiers for fixtures and counterexamples. Proposed extensions MUST NOT silently change a rule under the same version.

## 2 Artifacts and validation

An artifact contains schema version, module name, datatype/effect declarations, function definitions, entry function, input schema, and a source map. Functions and every AST node have unique artifact-local IDs assigned before optimization. IDs identify semantic locations; native addresses never identify semantic objects.

The canonical transport is UTF-8 JSON restricted to null, booleans, strings, arrays, and objects. All semantic integers are decimal strings with no plus sign, leading zero, or negative zero. Object keys are ASCII identifiers and sorted by unsigned UTF-8 bytes. No duplicate keys, JSON numeric tokens, insignificant whitespace in canonical output, or unpaired Unicode surrogates are permitted. Strings are not Unicode-normalized; escape control characters, quote, and backslash, and otherwise emit valid UTF-8. SHA-256 of canonical bytes identifies an artifact. A versioned serializer test corpus MUST establish cross-language agreement.

An AST expression is an array whose first item is a tag, second item is its node ID, and remaining items are operands. Declarations use objects with a closed field set. The implementation MUST publish a machine-readable schema and reject unknown fields. The grammar below determines constructor arity; the schema cannot widen the language without a spec amendment.

**TC0-VALIDATE:** Reject malformed syntax, unknown names, duplicate IDs, type/effect mismatches, non-exhaustive matches, invalid resource escape, invalid channel capacities, or an entry signature other than one declared input value to a serializable result. Invalid artifacts do not execute. Validation has separate input-size and work bounds; exceeding them is ValidationLimit, not acceptance.

## 3 Values and types

```text
T ::= Unit | Bool | I64 | Bytes
    | Tuple(T...) | D | T -> {effects} T
    | Channel(region,T) | Task(region,T) | Resource(region)
```

Tuples have arity 1 through 8. A declared datatype D has a finite set of named constructors with typed fields; recursive occurrences are allowed through constructor values. Type parameters and polymorphic recursion are absent. Bytes is an immutable finite octet vector. All type annotations are explicit in TC0; inference belongs to a future surface language.

I64 is signed two's-complement mathematical range minus 2^63 through 2^63 minus 1. Add, subtract, multiply and negation trap Overflow outside the range. Division truncates toward zero; division by zero traps DivZero and minimum-I64 divided by minus one traps Overflow. Byte indexing traps Bounds. Equality is structural only for Unit, Bool, I64, Bytes, tuples and datatypes containing equality-compatible fields. Functions, channels, tasks, and resources have no language equality or serialization.

**TC0-VALUE:** Immutable aliases retain their values across all future computation. Any reuse optimization must preserve this rule.

Handles are opaque and scoped by a lexical region. Region constraints prevent returning handles or closures capturing them from their owner scope. Child tasks may inherit channels/resources from ancestor regions that outlive them; resource ownership itself is not transferable. TC0 forbids sending task, channel, resource or closure values through channels; channel payload types must be serializable. This simplifies both validation and trace comparison.

## 4 Expressions and evaluation

The following is readable grammar, not a promise of final source syntax. Canonical AST constructors correspond one-to-one with these forms and carry node IDs as specified above.

```text
e ::= unit | bool(b) | int(n) | bytes(hex) | var(x)
    | let(x,e,e) | if(e,e,e) | tuple(e...) | project(e,i)
    | construct(D,C,e...) | match(e, [C(vars) => e]...)
    | lambda(x:T,e) | apply(e,e) | call(function,e)
    | prim(op,e...)
    | handle(effect, [op(x) => e]..., body)
    | perform(effect,op,e)
    | scope(body) | spawn(e) | await(e) | cancel(e) | yield
    | channel(T,capacity) | send(e,e) | receive(e) | close(e)
    | now | sleep(e)
    | resource(label,x,body) | use(e)
    | emit(label,e)
```

Named functions accept one argument, using tuples for multiple arguments, and may be mutually recursive. Lambda bodies capture immutable lexical environments. Spawn expects a Unit-to-T closure. Let is nonrecursive. Match arms bind constructor fields. Each primitive has a fixed declared signature; the initial set is I64 arithmetic and comparison, boolean negation, bytes length/index/concatenation, and structural equality.

**TC0-EVAL:** Evaluate operands strictly left to right, then apply the operation. If an operand traps, later operands do not execute. If evaluates exactly one branch; match evaluates exactly one matching arm. Evaluation never depends on hash iteration order.

**TC0-TAIL:** Tail calls do not increase semantic continuation depth. Native implementations MUST preserve bounded native stack use for an unbounded sequence of tail calls, subject to the campaign's execution budget.

The reference uses an explicit CEK-style machine: control expression/value, immutable environment, continuation frames. It MUST NOT rely on host recursion for task scheduling or target-language tail calls. Each reference step dispatches one expression constructor, returns a value into one continuation frame, or applies one primitive/runtime rule. Administrative environment lookup and canonical bookkeeping do not create additional scheduling steps. Phase 1 MUST enumerate the frames and publish one-step fixtures for every constructor before freezing the executable oracle.

## 5 Effects

Each user effect declares operation names and signatures A -> B. A handler supplies one clause per operation. Performing an operation evaluates its argument, finds the nearest lexical/dynamic handler for that effect in the current task, evaluates the clause, and supplies the clause's returned value to the suspended operation. The body result passes through unchanged.

**TC0-EFFECT:** Handlers are tail-resumptive and exactly-once by construction: there is no user-visible resume value. A clause runs outside its own handler, under the handler's enclosing effect context; performing the same effect inside the clause therefore forwards outward. On normal clause return, evaluation resumes inside the original handler. A trap or cancellation aborts the suspended continuation and unwinds resources; it does not fabricate a return value.

Built-in scheduler, channel, time and resource operations are reserved effects and cannot be replaced by user handlers. The effect checker tracks a finite set of effect names for each function. Handle removes the handled effect from the body requirement and adds the clause requirements. Nested handler clauses can use built-in operations and suspend. No row polymorphism exists in TC0.

Spawn snapshots the parent's active immutable user-handler environment. The child owns independent handler frames with the same captured immutable values. Region validation rejects captures whose lifetime could end before the child. Parent handler exit does not destroy a child's copied handler environment.

Unhandled user effects are validation errors for closed entry programs. An observed UnhandledEffect at runtime is a candidate defect or invalid-artifact execution, never ordinary success.

## 6 Machine state and identities

```text
State = {
  tasks, scopes, channels, resources,
  virtual_time, next_ids, observations,
  remaining_semantic_steps, program_hash, profile
}
Task = {
  id, parent_scope, control, environment, continuation,
  handlers, owned_resources, owned_scopes,
  status, cancel_requested, pending_operation, result
}
```

Task status is Runnable, Blocked(reason), Unwinding(reason), or Terminal(outcome). Outcomes are Ok(value), Cancelled, or Trap(code). IDs are increasing unsigned integers allocated by the model at creation. Exhaustion of an ID space is a harness configuration limit. Child identity also records parent and spawn node for diagnostics. Candidate-private IDs must map bijectively to model IDs.

The initial state contains root task 0 inside an implicit root scope, no channels/resources, virtual time zero, and canonical input. Identical initial state plus decisions MUST produce identical normalized observations.

## 7 Scheduler and time

**TC0-SCHEDULE:** At each semantic step, enabled decisions contain Run(task_id) for every Runnable or Unwinding task. Choosing Run advances exactly one reference-machine step for that task. A blocked task is not runnable until the rule resolving its pending operation makes it runnable. The candidate adapter must expose equivalent semantic safe points in the TC0 instrumented profile.

Pure evaluation is preemptible between semantic steps. No shared mutable state is exposed, but task completion and resource limits can make this scheduling observable. The canonical baseline policy picks the lowest runnable ID; exploration may choose any enabled decision. Canonical ordering of domains is numeric ID order.

Now returns the current nonnegative virtual time in nanoseconds, bounded to I64 max. Sleep(d) requires d >= 0 and checks time+d for overflow. Sleep(0) behaves as yield; positive sleep blocks until its deadline.

**TC0-TIME:** When no task is Runnable or Unwinding, and at least one live timer exists, the only enabled decision is AdvanceTime(minimum_live_deadline). This sets time to that deadline and makes every due sleeper runnable in numeric ID order. Cancellation removes a task's sleep timer. Time never advances merely because the host waited. If no runnable task or timer exists while root is unfinished, report Deadlock with the wait graph.

This policy intentionally does not promise timers progress while another task computes forever. Campaigns that test recovery under fairness must declare a scheduler constraint and a sufficient step budget. The unrestricted scheduler has no fairness guarantee. A wall-clock watchdog is HarnessTimeout, not a language timer.

## 8 Structured tasks and scopes

Scope creates a fresh child region and evaluates body. Spawn creates a child in the innermost active scope of the calling task, inherits permitted immutable context, and returns a Task handle. A new child is runnable after the spawn transition; it does not execute within that transition. Exceeding the configured modeled task-count quota traps TaskLimit before creating a child.

Await on a child returns an outcome value encoded as Ok(T), Cancelled, or Failed(TrapCode). It blocks if the child is unfinished. It is legal only for task handles accessible in the owning lexical region. Child failure does not asynchronously trap the parent; the enclosing scope determines propagation as below.

**TC0-SCOPE:** On normal completion of body, scope closes to new spawns and waits for all its children. If any child terminates with Trap, scope requests cancellation of all unfinished children and ultimately traps ChildFailed. If multiple child traps exist, diagnostics retain all in task-ID order. Otherwise it returns the body's value once every child is terminal. Explicitly cancelled children do not make a normally finishing scope fail.

If body traps or is cancelled, scope requests cancellation of every unfinished child and waits for their terminal states before allowing the parent unwind to leave the scope. The original body trap/cancellation remains the outcome. No child may outlive its owning scope. Scope-local resources remain valid until its children finish; region validation enforces nested lifetimes.

Root termination occurs only after implicit root-scope cleanup and child joins. No further guest semantic operations are accepted after terminal root outcome.

## 9 Cancellation

Cancel(task) requests cancellation, returns Unit immediately, and is idempotent. It is not a join. Cancelling a terminal task has no effect. Cancellation becomes effective when the target next takes a Run step; that step begins unwinding before any normal expression executes. If the target is Blocked, the request atomically removes its pending channel/timer/await registration and makes it Unwinding. Cancelled tasks cannot create new user operations.

**TC0-CANCEL:** Cancellation does not undo an already committed channel operation or emitted observation. The reference tracks pending operations as Registered, Committed, or Removed. Exactly one terminal disposition is permitted. A blocked registration removed by cancellation cannot later commit. A previously committed receive may already have removed a message even if cancellation prevents the task from evaluating subsequent code; the commit remains in the trace.

Cancel returns before the target is terminal. A caller needing completion uses await. Therefore fixtures must distinguish cancellation requested, cancellation effective, and task terminal. A send after an await returning Cancelled cannot be consumed by that cancelled task's stale receive registration.

Unwind steps release one innermost resource or manage one owned scope per step, then record task termination. User code does not execute during unwind. These steps remain scheduler-visible and count against the campaign budget. Exhausting a test budget during unwind is incomplete exploration, not evidence that cleanup completed.

## 10 Buffered channels

Channel(T,c) creates an open FIFO queue with capacity c in the current scope; 1 <= c <= configured maximum. Zero-capacity rendezvous channels are excluded. Handles cannot escape their region. All reads/writes of the abstract queue occur atomically in channel transitions.

Send evaluates channel then payload. On a closed channel it returns Closed. If space exists, append payload and commit Sent. Otherwise register a blocked sender carrying the evaluated payload. Receive returns Item(value) and removes the oldest queued value when one exists. On an empty closed channel return End; on an empty open channel register a receiver.

**TC0-CHANNEL:** Each channel transition concludes with deterministic stabilization: first serve waiting receivers from queued items, then admit waiting senders into free space if open, and repeat until no rule applies. Waiting operations are ordered by their monotonically assigned registration IDs. Each admitted sender appends one value and commits Sent; each receiver consumes one value and commits Item. Record commits in stabilization order. No other task interleaves within stabilization.

Close is idempotent. It marks closed, commits Closed for all blocked senders in registration order without enqueueing their payloads, delivers remaining queued values to blocked receivers, and returns End to remaining receivers when the queue is empty. Already buffered values remain readable. A channel owns each buffered message until a receive commit; no message can be consumed twice.

These are language-level FIFO and waiter-fairness decisions, not assumptions about OS sockets. Future networks may lose or reorder messages; TC0 channels do not.

## 11 Abstract resources and observations

Resource(label,x,body) atomically acquires a new abstract resource and binds x. Acquire failure injection is not part of TC0. Use(handle) validates that the resource is live and accessible, returns Unit, and emits a resource-use observation. Normal exit, trap, or cancellation releases it exactly once in innermost-first order after any nested child scopes have completed.

**TC0-RESOURCE:** Use-after-release, double release, or region escape is forbidden. Cleanup is a reserved, nonblocking, nonthrowing primitive; arbitrary user finalizers are excluded. This establishes lifetime rules without pretending to model socket close or transaction rollback.

Emit(label,value) accepts only serializable values and emits an application observation, then returns Unit. It has no influence on scheduling legality. Observable traces also include operation invocation/commit, task spawn/cancel-request/termination, scope entry/exit, resource acquire/use/release, and time advance. Arguments and results are canonical values.

Candidate trace events are checked against the reference as execution proceeds. Missing expected events, extra events, illegal outcomes, and output after termination are divergences. A candidate's claim that an invariant held never substitutes for model validation.

## 12 Atomicity and candidate adaptation

The unit of abstract atomicity is a reference step, including channel stabilization. Candidate lowering may execute multiple native instructions per step. The initial native backend MUST use a conservative explicit machine/state representation so its safe points correspond exactly to reference steps.

Later optimized code may coalesce unobservable pure steps only under a separately specified refinement profile. It cannot reuse TC0 exact-step tapes without a validated mapping. Record semantic and native instruction budgets separately.

A host adapter selects decisions and checks events. Candidate requests identify the expected task, node, operation ordinal and payload. The host MUST reject out-of-order, duplicated, oversized or malformed requests. Sequence numbers are checked independently of candidate contents. No ambient device is exposed to the guest.

## 13 Replay protocol

Each choice record includes schema, run ID, monotonically increasing index, artifact hash, semantic site (task/node/occurrence), decision kind, canonical enabled-domain hash, and selected decision. A run header binds oracle, environment, runtime, compiler and execution-profile identities. Hashes refer to exact bytes, not a moving branch label.

**TC0-REPLAY:** Exact replay validates header compatibility, site, decision kind, domain and selected membership at every choice, then consumes the entire tape. An exhausted tape before termination, unused suffix at termination, changed domain, or changed site is ReplayDiverged. No seed fallback is allowed. Candidate crash is CandidateCrash, retained separately from semantic divergence diagnostics.

Check semantic trace checkpoints and final outcome as well as choices. A matching tape alone does not establish that the implementation executed correctly. Cross-version replay requires an explicit migration and a different claim from exact original replay.

## 14 Bounds and verdicts

Recommended smoke profile: at most 4 live tasks including root, 2 channels of capacity up to 2, 2 live resources per task, 32-byte values, 200 AST nodes, 200 semantic steps, and input integers in minus 2 through 2. These are initial test settings, not universal language limits or a promise of tractable exhaustive search.

The campaign separately bounds search nodes, trace bytes, execution time and model states. Every cap and whether it was hit must be reported. TaskLimit is a modeled trap only when a task quota is explicitly part of the selected profile. Host out-of-memory, stack overflow caused by the implementation, or a truncated evidence stream is not a valid target-language trap.

Verdict has independent fields:

```text
property: SatisfiedWithinScope | Violated | Unknown | NotReached
execution: Completed | Deadlock | CandidateCrash | HarnessError | BudgetExhausted
replay: NotRequested | Exact | Diverged | Incompatible | Incomplete
exploration: Sampled | ExhaustiveWithinBounds | Truncated
```

Deadlock is an observable outcome permitted for some programs. It violates a property only when the test contract requires progress. A model and candidate agreeing on a trap establishes conformance for that case, not application success. ExhaustiveWithinBounds is valid only after all reachable alternatives within the finite declared scope were explored without pruning gaps or truncation.

## 15 Required conformance fixtures

| Fixture | Required result |
| --- | --- |
| Left operand traps, right emits | No right-side emission |
| Deep tail recursion | Correct result with bounded native stack |
| Retain alias, transform another reference | Retained alias unchanged |
| Nested same-effect handlers | Nearest handler selected; clause forwards to outer handler |
| Handler clause sleeps | Suspended operation resumes once with correct value |
| Child outlives body computation | Scope waits; no child escapes |
| Child traps | Siblings cancelled; scope eventually ChildFailed |
| Cancel blocked receiver, await Cancelled, then send | No stale consumption |
| Receive commits before cancellation | Message stays consumed; commit is retained |
| Full channel then receive | Oldest queued value returned; earliest blocked sender admitted |
| Close with buffered data and blocked senders | Senders Closed; data drains; receivers eventually End |
| Equal timer deadlines | All due tasks become runnable at the same virtual time |
| Resource body traps or cancels | Exactly one release after nested children finish |
| No runnable tasks and no timers | Deadlock with wait graph |
| Missing or extra replay choice | ReplayDiverged |
| Budget ends during cleanup | Unknown/incomplete, not successful cleanup |

Fixtures MUST have hand-derived expected observations and versioned IDs. Add generated type-correct programs and exhaustive small domains after these pass.

## 16 Mandatory mutants

The evaluator must kill mutations that reverse operand order, skip a handler, resume twice, lose or duplicate a queued value, keep a cancelled waiter, forget a child join, fail to release a resource, release twice, read host time, ignore a replay-domain mismatch, fabricate successful termination, or turn an unknown result into pass. A killed mutant means a correctly classified discrepancy with a retained reproducer, not merely a crashed harness.

At least one intentionally equivalent mutation must remain accepted so the mutation system is not simply rejecting all candidates. Mutation coverage is reported by rule ID, with surviving non-equivalent mutants blocking the relevant gate.

## 17 Shen reference implementation guidance

Represent constructors explicitly; keep maps canonically ordered; use integer arithmetic with explicit range checks; implement scheduler and continuation stacks as data. The semantic transition kernel MUST not read wall time, entropy, files, sockets or host thread identity. Its wrapper handles serialization and transport.

Shen types can express valid state construction and transition interfaces; Prolog may express admissibility or search. Search order is not semantic truth. Termination and completeness require explicit bounds. The imperative host wrapper must not decide which abstract outcomes are legal.

Run the same canonical fixtures through at least two Shen ports before promoting portability claims. Port agreement is useful evidence, not proof of the model. Preserve an independent executable fixture evaluator for canonical encoding and simple arithmetic cases.

## 18 Freeze criteria

TC0 is frozen only when the artifact schema, step/frame catalog, effect checker, reference interpreter, hand fixtures, mutant catalog, decision protocol, and verdict encoder agree and have no unresolved semantic ambiguity. No performance optimization may alter the oracle in its own implementation change.

Future core versions may add user exceptions, general handlers, polymorphism, rendezvous channels, shared memory, storage and real I/O. Each needs new semantic rules, generator support, replay compatibility rules, and independent evaluator tests before native implementation is accepted.
