#include <sys/uio.h>
#include <unistd.h>
#include <errno.h>
#include <stdlib.h>
static size_t cap;
static int interrupted;
static ssize_t short_send(int fd, const struct iovec *parts, int count) {
    if (!interrupted++) { errno = EINTR; return -1; }
    if (count != 2) return -1;
    struct iovec v[2] = {parts[0], parts[1]};
    if (cap < v[0].iov_len) { v[0].iov_len = cap; return writev(fd, v, 1); }
    v[1].iov_len = cap - v[0].iov_len;
    return writev(fd, v, 2);
}
#define writev short_send
#include "guest-client.c"
int main(int argc, char **argv) {
    if (argc != 2) return 1;
    cap = strtoul(argv[1], NULL, 10);
    struct {fen_object obj; unsigned char data[8192];} head = {0};
    head.obj.fields[0] = sizeof head.data;
    for (size_t i=0; i<sizeof head.data; i++) head.data[i] = (unsigned char)i;
    fen_object arg = {.fields = {(uintptr_t)&head.obj, 1}};
    outcome r = http_response(&arg);
    return r.status || r.result->fields[0] != 123;
}
