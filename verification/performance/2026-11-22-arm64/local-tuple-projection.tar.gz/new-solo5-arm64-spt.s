.text
.p2align 2
.globl fenrir_entry
fenrir_entry:
  .long 0x910003e9
  .long 0xf81f0fe0
  .long 0xf81f0ffe
  .long 0xf9400be0
  .long 0xf81f0fe0
  .long 0xd2800040
  .long 0xf2a00000
  .long 0xf2c00000
  .long 0xf2e00000
  .long 0xf81f0fe0
  .long 0xf9400be0
  .long 0xf81f0fe0
  .long 0xf9400be0
  .long 0xf81f0fe0
  .long 0xf9400be0
  .long 0xf81f0fe0
  .long 0xf9400be0
  .long 0xf84107e1
  .long 0xeb000020
  .long 0x54000087
  .long 0x9100013f
  .long 0xd2800021
b Lreport10
  .long 0x910043ff
  .long 0x910043ff
  .long 0x910043ff
  .long 0x910043ff
  .long 0xf81f0fe0
  .long 0xd2800120
  .long 0xf2a00000
  .long 0xf2c00000
  .long 0xf2e00000
  .long 0xf81f0fe0
  .long 0xf9401be0
  .long 0xf81f0fe0
  .long 0xf9400be0
  .long 0xf81f0fe0
  .long 0xf9400be0
  .long 0xf81f0fe0
  .long 0xf9400be0
  .long 0xf81f0fe0
  .long 0xf9400be0
  .long 0xf84107e1
  .long 0xeb000020
  .long 0x54000087
  .long 0x9100013f
  .long 0xd2800021
b Lreport10
  .long 0x910043ff
  .long 0x910043ff
  .long 0x910043ff
  .long 0x910043ff
  .long 0xf81f0fe0
  .long 0xf9400be0
  .long 0xf81f0fe0
  .long 0xf9400be0
  .long 0xf81f0fe0
  .long 0xf9400be0
  .long 0xf81f0fe0
  .long 0xf9400be0
  .long 0xf84107e1
  .long 0xeb000020
  .long 0x54000087
  .long 0x9100013f
  .long 0xd2800021
b Lreport10
  .long 0x910043ff
  .long 0x910043ff
  .long 0x910043ff
  .long 0x910043ff
  .long 0x9100013f
  .long 0xd2800001
  .long 0xd65f03c0
.p2align 2
Lreport10:
stp x1, x30, [sp, #-16]!
adrp x0, Lposition10
add x0, x0, :lo12:Lposition10
bl fen_set_location
ldp x1, x30, [sp], #16
ret
Lposition10:
.byte 116,114,97,112,32,97,116,58,32,104,101,108,112,101,114,46,102,101,110,58,51,58,49,48,10,0
.p2align 2
.text
.globl fen_print_result
fen_print_result:
b Lprint0
Lprint0:
b fen_write_i64
