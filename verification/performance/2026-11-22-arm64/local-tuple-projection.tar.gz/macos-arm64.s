.text
.p2align 2
.globl _fenrir_entry
_fenrir_entry:
Lfn0:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #112
stp xzr, xzr, [sp, #48]
str x0, [sp, #64]
add x0, sp, #16
add x1, sp, #48
mov x2, #2
bl _fen_enter
ldr x0, [sp, #64]
cmp x0, #0
b.ge Lfn0if4else
movz x0, #1, lsl #0
str x0, [sp, #72]
mov x0, #0
mov x1, #0
bl _fen_allocate_full
cbz x0, Lfn0fail8_3
ldr x2, [sp, #64]
ldr x3, [sp, #72]
stp x2, x3, [x0, #0]
str x0, [sp, #48]
b Lfn0if4done
Lfn0if4else:
movz x0, #2, lsl #0
str x0, [sp, #80]
mov x0, #0
mov x1, #0
bl _fen_allocate_full
cbz x0, Lfn0fail11_3
ldr x2, [sp, #80]
ldr x3, [sp, #64]
stp x2, x3, [x0, #0]
str x0, [sp, #48]
Lfn0if4done:
str x0, [sp, #56]
ldr x0, [x0, #0]
str x0, [sp, #88]
ldr x0, [sp, #56]
ldr x0, [x0, #8]
str x0, [sp, #96]
ldr x0, [sp, #88]
ldr x2, [sp, #96]
adds x0, x0, x2
b.vs Lfn0fail14_1
mov x1, #0
b Lfn0end
Lfn0fail8_3:
adrp x0, Lfn0fail8_3location@PAGE
add x0, x0, Lfn0fail8_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn0end
Lfn0fail11_3:
adrp x0, Lfn0fail11_3location@PAGE
add x0, x0, Lfn0fail11_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn0end
Lfn0fail14_1:
adrp x0, Lfn0fail14_1location@PAGE
add x0, x0, Lfn0fail14_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn0end
Lfn0end:
bl _fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
.text
.globl _fen_print_result
_fen_print_result:
b Lprint0
Lprint0:
b _fen_write_i64
Lfn0fail8_3location:
.byte 116,114,97,112,32,97,116,58,32,108,111,99,97,108,46,102,101,110,58,50,58,51,48,10,0
Lfn0fail11_3location:
.byte 116,114,97,112,32,97,116,58,32,108,111,99,97,108,46,102,101,110,58,50,58,52,50,10,0
Lfn0fail14_1location:
.byte 116,114,97,112,32,97,116,58,32,108,111,99,97,108,46,102,101,110,58,51,58,49,48,10,0
