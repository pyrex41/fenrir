.text
.p2align 2
Lfn0:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
str x0, [sp, #48]
ldr x0, [sp, #48]
cmp x0, #0
b.ne Lfn0if2else
adrp x0, Lconstant0
add x0, x0, :lo12:Lconstant0
b Lfn0if2done
Lfn0if2else:
mov x0, #0
mov x1, #0
bl fen_allocate
cbz x0, Lfn0fail11_3
adr x2, Llambda11
str x2, [x0]
ldr x2, [sp, #48]
str x2, [x0, #8]
Lfn0if2done:
mov x1, #0
b Lfn0end
Lfn0fail11_3:
adrp x0, Lfn0fail11_3location
add x0, x0, :lo12:Lfn0fail11_3location
bl fen_set_location
mov x1, #3
b Lfn0end
Lfn0end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
.globl fenrir_entry
fenrir_entry:
Lfn1:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #80
stp xzr, xzr, [sp, #48]
str xzr, [sp, #64]
str x0, [sp, #72]
add x0, sp, #16
add x1, sp, #48
mov x2, #3
bl fen_enter
movz x0, #0, lsl #0
bl Lfn0
cbnz x1, Lfn1end
str x0, [sp, #48]
ldr x0, [sp, #72]
adds x0, x0, #10
b.vs Lfn1fail25_1
bl Lfn0
cbnz x1, Lfn1end
str x0, [sp, #56]
ldr x0, [sp, #72]
adds x0, x0, #30
b.vs Lfn1fail31_1
bl Lfn0
cbnz x1, Lfn1end
str x0, [sp, #64]
movz x0, #0, lsl #0
ldr x1, [sp, #64]
ldr x2, [x1]
blr x2
cbnz x1, Lfn1end
ldr x1, [sp, #56]
ldr x2, [x1]
blr x2
cbnz x1, Lfn1end
ldr x1, [sp, #48]
bl fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ldr x2, [x1]
br x2
mov x1, #0
b Lfn1end
Lfn1fail25_1:
adrp x0, Lfn1fail25_1location
add x0, x0, :lo12:Lfn1fail25_1location
bl fen_set_location
mov x1, #1
b Lfn1end
Lfn1fail31_1:
adrp x0, Lfn1fail31_1location
add x0, x0, :lo12:Lfn1fail31_1location
bl fen_set_location
mov x1, #1
b Lfn1end
Lfn1end:
bl fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
Llambda6:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
str x0, [sp, #48]
ldr x0, [sp, #48]
adds x0, x0, #2
b.vs Llambda6fail8_1
mov x1, #0
b Llambda6end
Llambda6fail8_1:
adrp x0, Llambda6fail8_1location
add x0, x0, :lo12:Llambda6fail8_1location
bl fen_set_location
mov x1, #1
b Llambda6end
Llambda6end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Llambda11:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
ldr x2, [x1, #8]
str x2, [sp, #56]
str x0, [sp, #48]
ldr x0, [sp, #48]
ldr x2, [sp, #56]
adds x0, x0, x2
b.vs Llambda11fail13_1
mov x1, #0
b Llambda11end
Llambda11fail13_1:
adrp x0, Llambda11fail13_1location
add x0, x0, :lo12:Llambda11fail13_1location
bl fen_set_location
mov x1, #1
b Llambda11end
Llambda11end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
.text
.globl fen_print_result
fen_print_result:
b Lprint0
Lprint0:
b fen_write_i64
.section .rodata
.p2align 3
Lconstant0:
.quad Llambda6
.zero 64
.long 0
.byte 0,2,0,0
.text
Lfn0fail11_3location:
.byte 116,114,97,112,32,97,116,58,32,99,108,111,115,117,114,101,115,46,102,101,110,58,53,58,49,53,10,0
Lfn1fail25_1location:
.byte 116,114,97,112,32,97,116,58,32,99,108,111,115,117,114,101,115,46,102,101,110,58,57,58,51,52,10,0
Lfn1fail31_1location:
.byte 116,114,97,112,32,97,116,58,32,99,108,111,115,117,114,101,115,46,102,101,110,58,49,48,58,51,53,10,0
Llambda6fail8_1location:
.byte 116,114,97,112,32,97,116,58,32,99,108,111,115,117,114,101,115,46,102,101,110,58,52,58,51,51,10,0
Llambda11fail13_1location:
.byte 116,114,97,112,32,97,116,58,32,99,108,111,115,117,114,101,115,46,102,101,110,58,53,58,51,51,10,0
