import hashlib
import json
import tarfile
from pathlib import Path
import sys

root = Path(sys.argv[1])
apps = root / "apps"
report = json.loads((apps / "summary.json").read_text())
assert report["package"] == (root / "identity").read_text().strip()
for name, expected in report["files"].items():
    assert hashlib.sha256((apps / name).read_bytes()).hexdigest() == expected, name
with tarfile.open(sys.argv[2], 'w:gz') as archive:
    for name in ["identity", "source.sha256", "apps.log", "verify-apps.py"]:
        archive.add(root / name, arcname=name)
    for name in ("summary.json", *report["files"]):
        archive.add(apps / name, arcname="apps/" + name)
    for target in ("mac","spt"):
        log = apps / f"recovery-{target}.log"
        folder, = [Path(line.split(": ", 1)[1]) for line in log.read_text().splitlines()
                   if line.startswith("Recovery evidence: ")]
        history = folder / "history.json"
        assert report["recovery"][target]["history_sha256"] == hashlib.sha256(history.read_bytes()).hexdigest()
        archive.add(history, arcname=f"apps/{target}/history.json")
        archive.add(folder / "check/verdicts.jsonl", arcname=f"apps/{target}/verdicts.jsonl")
        archive.add(log, arcname="apps/" + log.name)
print(len(report["files"]), "file hashes and both history hashes verified")
