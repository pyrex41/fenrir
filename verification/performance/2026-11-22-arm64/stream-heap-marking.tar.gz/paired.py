from pathlib import Path
import hashlib,json,random,re,statistics,subprocess
d=Path(__file__).resolve().parent
old=json.loads((d.parents[1]/'build/scalar-compiler-noL4ZVcU/solo5-arm64-spt/stream/report.json').read_text())
assert hashlib.sha256((d/'corpus').read_bytes()).hexdigest()==old['input_sha256']
report={}
for mode in ['t','p']:
 suffix='-profile' if mode=='p' else ''
 orders=[['baseline','fenrir'] if i%2==0 else ['fenrir','baseline'] for i in range(81)]
 cmd=['docker','run','--rm','--platform','linux/arm64','--network','none','-v',f'{d}:/b:ro','--entrypoint','sh',old['container'],'-ec','cp /b/corpus /tmp/input; flag=$1; shift; for img do /opt/solo5-install/bin/solo5-spt --block:input=/tmp/input "/b/$img.spt" --solo5:quiet "$flag"; done','sh',mode+str((d/'corpus').stat().st_size),*(n+suffix for pair in orders for n in pair)]
 data=subprocess.check_output(cmd,timeout=180)
 (d/(mode+'.txt')).write_bytes(data)
 samples=[]
 lines=iter(data.splitlines(keepends=True))
 for pair in orders:
  row={}
  for name in pair:
   summary=b''.join(next(lines) for _ in range(64))
   assert hashlib.sha256(summary).hexdigest()==old['expected_output_sha256']
   values={}
   for field in (['allocations','collections','collection_ns','read_ns','write_ns','first_output_ns','elapsed_ns'] if mode=='p' else ['elapsed_ns']):
    k,v=next(lines).decode().split()
    assert k==field
    values[k]=int(v)
   row[name]=values
  samples.append(row)
 assert next(lines,None) is None
 result={}
 for key in samples[0]['fenrir']:
  ratios=[s['fenrir'][key]/s['baseline'][key] for s in samples[1:]]
  rng=random.Random(1147)
  boot=sorted(statistics.median(rng.choices(ratios,k=len(ratios))) for _ in range(10000))
  result[key]=[statistics.median(ratios),boot[249],boot[9749]]
 report[mode]=dict(samples=samples,orders=orders,ratio_median_and_ci95=result)
 print(mode,result)
(d/'paired.json').write_text(json.dumps(report))
