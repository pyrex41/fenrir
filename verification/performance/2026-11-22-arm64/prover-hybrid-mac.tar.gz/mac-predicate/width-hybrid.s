.text
.p2align 2
Lfn0:
ldp x8, x9, [x0, #0]
Lfn0fields:
ldr w2, [x8, #72]
cmp w2, #10
b.ne Lfn0frame
mov x0, x9
mov x1, #0
ret
Lfn0frame:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #80
stp xzr, xzr, [sp, #64]
stp x8, x9, [sp, #48]
add x0, sp, #16
add x1, sp, #48
mov x2, #4
bl _fen_enter
Lfn0loop:
ldr x0, [sp, #48]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn0match10arm10
cmp w0, #11
b.eq Lfn0match10arm11
brk #0
Lfn0match10arm10:
ldr x0, [sp, #56]
b Lfn0match10end
Lfn0match10arm11:
ldr x0, [sp, #48]
ldr x0, [x0, #16]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn0match16arm10
cmp w0, #11
b.eq Lfn0match16arm11
brk #0
Lfn0match16arm10:
mov x0, #6
mov x1, #11
bl _fen_allocate
cbz x0, Lfn0fail18_3
ldr x4, [sp, #48]
ldp x2, x3, [x4, #0]
stp x2, x3, [x0, #0]
ldr x2, [sp, #56]
str x2, [x0, #16]
b Lfn0match16end
Lfn0match16arm11:
ldr x8, [sp, #48]
ldr x8, [x8, #16]
ldr x8, [x8, #16]
ldr x9, [sp, #56]
bl Lfn0fields
cbnz x1, Lfn0end
str x0, [sp, #64]
mov x0, #6
mov x1, #11
bl _fen_allocate
cbz x0, Lfn0fail28_3
ldr x4, [sp, #48]
ldr x4, [x4, #16]
ldp x2, x3, [x4, #0]
stp x2, x3, [x0, #0]
ldr x2, [sp, #64]
str x2, [x0, #16]
str x0, [sp, #72]
mov x0, #6
mov x1, #11
bl _fen_allocate
cbz x0, Lfn0fail25_3
ldr x4, [sp, #48]
ldp x2, x3, [x4, #0]
stp x2, x3, [x0, #0]
ldr x2, [sp, #72]
str x2, [x0, #16]
b Lfn0match16end
Lfn0match16end:
b Lfn0match10end
Lfn0match10end:
mov x1, #0
b Lfn0end
Lfn0fail18_3:
adrp x0, Lfn0fail18_3location@PAGE
add x0, x0, Lfn0fail18_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn0end
Lfn0fail28_3:
adrp x0, Lfn0fail28_3location@PAGE
add x0, x0, Lfn0fail28_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn0end
Lfn0fail25_3:
adrp x0, Lfn0fail25_3location@PAGE
add x0, x0, Lfn0fail25_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn0end
Lfn0end:
bl _fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn1:
ldp x8, x9, [x0, #0]
ldr x10, [x0, #16]
Lfn1fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #80
str xzr, [sp, #64]
str x8, [sp, #48]
str x9, [sp, #72]
str x10, [sp, #56]
add x0, sp, #16
add x1, sp, #48
mov x2, #3
bl _fen_enter
Lfn1loop:
mov x0, #6
mov x1, #11
bl _fen_allocate
cbz x0, Lfn1fail52_3
ldr x2, [sp, #72]
ldr x3, [sp, #56]
stp x2, x3, [x0, #0]
adrp x2, Lconstant0@PAGE
add x2, x2, Lconstant0@PAGEOFF
str x2, [x0, #16]
str x0, [sp, #64]
bl _fen_leave_result
ldr x8, [sp, #48]
ldr x9, [sp, #64]
mov sp, x29
ldp x29, x30, [sp], #16
b Lfn0fields
mov x1, #0
b Lfn1end
Lfn1fail52_3:
adrp x0, Lfn1fail52_3location@PAGE
add x0, x0, Lfn1fail52_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn1end
Lfn1end:
bl _fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn2:
ldp x8, x9, [x0, #0]
Lfn2fields:
tbnz x8, #63, Lfn2arithmetic
cmp x9, #0
b.le Lfn2arithmetic
sub x2, x9, #1
tst x2, x9
b.ne Lfn2arithmetic
tst x8, x9
cset x0, ne
mov x1, #0
ret
Lfn2arithmetic:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
stp x8, x9, [sp, #48]
Lfn2loop:
ldr x0, [sp, #48]
ldr x2, [sp, #56]
cmp x0, x2
b.ge Lfn2if66else
movz x0, #0, lsl #0
b Lfn2if66done
Lfn2if66else:
ldr x0, [sp, #48]
ldr x2, [sp, #56]
cbz x2, Lfn2fail73_2
cmn x2, #1
b.ne 1f
negs x3, x0
b.vs Lfn2fail73_1
1:
sdiv x0, x0, x2
cmp x0, #0
neg x2, x0
and x2, x2, #1
and x0, x0, #1
csneg x0, x0, x2, ge
cmp x0, #1
cset x0, eq
Lfn2if66done:
mov x1, #0
b Lfn2end
Lfn2fail73_2:
adrp x0, Lfn2fail73_2location@PAGE
add x0, x0, Lfn2fail73_2location@PAGEOFF
bl _fen_set_location
mov x1, #2
b Lfn2end
Lfn2fail73_1:
adrp x0, Lfn2fail73_1location@PAGE
add x0, x0, Lfn2fail73_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn2end
Lfn2end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn3:
ldp x8, x9, [x0, #0]
Lfn3fields:
tbnz x8, #63, Lfn3arithmetic
cmp x9, #0
b.le Lfn3arithmetic
sub x2, x9, #1
tst x2, x9
b.ne Lfn3arithmetic
orr x0, x8, x9
mov x1, #0
ret
Lfn3arithmetic:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
stp x8, x9, [sp, #48]
Lfn3loop:
ldr x0, [sp, #48]
ldr x2, [sp, #56]
cmp x0, x2
b.ge Lfn3if95else
ldr x0, [sp, #48]
ldr x2, [sp, #56]
adds x0, x0, x2
b.vs Lfn3fail99_1
b Lfn3if95done
Lfn3if95else:
ldr x8, [sp, #48]
ldr x9, [sp, #56]
bl Lfn2fields
cbnz x1, Lfn3end
cbz x0, Lfn3if102else
ldr x0, [sp, #48]
b Lfn3if102done
Lfn3if102else:
ldr x0, [sp, #48]
ldr x2, [sp, #56]
adds x0, x0, x2
b.vs Lfn3fail108_1
Lfn3if102done:
Lfn3if95done:
mov x1, #0
b Lfn3end
Lfn3fail99_1:
adrp x0, Lfn3fail99_1location@PAGE
add x0, x0, Lfn3fail99_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn3end
Lfn3fail108_1:
adrp x0, Lfn3fail108_1location@PAGE
add x0, x0, Lfn3fail108_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn3end
Lfn3end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn4:
ldp x8, x9, [x0, #0]
Lfn4fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
stp x19, xzr, [sp, #-16]!
sub sp, sp, #96
stp xzr, xzr, [sp, #56]
str xzr, [sp, #72]
mov x19, x8
str x9, [sp, #48]
add x0, sp, #16
add x1, sp, #48
mov x2, #4
bl _fen_enter
Lfn4loop:
mov x0, x19
cmp x0, #8
b.lt Lfn4if121else
mov x0, x19
subs x0, x0, #8
b.vs Lfn4fail127_1
str x0, [sp, #80]
adrp x0, Lconstant1@PAGE
add x0, x0, Lconstant1@PAGEOFF
ldr x2, [sp, #48]
mov x1, x2
bl _fen_bytes_concat
cbz x0, Lfn4fail130_3
str x0, [sp, #56]
ldr x8, [sp, #80]
ldr x9, [sp, #56]
mov x19, x8
str x9, [sp, #48]
stp xzr, xzr, [sp, #56]
str xzr, [sp, #72]
b Lfn4loop
b Lfn4if121done
Lfn4if121else:
mov x0, x19
cmp x0, #0
b.ne Lfn4if133else
ldr x0, [sp, #48]
b Lfn4if133done
Lfn4if133else:
mov x0, x19
cmp x0, #4
b.ge Lfn4if139else
mov x0, x19
cmp x0, #2
b.ge Lfn4if143else
adrp x0, Lconstant2@PAGE
add x0, x0, Lconstant2@PAGEOFF
b Lfn4if143done
Lfn4if143else:
mov x0, x19
cmp x0, #2
b.ne Lfn4if148else
adrp x0, Lconstant3@PAGE
add x0, x0, Lconstant3@PAGEOFF
b Lfn4if148done
Lfn4if148else:
adrp x0, Lconstant4@PAGE
add x0, x0, Lconstant4@PAGEOFF
Lfn4if148done:
str x0, [sp, #56]
Lfn4if143done:
str x0, [sp, #64]
b Lfn4if139done
Lfn4if139else:
mov x0, x19
cmp x0, #6
b.ge Lfn4if154else
mov x0, x19
cmp x0, #4
b.ne Lfn4if158else
adrp x0, Lconstant5@PAGE
add x0, x0, Lconstant5@PAGEOFF
b Lfn4if158done
Lfn4if158else:
adrp x0, Lconstant6@PAGE
add x0, x0, Lconstant6@PAGEOFF
Lfn4if158done:
str x0, [sp, #56]
b Lfn4if154done
Lfn4if154else:
mov x0, x19
cmp x0, #6
b.ne Lfn4if164else
adrp x0, Lconstant7@PAGE
add x0, x0, Lconstant7@PAGEOFF
b Lfn4if164done
Lfn4if164else:
adrp x0, Lconstant8@PAGE
add x0, x0, Lconstant8@PAGEOFF
Lfn4if164done:
str x0, [sp, #56]
Lfn4if154done:
str x0, [sp, #64]
Lfn4if139done:
str x0, [sp, #72]
ldr x2, [sp, #48]
mov x1, x2
bl _fen_bytes_concat
cbz x0, Lfn4fail138_3
Lfn4if133done:
Lfn4if121done:
mov x1, #0
b Lfn4end
Lfn4fail127_1:
adrp x0, Lfn4fail127_1location@PAGE
add x0, x0, Lfn4fail127_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn4end
Lfn4fail130_3:
adrp x0, Lfn4fail130_3location@PAGE
add x0, x0, Lfn4fail130_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn4end
Lfn4fail138_3:
adrp x0, Lfn4fail138_3location@PAGE
add x0, x0, Lfn4fail138_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn4end
Lfn4end:
bl _fen_leave_result
ldp x19, xzr, [x29, #-16]
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn5:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
str x0, [sp, #48]
ldr x0, [sp, #48]
cmp x0, #8
b.lt Lfn5if173else
ldr x0, [sp, #48]
subs x0, x0, #8
b.vs Lfn5fail179_1
str x0, [sp, #56]
ldr x8, [sp, #56]
adrp x9, Lconstant9@PAGE
add x9, x9, Lconstant9@PAGEOFF
mov sp, x29
ldp x29, x30, [sp], #16
b Lfn4fields
b Lfn5if173done
Lfn5if173else:
ldr x0, [sp, #48]
cmp x0, #4
b.ge Lfn5if183else
ldr x0, [sp, #48]
cmp x0, #2
b.ge Lfn5if187else
ldr x0, [sp, #48]
cmp x0, #1
b.ge Lfn5if191else
adrp x0, Lconstant10@PAGE
add x0, x0, Lconstant10@PAGEOFF
b Lfn5if191done
Lfn5if191else:
adrp x0, Lconstant11@PAGE
add x0, x0, Lconstant11@PAGEOFF
Lfn5if191done:
b Lfn5if187done
Lfn5if187else:
ldr x0, [sp, #48]
cmp x0, #3
b.ge Lfn5if197else
adrp x0, Lconstant12@PAGE
add x0, x0, Lconstant12@PAGEOFF
b Lfn5if197done
Lfn5if197else:
adrp x0, Lconstant13@PAGE
add x0, x0, Lconstant13@PAGEOFF
Lfn5if197done:
Lfn5if187done:
b Lfn5if183done
Lfn5if183else:
ldr x0, [sp, #48]
cmp x0, #6
b.ge Lfn5if203else
ldr x0, [sp, #48]
cmp x0, #5
b.ge Lfn5if207else
adrp x0, Lconstant14@PAGE
add x0, x0, Lconstant14@PAGEOFF
b Lfn5if207done
Lfn5if207else:
adrp x0, Lconstant15@PAGE
add x0, x0, Lconstant15@PAGEOFF
Lfn5if207done:
b Lfn5if203done
Lfn5if203else:
ldr x0, [sp, #48]
cmp x0, #7
b.ge Lfn5if213else
adrp x0, Lconstant16@PAGE
add x0, x0, Lconstant16@PAGEOFF
b Lfn5if213done
Lfn5if213else:
adrp x0, Lconstant17@PAGE
add x0, x0, Lconstant17@PAGEOFF
Lfn5if213done:
Lfn5if203done:
Lfn5if183done:
Lfn5if173done:
mov x1, #0
b Lfn5end
Lfn5fail179_1:
adrp x0, Lfn5fail179_1location@PAGE
add x0, x0, Lfn5fail179_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn5end
Lfn5end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn6:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
str x0, [sp, #48]
ldr x0, [sp, #48]
cmp x0, #8
b.lt Lfn6if221else
ldr x0, [sp, #48]
subs x0, x0, #8
b.vs Lfn6fail227_1
str x0, [sp, #56]
ldr x8, [sp, #56]
adrp x9, Lconstant18@PAGE
add x9, x9, Lconstant18@PAGEOFF
mov sp, x29
ldp x29, x30, [sp], #16
b Lfn4fields
b Lfn6if221done
Lfn6if221else:
ldr x0, [sp, #48]
cmp x0, #4
b.ge Lfn6if231else
ldr x0, [sp, #48]
cmp x0, #2
b.ge Lfn6if235else
ldr x0, [sp, #48]
cmp x0, #1
b.ge Lfn6if239else
adrp x0, Lconstant19@PAGE
add x0, x0, Lconstant19@PAGEOFF
b Lfn6if239done
Lfn6if239else:
adrp x0, Lconstant20@PAGE
add x0, x0, Lconstant20@PAGEOFF
Lfn6if239done:
b Lfn6if235done
Lfn6if235else:
ldr x0, [sp, #48]
cmp x0, #3
b.ge Lfn6if245else
adrp x0, Lconstant21@PAGE
add x0, x0, Lconstant21@PAGEOFF
b Lfn6if245done
Lfn6if245else:
adrp x0, Lconstant22@PAGE
add x0, x0, Lconstant22@PAGEOFF
Lfn6if245done:
Lfn6if235done:
b Lfn6if231done
Lfn6if231else:
ldr x0, [sp, #48]
cmp x0, #6
b.ge Lfn6if251else
ldr x0, [sp, #48]
cmp x0, #5
b.ge Lfn6if255else
adrp x0, Lconstant23@PAGE
add x0, x0, Lconstant23@PAGEOFF
b Lfn6if255done
Lfn6if255else:
adrp x0, Lconstant24@PAGE
add x0, x0, Lconstant24@PAGEOFF
Lfn6if255done:
b Lfn6if251done
Lfn6if251else:
ldr x0, [sp, #48]
cmp x0, #7
b.ge Lfn6if261else
adrp x0, Lconstant25@PAGE
add x0, x0, Lconstant25@PAGEOFF
b Lfn6if261done
Lfn6if261else:
adrp x0, Lconstant26@PAGE
add x0, x0, Lconstant26@PAGEOFF
Lfn6if261done:
Lfn6if251done:
Lfn6if231done:
Lfn6if221done:
mov x1, #0
b Lfn6end
Lfn6fail227_1:
adrp x0, Lfn6fail227_1location@PAGE
add x0, x0, Lfn6fail227_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn6end
Lfn6end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn7:
ldp x8, x9, [x0, #0]
Lfn7fields:
ldr w2, [x8, #72]
cmp w2, #10
b.ne Lfn7frame
mov x0, x9
mov x1, #0
ret
Lfn7frame:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #80
str xzr, [sp, #64]
stp x8, x9, [sp, #48]
add x0, sp, #16
add x1, sp, #48
mov x2, #3
bl _fen_enter
Lfn7loop:
ldr x0, [sp, #48]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn7match277arm10
cmp w0, #11
b.eq Lfn7match277arm11
brk #0
Lfn7match277arm10:
ldr x0, [sp, #56]
b Lfn7match277end
Lfn7match277arm11:
mov x0, #6
mov x1, #11
bl _fen_allocate
cbz x0, Lfn7fail286_3
ldr x4, [sp, #48]
ldp x2, x3, [x4, #0]
stp x2, x3, [x0, #0]
ldr x2, [sp, #56]
str x2, [x0, #16]
str x0, [sp, #64]
ldr x8, [sp, #48]
ldr x8, [x8, #16]
ldr x9, [sp, #64]
str x8, [sp, #48]
str x9, [sp, #56]
str xzr, [sp, #64]
b Lfn7loop
b Lfn7match277end
Lfn7match277end:
mov x1, #0
b Lfn7end
Lfn7fail286_3:
adrp x0, Lfn7fail286_3location@PAGE
add x0, x0, Lfn7fail286_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn7end
Lfn7end:
bl _fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn8:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
str xzr, [sp, #56]
str x0, [sp, #48]
add x0, sp, #16
add x1, sp, #48
mov x2, #2
bl _fen_enter
ldr x0, [sp, #48]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn8match292arm10
cmp w0, #11
b.eq Lfn8match292arm11
brk #0
Lfn8match292arm10:
adrp x0, Lconstant0@PAGE
add x0, x0, Lconstant0@PAGEOFF
b Lfn8match292end
Lfn8match292arm11:
ldr x0, [sp, #48]
ldr x0, [x0, #16]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn8match298arm10
cmp w0, #11
b.eq Lfn8match298arm11
brk #0
Lfn8match298arm10:
ldr x0, [sp, #48]
b Lfn8match298end
Lfn8match298arm11:
mov x0, #6
mov x1, #11
bl _fen_allocate
cbz x0, Lfn8fail307_3
ldr x4, [sp, #48]
ldp x2, x3, [x4, #0]
stp x2, x3, [x0, #0]
adrp x2, Lconstant0@PAGE
add x2, x2, Lconstant0@PAGEOFF
str x2, [x0, #16]
str x0, [sp, #56]
bl _fen_leave_result
ldr x8, [sp, #48]
ldr x8, [x8, #16]
ldr x9, [sp, #56]
mov sp, x29
ldp x29, x30, [sp], #16
b Lfn7fields
b Lfn8match298end
Lfn8match298end:
b Lfn8match292end
Lfn8match292end:
mov x1, #0
b Lfn8end
Lfn8fail307_3:
adrp x0, Lfn8fail307_3location@PAGE
add x0, x0, Lfn8fail307_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn8end
Lfn8end:
bl _fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn9:
ldp x8, x9, [x0, #0]
ldp x10, x11, [x0, #16]
ldp x12, x13, [x0, #32]
Lfn9fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
stp x19, x20, [sp, #-16]!
stp x21, x22, [sp, #-16]!
stp x23, x24, [sp, #-16]!
sub sp, sp, #272
stp xzr, xzr, [sp, #64]
stp xzr, xzr, [sp, #80]
stp xzr, xzr, [sp, #96]
stp xzr, xzr, [sp, #112]
stp xzr, xzr, [sp, #128]
str xzr, [sp, #144]
stp x8, x9, [sp, #48]
mov x21, x10
mov x23, x11
mov x22, x12
mov x19, x13
add x0, sp, #16
add x1, sp, #48
mov x2, #13
bl _fen_enter
Lfn9loop:
mov x0, x22
cmp x0, #0
b.ne Lfn9if337else
adrp x0, Lconstant27@PAGE
add x0, x0, Lconstant27@PAGEOFF
b Lfn9if337done
Lfn9if337else:
mov x0, x22
subs x0, x0, #1
b.vs Lfn9fail344_1
mov x20, x0
ldr x0, [sp, #48]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn9match347arm10
cmp w0, #11
b.eq Lfn9match347arm11
brk #0
Lfn9match347arm10:
ldr x0, [sp, #56]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn9match349arm10
cmp w0, #11
b.eq Lfn9match349arm11
brk #0
Lfn9match349arm10:
mov x0, #0
mov x1, #13
bl _fen_allocate
cbz x0, Lfn9fail351_3
mov x2, x21
mov x3, x20
stp x2, x3, [x0, #0]
b Lfn9match349end
Lfn9match349arm11:
ldr x0, [sp, #56]
bl Lfn8
cbnz x1, Lfn9end
str x0, [sp, #64]
ldr x8, [sp, #64]
adrp x9, Lconstant0@PAGE
add x9, x9, Lconstant0@PAGEOFF
str x8, [sp, #48]
str x9, [sp, #56]
stp xzr, xzr, [sp, #64]
stp xzr, xzr, [sp, #80]
stp xzr, xzr, [sp, #96]
stp xzr, xzr, [sp, #112]
stp xzr, xzr, [sp, #128]
str xzr, [sp, #144]
b Lfn9loop
b Lfn9match349end
Lfn9match349end:
b Lfn9match347end
Lfn9match347arm11:
ldr x0, [sp, #48]
ldr x0, [x0, #8]
ldr w0, [x0, #72]
cmp w0, #7
b.eq Lfn9match369arm7
cmp w0, #8
b.eq Lfn9match369arm8
cmp w0, #9
b.eq Lfn9match369arm9
brk #0
Lfn9match369arm7:
ldr x0, [sp, #48]
ldr x0, [x0, #0]
cbz x0, Lfn9if375else
mov x0, x23
b Lfn9if375done
Lfn9if375else:
mov x0, x21
Lfn9if375done:
str x0, [sp, #152]
ldr x8, [sp, #152]
ldr x9, [sp, #48]
ldr x9, [x9, #8]
ldr x9, [x9, #0]
bl Lfn2fields
cbnz x1, Lfn9end
cbz x0, Lfn9if372else
mov x0, x19
bl Lfn5
cbnz x1, Lfn9end
str x0, [sp, #64]
mov x0, #1
mov x1, #12
bl _fen_allocate
cbz x0, Lfn9fail380_3
ldr x2, [sp, #64]
mov x3, x20
stp x2, x3, [x0, #0]
b Lfn9if372done
Lfn9if372else:
ldr x0, [sp, #48]
ldr x0, [x0, #0]
cbz x0, Lfn9if388else
mov x8, x21
ldr x9, [sp, #48]
ldr x9, [x9, #8]
ldr x9, [x9, #0]
bl Lfn3fields
cbnz x1, Lfn9end
b Lfn9if388done
Lfn9if388else:
mov x0, x21
Lfn9if388done:
str x0, [sp, #160]
ldr x0, [sp, #48]
ldr x0, [x0, #0]
cbz x0, Lfn9if395else
mov x0, x23
b Lfn9if395done
Lfn9if395else:
mov x8, x23
ldr x9, [sp, #48]
ldr x9, [x9, #8]
ldr x9, [x9, #0]
bl Lfn3fields
cbnz x1, Lfn9end
Lfn9if395done:
str x0, [sp, #168]
mov x0, x19
adds x0, x0, #1
b.vs Lfn9fail403_1
str x0, [sp, #176]
ldr x8, [sp, #48]
ldr x8, [x8, #16]
ldr x9, [sp, #160]
ldr x10, [sp, #168]
mov x11, x20
ldr x12, [sp, #176]
str x8, [sp, #48]
mov x21, x9
mov x23, x10
mov x22, x11
mov x19, x12
stp xzr, xzr, [sp, #64]
stp xzr, xzr, [sp, #80]
stp xzr, xzr, [sp, #96]
stp xzr, xzr, [sp, #112]
stp xzr, xzr, [sp, #128]
str xzr, [sp, #144]
b Lfn9loop
Lfn9if372done:
b Lfn9match369end
Lfn9match369arm8:
ldr x0, [sp, #48]
ldr x0, [x0, #16]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn9match407arm10
cmp w0, #11
b.eq Lfn9match407arm11
brk #0
Lfn9match407arm10:
ldr x0, [sp, #56]
bl Lfn8
cbnz x1, Lfn9end
str x0, [sp, #64]
ldr x0, [sp, #48]
ldr x0, [x0, #0]
eor x0, x0, #1
str x0, [sp, #184]
mov x0, #6
mov x1, #11
bl _fen_allocate
cbz x0, Lfn9fail413_3
ldr x2, [sp, #184]
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #0]
stp x2, x3, [x0, #0]
adrp x2, Lconstant0@PAGE
add x2, x2, Lconstant0@PAGEOFF
str x2, [x0, #16]
str x0, [sp, #72]
mov x0, x19
adds x0, x0, #1
b.vs Lfn9fail421_1
str x0, [sp, #192]
ldr x8, [sp, #64]
ldr x9, [sp, #72]
mov x10, x20
ldr x11, [sp, #192]
str x8, [sp, #48]
str x9, [sp, #56]
mov x22, x10
mov x19, x11
stp xzr, xzr, [sp, #64]
stp xzr, xzr, [sp, #80]
stp xzr, xzr, [sp, #96]
stp xzr, xzr, [sp, #112]
stp xzr, xzr, [sp, #128]
str xzr, [sp, #144]
b Lfn9loop
b Lfn9match407end
Lfn9match407arm11:
ldr x0, [sp, #48]
ldr x0, [x0, #0]
eor x0, x0, #1
str x0, [sp, #200]
mov x0, #6
mov x1, #11
bl _fen_allocate
cbz x0, Lfn9fail430_3
ldr x2, [sp, #200]
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #0]
stp x2, x3, [x0, #0]
ldr x2, [sp, #56]
str x2, [x0, #16]
str x0, [sp, #64]
mov x0, x19
adds x0, x0, #1
b.vs Lfn9fail438_1
str x0, [sp, #208]
ldr x8, [sp, #48]
ldr x8, [x8, #16]
ldr x9, [sp, #64]
mov x10, x20
ldr x11, [sp, #208]
str x8, [sp, #48]
str x9, [sp, #56]
mov x22, x10
mov x19, x11
stp xzr, xzr, [sp, #64]
stp xzr, xzr, [sp, #80]
stp xzr, xzr, [sp, #96]
stp xzr, xzr, [sp, #112]
stp xzr, xzr, [sp, #128]
str xzr, [sp, #144]
b Lfn9loop
b Lfn9match407end
Lfn9match407end:
b Lfn9match369end
Lfn9match369arm9:
ldr x0, [sp, #48]
ldr x0, [x0, #8]
ldr x0, [x0, #0]
cmp x0, #2
b.ne Lfn9if446else
ldr x0, [sp, #48]
ldr x0, [x0, #0]
eor x0, x0, #1
b Lfn9if446done
Lfn9if446else:
ldr x0, [sp, #48]
ldr x0, [x0, #0]
Lfn9if446done:
mov x24, x0
ldr x0, [sp, #48]
ldr x0, [x0, #8]
ldr x0, [x0, #0]
cmp x0, #0
cset x0, eq
ldr x2, [sp, #48]
ldr x2, [x2, #0]
cmp x0, x2
b.ne Lfn9if453else
ldr x0, [sp, #48]
ldr x0, [x0, #16]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn9match459arm10
cmp w0, #11
b.eq Lfn9match459arm11
brk #0
Lfn9match459arm10:
ldr x0, [sp, #56]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn9match461arm10
cmp w0, #11
b.eq Lfn9match461arm11
brk #0
Lfn9match461arm10:
mov x0, #6
mov x1, #11
bl _fen_allocate
cbz x0, Lfn9fail468_3
ldr x2, [sp, #48]
ldr x2, [x2, #0]
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #16]
stp x2, x3, [x0, #0]
adrp x2, Lconstant0@PAGE
add x2, x2, Lconstant0@PAGEOFF
str x2, [x0, #16]
str x0, [sp, #64]
mov x0, #6
mov x1, #11
bl _fen_allocate
cbz x0, Lfn9fail465_3
mov x2, x24
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #8]
stp x2, x3, [x0, #0]
ldr x2, [sp, #64]
str x2, [x0, #16]
str x0, [sp, #72]
mov x0, x19
adds x0, x0, #1
b.vs Lfn9fail476_1
str x0, [sp, #216]
ldr x8, [sp, #72]
adrp x9, Lconstant0@PAGE
add x9, x9, Lconstant0@PAGEOFF
mov x10, x20
ldr x11, [sp, #216]
str x8, [sp, #48]
str x9, [sp, #56]
mov x22, x10
mov x19, x11
stp xzr, xzr, [sp, #64]
stp xzr, xzr, [sp, #80]
stp xzr, xzr, [sp, #96]
stp xzr, xzr, [sp, #112]
stp xzr, xzr, [sp, #128]
str xzr, [sp, #144]
b Lfn9loop
b Lfn9match461end
Lfn9match461arm11:
ldr x0, [sp, #56]
bl Lfn8
cbnz x1, Lfn9end
str x0, [sp, #64]
mov x0, #6
mov x1, #11
bl _fen_allocate
cbz x0, Lfn9fail489_3
mov x2, x24
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #8]
stp x2, x3, [x0, #0]
adrp x2, Lconstant0@PAGE
add x2, x2, Lconstant0@PAGEOFF
str x2, [x0, #16]
str x0, [sp, #72]
mov x0, #6
mov x1, #11
bl _fen_allocate
cbz x0, Lfn9fail486_3
ldr x2, [sp, #48]
ldr x2, [x2, #0]
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #16]
stp x2, x3, [x0, #0]
ldr x2, [sp, #72]
str x2, [x0, #16]
str x0, [sp, #80]
mov x0, x19
adds x0, x0, #1
b.vs Lfn9fail496_1
str x0, [sp, #224]
ldr x8, [sp, #64]
ldr x9, [sp, #80]
mov x10, x20
ldr x11, [sp, #224]
str x8, [sp, #48]
str x9, [sp, #56]
mov x22, x10
mov x19, x11
stp xzr, xzr, [sp, #64]
stp xzr, xzr, [sp, #80]
stp xzr, xzr, [sp, #96]
stp xzr, xzr, [sp, #112]
stp xzr, xzr, [sp, #128]
str xzr, [sp, #144]
b Lfn9loop
b Lfn9match461end
Lfn9match461end:
b Lfn9match459end
Lfn9match459arm11:
mov x0, #6
mov x1, #11
bl _fen_allocate
cbz x0, Lfn9fail508_3
mov x2, x24
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #8]
stp x2, x3, [x0, #0]
ldr x2, [sp, #56]
str x2, [x0, #16]
str x0, [sp, #64]
mov x0, #6
mov x1, #11
bl _fen_allocate
cbz x0, Lfn9fail505_3
ldr x2, [sp, #48]
ldr x2, [x2, #0]
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #16]
stp x2, x3, [x0, #0]
ldr x2, [sp, #64]
str x2, [x0, #16]
str x0, [sp, #72]
mov x0, x19
adds x0, x0, #1
b.vs Lfn9fail515_1
str x0, [sp, #232]
ldr x8, [sp, #48]
ldr x8, [x8, #16]
ldr x9, [sp, #72]
mov x10, x20
ldr x11, [sp, #232]
str x8, [sp, #48]
str x9, [sp, #56]
mov x22, x10
mov x19, x11
stp xzr, xzr, [sp, #64]
stp xzr, xzr, [sp, #80]
stp xzr, xzr, [sp, #96]
stp xzr, xzr, [sp, #112]
stp xzr, xzr, [sp, #128]
str xzr, [sp, #144]
b Lfn9loop
b Lfn9match459end
Lfn9match459end:
b Lfn9if453done
Lfn9if453else:
ldr x0, [sp, #48]
ldr x0, [x0, #16]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn9match520arm10
cmp w0, #11
b.eq Lfn9match520arm11
brk #0
Lfn9match520arm10:
ldr x0, [sp, #56]
bl Lfn8
cbnz x1, Lfn9end
str x0, [sp, #64]
mov x0, #6
mov x1, #11
bl _fen_allocate
cbz x0, Lfn9fail526_3
mov x2, x24
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #8]
stp x2, x3, [x0, #0]
adrp x2, Lconstant0@PAGE
add x2, x2, Lconstant0@PAGEOFF
str x2, [x0, #16]
str x0, [sp, #72]
movz x0, #0, lsl #0
str x0, [sp, #240]
ldr x8, [sp, #64]
ldr x9, [sp, #72]
mov x10, x21
mov x11, x23
mov x12, x20
ldr x13, [sp, #240]
bl Lfn9fields
cbnz x1, Lfn9end
str x0, [sp, #80]
b Lfn9match520end
Lfn9match520arm11:
mov x0, #6
mov x1, #11
bl _fen_allocate
cbz x0, Lfn9fail540_3
mov x2, x24
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #8]
stp x2, x3, [x0, #0]
ldr x2, [sp, #56]
str x2, [x0, #16]
str x0, [sp, #64]
movz x0, #0, lsl #0
str x0, [sp, #248]
ldr x8, [sp, #48]
ldr x8, [x8, #16]
ldr x9, [sp, #64]
mov x10, x21
mov x11, x23
mov x12, x20
ldr x13, [sp, #248]
bl Lfn9fields
cbnz x1, Lfn9end
str x0, [sp, #72]
b Lfn9match520end
Lfn9match520end:
str x0, [sp, #88]
ldr w0, [x0, #72]
cmp w0, #12
b.eq Lfn9match548arm12
cmp w0, #13
b.eq Lfn9match548arm13
cmp w0, #14
b.eq Lfn9match548arm14
brk #0
Lfn9match548arm12:
ldr x0, [sp, #48]
ldr x0, [x0, #16]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn9match554arm10
cmp w0, #11
b.eq Lfn9match554arm11
brk #0
Lfn9match554arm10:
ldr x0, [sp, #56]
bl Lfn8
cbnz x1, Lfn9end
str x0, [sp, #96]
mov x0, #6
mov x1, #11
bl _fen_allocate
cbz x0, Lfn9fail560_3
ldr x2, [sp, #48]
ldr x2, [x2, #0]
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #16]
stp x2, x3, [x0, #0]
adrp x2, Lconstant0@PAGE
add x2, x2, Lconstant0@PAGEOFF
str x2, [x0, #16]
str x0, [sp, #104]
movz x0, #0, lsl #0
str x0, [sp, #256]
ldr x8, [sp, #96]
ldr x9, [sp, #104]
mov x10, x21
mov x11, x23
ldr x12, [sp, #88]
ldr x12, [x12, #8]
ldr x13, [sp, #256]
bl Lfn9fields
cbnz x1, Lfn9end
str x0, [sp, #112]
b Lfn9match554end
Lfn9match554arm11:
mov x0, #6
mov x1, #11
bl _fen_allocate
cbz x0, Lfn9fail574_3
ldr x2, [sp, #48]
ldr x2, [x2, #0]
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #16]
stp x2, x3, [x0, #0]
ldr x2, [sp, #56]
str x2, [x0, #16]
str x0, [sp, #96]
movz x0, #0, lsl #0
str x0, [sp, #264]
ldr x8, [sp, #48]
ldr x8, [x8, #16]
ldr x9, [sp, #96]
mov x10, x21
mov x11, x23
ldr x12, [sp, #88]
ldr x12, [x12, #8]
ldr x13, [sp, #264]
bl Lfn9fields
cbnz x1, Lfn9end
str x0, [sp, #104]
b Lfn9match554end
Lfn9match554end:
str x0, [sp, #120]
ldr w0, [x0, #72]
cmp w0, #12
b.eq Lfn9match582arm12
cmp w0, #13
b.eq Lfn9match582arm13
cmp w0, #14
b.eq Lfn9match582arm14
brk #0
Lfn9match582arm12:
mov x0, x19
bl Lfn6
cbnz x1, Lfn9end
str x0, [sp, #128]
ldr x0, [sp, #88]
ldr x0, [x0, #0]
ldr x2, [sp, #120]
ldr x2, [x2, #0]
mov x1, x2
bl _fen_bytes_concat
cbz x0, Lfn9fail590_3
str x0, [sp, #136]
ldr x0, [sp, #128]
ldr x2, [sp, #136]
mov x1, x2
bl _fen_bytes_concat
cbz x0, Lfn9fail587_3
str x0, [sp, #144]
mov x0, #1
mov x1, #12
bl _fen_allocate
cbz x0, Lfn9fail586_3
ldr x2, [sp, #144]
ldr x3, [sp, #120]
ldr x3, [x3, #8]
stp x2, x3, [x0, #0]
b Lfn9match582end
Lfn9match582arm13:
ldr x0, [sp, #120]
b Lfn9match582end
Lfn9match582arm14:
ldr x0, [sp, #120]
b Lfn9match582end
Lfn9match582end:
b Lfn9match548end
Lfn9match548arm13:
ldr x0, [sp, #88]
b Lfn9match548end
Lfn9match548arm14:
ldr x0, [sp, #88]
b Lfn9match548end
Lfn9match548end:
Lfn9if453done:
b Lfn9match369end
Lfn9match369end:
b Lfn9match347end
Lfn9match347end:
Lfn9if337done:
mov x1, #0
b Lfn9end
Lfn9fail344_1:
adrp x0, Lfn9fail344_1location@PAGE
add x0, x0, Lfn9fail344_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn9end
Lfn9fail351_3:
adrp x0, Lfn9fail351_3location@PAGE
add x0, x0, Lfn9fail351_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn9end
Lfn9fail380_3:
adrp x0, Lfn9fail380_3location@PAGE
add x0, x0, Lfn9fail380_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn9end
Lfn9fail403_1:
adrp x0, Lfn9fail403_1location@PAGE
add x0, x0, Lfn9fail403_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn9end
Lfn9fail413_3:
adrp x0, Lfn9fail413_3location@PAGE
add x0, x0, Lfn9fail413_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn9end
Lfn9fail421_1:
adrp x0, Lfn9fail421_1location@PAGE
add x0, x0, Lfn9fail421_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn9end
Lfn9fail430_3:
adrp x0, Lfn9fail430_3location@PAGE
add x0, x0, Lfn9fail430_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn9end
Lfn9fail438_1:
adrp x0, Lfn9fail438_1location@PAGE
add x0, x0, Lfn9fail438_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn9end
Lfn9fail468_3:
adrp x0, Lfn9fail468_3location@PAGE
add x0, x0, Lfn9fail468_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn9end
Lfn9fail465_3:
adrp x0, Lfn9fail465_3location@PAGE
add x0, x0, Lfn9fail465_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn9end
Lfn9fail476_1:
adrp x0, Lfn9fail476_1location@PAGE
add x0, x0, Lfn9fail476_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn9end
Lfn9fail489_3:
adrp x0, Lfn9fail489_3location@PAGE
add x0, x0, Lfn9fail489_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn9end
Lfn9fail486_3:
adrp x0, Lfn9fail486_3location@PAGE
add x0, x0, Lfn9fail486_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn9end
Lfn9fail496_1:
adrp x0, Lfn9fail496_1location@PAGE
add x0, x0, Lfn9fail496_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn9end
Lfn9fail508_3:
adrp x0, Lfn9fail508_3location@PAGE
add x0, x0, Lfn9fail508_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn9end
Lfn9fail505_3:
adrp x0, Lfn9fail505_3location@PAGE
add x0, x0, Lfn9fail505_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn9end
Lfn9fail515_1:
adrp x0, Lfn9fail515_1location@PAGE
add x0, x0, Lfn9fail515_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn9end
Lfn9fail526_3:
adrp x0, Lfn9fail526_3location@PAGE
add x0, x0, Lfn9fail526_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn9end
Lfn9fail540_3:
adrp x0, Lfn9fail540_3location@PAGE
add x0, x0, Lfn9fail540_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn9end
Lfn9fail560_3:
adrp x0, Lfn9fail560_3location@PAGE
add x0, x0, Lfn9fail560_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn9end
Lfn9fail574_3:
adrp x0, Lfn9fail574_3location@PAGE
add x0, x0, Lfn9fail574_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn9end
Lfn9fail590_3:
adrp x0, Lfn9fail590_3location@PAGE
add x0, x0, Lfn9fail590_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn9end
Lfn9fail587_3:
adrp x0, Lfn9fail587_3location@PAGE
add x0, x0, Lfn9fail587_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn9end
Lfn9fail586_3:
adrp x0, Lfn9fail586_3location@PAGE
add x0, x0, Lfn9fail586_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn9end
Lfn9end:
bl _fen_leave_result
ldp x19, x20, [x29, #-16]
ldp x21, x22, [x29, #-32]
ldp x23, x24, [x29, #-48]
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn10:
ldp x8, x9, [x0, #0]
ldp x10, x11, [x0, #16]
ldp x12, x13, [x0, #32]
Lfn10fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
stp x19, x20, [sp, #-16]!
stp x21, x22, [sp, #-16]!
stp x23, x24, [sp, #-16]!
sub sp, sp, #256
stp xzr, xzr, [sp, #64]
stp xzr, xzr, [sp, #80]
stp xzr, xzr, [sp, #96]
stp xzr, xzr, [sp, #112]
str xzr, [sp, #128]
stp x8, x9, [sp, #48]
mov x21, x10
mov x22, x11
mov x23, x12
mov x19, x13
add x0, sp, #16
add x1, sp, #48
mov x2, #11
bl _fen_enter
Lfn10loop:
mov x0, x23
cmp x0, #0
b.ne Lfn10if628else
adrp x0, Lconstant27@PAGE
add x0, x0, Lconstant27@PAGEOFF
b Lfn10if628done
Lfn10if628else:
mov x0, x23
subs x0, x0, #1
b.vs Lfn10fail635_1
mov x20, x0
ldr x0, [sp, #48]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn10match638arm10
cmp w0, #11
b.eq Lfn10match638arm11
brk #0
Lfn10match638arm10:
ldr x0, [sp, #56]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn10match640arm10
cmp w0, #11
b.eq Lfn10match640arm11
brk #0
Lfn10match640arm10:
mov x0, #0
mov x1, #13
bl _fen_allocate
cbz x0, Lfn10fail642_3
mov x2, x21
mov x3, x20
stp x2, x3, [x0, #0]
b Lfn10match640end
Lfn10match640arm11:
ldr x8, [sp, #56]
adrp x9, Lconstant0@PAGE
add x9, x9, Lconstant0@PAGEOFF
str x8, [sp, #48]
str x9, [sp, #56]
stp xzr, xzr, [sp, #64]
stp xzr, xzr, [sp, #80]
stp xzr, xzr, [sp, #96]
stp xzr, xzr, [sp, #112]
str xzr, [sp, #128]
b Lfn10loop
b Lfn10match640end
Lfn10match640end:
b Lfn10match638end
Lfn10match638arm11:
ldr x0, [sp, #48]
ldr x0, [x0, #8]
ldr w0, [x0, #72]
cmp w0, #7
b.eq Lfn10match659arm7
cmp w0, #8
b.eq Lfn10match659arm8
cmp w0, #9
b.eq Lfn10match659arm9
brk #0
Lfn10match659arm7:
ldr x0, [sp, #48]
ldr x0, [x0, #0]
cbz x0, Lfn10if665else
mov x0, x22
b Lfn10if665done
Lfn10if665else:
mov x0, x21
Lfn10if665done:
str x0, [sp, #136]
ldr x8, [sp, #136]
ldr x9, [sp, #48]
ldr x9, [x9, #8]
ldr x9, [x9, #0]
bl Lfn2fields
cbnz x1, Lfn10end
cbz x0, Lfn10if662else
mov x0, x19
bl Lfn5
cbnz x1, Lfn10end
str x0, [sp, #64]
mov x0, #1
mov x1, #12
bl _fen_allocate
cbz x0, Lfn10fail670_3
ldr x2, [sp, #64]
mov x3, x20
stp x2, x3, [x0, #0]
b Lfn10if662done
Lfn10if662else:
ldr x0, [sp, #48]
ldr x0, [x0, #0]
cbz x0, Lfn10if678else
mov x8, x21
ldr x9, [sp, #48]
ldr x9, [x9, #8]
ldr x9, [x9, #0]
bl Lfn3fields
cbnz x1, Lfn10end
b Lfn10if678done
Lfn10if678else:
mov x0, x21
Lfn10if678done:
str x0, [sp, #144]
ldr x0, [sp, #48]
ldr x0, [x0, #0]
cbz x0, Lfn10if685else
mov x0, x22
b Lfn10if685done
Lfn10if685else:
mov x8, x22
ldr x9, [sp, #48]
ldr x9, [x9, #8]
ldr x9, [x9, #0]
bl Lfn3fields
cbnz x1, Lfn10end
Lfn10if685done:
str x0, [sp, #152]
mov x0, x19
adds x0, x0, #1
b.vs Lfn10fail693_1
str x0, [sp, #160]
ldr x8, [sp, #48]
ldr x8, [x8, #16]
ldr x9, [sp, #144]
ldr x10, [sp, #152]
mov x11, x20
ldr x12, [sp, #160]
str x8, [sp, #48]
mov x21, x9
mov x22, x10
mov x23, x11
mov x19, x12
stp xzr, xzr, [sp, #64]
stp xzr, xzr, [sp, #80]
stp xzr, xzr, [sp, #96]
stp xzr, xzr, [sp, #112]
str xzr, [sp, #128]
b Lfn10loop
Lfn10if662done:
b Lfn10match659end
Lfn10match659arm8:
ldr x0, [sp, #48]
ldr x0, [x0, #16]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn10match697arm10
cmp w0, #11
b.eq Lfn10match697arm11
brk #0
Lfn10match697arm10:
ldr x0, [sp, #48]
ldr x0, [x0, #0]
eor x0, x0, #1
str x0, [sp, #168]
mov x0, #6
mov x1, #11
bl _fen_allocate
cbz x0, Lfn10fail702_3
ldr x2, [sp, #168]
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #0]
stp x2, x3, [x0, #0]
adrp x2, Lconstant0@PAGE
add x2, x2, Lconstant0@PAGEOFF
str x2, [x0, #16]
str x0, [sp, #64]
mov x0, x19
adds x0, x0, #1
b.vs Lfn10fail710_1
str x0, [sp, #176]
ldr x8, [sp, #56]
ldr x9, [sp, #64]
mov x10, x20
ldr x11, [sp, #176]
str x8, [sp, #48]
str x9, [sp, #56]
mov x23, x10
mov x19, x11
stp xzr, xzr, [sp, #64]
stp xzr, xzr, [sp, #80]
stp xzr, xzr, [sp, #96]
stp xzr, xzr, [sp, #112]
str xzr, [sp, #128]
b Lfn10loop
b Lfn10match697end
Lfn10match697arm11:
ldr x0, [sp, #48]
ldr x0, [x0, #0]
eor x0, x0, #1
str x0, [sp, #184]
ldr x8, [sp, #56]
ldr x9, [sp, #184]
ldr x10, [sp, #48]
ldr x10, [x10, #8]
ldr x10, [x10, #0]
bl Lfn1fields
cbnz x1, Lfn10end
str x0, [sp, #64]
mov x0, x19
adds x0, x0, #1
b.vs Lfn10fail728_1
str x0, [sp, #192]
ldr x8, [sp, #48]
ldr x8, [x8, #16]
ldr x9, [sp, #64]
mov x10, x20
ldr x11, [sp, #192]
str x8, [sp, #48]
str x9, [sp, #56]
mov x23, x10
mov x19, x11
stp xzr, xzr, [sp, #64]
stp xzr, xzr, [sp, #80]
stp xzr, xzr, [sp, #96]
stp xzr, xzr, [sp, #112]
str xzr, [sp, #128]
b Lfn10loop
b Lfn10match697end
Lfn10match697end:
b Lfn10match659end
Lfn10match659arm9:
ldr x0, [sp, #48]
ldr x0, [x0, #8]
ldr x0, [x0, #0]
cmp x0, #2
b.ne Lfn10if736else
ldr x0, [sp, #48]
ldr x0, [x0, #0]
eor x0, x0, #1
b Lfn10if736done
Lfn10if736else:
ldr x0, [sp, #48]
ldr x0, [x0, #0]
Lfn10if736done:
mov x24, x0
ldr x0, [sp, #48]
ldr x0, [x0, #8]
ldr x0, [x0, #0]
cmp x0, #0
cset x0, eq
ldr x2, [sp, #48]
ldr x2, [x2, #0]
cmp x0, x2
b.ne Lfn10if743else
ldr x0, [sp, #48]
ldr x0, [x0, #16]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn10match749arm10
cmp w0, #11
b.eq Lfn10match749arm11
brk #0
Lfn10match749arm10:
ldr x0, [sp, #56]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn10match752arm10
cmp w0, #11
b.eq Lfn10match752arm11
brk #0
Lfn10match752arm10:
movz x0, #0, lsl #0
b Lfn10match752end
Lfn10match752arm11:
ldr x0, [sp, #56]
ldr x0, [x0, #16]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn10match758arm10
cmp w0, #11
b.eq Lfn10match758arm11
brk #0
Lfn10match758arm10:
movz x0, #0, lsl #0
b Lfn10match758end
Lfn10match758arm11:
ldr x0, [sp, #56]
ldr x0, [x0, #16]
ldr x0, [x0, #16]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn10match764arm10
cmp w0, #11
b.eq Lfn10match764arm11
brk #0
Lfn10match764arm10:
movz x0, #0, lsl #0
b Lfn10match764end
Lfn10match764arm11:
ldr x0, [sp, #56]
ldr x0, [x0, #16]
ldr x0, [x0, #16]
ldr x0, [x0, #16]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn10match770arm10
cmp w0, #11
b.eq Lfn10match770arm11
brk #0
Lfn10match770arm10:
movz x0, #0, lsl #0
b Lfn10match770end
Lfn10match770arm11:
movz x0, #1, lsl #0
b Lfn10match770end
Lfn10match770end:
b Lfn10match764end
Lfn10match764end:
b Lfn10match758end
Lfn10match758end:
b Lfn10match752end
Lfn10match752end:
cbz x0, Lfn10if751else
mov x0, #6
mov x1, #11
bl _fen_allocate
cbz x0, Lfn10fail783_3
mov x2, x24
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #8]
stp x2, x3, [x0, #0]
adrp x2, Lconstant0@PAGE
add x2, x2, Lconstant0@PAGEOFF
str x2, [x0, #16]
str x0, [sp, #64]
mov x0, #6
mov x1, #11
bl _fen_allocate
cbz x0, Lfn10fail780_3
ldr x2, [sp, #48]
ldr x2, [x2, #0]
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #16]
stp x2, x3, [x0, #0]
ldr x2, [sp, #64]
str x2, [x0, #16]
str x0, [sp, #72]
mov x0, x19
adds x0, x0, #1
b.vs Lfn10fail790_1
str x0, [sp, #200]
bl _fen_leave_result
ldr x8, [sp, #56]
ldr x9, [sp, #72]
mov x10, x21
mov x11, x22
mov x12, x20
ldr x13, [sp, #200]
ldp x19, x20, [x29, #-16]
ldp x21, x22, [x29, #-32]
ldp x23, x24, [x29, #-48]
mov sp, x29
ldp x29, x30, [sp], #16
b Lfn9fields
b Lfn10if751done
Lfn10if751else:
mov x0, #6
mov x1, #11
bl _fen_allocate
cbz x0, Lfn10fail799_3
ldr x2, [sp, #48]
ldr x2, [x2, #0]
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #16]
stp x2, x3, [x0, #0]
adrp x2, Lconstant0@PAGE
add x2, x2, Lconstant0@PAGEOFF
str x2, [x0, #16]
str x0, [sp, #64]
mov x0, #6
mov x1, #11
bl _fen_allocate
cbz x0, Lfn10fail796_3
mov x2, x24
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #8]
stp x2, x3, [x0, #0]
ldr x2, [sp, #64]
str x2, [x0, #16]
str x0, [sp, #72]
mov x0, x19
adds x0, x0, #1
b.vs Lfn10fail806_1
str x0, [sp, #208]
ldr x8, [sp, #56]
ldr x9, [sp, #72]
mov x10, x20
ldr x11, [sp, #208]
str x8, [sp, #48]
str x9, [sp, #56]
mov x23, x10
mov x19, x11
stp xzr, xzr, [sp, #64]
stp xzr, xzr, [sp, #80]
stp xzr, xzr, [sp, #96]
stp xzr, xzr, [sp, #112]
str xzr, [sp, #128]
b Lfn10loop
Lfn10if751done:
b Lfn10match749end
Lfn10match749arm11:
mov x0, #6
mov x1, #11
bl _fen_allocate
cbz x0, Lfn10fail821_3
ldr x2, [sp, #48]
ldr x2, [x2, #0]
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #16]
stp x2, x3, [x0, #0]
adrp x2, Lconstant0@PAGE
add x2, x2, Lconstant0@PAGEOFF
str x2, [x0, #16]
str x0, [sp, #64]
mov x0, #6
mov x1, #11
bl _fen_allocate
cbz x0, Lfn10fail818_3
mov x2, x24
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #8]
stp x2, x3, [x0, #0]
ldr x2, [sp, #64]
str x2, [x0, #16]
str x0, [sp, #72]
ldr x8, [sp, #56]
ldr x9, [sp, #72]
bl Lfn0fields
cbnz x1, Lfn10end
str x0, [sp, #80]
mov x0, x19
adds x0, x0, #1
b.vs Lfn10fail828_1
str x0, [sp, #216]
ldr x8, [sp, #48]
ldr x8, [x8, #16]
ldr x9, [sp, #80]
mov x10, x20
ldr x11, [sp, #216]
str x8, [sp, #48]
str x9, [sp, #56]
mov x23, x10
mov x19, x11
stp xzr, xzr, [sp, #64]
stp xzr, xzr, [sp, #80]
stp xzr, xzr, [sp, #96]
stp xzr, xzr, [sp, #112]
str xzr, [sp, #128]
b Lfn10loop
b Lfn10match749end
Lfn10match749end:
b Lfn10if743done
Lfn10if743else:
ldr x0, [sp, #48]
ldr x0, [x0, #16]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn10match833arm10
cmp w0, #11
b.eq Lfn10match833arm11
brk #0
Lfn10match833arm10:
mov x0, #6
mov x1, #11
bl _fen_allocate
cbz x0, Lfn10fail838_3
mov x2, x24
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #8]
stp x2, x3, [x0, #0]
adrp x2, Lconstant0@PAGE
add x2, x2, Lconstant0@PAGEOFF
str x2, [x0, #16]
str x0, [sp, #64]
movz x0, #0, lsl #0
str x0, [sp, #224]
ldr x8, [sp, #56]
ldr x9, [sp, #64]
mov x10, x21
mov x11, x22
mov x12, x20
ldr x13, [sp, #224]
bl Lfn10fields
cbnz x1, Lfn10end
str x0, [sp, #72]
b Lfn10match833end
Lfn10match833arm11:
ldr x8, [sp, #56]
mov x9, x24
ldr x10, [sp, #48]
ldr x10, [x10, #8]
ldr x10, [x10, #8]
bl Lfn1fields
cbnz x1, Lfn10end
str x0, [sp, #64]
movz x0, #0, lsl #0
str x0, [sp, #232]
ldr x8, [sp, #48]
ldr x8, [x8, #16]
ldr x9, [sp, #64]
mov x10, x21
mov x11, x22
mov x12, x20
ldr x13, [sp, #232]
bl Lfn10fields
cbnz x1, Lfn10end
str x0, [sp, #72]
b Lfn10match833end
Lfn10match833end:
str x0, [sp, #80]
ldr w0, [x0, #72]
cmp w0, #12
b.eq Lfn10match861arm12
cmp w0, #13
b.eq Lfn10match861arm13
cmp w0, #14
b.eq Lfn10match861arm14
brk #0
Lfn10match861arm12:
ldr x0, [sp, #48]
ldr x0, [x0, #16]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn10match867arm10
cmp w0, #11
b.eq Lfn10match867arm11
brk #0
Lfn10match867arm10:
mov x0, #6
mov x1, #11
bl _fen_allocate
cbz x0, Lfn10fail872_3
ldr x2, [sp, #48]
ldr x2, [x2, #0]
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #16]
stp x2, x3, [x0, #0]
adrp x2, Lconstant0@PAGE
add x2, x2, Lconstant0@PAGEOFF
str x2, [x0, #16]
str x0, [sp, #88]
movz x0, #0, lsl #0
str x0, [sp, #240]
ldr x8, [sp, #56]
ldr x9, [sp, #88]
mov x10, x21
mov x11, x22
ldr x12, [sp, #80]
ldr x12, [x12, #8]
ldr x13, [sp, #240]
bl Lfn10fields
cbnz x1, Lfn10end
str x0, [sp, #96]
b Lfn10match867end
Lfn10match867arm11:
ldr x8, [sp, #56]
ldr x9, [sp, #48]
ldr x9, [x9, #0]
ldr x10, [sp, #48]
ldr x10, [x10, #8]
ldr x10, [x10, #16]
bl Lfn1fields
cbnz x1, Lfn10end
str x0, [sp, #88]
movz x0, #0, lsl #0
str x0, [sp, #248]
ldr x8, [sp, #48]
ldr x8, [x8, #16]
ldr x9, [sp, #88]
mov x10, x21
mov x11, x22
ldr x12, [sp, #80]
ldr x12, [x12, #8]
ldr x13, [sp, #248]
bl Lfn10fields
cbnz x1, Lfn10end
str x0, [sp, #96]
b Lfn10match867end
Lfn10match867end:
str x0, [sp, #104]
ldr w0, [x0, #72]
cmp w0, #12
b.eq Lfn10match895arm12
cmp w0, #13
b.eq Lfn10match895arm13
cmp w0, #14
b.eq Lfn10match895arm14
brk #0
Lfn10match895arm12:
mov x0, x19
bl Lfn6
cbnz x1, Lfn10end
str x0, [sp, #112]
ldr x0, [sp, #80]
ldr x0, [x0, #0]
ldr x2, [sp, #104]
ldr x2, [x2, #0]
mov x1, x2
bl _fen_bytes_concat
cbz x0, Lfn10fail903_3
str x0, [sp, #120]
ldr x0, [sp, #112]
ldr x2, [sp, #120]
mov x1, x2
bl _fen_bytes_concat
cbz x0, Lfn10fail900_3
str x0, [sp, #128]
mov x0, #1
mov x1, #12
bl _fen_allocate
cbz x0, Lfn10fail899_3
ldr x2, [sp, #128]
ldr x3, [sp, #104]
ldr x3, [x3, #8]
stp x2, x3, [x0, #0]
b Lfn10match895end
Lfn10match895arm13:
ldr x0, [sp, #104]
b Lfn10match895end
Lfn10match895arm14:
ldr x0, [sp, #104]
b Lfn10match895end
Lfn10match895end:
b Lfn10match861end
Lfn10match861arm13:
ldr x0, [sp, #80]
b Lfn10match861end
Lfn10match861arm14:
ldr x0, [sp, #80]
b Lfn10match861end
Lfn10match861end:
Lfn10if743done:
b Lfn10match659end
Lfn10match659end:
b Lfn10match638end
Lfn10match638end:
Lfn10if628done:
mov x1, #0
b Lfn10end
Lfn10fail635_1:
adrp x0, Lfn10fail635_1location@PAGE
add x0, x0, Lfn10fail635_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn10end
Lfn10fail642_3:
adrp x0, Lfn10fail642_3location@PAGE
add x0, x0, Lfn10fail642_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn10end
Lfn10fail670_3:
adrp x0, Lfn10fail670_3location@PAGE
add x0, x0, Lfn10fail670_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn10end
Lfn10fail693_1:
adrp x0, Lfn10fail693_1location@PAGE
add x0, x0, Lfn10fail693_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn10end
Lfn10fail702_3:
adrp x0, Lfn10fail702_3location@PAGE
add x0, x0, Lfn10fail702_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn10end
Lfn10fail710_1:
adrp x0, Lfn10fail710_1location@PAGE
add x0, x0, Lfn10fail710_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn10end
Lfn10fail728_1:
adrp x0, Lfn10fail728_1location@PAGE
add x0, x0, Lfn10fail728_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn10end
Lfn10fail783_3:
adrp x0, Lfn10fail783_3location@PAGE
add x0, x0, Lfn10fail783_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn10end
Lfn10fail780_3:
adrp x0, Lfn10fail780_3location@PAGE
add x0, x0, Lfn10fail780_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn10end
Lfn10fail790_1:
adrp x0, Lfn10fail790_1location@PAGE
add x0, x0, Lfn10fail790_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn10end
Lfn10fail799_3:
adrp x0, Lfn10fail799_3location@PAGE
add x0, x0, Lfn10fail799_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn10end
Lfn10fail796_3:
adrp x0, Lfn10fail796_3location@PAGE
add x0, x0, Lfn10fail796_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn10end
Lfn10fail806_1:
adrp x0, Lfn10fail806_1location@PAGE
add x0, x0, Lfn10fail806_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn10end
Lfn10fail821_3:
adrp x0, Lfn10fail821_3location@PAGE
add x0, x0, Lfn10fail821_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn10end
Lfn10fail818_3:
adrp x0, Lfn10fail818_3location@PAGE
add x0, x0, Lfn10fail818_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn10end
Lfn10fail828_1:
adrp x0, Lfn10fail828_1location@PAGE
add x0, x0, Lfn10fail828_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn10end
Lfn10fail838_3:
adrp x0, Lfn10fail838_3location@PAGE
add x0, x0, Lfn10fail838_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn10end
Lfn10fail872_3:
adrp x0, Lfn10fail872_3location@PAGE
add x0, x0, Lfn10fail872_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn10end
Lfn10fail903_3:
adrp x0, Lfn10fail903_3location@PAGE
add x0, x0, Lfn10fail903_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn10end
Lfn10fail900_3:
adrp x0, Lfn10fail900_3location@PAGE
add x0, x0, Lfn10fail900_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn10end
Lfn10fail899_3:
adrp x0, Lfn10fail899_3location@PAGE
add x0, x0, Lfn10fail899_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn10end
Lfn10end:
bl _fen_leave_result
ldp x19, x20, [x29, #-16]
ldp x21, x22, [x29, #-32]
ldp x23, x24, [x29, #-48]
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn11:
ldp x8, x9, [x0, #0]
ldp x10, x11, [x0, #16]
Lfn11fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #96
stp x8, x9, [sp, #48]
stp x10, x11, [sp, #64]
Lfn11loop:
movz x0, #0, lsl #0
str x0, [sp, #80]
ldr x8, [sp, #48]
adrp x9, Lconstant0@PAGE
add x9, x9, Lconstant0@PAGEOFF
ldr x10, [sp, #56]
ldr x11, [sp, #64]
ldr x12, [sp, #72]
ldr x13, [sp, #80]
mov sp, x29
ldp x29, x30, [sp], #16
b Lfn10fields
mov x1, #0
b Lfn11end
Lfn11end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn12:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #80
str xzr, [sp, #48]
str x0, [sp, #56]
add x0, sp, #16
add x1, sp, #48
mov x2, #1
bl _fen_enter
ldr x0, [sp, #56]
cmp x0, #1
b.ne Lfn12if943else
adrp x0, Lconstant28@PAGE
add x0, x0, Lconstant28@PAGEOFF
b Lfn12if943done
Lfn12if943else:
ldr x0, [sp, #56]
asr x2, x0, #63
add x0, x0, x2, lsr #63
asr x0, x0, #1
bl Lfn12
cbnz x1, Lfn12end
str x0, [sp, #48]
movz x0, #1, lsl #0
str x0, [sp, #64]
mov x0, #6
mov x1, #9
bl _fen_allocate
cbz x0, Lfn12fail955_3
ldr x2, [sp, #64]
ldr x3, [sp, #48]
stp x2, x3, [x0, #0]
ldr x2, [sp, #48]
str x2, [x0, #16]
Lfn12if943done:
mov x1, #0
b Lfn12end
Lfn12fail955_3:
adrp x0, Lfn12fail955_3location@PAGE
add x0, x0, Lfn12fail955_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn12end
Lfn12end:
bl _fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn13:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #80
str xzr, [sp, #48]
str x0, [sp, #56]
add x0, sp, #16
add x1, sp, #48
mov x2, #1
bl _fen_enter
ldr x0, [sp, #56]
cmp x0, #1
b.ne Lfn13if961else
adrp x0, Lconstant28@PAGE
add x0, x0, Lconstant28@PAGEOFF
b Lfn13if961done
Lfn13if961else:
movz x0, #1, lsl #0
str x0, [sp, #64]
ldr x0, [sp, #56]
subs x0, x0, #1
b.vs Lfn13fail972_1
bl Lfn13
cbnz x1, Lfn13end
str x0, [sp, #48]
mov x0, #6
mov x1, #9
bl _fen_allocate
cbz x0, Lfn13fail967_3
ldr x2, [sp, #64]
adrp x3, Lconstant28@PAGE
add x3, x3, Lconstant28@PAGEOFF
stp x2, x3, [x0, #0]
ldr x2, [sp, #48]
str x2, [x0, #16]
Lfn13if961done:
mov x1, #0
b Lfn13end
Lfn13fail972_1:
adrp x0, Lfn13fail972_1location@PAGE
add x0, x0, Lfn13fail972_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn13end
Lfn13fail967_3:
adrp x0, Lfn13fail967_3location@PAGE
add x0, x0, Lfn13fail967_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn13end
Lfn13end:
bl _fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn14:
ldp x8, x9, [x0, #0]
ldr x10, [x0, #16]
Lfn14fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
stp x19, x20, [sp, #-16]!
sub sp, sp, #128
stp xzr, xzr, [sp, #56]
str x8, [sp, #48]
mov x19, x9
mov x20, x10
add x0, sp, #16
add x1, sp, #48
mov x2, #3
bl _fen_enter
Lfn14loop:
mov x0, x19
cmp x0, #0
b.ne Lfn14if989else
mov x0, x20
b Lfn14if989done
Lfn14if989else:
movz x0, #0, lsl #0
str x0, [sp, #72]
mov x0, #6
mov x1, #11
bl _fen_allocate
cbz x0, Lfn14fail998_3
ldr x2, [sp, #72]
ldr x3, [sp, #48]
stp x2, x3, [x0, #0]
adrp x2, Lconstant0@PAGE
add x2, x2, Lconstant0@PAGEOFF
str x2, [x0, #16]
str x0, [sp, #56]
movz x0, #0, lsl #0
str x0, [sp, #80]
movz x0, #0, lsl #0
str x0, [sp, #88]
movz x0, #512, lsl #0
str x0, [sp, #96]
ldr x8, [sp, #56]
ldr x9, [sp, #80]
ldr x10, [sp, #88]
ldr x11, [sp, #96]
bl Lfn11fields
cbnz x1, Lfn14end
str x0, [sp, #64]
mov x0, x19
subs x0, x0, #1
b.vs Lfn14fail1008_1
str x0, [sp, #104]
ldr x0, [sp, #64]
adrp x2, Lconstant29@PAGE
add x2, x2, Lconstant29@PAGEOFF
mov x1, x2
bl _fen_equal
cbz x0, Lfn14if1013else
movz x0, #1, lsl #0
b Lfn14if1013done
Lfn14if1013else:
movz x0, #0, lsl #0
Lfn14if1013done:
str x0, [sp, #112]
mov x0, x20
ldr x2, [sp, #112]
adds x0, x0, x2
b.vs Lfn14fail1011_1
str x0, [sp, #120]
ldr x8, [sp, #104]
ldr x9, [sp, #120]
mov x19, x8
mov x20, x9
stp xzr, xzr, [sp, #56]
b Lfn14loop
Lfn14if989done:
mov x1, #0
b Lfn14end
Lfn14fail998_3:
adrp x0, Lfn14fail998_3location@PAGE
add x0, x0, Lfn14fail998_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn14end
Lfn14fail1008_1:
adrp x0, Lfn14fail1008_1location@PAGE
add x0, x0, Lfn14fail1008_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn14end
Lfn14fail1011_1:
adrp x0, Lfn14fail1011_1location@PAGE
add x0, x0, Lfn14fail1011_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn14end
Lfn14end:
bl _fen_leave_result
ldp x19, x20, [x29, #-16]
mov sp, x29
ldp x29, x30, [sp], #16
ret
.globl _fenrir_entry
_fenrir_entry:
Lfn15:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #96
stp xzr, xzr, [sp, #48]
str x0, [sp, #64]
add x0, sp, #16
add x1, sp, #48
mov x2, #2
bl _fen_enter
ldr x0, [sp, #64]
cmp x0, #0
b.ne Lfn15if1025else
movz x0, #64, lsl #0
bl Lfn12
cbnz x1, Lfn15end
str x0, [sp, #48]
b Lfn15if1025done
Lfn15if1025else:
movz x0, #64, lsl #0
bl Lfn13
cbnz x1, Lfn15end
str x0, [sp, #48]
Lfn15if1025done:
str x0, [sp, #56]
movz x0, #1000, lsl #0
str x0, [sp, #72]
movz x0, #0, lsl #0
str x0, [sp, #80]
bl _fen_leave_result
ldr x8, [sp, #56]
ldr x9, [sp, #72]
ldr x10, [sp, #80]
mov sp, x29
ldp x29, x30, [sp], #16
b Lfn14fields
mov x1, #0
b Lfn15end
Lfn15end:
bl _fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
.text
.globl _fen_print_result
_fen_print_result:
b Lprint0
Lprint0:
b _fen_write_i64
Lfn0fail18_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,56,58,49,55,10,0
Lfn0fail28_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,57,58,52,48,10,0
Lfn0fail25_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,57,58,50,55,10,0
.p2align 3
Lconstant0:
.zero 72
.long 10
.byte 0,2,0,0
Lfn1fail52_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,49,50,58,51,49,10,0
Lfn2fail73_2location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,49,54,58,51,49,10,0
Lfn2fail73_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,49,54,58,51,49,10,0
Lfn3fail99_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,50,48,58,51,50,10,0
Lfn3fail108_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,50,49,58,52,53,10,0
.p2align 3
Lconstant1:
.quad 8
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,115,115,115,115
.p2align 3
Lconstant2:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115
.p2align 3
Lconstant3:
.quad 2
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115
.p2align 3
Lconstant4:
.quad 3
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115
.p2align 3
Lconstant5:
.quad 4
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115
.p2align 3
Lconstant6:
.quad 5
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,115
.p2align 3
Lconstant7:
.quad 6
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,115,115
.p2align 3
Lconstant8:
.quad 7
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,115,115,115
Lfn4fail127_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,50,54,58,50,48,10,0
Lfn4fail130_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,50,54,58,51,50,10,0
Lfn4fail138_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,50,56,58,55,10,0
.p2align 3
Lconstant9:
.quad 9
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,115,115,115,115,120
.p2align 3
Lconstant10:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 120
.p2align 3
Lconstant11:
.quad 2
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,120
.p2align 3
Lconstant12:
.quad 3
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,120
.p2align 3
Lconstant13:
.quad 4
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,120
.p2align 3
Lconstant14:
.quad 5
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,120
.p2align 3
Lconstant15:
.quad 6
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,115,120
.p2align 3
Lconstant16:
.quad 7
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,115,115,120
.p2align 3
Lconstant17:
.quad 8
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,115,115,115,120
Lfn5fail179_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,51,55,58,50,48,10,0
.p2align 3
Lconstant18:
.quad 9
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,115,115,115,115,98
.p2align 3
Lconstant19:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 98
.p2align 3
Lconstant20:
.quad 2
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,98
.p2align 3
Lconstant21:
.quad 3
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,98
.p2align 3
Lconstant22:
.quad 4
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,98
.p2align 3
Lconstant23:
.quad 5
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,98
.p2align 3
Lconstant24:
.quad 6
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,115,98
.p2align 3
Lconstant25:
.quad 7
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,115,115,98
.p2align 3
Lconstant26:
.quad 8
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,115,115,115,98
Lfn6fail227_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,52,52,58,50,48,10,0
Lfn7fail286_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,53,50,58,52,52,10,0
Lfn8fail307_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,53,56,58,52,54,10,0
.p2align 3
Lconstant27:
.zero 72
.long 14
.byte 0,2,0,0
Lfn9fail344_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,54,49,58,49,53,10,0
Lfn9fail351_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,54,51,58,52,49,10,0
Lfn9fail380_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,54,56,58,49,57,10,0
Lfn9fail403_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,55,48,58,56,52,10,0
Lfn9fail413_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,55,50,58,54,54,10,0
Lfn9fail421_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,55,50,58,49,49,48,10,0
Lfn9fail430_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,55,51,58,54,53,10,0
Lfn9fail438_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,55,51,58,49,48,56,10,0
Lfn9fail468_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,55,57,58,54,51,10,0
Lfn9fail465_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,55,57,58,52,56,10,0
Lfn9fail476_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,56,48,58,53,52,10,0
Lfn9fail489_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,56,49,58,56,55,10,0
Lfn9fail486_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,56,49,58,55,52,10,0
Lfn9fail496_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,56,50,58,53,52,10,0
Lfn9fail508_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,56,51,58,55,52,10,0
Lfn9fail505_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,56,51,58,54,49,10,0
Lfn9fail515_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,56,52,58,53,51,10,0
Lfn9fail526_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,56,54,58,55,52,10,0
Lfn9fail540_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,56,55,58,55,51,10,0
Lfn9fail560_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,57,49,58,55,57,10,0
Lfn9fail574_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,57,50,58,55,56,10,0
Lfn9fail590_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,57,52,58,57,52,10,0
Lfn9fail587_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,57,52,58,53,57,10,0
Lfn9fail586_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,57,52,58,53,50,10,0
Lfn10fail635_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,49,48,50,58,49,53,10,0
Lfn10fail642_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,49,48,52,58,52,49,10,0
Lfn10fail670_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,49,48,57,58,49,57,10,0
Lfn10fail693_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,49,49,49,58,56,52,10,0
Lfn10fail702_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,49,49,51,58,53,54,10,0
Lfn10fail710_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,49,49,51,58,49,48,48,10,0
Lfn10fail728_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,49,49,52,58,49,49,50,10,0
Lfn10fail783_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,49,49,57,58,50,55,49,10,0
Lfn10fail780_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,49,49,57,58,50,53,56,10,0
Lfn10fail790_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,49,49,57,58,51,49,50,10,0
Lfn10fail799_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,49,49,57,58,51,53,57,10,0
Lfn10fail796_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,49,49,57,58,51,52,52,10,0
Lfn10fail806_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,49,49,57,58,51,57,56,10,0
Lfn10fail821_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,49,50,48,58,57,54,10,0
Lfn10fail818_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,49,50,48,58,56,49,10,0
Lfn10fail828_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,49,50,49,58,53,51,10,0
Lfn10fail838_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,49,50,51,58,54,52,10,0
Lfn10fail872_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,49,50,56,58,54,57,10,0
Lfn10fail903_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,49,51,49,58,57,52,10,0
Lfn10fail900_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,49,51,49,58,53,57,10,0
Lfn10fail899_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,49,51,49,58,53,50,10,0
.p2align 3
Lconstant28:
.quad 1
.zero 64
.long 7
.byte 0,2,0,0
Lfn12fail955_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,49,52,49,58,53,57,10,0
Lfn13fail972_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,49,52,51,58,53,53,10,0
Lfn13fail967_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,49,52,51,58,50,57,10,0
.p2align 3
Lconstant29:
.quad 0
.quad 384
.zero 56
.long 13
.byte 0,2,0,0
Lfn14fail998_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,49,52,54,58,50,53,10,0
Lfn14fail1008_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,49,52,55,58,50,55,10,0
Lfn14fail1011_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,103,114,97,109,46,102,101,110,58,49,52,55,58,52,51,10,0
