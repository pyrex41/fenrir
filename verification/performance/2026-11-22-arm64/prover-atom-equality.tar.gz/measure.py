import json,random,statistics,subprocess
from pathlib import Path
out=Path(__file__).resolve().parent
root=Path.cwd()
src=root/'build/retained-package-F2OMNVvV/package/libexec/fenrir'
image=(root/'build/clock-kernels-X5lfbNMk/image').read_text().strip()
docker=['docker','run','--rm','--network','none','--platform','linux/arm64','-v',f'{src.resolve()}:/src:ro','-v',f'{out}:/work','-w','/work','--entrypoint','sh',image,'-ec']
def run(cmd,**kw):return subprocess.check_output(cmd,text=True,timeout=180,**kw)
before=(src/'benchmarks/prover/formula.fen').read_text()
after=before.replace('(if (< mask bit) false','(if (= mask bit) true (if (< mask bit) false').replace('quotient 2))) 1))))','quotient 2))) 1)))))')
assert before!=after
(out/'candidate.fen').write_text(after)
for lane,cases in [('search',10),('check',6)]:
 p=out/lane;p.mkdir(exist_ok=True)
 old=(root/'build/prover-mask-range-m6PFVuAs'/lane/'benchmark.fen').read_text()
 suffix=old.removeprefix((root/'build/prover-mask-range-m6PFVuAs/formula.fen').read_text())
 assert suffix!=old
 for name,formula in [('baseline',before),('candidate',after)]:
  (p/f'{name}.fen').write_text(formula+suffix)
  run(['sh',src/'frontend/fenrir.sh','emit',name+'.fen',name+'.json'],cwd=p)
  run(['node',src/'tools/aarch64/native-image.mjs','solo5-arm64-spt',p/(name+'.json'),p/(name+'.s')])
  run(docker+['cd "$1"; export PATH=/opt/solo5-install/bin:$PATH FENRIR_SOLO5_MAIN=/src/benchmarks/prover/timed-spt.c; sh /src/tools/aarch64/link-spt.sh "$2.s" "$2.spt"','sh',lane,name])
 orders=[['baseline','candidate'] if i%2==0 else ['candidate','baseline'] for i in range(42)]
 output=run(docker+['cd "$1"; shift; for n do /opt/solo5-install/bin/solo5-spt "$n.spt" --solo5:quiet 50000; done','sh',lane,*[n for order in orders for n in order]])
 (p/'console.txt').write_text(output)
 lines=iter(output.splitlines());pairs=[]
 for order in orders:
  sample={}
  for n in order:
   total,ns=map(int,next(lines).split());assert total==cases*50000 and ns>0
   sample[n]=ns
  pairs.append(sample)
 assert not list(lines)
 ratios=[s['candidate']/s['baseline'] for s in pairs[2:]]
 rng=random.Random(1147);draws=sorted(statistics.median(rng.choices(ratios,k=len(ratios))) for _ in range(10000))
 report=dict(image=image,rounds=50000,orders=orders,ns=pairs,warmup_pairs=2,median=statistics.median(ratios),bootstrap95=[draws[249],draws[9749]])
 (p/'result.json').write_text(json.dumps(report,indent=2));print(lane,report['median'],report['bootstrap95'],flush=True)
