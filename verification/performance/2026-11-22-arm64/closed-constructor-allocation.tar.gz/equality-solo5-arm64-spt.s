.text
.p2align 2
Lfn0:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #80
str x0, [sp, #48]
add x0, sp, #16
add x1, sp, #48
mov x2, #1
bl fen_enter
ldr x0, [sp, #48]
ldr w0, [x0, #72]
cmp w0, #7
b.eq Lfn0match2arm7
cmp w0, #8
b.eq Lfn0match2arm8
brk #0
Lfn0match2arm7:
movz x0, #0, lsl #0
str x0, [sp, #56]
ldr x0, [sp, #48]
ldr x0, [x0, #0]
ldr x2, [sp, #56]
ldr x3, [x0]
cmp x2, x3
b.hs Lfn0fail5_4
ldr w3, [x0, #72]
cmn w3, #1
b.ne 1f
add x0, x0, #80
ldrb w0, [x0, x2]
b 2f
1:
mov x1, x2
bl fen_bytes_index
2:
b Lfn0match2end
Lfn0match2arm8:
ldr x0, [sp, #48]
ldr x0, [x0, #0]
bl Lfn0
cbnz x1, Lfn0end
str x0, [sp, #64]
ldr x0, [sp, #48]
ldr x0, [x0, #8]
bl Lfn0
cbnz x1, Lfn0end
str x0, [sp, #72]
ldr x0, [sp, #64]
ldr x2, [sp, #72]
adds x0, x0, x2
b.vs Lfn0fail10_1
b Lfn0match2end
Lfn0match2end:
mov x1, #0
b Lfn0end
Lfn0fail5_4:
adrp x0, Lfn0fail5_4location
add x0, x0, :lo12:Lfn0fail5_4location
bl fen_set_location
mov x1, #4
b Lfn0end
Lfn0fail10_1:
adrp x0, Lfn0fail10_1location
add x0, x0, :lo12:Lfn0fail10_1location
bl fen_set_location
mov x1, #1
b Lfn0end
Lfn0end:
bl fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
.globl fenrir_entry
fenrir_entry:
Lfn1:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #96
stp xzr, xzr, [sp, #48]
str xzr, [sp, #64]
str x0, [sp, #72]
add x0, sp, #16
add x1, sp, #48
mov x2, #3
bl fen_enter
adrp x0, Lconstant0
add x0, x0, :lo12:Lconstant0
adrp x2, Lconstant8
add x2, x2, :lo12:Lconstant8
mov x1, x2
bl fen_bytes_concat
cbz x0, Lfn1fail31_3
str x0, [sp, #48]
mov x0, #1
mov x1, #7
bl fen_allocate
cbz x0, Lfn1fail30_3
ldr x2, [sp, #48]
str x2, [x0, #0]
str x0, [sp, #56]
mov x0, #3
mov x1, #8
bl fen_allocate
cbz x0, Lfn1fail29_3
ldr x2, [sp, #56]
adrp x3, Lconstant6
add x3, x3, :lo12:Lconstant6
stp x2, x3, [x0, #0]
str x0, [sp, #64]
adrp x0, Lconstant7
add x0, x0, :lo12:Lconstant7
ldr x2, [sp, #64]
mov x1, x2
bl fen_equal
cbz x0, Lfn1if39else
adrp x0, Lconstant7
add x0, x0, :lo12:Lconstant7
bl Lfn0
cbnz x1, Lfn1end
str x0, [sp, #80]
ldr x0, [sp, #72]
ldr x2, [sp, #80]
adds x0, x0, x2
b.vs Lfn1fail43_1
b Lfn1if39done
Lfn1if39else:
movz x0, #0, lsl #0
Lfn1if39done:
mov x1, #0
b Lfn1end
Lfn1fail31_3:
adrp x0, Lfn1fail31_3location
add x0, x0, :lo12:Lfn1fail31_3location
bl fen_set_location
mov x1, #3
b Lfn1end
Lfn1fail30_3:
adrp x0, Lfn1fail30_3location
add x0, x0, :lo12:Lfn1fail30_3location
bl fen_set_location
mov x1, #3
b Lfn1end
Lfn1fail29_3:
adrp x0, Lfn1fail29_3location
add x0, x0, :lo12:Lfn1fail29_3location
bl fen_set_location
mov x1, #3
b Lfn1end
Lfn1fail43_1:
adrp x0, Lfn1fail43_1location
add x0, x0, :lo12:Lfn1fail43_1location
bl fen_set_location
mov x1, #1
b Lfn1end
Lfn1end:
bl fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
.text
.globl fen_print_result
fen_print_result:
b Lprint0
Lprint0:
b fen_write_i64
Lfn0fail5_4location:
.byte 116,114,97,112,32,97,116,58,32,47,85,115,101,114,115,47,114,101,117,98,101,110,47,112,114,111,106,101,99,116,115,47,102,101,110,114,105,114,47,98,117,105,108,100,47,99,108,111,115,101,100,45,99,111,110,115,116,114,117,99,116,111,114,115,45,103,69,114,112,56,121,76,115,47,101,113,117,97,108,105,116,121,46,102,101,110,58,54,58,50,50,10,0
Lfn0fail10_1location:
.byte 116,114,97,112,32,97,116,58,32,47,85,115,101,114,115,47,114,101,117,98,101,110,47,112,114,111,106,101,99,116,115,47,102,101,110,114,105,114,47,98,117,105,108,100,47,99,108,111,115,101,100,45,99,111,110,115,116,114,117,99,116,111,114,115,45,103,69,114,112,56,121,76,115,47,101,113,117,97,108,105,116,121,46,102,101,110,58,55,58,50,55,10,0
.p2align 3
Lconstant0:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 20
.section .rodata
.p2align 3
Lconstant1:
.quad Lconstant0
.zero 64
.long 7
.byte 1,2,0,0
.text
.p2align 3
Lconstant2:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 1
.section .rodata
.p2align 3
Lconstant3:
.quad Lconstant2
.zero 64
.long 7
.byte 1,2,0,0
.text
.p2align 3
Lconstant4:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 22
.section .rodata
.p2align 3
Lconstant5:
.quad Lconstant4
.zero 64
.long 7
.byte 1,2,0,0
.text
.section .rodata
.p2align 3
Lconstant6:
.quad Lconstant3
.quad Lconstant5
.zero 56
.long 8
.byte 3,2,0,0
.text
.section .rodata
.p2align 3
Lconstant7:
.quad Lconstant1
.quad Lconstant6
.zero 56
.long 8
.byte 3,2,0,0
.text
.p2align 3
Lconstant8:
.quad 0
.zero 64
.long 4294967295
.byte 0,2,0,0
Lfn1fail31_3location:
.byte 116,114,97,112,32,97,116,58,32,47,85,115,101,114,115,47,114,101,117,98,101,110,47,112,114,111,106,101,99,116,115,47,102,101,110,114,105,114,47,98,117,105,108,100,47,99,108,111,115,101,100,45,99,111,110,115,116,114,117,99,116,111,114,115,45,103,69,114,112,56,121,76,115,47,101,113,117,97,108,105,116,121,46,102,101,110,58,49,49,58,51,53,10,0
Lfn1fail30_3location:
.byte 116,114,97,112,32,97,116,58,32,47,85,115,101,114,115,47,114,101,117,98,101,110,47,112,114,111,106,101,99,116,115,47,102,101,110,114,105,114,47,98,117,105,108,100,47,99,108,111,115,101,100,45,99,111,110,115,116,114,117,99,116,111,114,115,45,103,69,114,112,56,121,76,115,47,101,113,117,97,108,105,116,121,46,102,101,110,58,49,49,58,50,57,10,0
Lfn1fail29_3location:
.byte 116,114,97,112,32,97,116,58,32,47,85,115,101,114,115,47,114,101,117,98,101,110,47,112,114,111,106,101,99,116,115,47,102,101,110,114,105,114,47,98,117,105,108,100,47,99,108,111,115,101,100,45,99,111,110,115,116,114,117,99,116,111,114,115,45,103,69,114,112,56,121,76,115,47,101,113,117,97,108,105,116,121,46,102,101,110,58,49,49,58,50,51,10,0
Lfn1fail43_1location:
.byte 116,114,97,112,32,97,116,58,32,47,85,115,101,114,115,47,114,101,117,98,101,110,47,112,114,111,106,101,99,116,115,47,102,101,110,114,105,114,47,98,117,105,108,100,47,99,108,111,115,101,100,45,99,111,110,115,116,114,117,99,116,111,114,115,45,103,69,114,112,56,121,76,115,47,101,113,117,97,108,105,116,121,46,102,101,110,58,49,50,58,51,52,10,0
