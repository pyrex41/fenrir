from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'base.s').read_text()
i=s.index('Lfn5fields:');j=s.index('Lfn6:',i);f=s[i:j]
def sub(old,new):
 global f
 assert f.count(old)==1,old
 f=f.replace(old,new)
sub('Lfn5fields:\n','Lfn5fields:\nmov x7, #0\nLproofEntry:\n')
sub('sub sp, sp, #240','sub sp, sp, #288\nstr x7, [sp, #240]')
for slot,remaining,node in [(64,'mov x3, x20',239),(152,'ldr x3, [sp, #280]',356)]:
 if node==356:sub('ldr x3, [sp, #128]\nldr x3, [x3, #8]',remaining)
 marker=f'str x0, [sp, #{slot}]\nmov x0, #1\nmov x1, #12'
 sub(marker,f'ldr x7, [sp, #240]\ncbz x7, Lbox{node}\n{remaining}\nstp x0, x3, [x7]\nmov x0, #0\nmov x1, #0\nb Lfn5end\nLbox{node}:\n'+marker)
for slot,arm,fuel in [(112,334,272),(128,352,280)]:
 old=f'bl Lfn5fields\ncbnz x1, Lfn5end\nstr x0, [sp, #{slot}]'
 sub(old,f'add x7, sp, #248\nbl LproofEntry\ncbnz x1, Lfn5end\ncbnz x0, Lboxed{arm}\nldp x2, x3, [sp, #248]\nstr x2, [sp, #{slot}]\nstr x3, [sp, #{fuel}]\nb Lfn5match{arm}arm12\nLboxed{arm}:\nstr x0, [sp, #{slot}]')
 sub(f'cmp w0, #12\nb.eq Lfn5match{arm}arm12\n','')
sub('ldr x12, [sp, #112]\nldr x12, [x12, #8]','ldr x12, [sp, #272]')
sub('ldr x0, [sp, #112]\nldr x0, [x0, #0]\nldr x2, [sp, #128]\nldr x2, [x2, #0]','ldr x0, [sp, #112]\nldr x2, [sp, #128]')
(p/'candidate.s').write_text(s[:i]+f+s[j:])
