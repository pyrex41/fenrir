"""Exercise the pipelined host binary with a guest that controls reply timing."""
import os
from pathlib import Path
import select
import socket
import struct
import subprocess
import sys
import time

ingress = Path(sys.argv[1])
def exact(fd, size):
    deadline = time.monotonic() + 5
    data = b''
    while len(data) < size:
        if not select.select([fd], [], [], max(0, deadline-time.monotonic()))[0]:
            raise TimeoutError('ingress withheld a request frame')
        chunk = os.read(fd, size-len(data))
        if not chunk:
            raise EOFError('incomplete request frame')
        data += chunk
    return data

def receive_header(worker, expected):
    length, complete = struct.unpack('<II', exact(worker.stdout.fileno(), 8))
    assert complete == 1 and length == len(expected)
    assert exact(worker.stdout.fileno(), length) == expected

def send_request(addr, path):
    head = b'GET '+path+b' HTTP/1.1\r\nHost:x\r\nConnection: close\r\n\r\n'
    conn = socket.create_connection(addr, timeout=5)
    conn.sendall(head)
    return conn,head


def truncated(prefix):
    with subprocess.Popen([ingress,'0'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE) as worker:
        conns=[]
        try:
            host,port=worker.stderr.readline().strip().split(b':')
            addr=(host.decode(),int(port))
            for i in range(16):
                conn,head=send_request(addr,b'/')
                conns.append(conn)
                receive_header(worker,head)
            reply=struct.pack('<QQQQ',200,1,0,0)
            worker.stdin.write(reply*3+reply[:prefix])
            worker.stdin.close()
            assert worker.wait(timeout=5)==2
            # Completed replies may race process exit; a partial guest reply
            # must never publish an HTTP success to its client or a later one.
            for conn in conns[3:]:
                try: data=conn.recv(8192)
                except ConnectionResetError: data=b''
                assert data==b'',(prefix,data)
        finally:
            for conn in conns:conn.close()
            if worker.poll() is None:worker.kill()
            worker.wait(timeout=5)

for prefix in range(32):truncated(prefix)
print('All 32 truncated reply lengths exited with status 2 and released waiting connections.')
