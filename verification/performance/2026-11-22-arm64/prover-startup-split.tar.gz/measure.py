import hashlib,json,subprocess,tempfile,time
from pathlib import Path
root=Path(__file__).resolve().parent
pkg=Path('/nix/store/7xpd99idqnh1frvgaybv8rmbas4fh2i0-fenrir-0.1-dev')
src=pkg/'libexec/fenrir/benchmarks/prover'
program=(src/'formula.fen').read_text()+(src/'search.fen').read_text()+'\n(define main {I64 --> Answer} i -> (if (= i 0) (search (More false (Binary 2 (Atom 1) (Atom 1)) Empty) 0 0 3) Exhausted))\n'
targets=['macos-arm64','solo5-arm64-spt']
container='fenrir-track1-solo5:38e0c348be23-arm64'
image_id=subprocess.check_output(['docker','image','inspect','--format','{{.Id}}',container],text=True).strip()
with (root/'samples.jsonl').open('x') as f:
 for block in range(10):
  for target in targets[::1 if block%2==0 else -1]:
   with tempfile.TemporaryDirectory() as tmp:
    p=Path(tmp);(p/'prover.fen').write_text(program);exe=p/'prover'
    start=time.monotonic_ns()
    subprocess.run([pkg/'bin/fenrir','build','--target',target,'prover.fen','-o',exe],cwd=p,capture_output=True,timeout=120,check=True)
    built=time.monotonic_ns()
    command=[exe] if target==targets[0] else ['docker','run','--rm','--platform','linux/arm64','--network','none','-v',f'{p}:/guest:ro','--entrypoint','/opt/solo5-install/bin/solo5-spt',image_id,'/guest/prover','--solo5:quiet']
    launch=time.monotonic_ns()
    result=subprocess.check_output([*command,'0'],timeout=30)
    done=time.monotonic_ns()
    assert result.strip()==b'(Proof #x737378 0)',result
    print(json.dumps(dict(block=block,target=target,build_ns=built-start,launch_ns=done-launch,image_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),container=image_id if target==targets[1] else None,output=result.decode())),file=f,flush=True)
