import collections,hashlib,json,re,subprocess,sys
from pathlib import Path
root=Path.cwd()
out=Path(__file__).resolve().parent
for lane,expected in [('search',10),('check',6)]:
    artifact=out/(lane+'.artifact')
    names=[f['name'] for f in json.loads(artifact.read_text())['functions']]
    plain=out/(lane+'.original.s')
    subprocess.run(['node','tools/aarch64/native-image.mjs','macos-arm64',artifact,plain],check=True)
    asm=[]; keys={}; owner=None
    for line in plain.read_text().splitlines():
        m=re.fullmatch(r'Lfn(\d+):',line)
        if m: owner=names[int(m[1])]
        if line=='.globl _fen_print_result': owner=None
        if owner and line and not line.startswith('.') and not line.endswith(':'):
            if re.search(r'\bx1[67]\b',line): raise ValueError(line)
            op=line.split()[0]
            kind=(line if op=='bl' else 'stack '+op if '[sp' in line else op)
            k=(owner,kind); idx=keys.setdefault(k,len(keys))
            label=f'Lcnt{idx}'
            asm.extend([f'adrp x16, {label}@PAGE',f'ldr x17, [x16, {label}@PAGEOFF]','add x17, x17, #1',f'str x17, [x16, {label}@PAGEOFF]'])
        asm.append(line)
    asm.extend(['.data','.p2align 3','.globl _counters','_counters:'])
    for i in range(len(keys)): asm.extend([f'Lcnt{i}:','.quad 0'])
    image=out/lane; source=out/(lane+'.s');source.write_text('\n'.join(asm)+'\n')
    main=out/(lane+'.c')
    main.write_text('#include <stdio.h>\n#include <stdint.h>\nstruct result {int64_t v,s;};extern struct result fenrir_entry(int64_t);extern uint64_t counters[];void fen_write(const char*p,size_t n){fwrite(p,1,n,stderr);}void fen_write_i64(int64_t n){fprintf(stderr,"%lld",(long long)n);}\nint main(void){struct result r=fenrir_entry(1);if(r.v!='+str(expected)+'||r.s)return 1;for(int i=0;i<'+str(len(keys))+';i++)printf("%llu\\n",(unsigned long long)counters[i]);return 0;}')
    subprocess.run(['clang','-arch','arm64','-O2',main,source,'runtime/native/heap.c','runtime/native/managed.c','-o',image],check=True)
    counts=list(map(int,subprocess.check_output([image],timeout=5).splitlines()))
    assert len(counts)==len(keys)
    detail=collections.defaultdict(dict)
    for (fn,op),i in keys.items(): detail[fn][op]=counts[i]
    totals={n:sum(v.values()) for n,v in detail.items()}
    report=dict(scope='generated ARM64 instructions executed for one verified corpus round; runtime and caller excluded',artifact_sha256=hashlib.sha256(artifact.read_bytes()).hexdigest(),assembly_sha256=hashlib.sha256(plain.read_bytes()).hexdigest(),result=expected,total=sum(totals.values()),by_function=totals,detail=detail)
    (out/(lane+'.json')).write_text(json.dumps(report,indent=2)+'\n')
    print(lane, report['total'],sorted(totals.items(),key=lambda item:-item[1])[:5])
