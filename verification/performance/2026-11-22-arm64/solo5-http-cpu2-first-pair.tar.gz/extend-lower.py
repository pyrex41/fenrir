import json
from pathlib import Path
import runpy
import select
import subprocess
import sys

root = Path(__file__).resolve().parent
grid = root / "grid"
pid = int(sys.argv[1])
events = select.kqueue()
watch = select.kevent(pid, filter=select.KQ_FILTER_PROC, flags=select.KQ_EV_ADD,
                      fflags=select.KQ_NOTE_EXIT)
try:
    events.control([watch], 1, 7200)
except ProcessLookupError:
    pass
capacity = runpy.run_path(str(root / "benchmarks/http/capacity.py"))["summarize"]
result = capacity(grid)
if any(v in ("missing", "excluded") for rates in result["observations"].values()
       for trials in rates.values() for v in trials):
    sys.exit("prior grid incomplete")
if any(b["sustained"] is None for b in result["capacity_bounds"].values()):
    subprocess.run([sys.executable, root / "benchmarks/http/sweep.py", root / "bin", root / "lower",
                    "--target", "solo5", "--guest-cpu", "2", "--driver-from", grid,
                    "--seconds", "600", "--blocks", "2", "--rates", "2000", "3500"],
                   check=True, timeout=6000)
    (root / "combined-capacity.json").write_text(json.dumps(capacity(grid, root / "lower"), indent=2))
