import collections, json, random, statistics, pathlib
p=pathlib.Path(__file__).resolve().parent
orders=[s.split() for s in (p/'orders').read_text().splitlines()]
rows=[s.split() for s in (p/'raw').read_text().splitlines()]
assert len(orders)==30 and len(rows)==150
assert (p/'stress.log').read_text().split()[0]=='2000'
for column in zip(*orders):
    assert set(collections.Counter(column).values())=={6}
blocks=[]
for i,order in enumerate(orders):
    samples=rows[i*5:i*5+5]
    assert [r[0] for r in samples]==order
    assert all(value=='500000' and int(ns)>0 for _,value,ns in samples)
    blocks.append({k:int(ns) for k,_,ns in samples})
rng=random.Random(712)
out={}
for a,b in [('atom','base'),('unboxed','base'),('both','base'),('both','atom'),('both','unboxed'),('both','compact')]:
    ratios=[r[a]/r[b] for r in blocks]
    boot=sorted(statistics.median(rng.choices(ratios,k=len(ratios))) for _ in range(10000))
    out[a+'/'+b]=dict(median=statistics.median(ratios),interval=[boot[249],boot[9749]])
print(json.dumps(out,indent=2))
