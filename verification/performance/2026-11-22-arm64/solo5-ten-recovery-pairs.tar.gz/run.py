import hashlib,json,os,subprocess,sys,statistics,random
from pathlib import Path
root,out,first=map(Path,sys.argv[1:])
def receipt(log):
    case=Path(next(l.split(': ',1)[1] for l in log.read_text().splitlines() if l.startswith('Recovery evidence: ')))
    history=json.loads((case/'history.json').read_bytes())
    timing=json.loads((case/'timings.json').read_bytes())
    verdict=json.loads((case/'check/verdicts.jsonl').read_bytes())
    assert verdict['verdict']=='accepted' and verdict['events']==len(history['events']) and verdict['history']==str(case/'history.json')
    return case,history,timing
workers=['fenrir-native-spt','c-native-spt']
initial={w:receipt(first/(w+'.log')) for w in workers}
image=(initial[workers[0]][0]/'container.id').read_text().strip()
rows=[]
for i in range(10):
    row={}
    for worker in (workers if i%2==0 else reversed(workers)):
        log=(out/f'{i}-{worker}.log') if i else first/(worker+'.log')
        if i:
            with log.open('x') as f:subprocess.run(['sh','host/service/check-supervised-recovery.sh',worker],env=dict(os.environ,FENRIR_RECOVERY_IMAGE=image),cwd=root,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=180)
        case,h,t=receipt(log)
        assert h['worker_implementation']==worker and h['events']==initial[workers[0]][1]['events']
        assert (case/'container.id').read_text().strip()==image
        assert (case/'native.spt').read_bytes()==(initial[worker][0]/'native.spt').read_bytes()
        assert t['sqlite_connection_before_and_after_restart']==initial[workers[0]][2]['sqlite_connection_before_and_after_restart']
        row[worker]=dict(case=str(case),timing=t)
    rows.append(row)
    (out/'pairs.json').write_text(json.dumps(rows,indent=2))
ratios=[r[workers[0]]['timing']['worker_kill_to_successful_retry_us']/r[workers[1]]['timing']['worker_kill_to_successful_retry_us'] for r in rows]
rng=random.Random(20261122)
dist=sorted(statistics.median(rng.choices(ratios,k=10)) for _ in range(10000))
summary=dict(pairs=10,median_us={w:statistics.median(r[w]['timing']['worker_kill_to_successful_retry_us'] for r in rows) for w in workers},paired_ratio=statistics.median(ratios),bootstrap95=[dist[249],dist[9749]],container=image)
(out/'summary.json').write_text(json.dumps(summary,indent=2))
