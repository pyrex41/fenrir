import hashlib,json,statistics,sys,tarfile
from pathlib import Path
from runpy import run_path
root,out,archive=map(Path,sys.argv[1:])
shared=run_path(str(root/'benchmarks/durable/compare-recovery.py'))
pairs=json.loads((out/'pairs.json').read_bytes())
summary=json.loads((out/'summary.json').read_bytes())
assert len(pairs)==summary['pairs']==10
workers=['fenrir-native-spt','c-native-spt']
fields=['worker_kill_to_successful_retry_us','worker_kill_to_replacement_observed_us',
        'replacement_observed_to_successful_retry_us','runner_start_to_verified_empty_us']
medians={w:{k:statistics.median(row[w]['timing'][k] for row in pairs) for k in fields} for w in workers}
assert summary['median_us']=={w:medians[w][fields[0]] for w in workers}
with tarfile.open(archive,'w:gz') as tar:
 for i,row in enumerate(pairs):
    assert list(row)==(workers if i%2==0 else workers[::-1])
    for w,item in row.items():
        p=Path(item['case']);t=json.loads((p/'timings.json').read_bytes())
        h=json.loads((p/'history.json').read_bytes());v=json.loads((p/'check/verdicts.jsonl').read_bytes())
        shared['check_recovery_timings'](t,h)
        assert t==item['timing'] and v['verdict']=='accepted' and v['events']==18
        for line in (p/'native.sha256').read_text().splitlines():
            digest,name=line.split('  ',1)
            assert hashlib.sha256((p/Path(name).name).read_bytes()).hexdigest()==digest
        for name in ['timings.json','history.json','fault.json','native.sha256','container.id','check/verdicts.jsonl']:
            tar.add(p/name,arcname=f'{i}/{w}/{name}')
 (out/'phase-medians.json').write_text(json.dumps(medians,indent=2))
 for name in ['summary.json','phase-medians.json','pairs.json','run.py','verify.py']:tar.add(out/name,arcname=name)
print(json.dumps(summary));print(json.dumps(medians))
