/* Representation control for the prover benchmark.
 *
 * Formulae are immutable pointer graphs and pending work is an immutable
 * singly-linked queue.  Appending copies the queue cells, matching the
 * algebraic Queue/More representation used by the Fenrir implementation.
 * This file intentionally keeps the same tableau order and proof protocol as
 * reference.c.  It is an experiment, not the production reference.
 */
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>

enum { REPRESENTATION_SLOT_BYTES = 80 };
enum { MAX_FORMULA = 64, MAX_PROOF = 256 };

typedef struct {
    char op[MAX_FORMULA];
    unsigned right[MAX_FORMULA];
} formula;
typedef enum { PROOF, COUNTERMODEL, EXHAUSTED, INVALID } outcome;
typedef struct {
    unsigned fuel, model, cursor;
    char generated[MAX_PROOF];
    const char *supplied;
    size_t length;
} traversal;
typedef struct {
    formula f;
    const char *proof;
    unsigned budget, nodes, model;
    outcome expected;
} test_case;
#include "corpus.h"

typedef struct formula_node formula_node;
struct formula_node {
    char op;
    formula_node *left;
    formula_node *right;
};
typedef struct queue_node queue_node;
struct queue_node {
    bool sign;
    const formula_node *formula;
    const queue_node *next;
};
typedef union {
    formula_node node;
    unsigned char slot[REPRESENTATION_SLOT_BYTES];
} formula_slot;
typedef union {
    queue_node node;
    unsigned char slot[REPRESENTATION_SLOT_BYTES];
} queue_slot;
enum { REPRESENTATION_FORMULA_CAP = 1024, REPRESENTATION_QUEUE_CAP = 65536 };
static formula_slot formula_pool[REPRESENTATION_FORMULA_CAP];
static queue_slot queue_pool[REPRESENTATION_QUEUE_CAP];
static unsigned formula_used, queue_used;
/* These counters are read by the diagnostic host.  They do not affect the
 * result and are deliberately absent from the normal compact C reference. */
uint64_t representation_formula_allocations;
uint64_t representation_queue_allocations;
uint64_t representation_queue_cells_copied;
uint64_t representation_case_steps[MAX_FORMULA];
int representation_case_outcomes[MAX_FORMULA];

static formula_node *make_formula(const formula *f, unsigned index) {
    if (formula_used == REPRESENTATION_FORMULA_CAP) __builtin_trap();
    formula_slot *slot = &formula_pool[formula_used++];
    formula_node *node = &slot->node;
    ++representation_formula_allocations;
    node->op = f->op[index];
    if (node->op == '!') {
        node->left = make_formula(f, index + 1);
    } else if (node->op < 'a' || node->op > 'z') {
        node->left = make_formula(f, index + 1);
        node->right = make_formula(f, f->right[index]);
    }
    return node;
}

static queue_node *new_queue_cell(bool sign, const formula_node *formula,
                                  const queue_node *next) {
    if (queue_used == REPRESENTATION_QUEUE_CAP) __builtin_trap();
    queue_slot *slot = &queue_pool[queue_used++];
    queue_node *node = &slot->node;
    ++representation_queue_allocations;
    node->sign = sign;
    node->formula = formula;
    node->next = next;
    return node;
}

static queue_node *append_suffix(const queue_node *queue,
                                 const queue_node *suffix) {
    if (!queue) return (queue_node *)suffix;
    ++representation_queue_cells_copied;
    return new_queue_cell(queue->sign, queue->formula,
                          append_suffix(queue->next, suffix));
}

static queue_node *append_one(const queue_node *queue, bool sign,
                              const formula_node *formula) {
    return append_suffix(queue, new_queue_cell(sign, formula, NULL));
}

static bool rule(traversal *t, char op) {
    if (t->cursor == MAX_PROOF) return false;
    if (t->supplied) {
        if (t->cursor >= t->length || t->supplied[t->cursor] != op) return false;
    } else {
        t->generated[t->cursor] = op;
    }
    ++t->cursor;
    return true;
}

static outcome visit(const queue_node *queue, unsigned pos, unsigned neg,
                     traversal *t) {
    for (;;) {
        if (!t->supplied) {
            if (!t->fuel) return EXHAUSTED;
            --t->fuel;
        }
        if (!queue) {
            t->model = pos;
            return t->supplied ? INVALID : COUNTERMODEL;
        }
        bool sign = queue->sign;
        const formula_node *f = queue->formula;
        queue = queue->next;
        char op = f->op;
        if (op >= 'a' && op <= 'z') {
            unsigned bit = 1u << (op - 'a');
            if ((sign ? neg : pos) & bit) return rule(t, 'x') ? PROOF : INVALID;
            if (sign) pos |= bit;
            else neg |= bit;
        } else {
            bool left_sign = sign;
            if (op == '>' || op == '!') left_sign = !sign;
            if (op == '!') {
                queue = append_one(queue, left_sign, f->left);
            } else {
                if ((op == '&') != sign) {
                    if (!rule(t, 'b')) return INVALID;
                    const queue_node *branch = append_one(queue, left_sign, f->left);
                    outcome first = visit(branch, pos, neg, t);
                    if (first != PROOF) return first;
                    queue = append_one(queue, sign, f->right);
                    continue;
                }
                queue_node *suffix = new_queue_cell(sign, f->right, NULL);
                suffix = new_queue_cell(left_sign, f->left, suffix);
                queue = append_suffix(queue, suffix);
            }
        }
        if (!rule(t, 's')) return INVALID;
    }
}

typedef struct {
    formula_node *root;
    const char *proof;
    unsigned budget, nodes, model;
    outcome expected;
} representation_case;

static representation_case prepared[sizeof cases / sizeof *cases];
static bool prepared_once;

static void prepare(void) {
    if (prepared_once) return;
    for (unsigned i = 0; i < sizeof cases / sizeof *cases; ++i) {
        prepared[i].root = make_formula(&cases[i].f, 0);
        prepared[i].proof = cases[i].proof;
        prepared[i].budget = cases[i].budget;
        prepared[i].nodes = cases[i].nodes;
        prepared[i].model = cases[i].model;
        prepared[i].expected = cases[i].expected;
    }
    prepared_once = true;
}

void representation_prepare(void) { prepare(); }
void representation_reset_queue(void) { queue_used = 0; }

static outcome evaluate_formula(const formula_node *root, traversal *t) {
    queue_node initial;
    initial.sign = false;
    initial.formula = root;
    initial.next = NULL;
    outcome result = visit(&initial, 0, 0, t);
    return t->supplied && t->cursor != t->length ? INVALID : result;
}

static int64_t check_mutations(void) {
    int64_t rejected = 0;
    for (unsigned i = 0; i < sizeof prepared / sizeof *prepared; ++i) {
        const representation_case *c = &prepared[i];
        representation_reset_queue();
        char tape[MAX_PROOF];
        size_t size = 0;
        while (c->proof[size]) {
            if (size + 1 >= sizeof tape) return -1;
            tape[size] = c->proof[size];
            ++size;
        }
        if (!size) return -1;
        traversal t;
        t.fuel = 0; t.model = 0; t.cursor = 0;
        t.generated[0] = 0; t.supplied = tape; t.length = size - 1;
        rejected += evaluate_formula(c->root, &t) == INVALID;
        representation_reset_queue();
        tape[size] = 'x'; t.cursor = 0; t.length = size + 1;
        rejected += evaluate_formula(c->root, &t) == INVALID;
        representation_reset_queue();
        tape[size - 1] = '?'; t.cursor = 0; t.length = size;
        rejected += evaluate_formula(c->root, &t) == INVALID;
    }
    return rejected;
}

struct outcome_value { int64_t value; uint64_t status; };
struct outcome_value fenrir_entry(int64_t rounds) {
    prepare();
    if (!rounds && checking) return (struct outcome_value){check_mutations(), 0};
    int64_t passed = 0;
    for (int64_t round = 0; round < rounds; ++round) {
        for (unsigned i = 0; i < sizeof prepared / sizeof *prepared; ++i) {
            const representation_case *c = &prepared[i];
            representation_reset_queue();
            size_t length = 0;
            while (c->proof[length]) ++length;
            traversal t;
            t.fuel = c->budget; t.model = 0; t.cursor = 0;
            t.generated[0] = 0; t.supplied = checking ? c->proof : NULL;
            t.length = length;
            outcome actual = evaluate_formula(c->root, &t);
            representation_case_steps[i] = checking ? t.cursor : c->budget - t.fuel;
            representation_case_outcomes[i] = actual;
            if (actual != c->expected) continue;
            if (!checking && c->budget - t.fuel != c->nodes) continue;
            if (c->expected == COUNTERMODEL && t.model != c->model) continue;
            if (c->expected == PROOF && !checking) {
                if (length != t.cursor) continue;
                size_t j = 0;
                while (j < length && t.generated[j] == c->proof[j]) ++j;
                if (j < length) continue;
            }
            ++passed;
        }
    }
    return (struct outcome_value){passed, 0};
}
