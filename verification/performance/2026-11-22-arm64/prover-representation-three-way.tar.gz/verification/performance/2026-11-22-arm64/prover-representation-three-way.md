# Prover representation-control diagnostic

This is an exploratory Solo5 run on the shared Linux host, pinned to CPU 1
(`--cpuset-cpus=1`). It is not an isolated macOS/ARM64 result. Each lane ran
12 alternating pairs of Fenrir, compact C, and the representation-control C
guest, with 5,000 search rounds or 3,000 checker rounds per invocation.

The representation control uses immutable formula pointer graphs and an
immutable singly-linked pending queue. Queue cells and formula nodes are
allocated from explicit 80-byte slots; formula preparation is outside the
timed interval. Both successors of a non-branching binary rule are built as
one suffix, then appended by copying the existing pending prefix. The compact
C and Fenrir guests are unchanged.

| lane | compact C median | representation C median | Fenrir median | representation / compact | Fenrir / compact |
| --- | ---: | ---: | ---: | ---: | ---: |
| search | 2,145,551 ns | 2,930,867 ns | 14,201,375 ns | 1.35x | 6.60x |
| check | 1,295,319 ns | 2,216,614 ns | 8,102,682 ns | 1.70x | 6.31x |

All outputs agreed: search returned 50,000 and check returned 30,000 in every
timed invocation. Representation counters were stable at 69 formula nodes,
605,000 queue-cell allocations and 300,000 copied queue cells for search, and
45 formula nodes, 520,000 queue-cell allocations and 275,000 copied cells for
check. Thus the control is substantially slower than compact C, but still
well ahead of Fenrir in this diagnostic. The result does not isolate generated
code from allocation strategy: the control uses a static pool and has no GC,
while Fenrir's separately instrumented guests report 31 search and 28 check
append allocations per round.

Raw alternating output is in `three-way-diagnostic.txt`; it includes the
per-run RSS sample and the representation counters.
