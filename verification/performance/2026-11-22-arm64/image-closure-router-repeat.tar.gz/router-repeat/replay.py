import hashlib,json,random,statistics,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
report=json.loads((root/'report.json').read_text())
order=['fenrir','c','c','fenrir']*13
rounds=1000
for name in set(order):
    p=root/(name+'.spt')
    assert hashlib.sha256(p.read_bytes()).hexdigest()==report['sha256'][p.name]
raw=subprocess.check_output(['docker','run','--rm','--network','none','--platform','linux/arm64','--cpuset-cpus','1','-v',f'{root}:/work:ro','-w','/work','--entrypoint','sh',report['container'],'-ec','rounds=$1; shift; for n do /opt/solo5-install/bin/solo5-spt "$n.spt" --solo5:quiet "$rounds"; done','sh',str(rounds),*order],text=True,timeout=180)
rows=[list(map(int,line.split())) for line in raw.splitlines()]
assert len(rows)==len(order) and all(v==rounds*report['heads_per_round'] and t>0 for v,t in rows)
pairs=[dict(zip(order[i:i+2],[r[1] for r in rows[i:i+2]])) for i in range(0,len(order),2)]
ratios=[p['fenrir']/p['c'] for p in pairs[2:]]
rng=random.Random(1147)
boot=sorted(statistics.median(rng.choices(ratios,k=len(ratios))) for _ in range(10000))
s=dict(cpu=1,rounds=rounds,order=order,rows=rows,warmup_pairs=2,median=statistics.median(ratios),interval=[boot[249],boot[9749]])
(root/'repeat.json').write_text(json.dumps(s,indent=2)+'\n')
print(s['median'],s['interval'],rows[0][0])
