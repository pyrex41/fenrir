"""Regression cases at the sustainable-rate evidence boundary."""
from copy import deepcopy
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from runpy import run_path
import unittest

assess = run_path(str(Path(__file__).with_name("assess-rate.py")))["assess"]


def valid_row():
    return dict(Seconds=600, Rate=10, Connections=2, Scheduled=6000, Valid=6000,
                Invalid=0, Errors=0, Missed=0, ElapsedNs=600_000_010_000,
                P50ns=100, P99ns=200, MaxNs=400,
                Timeline=[dict(Second=i, Scheduled=min(6000, i*10+1),
                               Completed=i*10, Backlog=int(i<600), ObservedNs=i*10**9)
                          for i in range(1, 601)])


class Assessment(unittest.TestCase):
    def test_single_capacity_sweep_requires_the_driver_and_servers(self):
        summarize = run_path(str(Path(__file__).with_name("capacity.py")))["summarize"]
        with TemporaryDirectory() as tmp:
            folder = Path(tmp)
            env = dict(target="mac", blocks=1, rates=[100], binaries={
                role: "a" * 64 for role in ("fenrir", "rust", "nim")
            })
            (folder / "environment.json").write_text(json.dumps(env))
            with self.assertRaisesRegex(ValueError, "incomplete benchmark binary identities"):
                summarize(folder)

    def test_release_requires_replicated_capacity_and_latency(self):
        service_gate = run_path(str(Path(__file__).with_name("paired-latency.py")))["service_gate"]
        def gate(*args):
            return service_gate(*args, origin_version=1)

        meets = "meets-threshold"
        self.assertEqual(gate(1, meets, True, meets), "undetermined")
        self.assertEqual(gate(10, meets, False, meets), "undetermined")
        self.assertEqual(gate(10, "undetermined", True, meets), "undetermined")
        self.assertEqual(gate(10, meets, True, meets), "passed")
        self.assertEqual(gate(10, "below-threshold", False, "undetermined"), "failed")
        self.assertEqual(gate(10, meets, True, "above-threshold"), "failed")

        for version in (None, True, 2):
            self.assertEqual(service_gate(10, meets, True, meets, origin_version=version), "undetermined")

    def test_sample_origin(self):
        verify = run_path(str(Path(__file__).with_name("assess-rate.py")))["verify_sample_origin"]
        env = dict(target="mac", sample_origin_version=1)
        origin = dict(worker="nim", position=0, environment_sha256="digest")
        verify({"Origin": origin}, env, "nim", 1, 1, "digest")
        for change in (dict(worker="rust"), dict(position=1), dict(environment_sha256="other")):
            with self.assertRaises(ValueError):
                verify({"Origin": {**origin, **change}}, env, "nim", 1, 1, "digest")
        with self.assertRaises(ValueError):
            verify({}, env, "nim", 1, 1, "digest")

    def test_latency_requires_valid_responses_within_the_run(self):
        row = valid_row()
        row.update(Valid=0, Invalid=row["Scheduled"])
        with self.assertRaisesRegex(ValueError, "without a valid response"):
            assess(row)
        row.update(P50ns=0, P99ns=0, MaxNs=0)
        self.assertEqual(assess(row)["verdict"], "invalid-response")
        row = valid_row()
        row["MaxNs"] = row["ElapsedNs"] + 1
        with self.assertRaisesRegex(ValueError, "latency distribution"):
            assess(row)

    def test_completions_after_final_sample(self):
        row = valid_row()
        row["Timeline"][-1].update(Completed=5996, Backlog=4)
        row.update(Valid=5998, Missed=2)
        result = assess(row)["completion_window"]
        self.assertEqual(result, dict(completed_by_last_sample=5996, completed_after_last_sample=2,
                                      last_sample_ns=600_000_000_000, remaining_wall_ns=10000))

    def test_complete(self):
        self.assertEqual(assess(valid_row())["verdict"], "sustained-at-offered-rate")

    def test_decreasing_tender_peak(self):
        row = valid_row()
        before = dict(tender_rss_bytes=8192, tender_lifetime_hwm_bytes=16384,
                      vm_total_bytes=65536, vm_available_bytes=32768)
        row["Solo5Memory"] = dict(container_id="a"*64, before=before,
                                  after={**before, "tender_lifetime_hwm_bytes": 12288})
        result = assess(row)
        self.assertEqual(result["verdict"], "sustained-at-offered-rate")
        self.assertEqual(result["solo5_memory"]["tender_hwm_status"], "inconsistent")
        self.assertIsNone(result["solo5_memory"]["tender_lifetime_peak_bytes"])

    def test_errors(self):
        row = valid_row()
        row.update(Valid=5994, Errors=6)
        self.assertEqual(assess(row)["verdict"], "failed-response-criteria")
        row.update(Valid=5995, Errors=5)
        self.assertEqual(assess(row)["verdict"], "sustained-at-offered-rate")
        row.update(Errors=4, Invalid=1)
        self.assertEqual(assess(row)["verdict"], "invalid-response")
        bounds = run_path(str(Path(__file__).with_name("capacity.py")))["bounds"]
        self.assertEqual(bounds({10: ["invalid-response"]}), {"sustained": None, "failed": None})

    def test_transport_error_census(self):
        row = valid_row()
        row.update(Errors=1, Valid=5999, ErrorKinds={"timeout": 1})
        for sample in row["Timeline"]:
            sample["Errors"] = int(sample["Second"] >= 30)
        self.assertEqual(assess(row)["error_kinds"], {"timeout": 1})
        with self.assertRaises(ValueError):
            assess(dict(row, ErrorKinds={}))
        row["Timeline"][31]["Errors"] = 0
        with self.assertRaises(ValueError):
            assess(row)

    def test_missing_and_corrupt(self):
        row = valid_row()
        for key, value in [("Timeline", row["Timeline"][:-1]), ("Valid", 5999),
                           ("ElapsedNs", 500_000_000_000), ("P99ns", 401)]:
            with self.subTest(key=key), self.assertRaises(ValueError):
                assess(dict(row, **{key:value}))
        for key, value in [("Scheduled", 0), ("Completed", 6000), ("ObservedNs", 1)]:
            broken = deepcopy(row)
            broken["Timeline"][25][key] = value
            with self.subTest(key=key), self.assertRaises(ValueError):
                assess(broken)

    def test_census_requires_whole_requests(self):
        row = valid_row()
        for invalid in [dict(row, Valid=5999.5, Errors=0.5), dict(row, Errors=False)]:
            with self.assertRaises(ValueError):
                assess(invalid)
        row["Timeline"][0].update(Completed=10.5, Backlog=0.5)
        with self.assertRaises(ValueError):
            assess(row)

    def test_process_resources(self):
        row = valid_row()
        row["ServerResources"] = dict(cpu_seconds=12, cpu_us_per_completed=2000,
            max_sampled_rss_bytes=4096, samples=[
                dict(elapsed_ns=1, cpu_seconds=2, rss_bytes=4096),
                dict(elapsed_ns=6_000_000_001, cpu_seconds=14, rss_bytes=2048)])
        self.assertEqual(assess(row)["process_resources"]["average_cpu_cores"], 2)
        resources = row["ServerResources"]
        self.assertIsNone(assess(row)["process_resources"]["host_cpu"])
        for sample, driver in zip(resources["samples"], [215.0, None]):
            sample["host_cpu"] = dict(server_percent=130, driver_percent=driver, other_processes_percent=10)
        summary = assess(row)["process_resources"]["host_cpu"]
        self.assertEqual(summary["driver_percent"], dict(samples=1, median=215, peak=215))
        self.assertEqual(summary["other_processes_percent"]["samples"], 2)
        resources["samples"][0]["host_cpu"]["driver_percent"] = -1
        with self.assertRaises(ValueError):
            assess(row)
        resources["samples"][0]["host_cpu"]["driver_percent"] = 215
        row["ServerResources"]["cpu_us_per_completed"] = 1750
        with self.assertRaisesRegex(ValueError, "resource summary"):
            assess(row)

    def test_phase_histograms(self):
        row = valid_row()
        bins = [5940, 60] + [0] * 62
        row["ValidRequestPhases"] = dict.fromkeys(("PreviousRequest", "Dispatch", "Fetch"), bins)
        self.assertEqual(assess(row)["phase_p99_upper_ms"]["Dispatch"], 0)
        bins[:2] = [5939, 61]
        self.assertEqual(assess(row)["phase_p99_upper_ms"]["Dispatch"], 0.000001)
        bins[0] -= 1
        with self.assertRaises(ValueError):
            assess(row)

    def test_lane_origin_matches_immediate_predecessor(self):
        row = valid_row()
        row["MaxNs"] = 300_000_000
        row["SlowestValid"] = dict(Index=4, Lane=0, ElapsedNs=row["MaxNs"],
                                   PreviousRequestNs=50_000_000, DispatchNs=0, FetchNs=250_000_000)
        origin = dict(Index=2, Lane=0, ElapsedNs=250_000_000,
                      PreviousRequestNs=0, DispatchNs=0, FetchNs=250_000_000, Valid=True)
        row["SlowestLaneOrigin"] = origin
        assess(row)
        for change in (dict(ElapsedNs=249_999_999, FetchNs=249_999_999), dict(Valid=False),
                       dict(Lane=1), dict(ElapsedNs=301_000_000, FetchNs=301_000_000)):
            with self.subTest(change=change), self.assertRaises(ValueError):
                assess(dict(row, SlowestLaneOrigin=dict(origin, **change)))
        assess(dict(row, SlowestValid=dict(row["SlowestValid"], PreviousRequestNs=0,
                                          FetchNs=row["MaxNs"]), SlowestLaneOrigin=dict(
                                              row["SlowestValid"], PreviousRequestNs=0,
                                              FetchNs=row["MaxNs"], Valid=True)))

    def test_backlog(self):
        row = valid_row()
        for s in row["Timeline"][-60:]:
            s["Completed"] -= 4
            s["Backlog"] += 4
        self.assertEqual(assess(row)["verdict"], "backlog-clearance-unconfirmed")

    def test_separated_rising_minute_ranges_bound_capacity(self):
        row = valid_row()
        for sample in row["Timeline"]:
            backlog = 3 + sample["Second"]
            sample.update(Backlog=backlog, Completed=sample["Scheduled"] - backlog)
        self.assertEqual(assess(row)["verdict"], "growing-backlog")
        bounds = run_path(str(Path(__file__).with_name("capacity.py")))["bounds"]
        self.assertEqual(bounds({10: ["growing-backlog", "failed-response-criteria"]})["failed"], 10)
        self.assertIsNone(bounds({10: ["growing-backlog", "missing"]})["failed"])
        # Touching ranges can also arise from a burst followed by a plateau.
        sample = row["Timeline"][60]
        sample.update(Backlog=63, Completed=sample["Scheduled"] - 63)
        self.assertEqual(assess(row)["verdict"], "backlog-clearance-unconfirmed")

    def test_late_sample_does_not_prove_sustained_rate(self):
        row = valid_row()
        delayed = row["Timeline"][99]
        delayed.update(ObservedNs=101 * 10**9, Scheduled=1011, Backlog=11)
        result = assess(row)
        self.assertEqual(result["verdict"], "sampling-cadence-unconfirmed")
        self.assertEqual(result["late_sample_seconds"], [100])
        self.assertEqual(result["max_observed_sample_delay_ns"], 10**9)
        delayed["ObservedNs"] += 1
        with self.assertRaisesRegex(ValueError, "sampling clock"):
            assess(row)

    def test_legacy(self):
        row = valid_row()
        for s in row["Timeline"]:
            del s["ObservedNs"]
        self.assertEqual(assess(row)["verdict"], "sustained-at-offered-rate")
        row["ElapsedNs"] += 2_000_000_000
        self.assertEqual(assess(row)["verdict"], "sampling-cadence-unconfirmed")


if __name__ == "__main__":
    unittest.main()
