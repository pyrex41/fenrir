
#include "/src/runtime/native/heap.h"
#define fenrir_entry http_benchmark_entry
#include "/src/benchmarks/prover/timed-spt.c"
#include "router-loop.h"
