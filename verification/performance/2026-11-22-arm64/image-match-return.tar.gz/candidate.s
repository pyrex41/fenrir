.text
.p2align 2
Lfn0:
ldr w2, [x0, #72]
cmp w2, #7
b.ne Lfn0frame
adrp x0, Lconstant0
add x0, x0, :lo12:Lconstant0
mov x1, #0
ret
Lfn0frame:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
str x0, [sp, #48]
add x0, sp, #16
add x1, sp, #48
mov x2, #1
bl fen_enter
ldr x0, [sp, #48]
ldr w0, [x0, #72]
cmp w0, #7
b.eq Lfn0match2arm7
cmp w0, #8
b.eq Lfn0match2arm8
brk #0
Lfn0match2arm7:
adrp x0, Lconstant0
add x0, x0, :lo12:Lconstant0
b Lfn0match2end
Lfn0match2arm8:
ldr x0, [sp, #48]
ldr x0, [x0, #0]
adds x0, x0, #1
b.vs Lfn0fail8_1
str x0, [sp, #56]
mov x0, #0
mov x1, #10
bl fen_allocate_full
cbz x0, Lfn0fail7_3
ldr x2, [sp, #56]
str x2, [x0, #0]
b Lfn0match2end
Lfn0match2end:
mov x1, #0
b Lfn0end
Lfn0fail8_1:
adrp x0, Lfn0fail8_1location
add x0, x0, :lo12:Lfn0fail8_1location
bl fen_set_location
mov x1, #1
b Lfn0end
Lfn0fail7_3:
adrp x0, Lfn0fail7_3location
add x0, x0, :lo12:Lfn0fail7_3location
bl fen_set_location
mov x1, #3
b Lfn0end
Lfn0end:
bl fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn1:
ldp x8, x9, [x0, #0]
ldr x10, [x0, #16]
Lfn1fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
stp x19, x20, [sp, #-16]!
sub sp, sp, #96
str xzr, [sp, #56]
mov x19, x8
str x9, [sp, #48]
mov x20, x10
add x0, sp, #16
add x1, sp, #48
mov x2, #2
bl fen_enter
Lfn1loop:
mov x0, x19
cmp x0, #0
b.ne Lfn1if25else
mov x0, x20
b Lfn1if25done
Lfn1if25else:
ldr x0, [sp, #48]
bl Lfn0
cbnz x1, Lfn1end
str x0, [sp, #56]
ldr w0, [x0, #72]
cmp w0, #9
b.eq Lfn1match30arm9
cmp w0, #10
b.eq Lfn1match30arm10
brk #0
Lfn1match30arm9:
mov x0, x19
subs x0, x0, #1
b.vs Lfn1fail36_1
str x0, [sp, #64]
mov x0, x20
ldr x2, [sp, #56]
ldr x2, [x2, #0]
adds x0, x0, x2
b.vs Lfn1fail40_1
str x0, [sp, #72]
ldr x8, [sp, #64]
ldr x9, [sp, #72]
mov x19, x8
mov x20, x9
str xzr, [sp, #56]
b Lfn1loop
b Lfn1match30end
Lfn1match30arm10:
mov x0, x19
subs x0, x0, #1
b.vs Lfn1fail46_1
str x0, [sp, #80]
mov x0, x20
ldr x2, [sp, #56]
ldr x2, [x2, #0]
adds x0, x0, x2
b.vs Lfn1fail50_1
str x0, [sp, #88]
ldr x8, [sp, #80]
ldr x9, [sp, #88]
mov x19, x8
mov x20, x9
str xzr, [sp, #56]
b Lfn1loop
b Lfn1match30end
Lfn1match30end:
Lfn1if25done:
mov x1, #0
b Lfn1end
Lfn1fail36_1:
adrp x0, Lfn1fail36_1location
add x0, x0, :lo12:Lfn1fail36_1location
bl fen_set_location
mov x1, #1
b Lfn1end
Lfn1fail40_1:
adrp x0, Lfn1fail40_1location
add x0, x0, :lo12:Lfn1fail40_1location
bl fen_set_location
mov x1, #1
b Lfn1end
Lfn1fail46_1:
adrp x0, Lfn1fail46_1location
add x0, x0, :lo12:Lfn1fail46_1location
bl fen_set_location
mov x1, #1
b Lfn1end
Lfn1fail50_1:
adrp x0, Lfn1fail50_1location
add x0, x0, :lo12:Lfn1fail50_1location
bl fen_set_location
mov x1, #1
b Lfn1end
Lfn1end:
bl fen_leave_result
ldp x19, x20, [x29, #-16]
mov sp, x29
ldp x29, x30, [sp], #16
ret
.globl fenrir_entry
fenrir_entry:
Lfn2:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #96
str xzr, [sp, #48]
str x0, [sp, #56]
add x0, sp, #16
add x1, sp, #48
mov x2, #1
bl fen_enter
ldr x0, [sp, #56]
cmp x0, #0
b.ge Lfn2if55else
movz x0, #1, lsl #0
str x0, [sp, #64]
movz x0, #0, lsl #0
ldr x2, [sp, #56]
subs x0, x0, x2
b.vs Lfn2fail63_1
str x0, [sp, #72]
mov x0, #0
mov x1, #8
bl fen_allocate_full
cbz x0, Lfn2fail62_3
ldr x2, [sp, #72]
str x2, [x0, #0]
str x0, [sp, #48]
movz x0, #0, lsl #0
str x0, [sp, #80]
bl fen_leave_result
ldr x8, [sp, #64]
ldr x9, [sp, #48]
ldr x10, [sp, #80]
mov sp, x29
ldp x29, x30, [sp], #16
b Lfn1fields
b Lfn2if55done
Lfn2if55else:
movz x0, #0, lsl #0
str x0, [sp, #88]
bl fen_leave_result
ldr x8, [sp, #56]
adrp x9, Lconstant1
add x9, x9, :lo12:Lconstant1
ldr x10, [sp, #88]
mov sp, x29
ldp x29, x30, [sp], #16
b Lfn1fields
Lfn2if55done:
mov x1, #0
b Lfn2end
Lfn2fail63_1:
adrp x0, Lfn2fail63_1location
add x0, x0, :lo12:Lfn2fail63_1location
bl fen_set_location
mov x1, #1
b Lfn2end
Lfn2fail62_3:
adrp x0, Lfn2fail62_3location
add x0, x0, :lo12:Lfn2fail62_3location
bl fen_set_location
mov x1, #3
b Lfn2end
Lfn2end:
bl fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
.text
.globl fen_print_result
fen_print_result:
b Lprint0
Lprint0:
b fen_write_i64
.p2align 3
Lconstant0:
.quad 1
.zero 64
.long 9
.byte 0,2,0,0
Lfn0fail8_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,46,102,101,110,58,52,58,53,53,10,0
Lfn0fail7_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,46,102,101,110,58,52,58,52,56,10,0
Lfn1fail36_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,46,102,101,110,58,56,58,50,52,10,0
Lfn1fail40_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,46,102,101,110,58,56,58,51,52,10,0
Lfn1fail46_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,46,102,101,110,58,57,58,50,53,10,0
Lfn1fail50_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,46,102,101,110,58,57,58,51,53,10,0
.p2align 3
Lconstant1:
.zero 72
.long 7
.byte 0,2,0,0
Lfn2fail63_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,46,102,101,110,58,49,49,58,51,51,10,0
Lfn2fail62_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,46,102,101,110,58,49,49,58,50,55,10,0
