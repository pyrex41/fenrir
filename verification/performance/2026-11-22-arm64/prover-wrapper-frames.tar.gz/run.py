from pathlib import Path
import json,os,random,statistics,subprocess,sys
k=Path(sys.argv[1]);out=Path(__file__).parent
r=json.loads((k/'results/prover/report.json').read_bytes())
for lane,count in [('search',10)]:
 p=out/lane;p.mkdir();src=k/'results/prover'/lane
 lines=(src/'program.s').read_text().splitlines()
 for fn in range(12,22):
  a=lines.index(f'Lfn{fn}:');b=lines.index(f'Lfn{fn+1}:')
  body=lines[a:b]
  assert [line for line in body if line.startswith('bl ')]==['bl fen_enter','bl Lfn11fields','bl fen_equal','bl fen_leave_result']
  assert [line for line in body if '[sp, #48]' in line]==['str xzr, [sp, #48]','str x0, [sp, #48]']
  assert body.index('bl Lfn11fields')<body.index('str x0, [sp, #48]')<body.index('bl fen_equal')
  i=body.index('bl fen_enter')
  assert body[i-3:i]==['add x0, sp, #16','add x1, sp, #48','mov x2, #1']
  del body[i-3:i+1]
  lines[a:b]=[line for line in body if line not in ('str xzr, [sp, #48]','str x0, [sp, #48]','bl fen_leave_result')]
 (p/'candidate.s').write_text('\n'.join(lines)+'\n');(p/'baseline.spt').write_bytes((src/'program.spt').read_bytes())
 order=[('baseline','candidate') if i%2==0 else ('candidate','baseline') for i in range(26)]
 shell='export PATH=/opt/solo5-install/bin:$PATH FENRIR_SOLO5_MAIN=/src/benchmarks/prover/timed-spt.c; sh /src/tools/aarch64/link-spt.sh candidate.s candidate.spt; '
 if lane=='check':shell+='solo5-spt candidate.spt --solo5:quiet 0; '
 shell+='for n do solo5-spt "$n.spt" --solo5:quiet 50000; done'
 cmd=['docker','run','--rm','--network','none','--platform','linux/arm64','--cpuset-cpus','4','--user',f'{os.getuid()}:{os.getgid()}','-v',f'{k}/src:/src:ro','-v',f'{p}:/work','-w','/work','--entrypoint','sh',r['container'],'-ec',shell,'sh',*[v for pair in order for v in pair]]
 raw=subprocess.check_output(cmd,text=True,timeout=300);(p/'console.txt').write_text(raw);it=iter(raw.splitlines())
 if lane=='check':assert int(next(it).split()[0])==18
 samples=[]
 for pair in order:
  row={}
  for name in pair:
   answer,ns=map(int,next(it).split());assert answer==count*50000 and ns>0;row[name]=ns
  samples.append(row)
 assert next(it,None) is None
 ratios=[s['candidate']/s['baseline'] for s in samples[2:]];rng=random.Random(1147);boot=sorted(statistics.median(rng.choices(ratios,k=len(ratios))) for _ in range(10000))
 result=dict(median=statistics.median(ratios),interval=[boot[249],boot[9749]],samples=samples);(p/'result.json').write_text(json.dumps(result,indent=2));print(lane,result['median'],result['interval'],flush=True)
