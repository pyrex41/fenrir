.text
.p2align 2
.globl _fenrir_entry
_fenrir_entry:
Lfn0:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #80
str x0, [sp, #48]
movz x0, #1, lsl #0
ldr x2, [sp, #48]
cbz x2, Lfn0fail4_2
cmn x2, #1
b.ne 1f
negs x3, x0
b.vs Lfn0fail4_1
1:
sdiv x0, x0, x2
str x0, [sp, #56]
ldr x0, [sp, #48]
adds x0, x0, #1
b.vs Lfn0fail8_1
str x0, [sp, #64]
ldr x0, [sp, #48]
mov x1, #0
b Lfn0end
Lfn0fail4_2:
adrp x0, Lfn0fail4_2location@PAGE
add x0, x0, Lfn0fail4_2location@PAGEOFF
bl _fen_set_location
mov x1, #2
b Lfn0end
Lfn0fail4_1:
adrp x0, Lfn0fail4_1location@PAGE
add x0, x0, Lfn0fail4_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn0end
Lfn0fail8_1:
adrp x0, Lfn0fail8_1location@PAGE
add x0, x0, Lfn0fail8_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn0end
Lfn0end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
.text
.globl _fen_print_result
_fen_print_result:
b Lprint0
Lprint0:
b _fen_write_i64
Lfn0fail4_2location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,106,101,99,116,105,111,110,46,102,101,110,58,50,58,50,52,10,0
Lfn0fail4_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,106,101,99,116,105,111,110,46,102,101,110,58,50,58,50,52,10,0
Lfn0fail8_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,106,101,99,116,105,111,110,46,102,101,110,58,50,58,51,52,10,0
