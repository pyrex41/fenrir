import re
from pathlib import Path
d=Path(__file__).resolve().parent
s=(d/'base.s').read_text()
helpers=s[s.index('Lfn0:'):s.index('Lfn2:')]
labels=set(re.findall(r'^(L\w+):',helpers,re.M))
clone=re.sub(r'\bL\w+\b',lambda m:'owned'+m[0] if m[0] in labels else m[0],helpers)
def guard(part,op,bit,skip,expected):
    seen=0
    def replace(m):
        nonlocal seen
        seen+=1
        if seen<=skip:return m[0]
        return f'tbz x28, #{bit}, 8f\nldr x0, [sp, #48]\nb 9f\n8:\n{op}\n9:'
    part=re.sub('^'+op+'$',replace,part,flags=re.M)
    assert seen==expected
    return part
i=clone.index('ownedLfn1:')
clone=guard(clone[:i],'bl fen_allocate',0,2,4)+guard(clone[i:],'bl fen_allocate_full',1,8,16)
a,b=s.index('Lfn5fields:'),s.index('Lfn6:')
walk=s[a:b]
assert walk.count('bl Lfn1fields')==4
walk=walk.replace('Lfn5fields:\n','Lfn5fields:\nstp x27, x28, [sp, #-16]!\nmov x27, #0\n').replace('ldp x29, x30, [sp], #16','ldp x29, x30, [sp], #16\nldp x27, x28, [sp], #16')
# Bits 0..31 identify pairs, 32..35 identify groups. x28 records the
# previous flags across calls; the mask lives only in this walk frame.
walk=walk.replace('bl Lfn1fields','''lsr x2, x9, #1
lsr x3, x9, #4
add x3, x3, #32
mov x4, #1
lsl x5, x4, x2
lsl x6, x4, x3
lsr x28, x27, x2
and x28, x28, #1
tst x27, x6
cset x7, ne
orr x28, x28, x7, lsl #1
orr x27, x27, x5
orr x27, x27, x6
bl ownedLfn1fields''')
(d/'candidate.s').write_text(s[:a]+walk+s[b:]+'\n.text\n'+clone)
