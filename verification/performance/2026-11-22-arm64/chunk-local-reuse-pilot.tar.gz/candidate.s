.text
.p2align 2
Lfn0:
ldp x8, x9, [x0, #0]
ldp x10, x11, [x0, #16]
Lfn0fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #208
stp x8, x9, [sp, #48]
stp x10, x11, [sp, #64]
add x0, sp, #16
add x1, sp, #48
mov x2, #1
bl fen_enter
Lfn0loop:
ldr x0, [sp, #56]
asr x2, x0, #63
add x0, x0, x2, lsr #63
asr x0, x0, #1
lsl x2, x0, #1
cmp x0, x2, asr #1
b.ne Lfn0fail20_1
mov x0, x2
str x0, [sp, #80]
ldr x0, [sp, #48]
ldr w0, [x0, #72]
cmp w0, #9
b.eq Lfn0match25arm9
cmp w0, #10
b.eq Lfn0match25arm10
cmp w0, #11
b.eq Lfn0match25arm11
cmp w0, #12
b.eq Lfn0match25arm12
brk #0
Lfn0match25arm9:
ldr x0, [sp, #56]
ldr x2, [sp, #80]
cmp x0, x2
b.ne Lfn0if27else
movz x0, #1, lsl #0
str x0, [sp, #88]
movz x0, #0, lsl #0
str x0, [sp, #96]
movz x0, #0, lsl #0
str x0, [sp, #104]
movz x0, #0, lsl #0
str x0, [sp, #112]
mov x0, #0
mov x1, #10
bl fen_allocate
cbz x0, Lfn0fail31_3
ldr x2, [sp, #80]
ldr x3, [sp, #88]
stp x2, x3, [x0, #0]
ldr x2, [sp, #64]
ldr x3, [sp, #72]
stp x2, x3, [x0, #16]
ldr x2, [sp, #96]
ldr x3, [sp, #104]
stp x2, x3, [x0, #32]
ldr x2, [sp, #112]
str x2, [x0, #48]
b Lfn0if27done
Lfn0if27else:
movz x0, #0, lsl #0
str x0, [sp, #120]
movz x0, #0, lsl #0
str x0, [sp, #128]
movz x0, #0, lsl #0
str x0, [sp, #136]
movz x0, #1, lsl #0
str x0, [sp, #144]
mov x0, #0
mov x1, #10
bl fen_allocate
cbz x0, Lfn0fail39_3
ldr x2, [sp, #80]
ldr x3, [sp, #120]
stp x2, x3, [x0, #0]
ldr x2, [sp, #128]
ldr x3, [sp, #136]
stp x2, x3, [x0, #16]
ldr x2, [sp, #144]
ldr x3, [sp, #64]
stp x2, x3, [x0, #32]
ldr x2, [sp, #72]
str x2, [x0, #48]
Lfn0if27done:
b Lfn0match25end
Lfn0match25arm10:
ldr x0, [sp, #56]
ldr x2, [sp, #80]
cmp x0, x2
b.ne Lfn0if54else
ldr x0, [sp, #48]
ldr x0, [x0, #8]
adds x0, x0, #1
b.vs Lfn0fail60_1
str x0, [sp, #152]
ldr x0, [sp, #48]
ldr x0, [x0, #16]
ldr x2, [sp, #64]
adds x0, x0, x2
b.vs Lfn0fail63_1
str x0, [sp, #160]
ldr x0, [sp, #48]
ldr x0, [x0, #24]
ldr x2, [sp, #72]
adds x0, x0, x2
b.vs Lfn0fail66_1
str x0, [sp, #168]
mov x0, #0
mov x1, #10
bl fen_allocate
cbz x0, Lfn0fail58_3
ldr x2, [sp, #48]
ldr x2, [x2, #0]
ldr x3, [sp, #152]
stp x2, x3, [x0, #0]
ldr x2, [sp, #160]
ldr x3, [sp, #168]
stp x2, x3, [x0, #16]
ldr x4, [sp, #48]
ldp x2, x3, [x4, #32]
stp x2, x3, [x0, #32]
ldr x2, [x4, #48]
str x2, [x0, #48]
b Lfn0if54done
Lfn0if54else:
ldr x0, [sp, #48]
ldr x0, [x0, #32]
adds x0, x0, #1
b.vs Lfn0fail77_1
str x0, [sp, #176]
ldr x0, [sp, #48]
ldr x0, [x0, #40]
ldr x2, [sp, #64]
adds x0, x0, x2
b.vs Lfn0fail80_1
str x0, [sp, #184]
ldr x0, [sp, #48]
ldr x0, [x0, #48]
ldr x2, [sp, #72]
adds x0, x0, x2
b.vs Lfn0fail83_1
str x0, [sp, #192]
mov x0, #0
mov x1, #10
bl fen_allocate
cbz x0, Lfn0fail72_3
ldr x4, [sp, #48]
ldp x2, x3, [x4, #0]
stp x2, x3, [x0, #0]
ldp x2, x3, [x4, #16]
stp x2, x3, [x0, #16]
ldr x2, [sp, #176]
ldr x3, [sp, #184]
stp x2, x3, [x0, #32]
ldr x2, [sp, #192]
str x2, [x0, #48]
Lfn0if54done:
b Lfn0match25end
Lfn0match25arm11:
ldr x0, [sp, #48]
b Lfn0match25end
Lfn0match25arm12:
ldr x0, [sp, #48]
b Lfn0match25end
Lfn0match25end:
mov x1, #0
b Lfn0end
Lfn0fail20_1:
adrp x0, Lfn0fail20_1location
add x0, x0, :lo12:Lfn0fail20_1location
bl fen_set_location
mov x1, #1
b Lfn0end
Lfn0fail31_3:
adrp x0, Lfn0fail31_3location
add x0, x0, :lo12:Lfn0fail31_3location
bl fen_set_location
mov x1, #3
b Lfn0end
Lfn0fail39_3:
adrp x0, Lfn0fail39_3location
add x0, x0, :lo12:Lfn0fail39_3location
bl fen_set_location
mov x1, #3
b Lfn0end
Lfn0fail60_1:
adrp x0, Lfn0fail60_1location
add x0, x0, :lo12:Lfn0fail60_1location
bl fen_set_location
mov x1, #1
b Lfn0end
Lfn0fail63_1:
adrp x0, Lfn0fail63_1location
add x0, x0, :lo12:Lfn0fail63_1location
bl fen_set_location
mov x1, #1
b Lfn0end
Lfn0fail66_1:
adrp x0, Lfn0fail66_1location
add x0, x0, :lo12:Lfn0fail66_1location
bl fen_set_location
mov x1, #1
b Lfn0end
Lfn0fail58_3:
adrp x0, Lfn0fail58_3location
add x0, x0, :lo12:Lfn0fail58_3location
bl fen_set_location
mov x1, #3
b Lfn0end
Lfn0fail77_1:
adrp x0, Lfn0fail77_1location
add x0, x0, :lo12:Lfn0fail77_1location
bl fen_set_location
mov x1, #1
b Lfn0end
Lfn0fail80_1:
adrp x0, Lfn0fail80_1location
add x0, x0, :lo12:Lfn0fail80_1location
bl fen_set_location
mov x1, #1
b Lfn0end
Lfn0fail83_1:
adrp x0, Lfn0fail83_1location
add x0, x0, :lo12:Lfn0fail83_1location
bl fen_set_location
mov x1, #1
b Lfn0end
Lfn0fail72_3:
adrp x0, Lfn0fail72_3location
add x0, x0, :lo12:Lfn0fail72_3location
bl fen_set_location
mov x1, #3
b Lfn0end
Lfn0end:
bl fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn1:
ldp x8, x9, [x0, #0]
ldp x10, x11, [x0, #16]
Lfn1fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
stp x19, x20, [sp, #-16]!
stp x21, x22, [sp, #-16]!
stp x23, xzr, [sp, #-16]!
sub sp, sp, #96
stp xzr, xzr, [sp, #56]
stp xzr, xzr, [sp, #72]
str x8, [sp, #48]
mov x19, x9
mov x20, x10
mov x21, x11
add x0, sp, #16
add x1, sp, #48
mov x2, #5
bl fen_enter
Lfn1loop:
ldr x0, [sp, #48]
ldr w0, [x0, #72]
cmp w0, #9
b.eq Lfn1match118arm9
cmp w0, #10
b.eq Lfn1match118arm10
cmp w0, #11
b.eq Lfn1match118arm11
cmp w0, #12
b.eq Lfn1match118arm12
brk #0
Lfn1match118arm9:
bl fen_leave_result
adrp x8, Lconstant0
add x8, x8, :lo12:Lconstant0
mov x9, x19
mov x10, x20
mov x11, x21
ldp x19, x20, [x29, #-16]
ldp x21, x22, [x29, #-32]
ldp x23, xzr, [x29, #-48]
mov sp, x29
ldp x29, x30, [sp], #16
b Lfn0fields
b Lfn1match118end
Lfn1match118arm10:
mov x0, x19
asr x2, x0, #63
add x0, x0, x2, lsr #63
asr x0, x0, #1
lsl x2, x0, #1
cmp x0, x2, asr #1
b.ne Lfn1fail136_1
mov x0, x2
str x0, [sp, #88]
ldr x0, [sp, #48]
ldr x0, [x0, #0]
ldr x2, [sp, #88]
cmp x0, x2
b.ne Lfn1if133else
bl fen_leave_result
ldr x8, [sp, #48]
mov x9, x19
mov x10, x20
mov x11, x21
ldp x19, x20, [x29, #-16]
ldp x21, x22, [x29, #-32]
ldp x23, xzr, [x29, #-48]
mov sp, x29
ldp x29, x30, [sp], #16
b Lfn0fields
b Lfn1if133done
Lfn1if133else:
ldr x0, [sp, #48]
ldr x0, [x0, #0]
cmp x0, #0
neg x2, x0
and x2, x2, #15
and x0, x0, #15
csneg x0, x0, x2, ge
asr x2, x0, #63
add x0, x0, x2, lsr #63
asr x0, x0, #1
mov x22, x0
cmp x0, #4
b.ge Lfn1if160else
mov x0, x22
cmp x0, #2
b.ge Lfn1if164else
mov x0, x22
cmp x0, #1
b.ge Lfn1if168else
mov x0, #255
mov x1, #12
bl fen_allocate_full
cbz x0, Lfn1fail172_3
ldr x2, [sp, #48]
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #0]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #16]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #32]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #48]
str x0, [sp, #56]
b Lfn1if168done
Lfn1if168else:
mov x0, #255
mov x1, #12
bl fen_allocate_full
cbz x0, Lfn1fail181_3
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
ldr x3, [sp, #48]
stp x2, x3, [x0, #0]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #16]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #32]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #48]
str x0, [sp, #56]
Lfn1if168done:
str x0, [sp, #64]
b Lfn1if164done
Lfn1if164else:
mov x0, x22
cmp x0, #3
b.ge Lfn1if190else
mov x0, #255
mov x1, #12
bl fen_allocate_full
cbz x0, Lfn1fail194_3
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #0]
ldr x2, [sp, #48]
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #16]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #32]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #48]
str x0, [sp, #56]
b Lfn1if190done
Lfn1if190else:
mov x0, #255
mov x1, #12
bl fen_allocate_full
cbz x0, Lfn1fail203_3
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #0]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
ldr x3, [sp, #48]
stp x2, x3, [x0, #16]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #32]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #48]
str x0, [sp, #56]
Lfn1if190done:
str x0, [sp, #64]
Lfn1if164done:
str x0, [sp, #72]
b Lfn1if160done
Lfn1if160else:
mov x0, x22
cmp x0, #6
b.ge Lfn1if212else
mov x0, x22
cmp x0, #5
b.ge Lfn1if216else
mov x0, #255
mov x1, #12
bl fen_allocate_full
cbz x0, Lfn1fail220_3
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #0]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #16]
ldr x2, [sp, #48]
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #32]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #48]
str x0, [sp, #56]
b Lfn1if216done
Lfn1if216else:
mov x0, #255
mov x1, #12
bl fen_allocate_full
cbz x0, Lfn1fail229_3
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #0]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #16]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
ldr x3, [sp, #48]
stp x2, x3, [x0, #32]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #48]
str x0, [sp, #56]
Lfn1if216done:
str x0, [sp, #64]
b Lfn1if212done
Lfn1if212else:
mov x0, x22
cmp x0, #7
b.ge Lfn1if238else
mov x0, #255
mov x1, #12
bl fen_allocate_full
cbz x0, Lfn1fail242_3
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #0]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #16]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #32]
ldr x2, [sp, #48]
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #48]
str x0, [sp, #56]
b Lfn1if238done
Lfn1if238else:
mov x0, #255
mov x1, #12
bl fen_allocate_full
cbz x0, Lfn1fail251_3
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #0]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #16]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #32]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
ldr x3, [sp, #48]
stp x2, x3, [x0, #48]
str x0, [sp, #56]
Lfn1if238done:
str x0, [sp, #64]
Lfn1if212done:
str x0, [sp, #72]
Lfn1if160done:
str x0, [sp, #80]
ldr x8, [sp, #80]
str x8, [sp, #48]
stp xzr, xzr, [sp, #56]
stp xzr, xzr, [sp, #72]
b Lfn1loop
Lfn1if133done:
b Lfn1match118end
Lfn1match118arm11:
ldr x0, [sp, #48]
b Lfn1match118end
Lfn1match118arm12:
mov x0, x19
cmp x0, #0
neg x2, x0
and x2, x2, #15
and x0, x0, #15
csneg x0, x0, x2, ge
asr x2, x0, #63
add x0, x0, x2, lsr #63
asr x0, x0, #1
mov x23, x0
cmp x0, #4
b.ge Lfn1if287else
mov x0, x23
cmp x0, #2
b.ge Lfn1if291else
mov x0, x23
cmp x0, #1
b.ge Lfn1if295else
ldr x8, [sp, #48]
ldr x8, [x8, #0]
mov x9, x19
mov x10, x20
mov x11, x21
bl Lfn0fields
cbnz x1, Lfn1end
str x0, [sp, #56]
mov x0, #255
mov x1, #12
bl fen_allocate_full
cbz x0, Lfn1fail299_3
ldr x2, [sp, #56]
ldr x3, [sp, #48]
ldr x3, [x3, #8]
stp x2, x3, [x0, #0]
ldr x4, [sp, #48]
ldp x2, x3, [x4, #16]
stp x2, x3, [x0, #16]
ldp x2, x3, [x4, #32]
stp x2, x3, [x0, #32]
ldp x2, x3, [x4, #48]
stp x2, x3, [x0, #48]
b Lfn1if295done
Lfn1if295else:
ldr x8, [sp, #48]
ldr x8, [x8, #8]
mov x9, x19
mov x10, x20
mov x11, x21
bl Lfn0fields
cbnz x1, Lfn1end
str x0, [sp, #56]
mov x0, #255
mov x1, #12
bl fen_allocate_full
cbz x0, Lfn1fail313_3
ldr x2, [sp, #48]
ldr x2, [x2, #0]
ldr x3, [sp, #56]
stp x2, x3, [x0, #0]
ldr x4, [sp, #48]
ldp x2, x3, [x4, #16]
stp x2, x3, [x0, #16]
ldp x2, x3, [x4, #32]
stp x2, x3, [x0, #32]
ldp x2, x3, [x4, #48]
stp x2, x3, [x0, #48]
Lfn1if295done:
b Lfn1if291done
Lfn1if291else:
mov x0, x23
cmp x0, #3
b.ge Lfn1if327else
ldr x8, [sp, #48]
ldr x8, [x8, #16]
mov x9, x19
mov x10, x20
mov x11, x21
bl Lfn0fields
cbnz x1, Lfn1end
str x0, [sp, #56]
mov x0, #255
mov x1, #12
bl fen_allocate_full
cbz x0, Lfn1fail331_3
ldr x4, [sp, #48]
ldp x2, x3, [x4, #0]
stp x2, x3, [x0, #0]
ldr x2, [sp, #56]
ldr x3, [x4, #24]
stp x2, x3, [x0, #16]
ldp x2, x3, [x4, #32]
stp x2, x3, [x0, #32]
ldp x2, x3, [x4, #48]
stp x2, x3, [x0, #48]
b Lfn1if327done
Lfn1if327else:
ldr x8, [sp, #48]
ldr x8, [x8, #24]
mov x9, x19
mov x10, x20
mov x11, x21
bl Lfn0fields
cbnz x1, Lfn1end
str x0, [sp, #56]
mov x0, #255
mov x1, #12
bl fen_allocate_full
cbz x0, Lfn1fail345_3
ldr x4, [sp, #48]
ldp x2, x3, [x4, #0]
stp x2, x3, [x0, #0]
ldr x2, [x4, #16]
ldr x3, [sp, #56]
stp x2, x3, [x0, #16]
ldp x2, x3, [x4, #32]
stp x2, x3, [x0, #32]
ldp x2, x3, [x4, #48]
stp x2, x3, [x0, #48]
Lfn1if327done:
Lfn1if291done:
b Lfn1if287done
Lfn1if287else:
mov x0, x23
cmp x0, #6
b.ge Lfn1if359else
mov x0, x23
cmp x0, #5
b.ge Lfn1if363else
ldr x8, [sp, #48]
ldr x8, [x8, #32]
mov x9, x19
mov x10, x20
mov x11, x21
bl Lfn0fields
cbnz x1, Lfn1end
str x0, [sp, #56]
mov x0, #255
mov x1, #12
bl fen_allocate_full
cbz x0, Lfn1fail367_3
ldr x4, [sp, #48]
ldp x2, x3, [x4, #0]
stp x2, x3, [x0, #0]
ldp x2, x3, [x4, #16]
stp x2, x3, [x0, #16]
ldr x2, [sp, #56]
ldr x3, [x4, #40]
stp x2, x3, [x0, #32]
ldp x2, x3, [x4, #48]
stp x2, x3, [x0, #48]
b Lfn1if363done
Lfn1if363else:
ldr x8, [sp, #48]
ldr x8, [x8, #40]
mov x9, x19
mov x10, x20
mov x11, x21
bl Lfn0fields
cbnz x1, Lfn1end
str x0, [sp, #56]
mov x0, #255
mov x1, #12
bl fen_allocate_full
cbz x0, Lfn1fail381_3
ldr x4, [sp, #48]
ldp x2, x3, [x4, #0]
stp x2, x3, [x0, #0]
ldp x2, x3, [x4, #16]
stp x2, x3, [x0, #16]
ldr x2, [x4, #32]
ldr x3, [sp, #56]
stp x2, x3, [x0, #32]
ldp x2, x3, [x4, #48]
stp x2, x3, [x0, #48]
Lfn1if363done:
b Lfn1if359done
Lfn1if359else:
mov x0, x23
cmp x0, #7
b.ge Lfn1if395else
ldr x8, [sp, #48]
ldr x8, [x8, #48]
mov x9, x19
mov x10, x20
mov x11, x21
bl Lfn0fields
cbnz x1, Lfn1end
str x0, [sp, #56]
mov x0, #255
mov x1, #12
bl fen_allocate_full
cbz x0, Lfn1fail399_3
ldr x4, [sp, #48]
ldp x2, x3, [x4, #0]
stp x2, x3, [x0, #0]
ldp x2, x3, [x4, #16]
stp x2, x3, [x0, #16]
ldp x2, x3, [x4, #32]
stp x2, x3, [x0, #32]
ldr x2, [sp, #56]
ldr x3, [x4, #56]
stp x2, x3, [x0, #48]
b Lfn1if395done
Lfn1if395else:
ldr x8, [sp, #48]
ldr x8, [x8, #56]
mov x9, x19
mov x10, x20
mov x11, x21
bl Lfn0fields
cbnz x1, Lfn1end
str x0, [sp, #56]
mov x0, #255
mov x1, #12
bl fen_allocate_full
cbz x0, Lfn1fail413_3
ldr x4, [sp, #48]
ldp x2, x3, [x4, #0]
stp x2, x3, [x0, #0]
ldp x2, x3, [x4, #16]
stp x2, x3, [x0, #16]
ldp x2, x3, [x4, #32]
stp x2, x3, [x0, #32]
ldr x2, [x4, #48]
ldr x3, [sp, #56]
stp x2, x3, [x0, #48]
Lfn1if395done:
Lfn1if359done:
Lfn1if287done:
b Lfn1match118end
Lfn1match118end:
mov x1, #0
b Lfn1end
Lfn1fail136_1:
adrp x0, Lfn1fail136_1location
add x0, x0, :lo12:Lfn1fail136_1location
bl fen_set_location
mov x1, #1
b Lfn1end
Lfn1fail172_3:
adrp x0, Lfn1fail172_3location
add x0, x0, :lo12:Lfn1fail172_3location
bl fen_set_location
mov x1, #3
b Lfn1end
Lfn1fail181_3:
adrp x0, Lfn1fail181_3location
add x0, x0, :lo12:Lfn1fail181_3location
bl fen_set_location
mov x1, #3
b Lfn1end
Lfn1fail194_3:
adrp x0, Lfn1fail194_3location
add x0, x0, :lo12:Lfn1fail194_3location
bl fen_set_location
mov x1, #3
b Lfn1end
Lfn1fail203_3:
adrp x0, Lfn1fail203_3location
add x0, x0, :lo12:Lfn1fail203_3location
bl fen_set_location
mov x1, #3
b Lfn1end
Lfn1fail220_3:
adrp x0, Lfn1fail220_3location
add x0, x0, :lo12:Lfn1fail220_3location
bl fen_set_location
mov x1, #3
b Lfn1end
Lfn1fail229_3:
adrp x0, Lfn1fail229_3location
add x0, x0, :lo12:Lfn1fail229_3location
bl fen_set_location
mov x1, #3
b Lfn1end
Lfn1fail242_3:
adrp x0, Lfn1fail242_3location
add x0, x0, :lo12:Lfn1fail242_3location
bl fen_set_location
mov x1, #3
b Lfn1end
Lfn1fail251_3:
adrp x0, Lfn1fail251_3location
add x0, x0, :lo12:Lfn1fail251_3location
bl fen_set_location
mov x1, #3
b Lfn1end
Lfn1fail299_3:
adrp x0, Lfn1fail299_3location
add x0, x0, :lo12:Lfn1fail299_3location
bl fen_set_location
mov x1, #3
b Lfn1end
Lfn1fail313_3:
adrp x0, Lfn1fail313_3location
add x0, x0, :lo12:Lfn1fail313_3location
bl fen_set_location
mov x1, #3
b Lfn1end
Lfn1fail331_3:
adrp x0, Lfn1fail331_3location
add x0, x0, :lo12:Lfn1fail331_3location
bl fen_set_location
mov x1, #3
b Lfn1end
Lfn1fail345_3:
adrp x0, Lfn1fail345_3location
add x0, x0, :lo12:Lfn1fail345_3location
bl fen_set_location
mov x1, #3
b Lfn1end
Lfn1fail367_3:
adrp x0, Lfn1fail367_3location
add x0, x0, :lo12:Lfn1fail367_3location
bl fen_set_location
mov x1, #3
b Lfn1end
Lfn1fail381_3:
adrp x0, Lfn1fail381_3location
add x0, x0, :lo12:Lfn1fail381_3location
bl fen_set_location
mov x1, #3
b Lfn1end
Lfn1fail399_3:
adrp x0, Lfn1fail399_3location
add x0, x0, :lo12:Lfn1fail399_3location
bl fen_set_location
mov x1, #3
b Lfn1end
Lfn1fail413_3:
adrp x0, Lfn1fail413_3location
add x0, x0, :lo12:Lfn1fail413_3location
bl fen_set_location
mov x1, #3
b Lfn1end
Lfn1end:
bl fen_leave_result
ldp x19, x20, [x29, #-16]
ldp x21, x22, [x29, #-32]
ldp x23, xzr, [x29, #-48]
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn2:
ldp x8, x9, [x0, #0]
ldp x10, x11, [x0, #16]
Lfn2fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
stp x19, x20, [sp, #-16]!
stp x21, x22, [sp, #-16]!
sub sp, sp, #64
str xzr, [sp, #56]
str x8, [sp, #48]
mov x19, x9
mov x20, x10
mov x21, x11
add x0, sp, #16
add x1, sp, #48
mov x2, #2
bl fen_enter
Lfn2loop:
ldr x0, [sp, #48]
ldr w0, [x0, #72]
cmp w0, #9
b.eq Lfn2match445arm9
cmp w0, #10
b.eq Lfn2match445arm10
cmp w0, #12
b.eq Lfn2match445arm12
cmp w0, #11
b.eq Lfn2match445arm11
brk #0
Lfn2match445arm9:
adrp x8, Lconstant1
add x8, x8, :lo12:Lconstant1
str x8, [sp, #48]
str xzr, [sp, #56]
b Lfn2loop
b Lfn2match445end
Lfn2match445arm10:
ldr x0, [sp, #48]
b Lfn2match445end
Lfn2match445arm12:
ldr x0, [sp, #48]
b Lfn2match445end
Lfn2match445arm11:
mov x0, x19
asr x2, x0, #63
add x0, x0, x2, lsr #60
asr x0, x0, #4
mov x22, x0
cmp x0, #2
b.ge Lfn2if483else
mov x0, x22
cmp x0, #1
b.ge Lfn2if487else
ldr x8, [sp, #48]
ldr x8, [x8, #0]
mov x9, x19
mov x10, x20
mov x11, x21
bl Lfn1fields
cbnz x1, Lfn2end
str x0, [sp, #56]
mov x0, #15
mov x1, #11
bl fen_allocate
cbz x0, Lfn2fail491_3
ldr x2, [sp, #56]
ldr x3, [sp, #48]
ldr x3, [x3, #8]
stp x2, x3, [x0, #0]
ldr x4, [sp, #48]
ldp x2, x3, [x4, #16]
stp x2, x3, [x0, #16]
b Lfn2if487done
Lfn2if487else:
ldr x8, [sp, #48]
ldr x8, [x8, #8]
mov x9, x19
mov x10, x20
mov x11, x21
bl Lfn1fields
cbnz x1, Lfn2end
str x0, [sp, #56]
mov x0, #15
mov x1, #11
bl fen_allocate
cbz x0, Lfn2fail501_3
ldr x2, [sp, #48]
ldr x2, [x2, #0]
ldr x3, [sp, #56]
stp x2, x3, [x0, #0]
ldr x4, [sp, #48]
ldp x2, x3, [x4, #16]
stp x2, x3, [x0, #16]
Lfn2if487done:
b Lfn2if483done
Lfn2if483else:
mov x0, x22
cmp x0, #3
b.ge Lfn2if511else
ldr x8, [sp, #48]
ldr x8, [x8, #16]
mov x9, x19
mov x10, x20
mov x11, x21
bl Lfn1fields
cbnz x1, Lfn2end
str x0, [sp, #56]
mov x0, #15
mov x1, #11
bl fen_allocate
cbz x0, Lfn2fail515_3
ldr x4, [sp, #48]
ldp x2, x3, [x4, #0]
stp x2, x3, [x0, #0]
ldr x2, [sp, #56]
ldr x3, [x4, #24]
stp x2, x3, [x0, #16]
b Lfn2if511done
Lfn2if511else:
ldr x8, [sp, #48]
ldr x8, [x8, #24]
mov x9, x19
mov x10, x20
mov x11, x21
bl Lfn1fields
cbnz x1, Lfn2end
str x0, [sp, #56]
mov x0, #15
mov x1, #11
bl fen_allocate
cbz x0, Lfn2fail525_3
ldr x4, [sp, #48]
ldp x2, x3, [x4, #0]
stp x2, x3, [x0, #0]
ldr x2, [x4, #16]
ldr x3, [sp, #56]
stp x2, x3, [x0, #16]
Lfn2if511done:
Lfn2if483done:
b Lfn2match445end
Lfn2match445end:
mov x1, #0
b Lfn2end
Lfn2fail491_3:
adrp x0, Lfn2fail491_3location
add x0, x0, :lo12:Lfn2fail491_3location
bl fen_set_location
mov x1, #3
b Lfn2end
Lfn2fail501_3:
adrp x0, Lfn2fail501_3location
add x0, x0, :lo12:Lfn2fail501_3location
bl fen_set_location
mov x1, #3
b Lfn2end
Lfn2fail515_3:
adrp x0, Lfn2fail515_3location
add x0, x0, :lo12:Lfn2fail515_3location
bl fen_set_location
mov x1, #3
b Lfn2end
Lfn2fail525_3:
adrp x0, Lfn2fail525_3location
add x0, x0, :lo12:Lfn2fail525_3location
bl fen_set_location
mov x1, #3
b Lfn2end
Lfn2end:
bl fen_leave_result
ldp x19, x20, [x29, #-16]
ldp x21, x22, [x29, #-32]
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn3:
ldp x8, x9, [x0, #0]
Lfn3fields:
ldr w2, [x8, #72]
cmp w2, #9
b.ne Lfn3frame
mov x0, x9
mov x1, #0
ret
Lfn3frame:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #128
stp xzr, xzr, [sp, #64]
stp xzr, xzr, [sp, #80]
stp xzr, xzr, [sp, #96]
str xzr, [sp, #112]
stp x8, x9, [sp, #48]
add x0, sp, #16
add x1, sp, #48
mov x2, #9
bl fen_enter
Lfn3loop:
ldr x0, [sp, #48]
ldr w0, [x0, #72]
cmp w0, #9
b.eq Lfn3match545arm9
cmp w0, #10
b.eq Lfn3match545arm10
cmp w0, #11
b.eq Lfn3match545arm11
cmp w0, #12
b.eq Lfn3match545arm12
brk #0
Lfn3match545arm9:
ldr x0, [sp, #56]
b Lfn3match545end
Lfn3match545arm10:
ldr x0, [sp, #48]
ldr x0, [x0, #32]
cmp x0, #0
b.ne Lfn3if557else
ldr x0, [sp, #56]
b Lfn3if557done
Lfn3if557else:
ldr x0, [sp, #48]
ldr x0, [x0, #0]
adds x0, x0, #1
b.vs Lfn3fail563_1
str x0, [sp, #120]
mov x0, #16
mov x1, #8
bl fen_allocate
cbz x0, Lfn3fail562_3
ldr x2, [sp, #120]
ldr x3, [sp, #48]
ldr x3, [x3, #32]
stp x2, x3, [x0, #0]
ldr x4, [sp, #48]
ldp x2, x3, [x4, #40]
stp x2, x3, [x0, #16]
ldr x2, [sp, #56]
str x2, [x0, #32]
str x0, [sp, #64]
Lfn3if557done:
str x0, [sp, #72]
ldr x0, [sp, #48]
ldr x0, [x0, #8]
cmp x0, #0
b.ne Lfn3if570else
ldr x0, [sp, #72]
b Lfn3if570done
Lfn3if570else:
mov x0, #16
mov x1, #8
bl fen_allocate
cbz x0, Lfn3fail575_3
ldr x4, [sp, #48]
ldp x2, x3, [x4, #0]
stp x2, x3, [x0, #0]
ldp x2, x3, [x4, #16]
stp x2, x3, [x0, #16]
ldr x2, [sp, #72]
str x2, [x0, #32]
Lfn3if570done:
b Lfn3match545end
Lfn3match545arm11:
ldr x8, [sp, #48]
ldr x8, [x8, #24]
ldr x9, [sp, #56]
bl Lfn3fields
cbnz x1, Lfn3end
str x0, [sp, #64]
ldr x8, [sp, #48]
ldr x8, [x8, #16]
ldr x9, [sp, #64]
bl Lfn3fields
cbnz x1, Lfn3end
str x0, [sp, #72]
ldr x8, [sp, #48]
ldr x8, [x8, #8]
ldr x9, [sp, #72]
bl Lfn3fields
cbnz x1, Lfn3end
str x0, [sp, #80]
ldr x8, [sp, #48]
ldr x8, [x8, #0]
ldr x9, [sp, #80]
str x8, [sp, #48]
str x9, [sp, #56]
stp xzr, xzr, [sp, #64]
stp xzr, xzr, [sp, #80]
stp xzr, xzr, [sp, #96]
str xzr, [sp, #112]
b Lfn3loop
b Lfn3match545end
Lfn3match545arm12:
ldr x8, [sp, #48]
ldr x8, [x8, #56]
ldr x9, [sp, #56]
bl Lfn3fields
cbnz x1, Lfn3end
str x0, [sp, #64]
ldr x8, [sp, #48]
ldr x8, [x8, #48]
ldr x9, [sp, #64]
bl Lfn3fields
cbnz x1, Lfn3end
str x0, [sp, #72]
ldr x8, [sp, #48]
ldr x8, [x8, #40]
ldr x9, [sp, #72]
bl Lfn3fields
cbnz x1, Lfn3end
str x0, [sp, #80]
ldr x8, [sp, #48]
ldr x8, [x8, #32]
ldr x9, [sp, #80]
bl Lfn3fields
cbnz x1, Lfn3end
str x0, [sp, #88]
ldr x8, [sp, #48]
ldr x8, [x8, #24]
ldr x9, [sp, #88]
bl Lfn3fields
cbnz x1, Lfn3end
str x0, [sp, #96]
ldr x8, [sp, #48]
ldr x8, [x8, #16]
ldr x9, [sp, #96]
bl Lfn3fields
cbnz x1, Lfn3end
str x0, [sp, #104]
ldr x8, [sp, #48]
ldr x8, [x8, #8]
ldr x9, [sp, #104]
bl Lfn3fields
cbnz x1, Lfn3end
str x0, [sp, #112]
ldr x8, [sp, #48]
ldr x8, [x8, #0]
ldr x9, [sp, #112]
str x8, [sp, #48]
str x9, [sp, #56]
stp xzr, xzr, [sp, #64]
stp xzr, xzr, [sp, #80]
stp xzr, xzr, [sp, #96]
str xzr, [sp, #112]
b Lfn3loop
b Lfn3match545end
Lfn3match545end:
mov x1, #0
b Lfn3end
Lfn3fail563_1:
adrp x0, Lfn3fail563_1location
add x0, x0, :lo12:Lfn3fail563_1location
bl fen_set_location
mov x1, #1
b Lfn3end
Lfn3fail562_3:
adrp x0, Lfn3fail562_3location
add x0, x0, :lo12:Lfn3fail562_3location
bl fen_set_location
mov x1, #3
b Lfn3end
Lfn3fail575_3:
adrp x0, Lfn3fail575_3location
add x0, x0, :lo12:Lfn3fail575_3location
bl fen_set_location
mov x1, #3
b Lfn3end
Lfn3end:
bl fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn4:
ldp x8, x9, [x0, #0]
ldp x10, x11, [x0, #16]
Lfn4fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #112
stp x8, x9, [sp, #48]
stp x10, x11, [sp, #64]
ldr x0, [sp, #48]
ldr x1, [sp, #56]
ldr x2, [sp, #64]
ldr x3, [sp, #72]
bl fen_try_byte_sum
cbz x1, Lfn4loop
mov x1, #0
b Lfn4end
Lfn4loop:
ldr x0, [sp, #56]
ldr x2, [sp, #64]
cmp x0, x2
b.ne Lfn4if649else
ldr x0, [sp, #72]
b Lfn4if649done
Lfn4if649else:
ldr x0, [sp, #56]
adds x0, x0, #1
b.vs Lfn4fail657_1
str x0, [sp, #80]
ldr x0, [sp, #48]
ldr x2, [sp, #56]
ldr x3, [x0]
cmp x2, x3
b.hs Lfn4fail663_4
ldr w3, [x0, #72]
cmn w3, #1
b.ne 1f
add x0, x0, #80
ldrb w0, [x0, x2]
b 2f
1:
mov x1, x2
bl fen_bytes_index
2:
str x0, [sp, #88]
ldr x0, [sp, #72]
ldr x2, [sp, #88]
adds x0, x0, x2
b.vs Lfn4fail661_1
str x0, [sp, #96]
ldr x8, [sp, #80]
ldr x9, [sp, #96]
str x8, [sp, #56]
str x9, [sp, #72]
b Lfn4loop
Lfn4if649done:
mov x1, #0
b Lfn4end
Lfn4fail657_1:
adrp x0, Lfn4fail657_1location
add x0, x0, :lo12:Lfn4fail657_1location
bl fen_set_location
mov x1, #1
b Lfn4end
Lfn4fail663_4:
adrp x0, Lfn4fail663_4location
add x0, x0, :lo12:Lfn4fail663_4location
bl fen_set_location
mov x1, #4
b Lfn4end
Lfn4fail661_1:
adrp x0, Lfn4fail661_1location
add x0, x0, :lo12:Lfn4fail661_1location
bl fen_set_location
mov x1, #1
b Lfn4end
Lfn4end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn5:
ldp x8, x9, [x0, #0]
ldp x10, x11, [x0, #16]
ldp x12, x13, [x0, #32]
ldr x14, [x0, #48]
Lfn5fields:
stp x27, x28, [sp, #-16]!
mov x27, #0
stp x29, x30, [sp, #-16]!
mov x29, sp
stp x19, x20, [sp, #-16]!
stp x21, x22, [sp, #-16]!
stp x23, x24, [sp, #-16]!
stp x25, x26, [sp, #-16]!
sub sp, sp, #240
stp xzr, xzr, [sp, #88]
mov x19, x8
str x9, [sp, #48]
mov x21, x10
stp x11, x12, [sp, #56]
stp x13, x14, [sp, #72]
add x0, sp, #16
add x1, sp, #48
mov x2, #7
bl fen_enter
Lfn5loop:
ldr x0, [sp, #48]
ldr x0, [x0]
str x0, [sp, #104]
mov x0, x21
ldr x2, [sp, #104]
cmp x0, x2
b.ne Lfn5if696else
mov x0, #15
mov x1, #11
bl fen_allocate
cbz x0, Lfn5fail703_3
ldr x2, [sp, #56]
ldr x3, [sp, #64]
stp x2, x3, [x0, #0]
ldr x2, [sp, #72]
ldr x3, [sp, #80]
stp x2, x3, [x0, #16]
str x0, [sp, #88]
mov x0, #2
mov x1, #13
bl fen_allocate
cbz x0, Lfn5fail701_3
mov x2, x19
ldr x3, [sp, #88]
stp x2, x3, [x0, #0]
b Lfn5if696done
Lfn5if696else:
ldr x0, [sp, #48]
mov x2, x21
ldr x3, [x0]
cmp x2, x3
b.hs Lfn5fail711_4
ldr w3, [x0, #72]
cmn w3, #1
b.ne 1f
add x0, x0, #80
ldrb w0, [x0, x2]
b 2f
1:
mov x1, x2
bl fen_bytes_index
2:
lsl x2, x0, #8
cmp x0, x2, asr #8
b.ne Lfn5fail710_1
mov x0, x2
mov x26, x0
ldr x0, [sp, #48]
ldr x0, [x0]
mov x2, x21
subs x0, x0, x2
b.vs Lfn5fail717_1
cmp x0, #3
b.ge Lfn5if715else
mov x0, x19
adds x0, x0, #1
b.vs Lfn5fail725_1
str x0, [sp, #112]
mov x0, #15
mov x1, #11
bl fen_allocate
cbz x0, Lfn5fail729_3
ldr x2, [sp, #56]
ldr x3, [sp, #64]
stp x2, x3, [x0, #0]
ldr x2, [sp, #72]
ldr x3, [sp, #80]
stp x2, x3, [x0, #16]
str x0, [sp, #88]
mov x0, #4
mov x1, #14
bl fen_allocate
cbz x0, Lfn5fail724_3
ldr x2, [sp, #112]
mov x3, x26
stp x2, x3, [x0, #0]
ldr x2, [sp, #88]
str x2, [x0, #16]
str x0, [sp, #96]
mov x0, x21
adds x0, x0, #1
b.vs Lfn5fail735_1
str x0, [sp, #120]
bl fen_leave_result
ldr x8, [sp, #96]
ldr x9, [sp, #48]
ldr x10, [sp, #120]
ldp x19, x20, [x29, #-16]
ldp x21, x22, [x29, #-32]
ldp x23, x24, [x29, #-48]
ldp x25, x26, [x29, #-64]
mov sp, x29
ldp x29, x30, [sp], #16
ldp x27, x28, [sp], #16
b Lfn7fields
b Lfn5if715done
Lfn5if715else:
mov x0, x21
adds x0, x0, #1
b.vs Lfn5fail744_1
str x0, [sp, #128]
ldr x0, [sp, #48]
ldr x2, [sp, #128]
ldr x3, [x0]
cmp x2, x3
b.hs Lfn5fail742_4
ldr w3, [x0, #72]
cmn w3, #1
b.ne 1f
add x0, x0, #80
ldrb w0, [x0, x2]
b 2f
1:
mov x1, x2
bl fen_bytes_index
2:
str x0, [sp, #136]
mov x0, x26
ldr x2, [sp, #136]
adds x0, x0, x2
b.vs Lfn5fail740_1
str x0, [sp, #144]
cmp x0, #0
b.ne Lfn5if747else
mov x0, #0
mov x1, #17
bl fen_allocate
cbz x0, Lfn5fail751_3
mov x2, x19
str x2, [x0, #0]
b Lfn5if747done
Lfn5if747else:
mov x0, x21
adds x0, x0, #2
b.vs Lfn5fail757_1
str x0, [sp, #152]
ldr x0, [sp, #48]
ldr x2, [sp, #152]
ldr x3, [x0]
cmp x2, x3
b.hs Lfn5fail755_4
ldr w3, [x0, #72]
cmn w3, #1
b.ne 1f
add x0, x0, #80
ldrb w0, [x0, x2]
b 2f
1:
mov x1, x2
bl fen_bytes_index
2:
mov x22, x0
cmp x0, #63
b.le Lfn5if760else
mov x0, x19
adds x0, x0, #2
b.vs Lfn5fail765_1
str x0, [sp, #160]
mov x0, #0
mov x1, #17
bl fen_allocate
cbz x0, Lfn5fail764_3
ldr x2, [sp, #160]
str x2, [x0, #0]
b Lfn5if760done
Lfn5if760else:
mov x0, x21
adds x0, x0, #3
b.vs Lfn5fail770_1
mov x24, x0
ldr x0, [sp, #144]
subs x0, x0, #1
b.vs Lfn5fail775_1
mov x20, x0
ldr x0, [sp, #48]
ldr x0, [x0]
mov x2, x24
subs x0, x0, x2
b.vs Lfn5fail781_1
str x0, [sp, #168]
mov x0, x20
ldr x2, [sp, #168]
cmp x0, x2
b.gt Lfn5if778else
mov x0, x24
mov x2, x20
adds x0, x0, x2
b.vs Lfn5fail787_1
mov x23, x0
movz x0, #0, lsl #0
str x0, [sp, #176]
ldr x8, [sp, #48]
mov x9, x24
mov x10, x23
ldr x11, [sp, #176]
bl Lfn4fields
cbnz x1, Lfn5end
mov x25, x0
mov x0, x22
cmp x0, #32
b.ge Lfn5if798else
mov x0, x22
cmp x0, #16
b.ge Lfn5if802else
mov x0, x19
adds x0, x0, #3
b.vs Lfn5fail809_1
mov x2, x20
adds x0, x0, x2
b.vs Lfn5fail808_1
str x0, [sp, #184]
ldr x8, [sp, #56]
mov x9, x22
mov x10, x20
mov x11, x25
lsr x2, x9, #1
lsr x3, x9, #4
add x3, x3, #32
mov x4, #1
lsl x5, x4, x2
lsl x6, x4, x3
lsr x28, x27, x2
and x28, x28, #1
tst x27, x6
cset x7, ne
orr x28, x28, x7, lsl #1
orr x27, x27, x5
orr x27, x27, x6
bl ownedLfn1fields
cbnz x1, Lfn5end
str x0, [sp, #88]
ldr x8, [sp, #184]
mov x9, x23
ldr x10, [sp, #88]
mov x19, x8
mov x21, x9
str x10, [sp, #56]
stp xzr, xzr, [sp, #88]
b Lfn5loop
b Lfn5if802done
Lfn5if802else:
mov x0, x19
adds x0, x0, #3
b.vs Lfn5fail827_1
mov x2, x20
adds x0, x0, x2
b.vs Lfn5fail826_1
str x0, [sp, #192]
ldr x8, [sp, #64]
mov x9, x22
mov x10, x20
mov x11, x25
lsr x2, x9, #1
lsr x3, x9, #4
add x3, x3, #32
mov x4, #1
lsl x5, x4, x2
lsl x6, x4, x3
lsr x28, x27, x2
and x28, x28, #1
tst x27, x6
cset x7, ne
orr x28, x28, x7, lsl #1
orr x27, x27, x5
orr x27, x27, x6
bl ownedLfn1fields
cbnz x1, Lfn5end
str x0, [sp, #88]
ldr x8, [sp, #192]
mov x9, x23
ldr x10, [sp, #88]
mov x19, x8
mov x21, x9
str x10, [sp, #64]
stp xzr, xzr, [sp, #88]
b Lfn5loop
Lfn5if802done:
b Lfn5if798done
Lfn5if798else:
mov x0, x22
cmp x0, #48
b.ge Lfn5if842else
mov x0, x19
adds x0, x0, #3
b.vs Lfn5fail849_1
mov x2, x20
adds x0, x0, x2
b.vs Lfn5fail848_1
str x0, [sp, #200]
ldr x8, [sp, #72]
mov x9, x22
mov x10, x20
mov x11, x25
lsr x2, x9, #1
lsr x3, x9, #4
add x3, x3, #32
mov x4, #1
lsl x5, x4, x2
lsl x6, x4, x3
lsr x28, x27, x2
and x28, x28, #1
tst x27, x6
cset x7, ne
orr x28, x28, x7, lsl #1
orr x27, x27, x5
orr x27, x27, x6
bl ownedLfn1fields
cbnz x1, Lfn5end
str x0, [sp, #88]
ldr x8, [sp, #200]
mov x9, x23
ldr x10, [sp, #88]
mov x19, x8
mov x21, x9
str x10, [sp, #72]
stp xzr, xzr, [sp, #88]
b Lfn5loop
b Lfn5if842done
Lfn5if842else:
mov x0, x19
adds x0, x0, #3
b.vs Lfn5fail867_1
mov x2, x20
adds x0, x0, x2
b.vs Lfn5fail866_1
str x0, [sp, #208]
ldr x8, [sp, #80]
mov x9, x22
mov x10, x20
mov x11, x25
lsr x2, x9, #1
lsr x3, x9, #4
add x3, x3, #32
mov x4, #1
lsl x5, x4, x2
lsl x6, x4, x3
lsr x28, x27, x2
and x28, x28, #1
tst x27, x6
cset x7, ne
orr x28, x28, x7, lsl #1
orr x27, x27, x5
orr x27, x27, x6
bl ownedLfn1fields
cbnz x1, Lfn5end
str x0, [sp, #88]
ldr x8, [sp, #208]
mov x9, x23
ldr x10, [sp, #88]
mov x19, x8
mov x21, x9
str x10, [sp, #80]
stp xzr, xzr, [sp, #88]
b Lfn5loop
Lfn5if842done:
Lfn5if798done:
b Lfn5if778done
Lfn5if778else:
mov x0, x19
adds x0, x0, #3
b.vs Lfn5fail885_1
str x0, [sp, #216]
movz x0, #0, lsl #0
str x0, [sp, #224]
mov x0, #15
mov x1, #11
bl fen_allocate
cbz x0, Lfn5fail892_3
ldr x2, [sp, #56]
ldr x3, [sp, #64]
stp x2, x3, [x0, #0]
ldr x2, [sp, #72]
ldr x3, [sp, #80]
stp x2, x3, [x0, #16]
str x0, [sp, #88]
mov x0, #32
mov x1, #16
bl fen_allocate
cbz x0, Lfn5fail884_3
ldr x2, [sp, #216]
mov x3, x22
stp x2, x3, [x0, #0]
mov x2, x20
mov x3, x20
stp x2, x3, [x0, #16]
ldr x2, [sp, #224]
ldr x3, [sp, #88]
stp x2, x3, [x0, #32]
str x0, [sp, #96]
bl fen_leave_result
ldr x8, [sp, #96]
ldr x9, [sp, #48]
mov x10, x24
ldp x19, x20, [x29, #-16]
ldp x21, x22, [x29, #-32]
ldp x23, x24, [x29, #-48]
ldp x25, x26, [x29, #-64]
mov sp, x29
ldp x29, x30, [sp], #16
ldp x27, x28, [sp], #16
b Lfn7fields
Lfn5if778done:
Lfn5if760done:
Lfn5if747done:
Lfn5if715done:
Lfn5if696done:
mov x1, #0
b Lfn5end
Lfn5fail703_3:
adrp x0, Lfn5fail703_3location
add x0, x0, :lo12:Lfn5fail703_3location
bl fen_set_location
mov x1, #3
b Lfn5end
Lfn5fail701_3:
adrp x0, Lfn5fail701_3location
add x0, x0, :lo12:Lfn5fail701_3location
bl fen_set_location
mov x1, #3
b Lfn5end
Lfn5fail711_4:
adrp x0, Lfn5fail711_4location
add x0, x0, :lo12:Lfn5fail711_4location
bl fen_set_location
mov x1, #4
b Lfn5end
Lfn5fail710_1:
adrp x0, Lfn5fail710_1location
add x0, x0, :lo12:Lfn5fail710_1location
bl fen_set_location
mov x1, #1
b Lfn5end
Lfn5fail717_1:
adrp x0, Lfn5fail717_1location
add x0, x0, :lo12:Lfn5fail717_1location
bl fen_set_location
mov x1, #1
b Lfn5end
Lfn5fail725_1:
adrp x0, Lfn5fail725_1location
add x0, x0, :lo12:Lfn5fail725_1location
bl fen_set_location
mov x1, #1
b Lfn5end
Lfn5fail729_3:
adrp x0, Lfn5fail729_3location
add x0, x0, :lo12:Lfn5fail729_3location
bl fen_set_location
mov x1, #3
b Lfn5end
Lfn5fail724_3:
adrp x0, Lfn5fail724_3location
add x0, x0, :lo12:Lfn5fail724_3location
bl fen_set_location
mov x1, #3
b Lfn5end
Lfn5fail735_1:
adrp x0, Lfn5fail735_1location
add x0, x0, :lo12:Lfn5fail735_1location
bl fen_set_location
mov x1, #1
b Lfn5end
Lfn5fail744_1:
adrp x0, Lfn5fail744_1location
add x0, x0, :lo12:Lfn5fail744_1location
bl fen_set_location
mov x1, #1
b Lfn5end
Lfn5fail742_4:
adrp x0, Lfn5fail742_4location
add x0, x0, :lo12:Lfn5fail742_4location
bl fen_set_location
mov x1, #4
b Lfn5end
Lfn5fail740_1:
adrp x0, Lfn5fail740_1location
add x0, x0, :lo12:Lfn5fail740_1location
bl fen_set_location
mov x1, #1
b Lfn5end
Lfn5fail751_3:
adrp x0, Lfn5fail751_3location
add x0, x0, :lo12:Lfn5fail751_3location
bl fen_set_location
mov x1, #3
b Lfn5end
Lfn5fail757_1:
adrp x0, Lfn5fail757_1location
add x0, x0, :lo12:Lfn5fail757_1location
bl fen_set_location
mov x1, #1
b Lfn5end
Lfn5fail755_4:
adrp x0, Lfn5fail755_4location
add x0, x0, :lo12:Lfn5fail755_4location
bl fen_set_location
mov x1, #4
b Lfn5end
Lfn5fail765_1:
adrp x0, Lfn5fail765_1location
add x0, x0, :lo12:Lfn5fail765_1location
bl fen_set_location
mov x1, #1
b Lfn5end
Lfn5fail764_3:
adrp x0, Lfn5fail764_3location
add x0, x0, :lo12:Lfn5fail764_3location
bl fen_set_location
mov x1, #3
b Lfn5end
Lfn5fail770_1:
adrp x0, Lfn5fail770_1location
add x0, x0, :lo12:Lfn5fail770_1location
bl fen_set_location
mov x1, #1
b Lfn5end
Lfn5fail775_1:
adrp x0, Lfn5fail775_1location
add x0, x0, :lo12:Lfn5fail775_1location
bl fen_set_location
mov x1, #1
b Lfn5end
Lfn5fail781_1:
adrp x0, Lfn5fail781_1location
add x0, x0, :lo12:Lfn5fail781_1location
bl fen_set_location
mov x1, #1
b Lfn5end
Lfn5fail787_1:
adrp x0, Lfn5fail787_1location
add x0, x0, :lo12:Lfn5fail787_1location
bl fen_set_location
mov x1, #1
b Lfn5end
Lfn5fail809_1:
adrp x0, Lfn5fail809_1location
add x0, x0, :lo12:Lfn5fail809_1location
bl fen_set_location
mov x1, #1
b Lfn5end
Lfn5fail808_1:
adrp x0, Lfn5fail808_1location
add x0, x0, :lo12:Lfn5fail808_1location
bl fen_set_location
mov x1, #1
b Lfn5end
Lfn5fail827_1:
adrp x0, Lfn5fail827_1location
add x0, x0, :lo12:Lfn5fail827_1location
bl fen_set_location
mov x1, #1
b Lfn5end
Lfn5fail826_1:
adrp x0, Lfn5fail826_1location
add x0, x0, :lo12:Lfn5fail826_1location
bl fen_set_location
mov x1, #1
b Lfn5end
Lfn5fail849_1:
adrp x0, Lfn5fail849_1location
add x0, x0, :lo12:Lfn5fail849_1location
bl fen_set_location
mov x1, #1
b Lfn5end
Lfn5fail848_1:
adrp x0, Lfn5fail848_1location
add x0, x0, :lo12:Lfn5fail848_1location
bl fen_set_location
mov x1, #1
b Lfn5end
Lfn5fail867_1:
adrp x0, Lfn5fail867_1location
add x0, x0, :lo12:Lfn5fail867_1location
bl fen_set_location
mov x1, #1
b Lfn5end
Lfn5fail866_1:
adrp x0, Lfn5fail866_1location
add x0, x0, :lo12:Lfn5fail866_1location
bl fen_set_location
mov x1, #1
b Lfn5end
Lfn5fail885_1:
adrp x0, Lfn5fail885_1location
add x0, x0, :lo12:Lfn5fail885_1location
bl fen_set_location
mov x1, #1
b Lfn5end
Lfn5fail892_3:
adrp x0, Lfn5fail892_3location
add x0, x0, :lo12:Lfn5fail892_3location
bl fen_set_location
mov x1, #3
b Lfn5end
Lfn5fail884_3:
adrp x0, Lfn5fail884_3location
add x0, x0, :lo12:Lfn5fail884_3location
bl fen_set_location
mov x1, #3
b Lfn5end
Lfn5end:
bl fen_leave_result
ldp x19, x20, [x29, #-16]
ldp x21, x22, [x29, #-32]
ldp x23, x24, [x29, #-48]
ldp x25, x26, [x29, #-64]
mov sp, x29
ldp x29, x30, [sp], #16
ldp x27, x28, [sp], #16
ret
Lfn6:
ldp x8, x9, [x0, #0]
ldp x10, x11, [x0, #16]
Lfn6fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #80
str x8, [sp, #64]
stp x9, x10, [sp, #48]
str x11, [sp, #72]
add x0, sp, #16
add x1, sp, #48
mov x2, #2
bl fen_enter
Lfn6loop:
ldr x0, [sp, #48]
ldr w0, [x0, #72]
cmp w0, #9
b.eq Lfn6match917arm9
cmp w0, #11
b.eq Lfn6match917arm11
cmp w0, #12
b.eq Lfn6match917arm12
cmp w0, #10
b.eq Lfn6match917arm10
brk #0
Lfn6match917arm9:
bl fen_leave_result
ldr x8, [sp, #64]
ldr x9, [sp, #56]
ldr x10, [sp, #72]
adrp x11, Lconstant0
add x11, x11, :lo12:Lconstant0
adrp x12, Lconstant0
add x12, x12, :lo12:Lconstant0
adrp x13, Lconstant0
add x13, x13, :lo12:Lconstant0
adrp x14, Lconstant0
add x14, x14, :lo12:Lconstant0
mov sp, x29
ldp x29, x30, [sp], #16
b Lfn5fields
b Lfn6match917end
Lfn6match917arm11:
bl fen_leave_result
ldr x8, [sp, #64]
ldr x9, [sp, #56]
ldr x10, [sp, #72]
ldr x11, [sp, #48]
ldr x11, [x11, #0]
ldr x12, [sp, #48]
ldr x12, [x12, #8]
ldr x13, [sp, #48]
ldr x13, [x13, #16]
ldr x14, [sp, #48]
ldr x14, [x14, #24]
mov sp, x29
ldp x29, x30, [sp], #16
b Lfn5fields
b Lfn6match917end
Lfn6match917arm12:
mov x0, #0
mov x1, #17
bl fen_allocate
cbz x0, Lfn6fail949_3
ldr x2, [sp, #64]
str x2, [x0, #0]
b Lfn6match917end
Lfn6match917arm10:
mov x0, #0
mov x1, #17
bl fen_allocate
cbz x0, Lfn6fail958_3
ldr x2, [sp, #64]
str x2, [x0, #0]
b Lfn6match917end
Lfn6match917end:
mov x1, #0
b Lfn6end
Lfn6fail949_3:
adrp x0, Lfn6fail949_3location
add x0, x0, :lo12:Lfn6fail949_3location
bl fen_set_location
mov x1, #3
b Lfn6end
Lfn6fail958_3:
adrp x0, Lfn6fail958_3location
add x0, x0, :lo12:Lfn6fail958_3location
bl fen_set_location
mov x1, #3
b Lfn6end
Lfn6end:
bl fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn7:
ldp x8, x9, [x0, #0]
ldr x10, [x0, #16]
Lfn7fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
stp x19, x20, [sp, #-16]!
stp x21, x22, [sp, #-16]!
stp x23, xzr, [sp, #-16]!
sub sp, sp, #240
stp xzr, xzr, [sp, #64]
str xzr, [sp, #80]
stp x8, x9, [sp, #48]
mov x19, x10
add x0, sp, #16
add x1, sp, #48
mov x2, #5
bl fen_enter
Lfn7loop:
ldr x0, [sp, #56]
ldr x0, [x0]
str x0, [sp, #88]
mov x0, x19
ldr x2, [sp, #88]
cmp x0, x2
b.ne Lfn7if974else
ldr x0, [sp, #48]
b Lfn7if974done
Lfn7if974else:
ldr x0, [sp, #48]
ldr w0, [x0, #72]
cmp w0, #17
b.eq Lfn7match980arm17
cmp w0, #13
b.eq Lfn7match980arm13
cmp w0, #14
b.eq Lfn7match980arm14
cmp w0, #15
b.eq Lfn7match980arm15
cmp w0, #16
b.eq Lfn7match980arm16
brk #0
Lfn7match980arm17:
ldr x0, [sp, #48]
b Lfn7match980end
Lfn7match980arm13:
bl fen_leave_result
ldr x8, [sp, #48]
ldr x8, [x8, #0]
ldr x9, [sp, #48]
ldr x9, [x9, #8]
ldr x10, [sp, #56]
mov x11, x19
ldp x19, x20, [x29, #-16]
ldp x21, x22, [x29, #-32]
ldp x23, xzr, [x29, #-48]
mov sp, x29
ldp x29, x30, [sp], #16
b Lfn6fields
b Lfn7match980end
Lfn7match980arm14:
ldr x0, [sp, #56]
mov x2, x19
ldr x3, [x0]
cmp x2, x3
b.hs Lfn7fail999_4
ldr w3, [x0, #72]
cmn w3, #1
b.ne 1f
add x0, x0, #80
ldrb w0, [x0, x2]
b 2f
1:
mov x1, x2
bl fen_bytes_index
2:
str x0, [sp, #96]
ldr x0, [sp, #48]
ldr x0, [x0, #8]
ldr x2, [sp, #96]
adds x0, x0, x2
b.vs Lfn7fail997_1
str x0, [sp, #104]
cmp x0, #0
b.ne Lfn7if1002else
ldr x0, [sp, #48]
ldr x0, [x0, #0]
subs x0, x0, #1
b.vs Lfn7fail1007_1
str x0, [sp, #112]
mov x0, #0
mov x1, #17
bl fen_allocate
cbz x0, Lfn7fail1006_3
ldr x2, [sp, #112]
str x2, [x0, #0]
b Lfn7if1002done
Lfn7if1002else:
ldr x0, [sp, #48]
ldr x0, [x0, #0]
adds x0, x0, #1
b.vs Lfn7fail1013_1
str x0, [sp, #120]
mov x0, #4
mov x1, #15
bl fen_allocate
cbz x0, Lfn7fail1012_3
ldr x2, [sp, #120]
ldr x3, [sp, #104]
stp x2, x3, [x0, #0]
ldr x2, [sp, #48]
ldr x2, [x2, #16]
str x2, [x0, #16]
str x0, [sp, #64]
mov x0, x19
adds x0, x0, #1
b.vs Lfn7fail1019_1
str x0, [sp, #128]
ldr x8, [sp, #64]
ldr x9, [sp, #128]
str x8, [sp, #48]
mov x19, x9
stp xzr, xzr, [sp, #64]
str xzr, [sp, #80]
b Lfn7loop
Lfn7if1002done:
b Lfn7match980end
Lfn7match980arm15:
ldr x0, [sp, #56]
mov x2, x19
ldr x3, [x0]
cmp x2, x3
b.hs Lfn7fail1027_4
ldr w3, [x0, #72]
cmn w3, #1
b.ne 1f
add x0, x0, #80
ldrb w0, [x0, x2]
b 2f
1:
mov x1, x2
bl fen_bytes_index
2:
mov x21, x0
movz x0, #63, lsl #0
mov x2, x21
cmp x0, x2
b.ge Lfn7if1030else
mov x0, #0
mov x1, #17
bl fen_allocate
cbz x0, Lfn7fail1034_3
ldr x2, [sp, #48]
ldr x2, [x2, #0]
str x2, [x0, #0]
b Lfn7if1030done
Lfn7if1030else:
ldr x0, [sp, #48]
ldr x0, [x0, #8]
cmp x0, #1
b.ne Lfn7if1038else
ldr x0, [sp, #48]
ldr x0, [x0, #0]
adds x0, x0, #1
b.vs Lfn7fail1043_1
str x0, [sp, #136]
movz x0, #0, lsl #0
str x0, [sp, #144]
movz x0, #0, lsl #0
str x0, [sp, #152]
ldr x8, [sp, #48]
ldr x8, [x8, #16]
mov x9, x21
ldr x10, [sp, #144]
ldr x11, [sp, #152]
bl Lfn2fields
cbnz x1, Lfn7end
str x0, [sp, #64]
mov x0, #2
mov x1, #13
bl fen_allocate
cbz x0, Lfn7fail1042_3
ldr x2, [sp, #136]
ldr x3, [sp, #64]
stp x2, x3, [x0, #0]
str x0, [sp, #72]
b Lfn7if1038done
Lfn7if1038else:
ldr x0, [sp, #48]
ldr x0, [x0, #0]
adds x0, x0, #1
b.vs Lfn7fail1053_1
str x0, [sp, #160]
ldr x0, [sp, #48]
ldr x0, [x0, #8]
subs x0, x0, #1
b.vs Lfn7fail1057_1
str x0, [sp, #168]
ldr x0, [sp, #48]
ldr x0, [x0, #8]
subs x0, x0, #1
b.vs Lfn7fail1060_1
str x0, [sp, #176]
movz x0, #0, lsl #0
str x0, [sp, #184]
mov x0, #32
mov x1, #16
bl fen_allocate
cbz x0, Lfn7fail1052_3
ldr x2, [sp, #160]
mov x3, x21
stp x2, x3, [x0, #0]
ldr x2, [sp, #168]
ldr x3, [sp, #176]
stp x2, x3, [x0, #16]
ldr x2, [sp, #184]
ldr x3, [sp, #48]
ldr x3, [x3, #16]
stp x2, x3, [x0, #32]
str x0, [sp, #64]
Lfn7if1038done:
str x0, [sp, #80]
mov x0, x19
adds x0, x0, #1
b.vs Lfn7fail1066_1
str x0, [sp, #192]
ldr x8, [sp, #80]
ldr x9, [sp, #192]
str x8, [sp, #48]
mov x19, x9
stp xzr, xzr, [sp, #64]
str xzr, [sp, #80]
b Lfn7loop
Lfn7if1030done:
b Lfn7match980end
Lfn7match980arm16:
ldr x0, [sp, #56]
ldr x0, [x0]
mov x2, x19
subs x0, x0, x2
b.vs Lfn7fail1077_1
str x0, [sp, #200]
ldr x2, [sp, #48]
ldr x2, [x2, #24]
cmp x0, x2
b.ge Lfn7if1083else
ldr x0, [sp, #200]
b Lfn7if1083done
Lfn7if1083else:
ldr x0, [sp, #48]
ldr x0, [x0, #24]
Lfn7if1083done:
mov x20, x0
mov x0, x19
mov x2, x20
adds x0, x0, x2
b.vs Lfn7fail1091_1
mov x22, x0
ldr x8, [sp, #56]
mov x9, x19
mov x10, x22
ldr x11, [sp, #48]
ldr x11, [x11, #32]
bl Lfn4fields
cbnz x1, Lfn7end
mov x23, x0
mov x0, x20
ldr x2, [sp, #48]
ldr x2, [x2, #24]
cmp x0, x2
b.ne Lfn7if1102else
ldr x0, [sp, #48]
ldr x0, [x0, #0]
mov x2, x20
adds x0, x0, x2
b.vs Lfn7fail1109_1
str x0, [sp, #208]
ldr x8, [sp, #48]
ldr x8, [x8, #40]
ldr x9, [sp, #48]
ldr x9, [x9, #8]
ldr x10, [sp, #48]
ldr x10, [x10, #16]
mov x11, x23
bl Lfn2fields
cbnz x1, Lfn7end
str x0, [sp, #64]
mov x0, #2
mov x1, #13
bl fen_allocate
cbz x0, Lfn7fail1108_3
ldr x2, [sp, #208]
ldr x3, [sp, #64]
stp x2, x3, [x0, #0]
str x0, [sp, #72]
ldr x8, [sp, #72]
mov x9, x22
str x8, [sp, #48]
mov x19, x9
stp xzr, xzr, [sp, #64]
str xzr, [sp, #80]
b Lfn7loop
b Lfn7if1102done
Lfn7if1102else:
ldr x0, [sp, #48]
ldr x0, [x0, #0]
mov x2, x20
adds x0, x0, x2
b.vs Lfn7fail1121_1
str x0, [sp, #216]
ldr x0, [sp, #48]
ldr x0, [x0, #24]
mov x2, x20
subs x0, x0, x2
b.vs Lfn7fail1126_1
str x0, [sp, #224]
mov x0, #32
mov x1, #16
bl fen_allocate
cbz x0, Lfn7fail1120_3
ldr x2, [sp, #216]
ldr x3, [sp, #48]
ldr x3, [x3, #8]
stp x2, x3, [x0, #0]
ldr x2, [sp, #48]
ldr x2, [x2, #16]
ldr x3, [sp, #224]
stp x2, x3, [x0, #16]
mov x2, x23
ldr x3, [sp, #48]
ldr x3, [x3, #40]
stp x2, x3, [x0, #32]
Lfn7if1102done:
b Lfn7match980end
Lfn7match980end:
Lfn7if974done:
mov x1, #0
b Lfn7end
Lfn7fail999_4:
adrp x0, Lfn7fail999_4location
add x0, x0, :lo12:Lfn7fail999_4location
bl fen_set_location
mov x1, #4
b Lfn7end
Lfn7fail997_1:
adrp x0, Lfn7fail997_1location
add x0, x0, :lo12:Lfn7fail997_1location
bl fen_set_location
mov x1, #1
b Lfn7end
Lfn7fail1007_1:
adrp x0, Lfn7fail1007_1location
add x0, x0, :lo12:Lfn7fail1007_1location
bl fen_set_location
mov x1, #1
b Lfn7end
Lfn7fail1006_3:
adrp x0, Lfn7fail1006_3location
add x0, x0, :lo12:Lfn7fail1006_3location
bl fen_set_location
mov x1, #3
b Lfn7end
Lfn7fail1013_1:
adrp x0, Lfn7fail1013_1location
add x0, x0, :lo12:Lfn7fail1013_1location
bl fen_set_location
mov x1, #1
b Lfn7end
Lfn7fail1012_3:
adrp x0, Lfn7fail1012_3location
add x0, x0, :lo12:Lfn7fail1012_3location
bl fen_set_location
mov x1, #3
b Lfn7end
Lfn7fail1019_1:
adrp x0, Lfn7fail1019_1location
add x0, x0, :lo12:Lfn7fail1019_1location
bl fen_set_location
mov x1, #1
b Lfn7end
Lfn7fail1027_4:
adrp x0, Lfn7fail1027_4location
add x0, x0, :lo12:Lfn7fail1027_4location
bl fen_set_location
mov x1, #4
b Lfn7end
Lfn7fail1034_3:
adrp x0, Lfn7fail1034_3location
add x0, x0, :lo12:Lfn7fail1034_3location
bl fen_set_location
mov x1, #3
b Lfn7end
Lfn7fail1043_1:
adrp x0, Lfn7fail1043_1location
add x0, x0, :lo12:Lfn7fail1043_1location
bl fen_set_location
mov x1, #1
b Lfn7end
Lfn7fail1042_3:
adrp x0, Lfn7fail1042_3location
add x0, x0, :lo12:Lfn7fail1042_3location
bl fen_set_location
mov x1, #3
b Lfn7end
Lfn7fail1053_1:
adrp x0, Lfn7fail1053_1location
add x0, x0, :lo12:Lfn7fail1053_1location
bl fen_set_location
mov x1, #1
b Lfn7end
Lfn7fail1057_1:
adrp x0, Lfn7fail1057_1location
add x0, x0, :lo12:Lfn7fail1057_1location
bl fen_set_location
mov x1, #1
b Lfn7end
Lfn7fail1060_1:
adrp x0, Lfn7fail1060_1location
add x0, x0, :lo12:Lfn7fail1060_1location
bl fen_set_location
mov x1, #1
b Lfn7end
Lfn7fail1052_3:
adrp x0, Lfn7fail1052_3location
add x0, x0, :lo12:Lfn7fail1052_3location
bl fen_set_location
mov x1, #3
b Lfn7end
Lfn7fail1066_1:
adrp x0, Lfn7fail1066_1location
add x0, x0, :lo12:Lfn7fail1066_1location
bl fen_set_location
mov x1, #1
b Lfn7end
Lfn7fail1077_1:
adrp x0, Lfn7fail1077_1location
add x0, x0, :lo12:Lfn7fail1077_1location
bl fen_set_location
mov x1, #1
b Lfn7end
Lfn7fail1091_1:
adrp x0, Lfn7fail1091_1location
add x0, x0, :lo12:Lfn7fail1091_1location
bl fen_set_location
mov x1, #1
b Lfn7end
Lfn7fail1109_1:
adrp x0, Lfn7fail1109_1location
add x0, x0, :lo12:Lfn7fail1109_1location
bl fen_set_location
mov x1, #1
b Lfn7end
Lfn7fail1108_3:
adrp x0, Lfn7fail1108_3location
add x0, x0, :lo12:Lfn7fail1108_3location
bl fen_set_location
mov x1, #3
b Lfn7end
Lfn7fail1121_1:
adrp x0, Lfn7fail1121_1location
add x0, x0, :lo12:Lfn7fail1121_1location
bl fen_set_location
mov x1, #1
b Lfn7end
Lfn7fail1126_1:
adrp x0, Lfn7fail1126_1location
add x0, x0, :lo12:Lfn7fail1126_1location
bl fen_set_location
mov x1, #1
b Lfn7end
Lfn7fail1120_3:
adrp x0, Lfn7fail1120_3location
add x0, x0, :lo12:Lfn7fail1120_3location
bl fen_set_location
mov x1, #3
b Lfn7end
Lfn7end:
bl fen_leave_result
ldp x19, x20, [x29, #-16]
ldp x21, x22, [x29, #-32]
ldp x23, xzr, [x29, #-48]
mov sp, x29
ldp x29, x30, [sp], #16
ret
.globl stream_feed
stream_feed:
Lfn8:
ldp x8, x9, [x0, #0]
Lfn8fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #80
stp x8, x9, [sp, #48]
Lfn8loop:
movz x0, #0, lsl #0
str x0, [sp, #64]
ldr x8, [sp, #48]
ldr x9, [sp, #56]
ldr x10, [sp, #64]
mov sp, x29
ldp x29, x30, [sp], #16
b Lfn7fields
mov x1, #0
b Lfn8end
Lfn8end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
.globl stream_finish
stream_finish:
Lfn9:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
str xzr, [sp, #56]
str x0, [sp, #48]
add x0, sp, #16
add x1, sp, #48
mov x2, #2
bl fen_enter
ldr x0, [sp, #48]
ldr w0, [x0, #72]
cmp w0, #13
b.eq Lfn9match1148arm13
cmp w0, #14
b.eq Lfn9match1148arm14
cmp w0, #15
b.eq Lfn9match1148arm15
cmp w0, #16
b.eq Lfn9match1148arm16
cmp w0, #17
b.eq Lfn9match1148arm17
brk #0
Lfn9match1148arm13:
ldr x8, [sp, #48]
ldr x8, [x8, #8]
adrp x9, Lconstant2
add x9, x9, :lo12:Lconstant2
bl Lfn3fields
cbnz x1, Lfn9end
str x0, [sp, #56]
mov x0, #1
mov x1, #18
bl fen_allocate
cbz x0, Lfn9fail1152_3
ldr x2, [sp, #56]
str x2, [x0, #0]
b Lfn9match1148end
Lfn9match1148arm14:
mov x0, #0
mov x1, #19
bl fen_allocate
cbz x0, Lfn9fail1160_3
ldr x2, [sp, #48]
ldr x2, [x2, #0]
str x2, [x0, #0]
b Lfn9match1148end
Lfn9match1148arm15:
mov x0, #0
mov x1, #19
bl fen_allocate
cbz x0, Lfn9fail1165_3
ldr x2, [sp, #48]
ldr x2, [x2, #0]
str x2, [x0, #0]
b Lfn9match1148end
Lfn9match1148arm16:
mov x0, #0
mov x1, #19
bl fen_allocate
cbz x0, Lfn9fail1173_3
ldr x2, [sp, #48]
ldr x2, [x2, #0]
str x2, [x0, #0]
b Lfn9match1148end
Lfn9match1148arm17:
mov x0, #0
mov x1, #19
bl fen_allocate
cbz x0, Lfn9fail1176_3
ldr x2, [sp, #48]
ldr x2, [x2, #0]
str x2, [x0, #0]
b Lfn9match1148end
Lfn9match1148end:
mov x1, #0
b Lfn9end
Lfn9fail1152_3:
adrp x0, Lfn9fail1152_3location
add x0, x0, :lo12:Lfn9fail1152_3location
bl fen_set_location
mov x1, #3
b Lfn9end
Lfn9fail1160_3:
adrp x0, Lfn9fail1160_3location
add x0, x0, :lo12:Lfn9fail1160_3location
bl fen_set_location
mov x1, #3
b Lfn9end
Lfn9fail1165_3:
adrp x0, Lfn9fail1165_3location
add x0, x0, :lo12:Lfn9fail1165_3location
bl fen_set_location
mov x1, #3
b Lfn9end
Lfn9fail1173_3:
adrp x0, Lfn9fail1173_3location
add x0, x0, :lo12:Lfn9fail1173_3location
bl fen_set_location
mov x1, #3
b Lfn9end
Lfn9fail1176_3:
adrp x0, Lfn9fail1176_3location
add x0, x0, :lo12:Lfn9fail1176_3location
bl fen_set_location
mov x1, #3
b Lfn9end
Lfn9end:
bl fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn10:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
str x0, [sp, #48]
ldr x0, [sp, #48]
cmp x0, #5
b.ge Lfn10if1180else
ldr x0, [sp, #48]
cmp x0, #2
b.ge Lfn10if1184else
ldr x0, [sp, #48]
cmp x0, #0
b.ne Lfn10if1188else
adrp x0, Lconstant3
add x0, x0, :lo12:Lconstant3
b Lfn10if1188done
Lfn10if1188else:
adrp x0, Lconstant4
add x0, x0, :lo12:Lconstant4
Lfn10if1188done:
b Lfn10if1184done
Lfn10if1184else:
ldr x0, [sp, #48]
cmp x0, #2
b.ne Lfn10if1194else
adrp x0, Lconstant5
add x0, x0, :lo12:Lconstant5
b Lfn10if1194done
Lfn10if1194else:
ldr x0, [sp, #48]
cmp x0, #3
b.ne Lfn10if1199else
adrp x0, Lconstant6
add x0, x0, :lo12:Lconstant6
b Lfn10if1199done
Lfn10if1199else:
adrp x0, Lconstant7
add x0, x0, :lo12:Lconstant7
Lfn10if1199done:
Lfn10if1194done:
Lfn10if1184done:
b Lfn10if1180done
Lfn10if1180else:
ldr x0, [sp, #48]
cmp x0, #7
b.ge Lfn10if1205else
ldr x0, [sp, #48]
cmp x0, #5
b.ne Lfn10if1209else
adrp x0, Lconstant8
add x0, x0, :lo12:Lconstant8
b Lfn10if1209done
Lfn10if1209else:
adrp x0, Lconstant9
add x0, x0, :lo12:Lconstant9
Lfn10if1209done:
b Lfn10if1205done
Lfn10if1205else:
ldr x0, [sp, #48]
cmp x0, #7
b.ne Lfn10if1215else
adrp x0, Lconstant10
add x0, x0, :lo12:Lconstant10
b Lfn10if1215done
Lfn10if1215else:
ldr x0, [sp, #48]
cmp x0, #8
b.ne Lfn10if1220else
adrp x0, Lconstant11
add x0, x0, :lo12:Lconstant11
b Lfn10if1220done
Lfn10if1220else:
adrp x0, Lconstant12
add x0, x0, :lo12:Lconstant12
Lfn10if1220done:
Lfn10if1215done:
Lfn10if1205done:
Lfn10if1180done:
mov x1, #0
b Lfn10end
Lfn10end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn11:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #112
stp xzr, xzr, [sp, #48]
str x0, [sp, #64]
add x0, sp, #16
add x1, sp, #48
mov x2, #2
bl fen_enter
ldr x0, [sp, #64]
cmp x0, #10
b.ge Lfn11if1228else
ldr x0, [sp, #64]
bl fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
b Lfn10
b Lfn11if1228done
Lfn11if1228else:
movz x0, #10, lsl #0
str x0, [sp, #72]
ldr x0, [sp, #64]
ldr x2, [sp, #72]
cbz x2, Lfn11fail1236_2
cmn x2, #1
b.ne 1f
negs x3, x0
b.vs Lfn11fail1236_1
1:
sdiv x0, x0, x2
str x0, [sp, #80]
bl Lfn11
cbnz x1, Lfn11end
str x0, [sp, #48]
movz x0, #10, lsl #0
str x0, [sp, #88]
ldr x0, [sp, #80]
ldr x2, [sp, #88]
smulh x3, x0, x2
mul x0, x0, x2
cmp x3, x0, asr #63
b.ne Lfn11fail1245_1
str x0, [sp, #96]
ldr x0, [sp, #64]
ldr x2, [sp, #96]
subs x0, x0, x2
b.vs Lfn11fail1243_1
bl Lfn10
cbnz x1, Lfn11end
str x0, [sp, #56]
ldr x0, [sp, #48]
ldr x2, [sp, #56]
mov x1, x2
bl fen_bytes_concat
cbz x0, Lfn11fail1239_3
Lfn11if1228done:
mov x1, #0
b Lfn11end
Lfn11fail1236_2:
adrp x0, Lfn11fail1236_2location
add x0, x0, :lo12:Lfn11fail1236_2location
bl fen_set_location
mov x1, #2
b Lfn11end
Lfn11fail1236_1:
adrp x0, Lfn11fail1236_1location
add x0, x0, :lo12:Lfn11fail1236_1location
bl fen_set_location
mov x1, #1
b Lfn11end
Lfn11fail1245_1:
adrp x0, Lfn11fail1245_1location
add x0, x0, :lo12:Lfn11fail1245_1location
bl fen_set_location
mov x1, #1
b Lfn11end
Lfn11fail1243_1:
adrp x0, Lfn11fail1243_1location
add x0, x0, :lo12:Lfn11fail1243_1location
bl fen_set_location
mov x1, #1
b Lfn11end
Lfn11fail1239_3:
adrp x0, Lfn11fail1239_3location
add x0, x0, :lo12:Lfn11fail1239_3location
bl fen_set_location
mov x1, #3
b Lfn11end
Lfn11end:
bl fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn12:
ldp x8, x9, [x0, #0]
ldp x10, x11, [x0, #16]
Lfn12fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #160
stp xzr, xzr, [sp, #48]
stp xzr, xzr, [sp, #64]
stp xzr, xzr, [sp, #80]
stp xzr, xzr, [sp, #96]
stp xzr, xzr, [sp, #112]
stp x8, x9, [sp, #128]
stp x10, x11, [sp, #144]
add x0, sp, #16
add x1, sp, #48
mov x2, #10
bl fen_enter
Lfn12loop:
ldr x0, [sp, #128]
bl Lfn11
cbnz x1, Lfn12end
str x0, [sp, #48]
ldr x0, [sp, #136]
bl Lfn11
cbnz x1, Lfn12end
str x0, [sp, #56]
adrp x0, Lconstant13
add x0, x0, :lo12:Lconstant13
ldr x2, [sp, #56]
mov x1, x2
bl fen_bytes_concat
cbz x0, Lfn12fail1270_3
str x0, [sp, #64]
ldr x0, [sp, #48]
ldr x2, [sp, #64]
mov x1, x2
bl fen_bytes_concat
cbz x0, Lfn12fail1267_3
str x0, [sp, #72]
ldr x0, [sp, #144]
bl Lfn11
cbnz x1, Lfn12end
str x0, [sp, #80]
adrp x0, Lconstant13
add x0, x0, :lo12:Lconstant13
ldr x2, [sp, #80]
mov x1, x2
bl fen_bytes_concat
cbz x0, Lfn12fail1275_3
str x0, [sp, #88]
ldr x0, [sp, #152]
bl Lfn11
cbnz x1, Lfn12end
str x0, [sp, #96]
adrp x2, Lconstant14
add x2, x2, :lo12:Lconstant14
mov x1, x2
bl fen_bytes_concat
cbz x0, Lfn12fail1281_3
str x0, [sp, #104]
adrp x0, Lconstant13
add x0, x0, :lo12:Lconstant13
ldr x2, [sp, #104]
mov x1, x2
bl fen_bytes_concat
cbz x0, Lfn12fail1279_3
str x0, [sp, #112]
ldr x0, [sp, #88]
ldr x2, [sp, #112]
mov x1, x2
bl fen_bytes_concat
cbz x0, Lfn12fail1274_3
str x0, [sp, #120]
ldr x0, [sp, #72]
ldr x2, [sp, #120]
mov x1, x2
bl fen_bytes_concat
cbz x0, Lfn12fail1266_3
mov x1, #0
b Lfn12end
Lfn12fail1270_3:
adrp x0, Lfn12fail1270_3location
add x0, x0, :lo12:Lfn12fail1270_3location
bl fen_set_location
mov x1, #3
b Lfn12end
Lfn12fail1267_3:
adrp x0, Lfn12fail1267_3location
add x0, x0, :lo12:Lfn12fail1267_3location
bl fen_set_location
mov x1, #3
b Lfn12end
Lfn12fail1275_3:
adrp x0, Lfn12fail1275_3location
add x0, x0, :lo12:Lfn12fail1275_3location
bl fen_set_location
mov x1, #3
b Lfn12end
Lfn12fail1281_3:
adrp x0, Lfn12fail1281_3location
add x0, x0, :lo12:Lfn12fail1281_3location
bl fen_set_location
mov x1, #3
b Lfn12end
Lfn12fail1279_3:
adrp x0, Lfn12fail1279_3location
add x0, x0, :lo12:Lfn12fail1279_3location
bl fen_set_location
mov x1, #3
b Lfn12end
Lfn12fail1274_3:
adrp x0, Lfn12fail1274_3location
add x0, x0, :lo12:Lfn12fail1274_3location
bl fen_set_location
mov x1, #3
b Lfn12end
Lfn12fail1266_3:
adrp x0, Lfn12fail1266_3location
add x0, x0, :lo12:Lfn12fail1266_3location
bl fen_set_location
mov x1, #3
b Lfn12end
Lfn12end:
bl fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
.globl stream_rejection_line
stream_rejection_line:
Lfn13:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #80
stp xzr, xzr, [sp, #48]
str x0, [sp, #64]
add x0, sp, #16
add x1, sp, #48
mov x2, #2
bl fen_enter
ldr x0, [sp, #64]
bl Lfn11
cbnz x1, Lfn13end
str x0, [sp, #48]
adrp x2, Lconstant14
add x2, x2, :lo12:Lconstant14
mov x1, x2
bl fen_bytes_concat
cbz x0, Lfn13fail1289_3
str x0, [sp, #56]
adrp x0, Lconstant15
add x0, x0, :lo12:Lconstant15
ldr x2, [sp, #56]
mov x1, x2
bl fen_bytes_concat
cbz x0, Lfn13fail1287_3
mov x1, #0
b Lfn13end
Lfn13fail1289_3:
adrp x0, Lfn13fail1289_3location
add x0, x0, :lo12:Lfn13fail1289_3location
bl fen_set_location
mov x1, #3
b Lfn13end
Lfn13fail1287_3:
adrp x0, Lfn13fail1287_3location
add x0, x0, :lo12:Lfn13fail1287_3location
bl fen_set_location
mov x1, #3
b Lfn13end
Lfn13end:
bl fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
.globl stream_next_line
stream_next_line:
Lfn14:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
str xzr, [sp, #56]
str x0, [sp, #48]
add x0, sp, #16
add x1, sp, #48
mov x2, #2
bl fen_enter
ldr x0, [sp, #48]
ldr w0, [x0, #72]
cmp w0, #7
b.eq Lfn14match1295arm7
cmp w0, #8
b.eq Lfn14match1295arm8
brk #0
Lfn14match1295arm7:
adrp x0, Lconstant16
add x0, x0, :lo12:Lconstant16
b Lfn14match1295end
Lfn14match1295arm8:
ldr x8, [sp, #48]
ldr x8, [x8, #0]
ldr x9, [sp, #48]
ldr x9, [x9, #8]
ldr x10, [sp, #48]
ldr x10, [x10, #16]
ldr x11, [sp, #48]
ldr x11, [x11, #24]
bl Lfn12fields
cbnz x1, Lfn14end
str x0, [sp, #56]
mov x0, #3
mov x1, #21
bl fen_allocate
cbz x0, Lfn14fail1303_3
ldr x2, [sp, #56]
ldr x3, [sp, #48]
ldr x3, [x3, #32]
stp x2, x3, [x0, #0]
b Lfn14match1295end
Lfn14match1295end:
mov x1, #0
b Lfn14end
Lfn14fail1303_3:
adrp x0, Lfn14fail1303_3location
add x0, x0, :lo12:Lfn14fail1303_3location
bl fen_set_location
mov x1, #3
b Lfn14end
Lfn14end:
bl fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
.globl fenrir_entry
fenrir_entry:
Lfn15:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
str x0, [sp, #48]
adrp x0, Lconstant17
add x0, x0, :lo12:Lconstant17
mov x1, #0
b Lfn15end
Lfn15end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
.globl stream_invalid_offset
stream_invalid_offset:
Lfn16:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
str x0, [sp, #48]
ldr x0, [sp, #48]
ldr w0, [x0, #72]
cmp w0, #13
b.eq Lfn16match1318arm13
cmp w0, #14
b.eq Lfn16match1318arm14
cmp w0, #15
b.eq Lfn16match1318arm15
cmp w0, #16
b.eq Lfn16match1318arm16
cmp w0, #17
b.eq Lfn16match1318arm17
brk #0
Lfn16match1318arm13:
movn x0, #0, lsl #0
b Lfn16match1318end
Lfn16match1318arm14:
movn x0, #0, lsl #0
b Lfn16match1318end
Lfn16match1318arm15:
movn x0, #0, lsl #0
b Lfn16match1318end
Lfn16match1318arm16:
movn x0, #0, lsl #0
b Lfn16match1318end
Lfn16match1318arm17:
ldr x0, [sp, #48]
ldr x0, [x0, #0]
b Lfn16match1318end
Lfn16match1318end:
mov x1, #0
b Lfn16end
Lfn16end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
.globl stream_final_offset
stream_final_offset:
Lfn17:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
str x0, [sp, #48]
ldr x0, [sp, #48]
ldr w0, [x0, #72]
cmp w0, #18
b.eq Lfn17match1342arm18
cmp w0, #19
b.eq Lfn17match1342arm19
brk #0
Lfn17match1342arm18:
movn x0, #0, lsl #0
b Lfn17match1342end
Lfn17match1342arm19:
ldr x0, [sp, #48]
ldr x0, [x0, #0]
b Lfn17match1342end
Lfn17match1342end:
mov x1, #0
b Lfn17end
Lfn17end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
.globl stream_summary_keys
stream_summary_keys:
Lfn18:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
str x0, [sp, #48]
ldr x0, [sp, #48]
ldr w0, [x0, #72]
cmp w0, #18
b.eq Lfn18match1350arm18
cmp w0, #19
b.eq Lfn18match1350arm19
brk #0
Lfn18match1350arm18:
ldr x0, [sp, #48]
ldr x0, [x0, #0]
b Lfn18match1350end
Lfn18match1350arm19:
adrp x0, Lconstant2
add x0, x0, :lo12:Lconstant2
b Lfn18match1350end
Lfn18match1350end:
mov x1, #0
b Lfn18end
Lfn18end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
.globl stream_line_bytes
stream_line_bytes:
Lfn19:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
str x0, [sp, #48]
ldr x0, [sp, #48]
ldr w0, [x0, #72]
cmp w0, #20
b.eq Lfn19match1358arm20
cmp w0, #21
b.eq Lfn19match1358arm21
brk #0
Lfn19match1358arm20:
adrp x0, Lconstant18
add x0, x0, :lo12:Lconstant18
b Lfn19match1358end
Lfn19match1358arm21:
ldr x0, [sp, #48]
ldr x0, [x0, #0]
b Lfn19match1358end
Lfn19match1358end:
mov x1, #0
b Lfn19end
Lfn19end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
.globl stream_remaining_keys
stream_remaining_keys:
Lfn20:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
str x0, [sp, #48]
ldr x0, [sp, #48]
ldr w0, [x0, #72]
cmp w0, #20
b.eq Lfn20match1366arm20
cmp w0, #21
b.eq Lfn20match1366arm21
brk #0
Lfn20match1366arm20:
adrp x0, Lconstant2
add x0, x0, :lo12:Lconstant2
b Lfn20match1366end
Lfn20match1366arm21:
ldr x0, [sp, #48]
ldr x0, [x0, #8]
b Lfn20match1366end
Lfn20match1366end:
mov x1, #0
b Lfn20end
Lfn20end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
.text
.globl fen_print_result
fen_print_result:
b Lprint0
Lprint0:
stp x19, x30, [sp, #-16]!
mov x19, x0
bl fen_tag
mov x1, #13
cmp x0, x1
b.eq Lprint0v13
mov x1, #14
cmp x0, x1
b.eq Lprint0v14
mov x1, #15
cmp x0, x1
b.eq Lprint0v15
mov x1, #16
cmp x0, x1
b.eq Lprint0v16
mov x1, #17
cmp x0, x1
b.eq Lprint0v17
brk #0
Lprint0v13:
adrp x0, Lstr0
add x0, x0, :lo12:Lstr0
mov x1, #9
bl fen_write
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #0]
bl Lprint1
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #8]
bl Lprint2
adrp x0, Lstr2
add x0, x0, :lo12:Lstr2
mov x1, #1
bl fen_write
b Lprint0done
Lprint0v14:
adrp x0, Lstr3
add x0, x0, :lo12:Lstr3
mov x1, #9
bl fen_write
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #0]
bl Lprint1
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #8]
bl Lprint1
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #16]
bl Lprint2
adrp x0, Lstr2
add x0, x0, :lo12:Lstr2
mov x1, #1
bl fen_write
b Lprint0done
Lprint0v15:
adrp x0, Lstr4
add x0, x0, :lo12:Lstr4
mov x1, #8
bl fen_write
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #0]
bl Lprint1
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #8]
bl Lprint1
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #16]
bl Lprint2
adrp x0, Lstr2
add x0, x0, :lo12:Lstr2
mov x1, #1
bl fen_write
b Lprint0done
Lprint0v16:
adrp x0, Lstr5
add x0, x0, :lo12:Lstr5
mov x1, #8
bl fen_write
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #0]
bl Lprint1
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #8]
bl Lprint1
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #16]
bl Lprint1
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #24]
bl Lprint1
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #32]
bl Lprint1
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #40]
bl Lprint2
adrp x0, Lstr2
add x0, x0, :lo12:Lstr2
mov x1, #1
bl fen_write
b Lprint0done
Lprint0v17:
adrp x0, Lstr6
add x0, x0, :lo12:Lstr6
mov x1, #8
bl fen_write
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #0]
bl Lprint1
adrp x0, Lstr2
add x0, x0, :lo12:Lstr2
mov x1, #1
bl fen_write
b Lprint0done
Lprint0done:
ldp x19, x30, [sp], #16
ret
Lprint1:
b fen_write_i64
Lprint2:
stp x19, x30, [sp, #-16]!
mov x19, x0
bl fen_tag
mov x1, #9
cmp x0, x1
b.eq Lprint2v9
mov x1, #10
cmp x0, x1
b.eq Lprint2v10
mov x1, #11
cmp x0, x1
b.eq Lprint2v11
mov x1, #12
cmp x0, x1
b.eq Lprint2v12
brk #0
Lprint2v9:
adrp x0, Lstr7
add x0, x0, :lo12:Lstr7
mov x1, #6
bl fen_write
b Lprint2done
Lprint2v10:
adrp x0, Lstr8
add x0, x0, :lo12:Lstr8
mov x1, #5
bl fen_write
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #0]
bl Lprint1
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #8]
bl Lprint1
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #16]
bl Lprint1
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #24]
bl Lprint1
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #32]
bl Lprint1
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #40]
bl Lprint1
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #48]
bl Lprint1
adrp x0, Lstr2
add x0, x0, :lo12:Lstr2
mov x1, #1
bl fen_write
b Lprint2done
Lprint2v11:
adrp x0, Lstr9
add x0, x0, :lo12:Lstr9
mov x1, #6
bl fen_write
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #0]
bl Lprint2
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #8]
bl Lprint2
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #16]
bl Lprint2
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #24]
bl Lprint2
adrp x0, Lstr2
add x0, x0, :lo12:Lstr2
mov x1, #1
bl fen_write
b Lprint2done
Lprint2v12:
adrp x0, Lstr10
add x0, x0, :lo12:Lstr10
mov x1, #7
bl fen_write
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #0]
bl Lprint2
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #8]
bl Lprint2
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #16]
bl Lprint2
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #24]
bl Lprint2
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #32]
bl Lprint2
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #40]
bl Lprint2
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #48]
bl Lprint2
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #56]
bl Lprint2
adrp x0, Lstr2
add x0, x0, :lo12:Lstr2
mov x1, #1
bl fen_write
b Lprint2done
Lprint2done:
ldp x19, x30, [sp], #16
ret
Lstr0:
.byte 40,76,101,110,103,116,104,72,105
Lstr1:
.byte 32
Lstr2:
.byte 41
Lstr3:
.byte 40,76,101,110,103,116,104,76,111
Lstr4:
.byte 40,82,101,97,100,75,101,121
Lstr5:
.byte 40,80,97,121,108,111,97,100
Lstr6:
.byte 40,73,110,118,97,108,105,100
Lstr7:
.byte 86,97,99,97,110,116
Lstr8:
.byte 40,80,97,105,114
Lstr9:
.byte 40,71,114,111,117,112
Lstr10:
.byte 40,66,114,97,110,99,104
Lfn0fail20_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,51,58,51,52,10,0
Lfn0fail31_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,53,58,51,53,10,0
Lfn0fail39_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,53,58,54,52,10,0
Lfn0fail60_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,55,58,49,55,10,0
Lfn0fail63_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,55,58,50,53,10,0
Lfn0fail66_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,55,58,51,54,10,0
Lfn0fail58_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,55,58,57,10,0
Lfn0fail77_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,56,58,50,51,10,0
Lfn0fail80_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,56,58,51,49,10,0
Lfn0fail83_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,56,58,52,50,10,0
Lfn0fail72_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,56,58,57,10,0
.p2align 3
Lconstant0:
.zero 72
.long 9
.byte 0,2,0,0
Lfn1fail136_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,50,54,58,49,54,10,0
Lfn1fail172_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,51,50,58,49,57,10,0
Lfn1fail181_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,51,51,58,49,57,10,0
Lfn1fail194_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,51,53,58,49,57,10,0
Lfn1fail203_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,51,54,58,49,57,10,0
Lfn1fail220_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,51,57,58,49,57,10,0
Lfn1fail229_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,52,48,58,49,57,10,0
Lfn1fail242_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,52,50,58,49,57,10,0
Lfn1fail251_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,52,51,58,49,57,10,0
Lfn1fail299_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,53,48,58,49,53,10,0
Lfn1fail313_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,53,49,58,49,53,10,0
Lfn1fail331_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,53,51,58,49,53,10,0
Lfn1fail345_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,53,52,58,49,53,10,0
Lfn1fail367_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,53,55,58,49,53,10,0
Lfn1fail381_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,53,56,58,49,53,10,0
Lfn1fail399_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,54,48,58,49,53,10,0
Lfn1fail413_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,54,49,58,49,53,10,0
.section .rodata
.p2align 3
Lconstant1:
.quad Lconstant0
.quad Lconstant0
.quad Lconstant0
.quad Lconstant0
.zero 40
.long 11
.byte 15,2,0,0
.text
Lfn2fail491_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,55,50,58,49,51,10,0
Lfn2fail501_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,55,52,58,49,51,10,0
Lfn2fail515_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,55,55,58,49,51,10,0
Lfn2fail525_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,55,57,58,49,51,10,0
Lfn3fail563_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,56,53,58,54,50,10,0
Lfn3fail562_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,56,53,58,53,55,10,0
Lfn3fail575_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,56,54,58,50,52,10,0
Lfn4fail657_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,57,51,58,50,50,10,0
Lfn4fail663_4location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,57,51,58,52,49,10,0
Lfn4fail661_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,57,51,58,51,52,10,0
Lfn5fail703_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,57,55,58,54,57,10,0
Lfn5fail701_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,57,55,58,53,54,10,0
Lfn5fail711_4location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,57,56,58,49,54,10,0
Lfn5fail710_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,57,56,58,49,51,10,0
Lfn5fail717_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,57,57,58,49,56,10,0
Lfn5fail725_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,48,48,58,51,52,10,0
Lfn5fail729_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,48,48,58,52,54,10,0
Lfn5fail724_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,48,48,58,50,52,10,0
Lfn5fail735_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,48,48,58,54,57,10,0
Lfn5fail744_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,48,49,58,52,56,10,0
Lfn5fail742_4location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,48,49,58,50,57,10,0
Lfn5fail740_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,48,49,58,50,51,10,0
Lfn5fail751_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,48,50,58,51,48,10,0
Lfn5fail757_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,48,51,58,52,53,10,0
Lfn5fail755_4location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,48,51,58,50,54,10,0
Lfn5fail765_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,48,52,58,52,51,10,0
Lfn5fail764_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,48,52,58,51,52,10,0
Lfn5fail770_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,48,53,58,51,50,10,0
Lfn5fail775_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,48,54,58,51,48,10,0
Lfn5fail781_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,48,55,58,51,53,10,0
Lfn5fail787_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,48,56,58,51,54,10,0
Lfn5fail809_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,49,50,58,52,52,10,0
Lfn5fail808_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,49,50,58,52,49,10,0
Lfn5fail827_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,49,52,58,52,52,10,0
Lfn5fail826_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,49,52,58,52,49,10,0
Lfn5fail849_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,49,55,58,52,52,10,0
Lfn5fail848_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,49,55,58,52,49,10,0
Lfn5fail867_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,49,57,58,52,52,10,0
Lfn5fail866_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,49,57,58,52,49,10,0
Lfn5fail885_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,50,49,58,52,55,10,0
Lfn5fail892_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,50,49,58,54,54,10,0
Lfn5fail884_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,50,49,58,51,56,10,0
Lfn6fail949_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,50,55,58,51,52,10,0
Lfn6fail958_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,50,56,58,51,48,10,0
Lfn7fail999_4location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,51,54,58,50,53,10,0
Lfn7fail997_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,51,54,58,49,57,10,0
Lfn7fail1007_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,51,55,58,51,53,10,0
Lfn7fail1006_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,51,55,58,50,54,10,0
Lfn7fail1013_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,51,56,58,51,51,10,0
Lfn7fail1012_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,51,56,58,50,52,10,0
Lfn7fail1019_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,51,56,58,54,49,10,0
Lfn7fail1027_4location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,52,48,58,49,56,10,0
Lfn7fail1034_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,52,49,58,50,54,10,0
Lfn7fail1043_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,52,50,58,52,57,10,0
Lfn7fail1042_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,52,50,58,51,57,10,0
Lfn7fail1053_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,52,51,58,51,53,10,0
Lfn7fail1057_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,52,51,58,52,56,10,0
Lfn7fail1060_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,52,51,58,53,57,10,0
Lfn7fail1052_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,52,51,58,50,54,10,0
Lfn7fail1066_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,52,52,58,51,48,10,0
Lfn7fail1077_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,52,54,58,50,52,10,0
Lfn7fail1091_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,52,56,58,50,50,10,0
Lfn7fail1109_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,53,49,58,52,48,10,0
Lfn7fail1108_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,53,49,58,51,48,10,0
Lfn7fail1121_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,53,50,58,50,56,10,0
Lfn7fail1126_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,53,50,58,52,57,10,0
Lfn7fail1120_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,53,50,58,49,57,10,0
.p2align 3
Lconstant2:
.zero 72
.long 7
.byte 0,2,0,0
Lfn9fail1152_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,53,57,58,51,48,10,0
Lfn9fail1160_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,54,48,58,51,51,10,0
Lfn9fail1165_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,54,49,58,51,52,10,0
Lfn9fail1173_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,54,50,58,52,55,10,0
Lfn9fail1176_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,54,51,58,50,50,10,0
.p2align 3
Lconstant3:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 48
.p2align 3
Lconstant4:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 49
.p2align 3
Lconstant5:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 50
.p2align 3
Lconstant6:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 51
.p2align 3
Lconstant7:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 52
.p2align 3
Lconstant8:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 53
.p2align 3
Lconstant9:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 54
.p2align 3
Lconstant10:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 55
.p2align 3
Lconstant11:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 56
.p2align 3
Lconstant12:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 57
Lfn11fail1236_2location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,55,52,58,49,53,10,0
Lfn11fail1236_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,55,52,58,49,53,10,0
Lfn11fail1245_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,55,53,58,52,56,10,0
Lfn11fail1243_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,55,53,58,52,51,10,0
Lfn11fail1239_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,55,53,58,55,10,0
.p2align 3
Lconstant13:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 32
.p2align 3
Lconstant14:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 10
Lfn12fail1270_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,55,57,58,52,55,10,0
Lfn12fail1267_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,55,57,58,49,57,10,0
Lfn12fail1275_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,56,48,58,50,49,10,0
Lfn12fail1281_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,56,49,58,50,55,10,0
Lfn12fail1279_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,56,49,58,57,10,0
Lfn12fail1274_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,56,48,58,55,10,0
Lfn12fail1266_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,55,57,58,53,10,0
.p2align 3
Lconstant15:
.quad 7
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 114,101,106,101,99,116,32
Lfn13fail1289_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,56,52,58,51,55,10,0
Lfn13fail1287_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,56,52,58,49,51,10,0
.p2align 3
Lconstant16:
.zero 72
.long 20
.byte 0,2,0,0
Lfn14fail1303_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,57,50,58,55,10,0
.section .rodata
.p2align 3
Lconstant17:
.quad 0
.quad Lconstant0
.zero 56
.long 13
.byte 2,2,0,0
.text
.p2align 3
Lconstant18:
.quad 0
.zero 64
.long 4294967295
.byte 0,2,0,0

.text
ownedLfn0:
ldp x8, x9, [x0, #0]
ldp x10, x11, [x0, #16]
ownedLfn0fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #208
stp x8, x9, [sp, #48]
stp x10, x11, [sp, #64]
add x0, sp, #16
add x1, sp, #48
mov x2, #1
bl fen_enter
ownedLfn0loop:
ldr x0, [sp, #56]
asr x2, x0, #63
add x0, x0, x2, lsr #63
asr x0, x0, #1
lsl x2, x0, #1
cmp x0, x2, asr #1
b.ne ownedLfn0fail20_1
mov x0, x2
str x0, [sp, #80]
ldr x0, [sp, #48]
ldr w0, [x0, #72]
cmp w0, #9
b.eq ownedLfn0match25arm9
cmp w0, #10
b.eq ownedLfn0match25arm10
cmp w0, #11
b.eq ownedLfn0match25arm11
cmp w0, #12
b.eq ownedLfn0match25arm12
brk #0
ownedLfn0match25arm9:
ldr x0, [sp, #56]
ldr x2, [sp, #80]
cmp x0, x2
b.ne ownedLfn0if27else
movz x0, #1, lsl #0
str x0, [sp, #88]
movz x0, #0, lsl #0
str x0, [sp, #96]
movz x0, #0, lsl #0
str x0, [sp, #104]
movz x0, #0, lsl #0
str x0, [sp, #112]
mov x0, #0
mov x1, #10
bl fen_allocate
cbz x0, ownedLfn0fail31_3
ldr x2, [sp, #80]
ldr x3, [sp, #88]
stp x2, x3, [x0, #0]
ldr x2, [sp, #64]
ldr x3, [sp, #72]
stp x2, x3, [x0, #16]
ldr x2, [sp, #96]
ldr x3, [sp, #104]
stp x2, x3, [x0, #32]
ldr x2, [sp, #112]
str x2, [x0, #48]
b ownedLfn0if27done
ownedLfn0if27else:
movz x0, #0, lsl #0
str x0, [sp, #120]
movz x0, #0, lsl #0
str x0, [sp, #128]
movz x0, #0, lsl #0
str x0, [sp, #136]
movz x0, #1, lsl #0
str x0, [sp, #144]
mov x0, #0
mov x1, #10
bl fen_allocate
cbz x0, ownedLfn0fail39_3
ldr x2, [sp, #80]
ldr x3, [sp, #120]
stp x2, x3, [x0, #0]
ldr x2, [sp, #128]
ldr x3, [sp, #136]
stp x2, x3, [x0, #16]
ldr x2, [sp, #144]
ldr x3, [sp, #64]
stp x2, x3, [x0, #32]
ldr x2, [sp, #72]
str x2, [x0, #48]
ownedLfn0if27done:
b ownedLfn0match25end
ownedLfn0match25arm10:
ldr x0, [sp, #56]
ldr x2, [sp, #80]
cmp x0, x2
b.ne ownedLfn0if54else
ldr x0, [sp, #48]
ldr x0, [x0, #8]
adds x0, x0, #1
b.vs ownedLfn0fail60_1
str x0, [sp, #152]
ldr x0, [sp, #48]
ldr x0, [x0, #16]
ldr x2, [sp, #64]
adds x0, x0, x2
b.vs ownedLfn0fail63_1
str x0, [sp, #160]
ldr x0, [sp, #48]
ldr x0, [x0, #24]
ldr x2, [sp, #72]
adds x0, x0, x2
b.vs ownedLfn0fail66_1
str x0, [sp, #168]
mov x0, #0
mov x1, #10
tbz x28, #0, 8f
ldr x0, [sp, #48]
b 9f
8:
bl fen_allocate
9:
cbz x0, ownedLfn0fail58_3
ldr x2, [sp, #48]
ldr x2, [x2, #0]
ldr x3, [sp, #152]
stp x2, x3, [x0, #0]
ldr x2, [sp, #160]
ldr x3, [sp, #168]
stp x2, x3, [x0, #16]
ldr x4, [sp, #48]
ldp x2, x3, [x4, #32]
stp x2, x3, [x0, #32]
ldr x2, [x4, #48]
str x2, [x0, #48]
b ownedLfn0if54done
ownedLfn0if54else:
ldr x0, [sp, #48]
ldr x0, [x0, #32]
adds x0, x0, #1
b.vs ownedLfn0fail77_1
str x0, [sp, #176]
ldr x0, [sp, #48]
ldr x0, [x0, #40]
ldr x2, [sp, #64]
adds x0, x0, x2
b.vs ownedLfn0fail80_1
str x0, [sp, #184]
ldr x0, [sp, #48]
ldr x0, [x0, #48]
ldr x2, [sp, #72]
adds x0, x0, x2
b.vs ownedLfn0fail83_1
str x0, [sp, #192]
mov x0, #0
mov x1, #10
tbz x28, #0, 8f
ldr x0, [sp, #48]
b 9f
8:
bl fen_allocate
9:
cbz x0, ownedLfn0fail72_3
ldr x4, [sp, #48]
ldp x2, x3, [x4, #0]
stp x2, x3, [x0, #0]
ldp x2, x3, [x4, #16]
stp x2, x3, [x0, #16]
ldr x2, [sp, #176]
ldr x3, [sp, #184]
stp x2, x3, [x0, #32]
ldr x2, [sp, #192]
str x2, [x0, #48]
ownedLfn0if54done:
b ownedLfn0match25end
ownedLfn0match25arm11:
ldr x0, [sp, #48]
b ownedLfn0match25end
ownedLfn0match25arm12:
ldr x0, [sp, #48]
b ownedLfn0match25end
ownedLfn0match25end:
mov x1, #0
b ownedLfn0end
ownedLfn0fail20_1:
adrp x0, Lfn0fail20_1location
add x0, x0, :lo12:Lfn0fail20_1location
bl fen_set_location
mov x1, #1
b ownedLfn0end
ownedLfn0fail31_3:
adrp x0, Lfn0fail31_3location
add x0, x0, :lo12:Lfn0fail31_3location
bl fen_set_location
mov x1, #3
b ownedLfn0end
ownedLfn0fail39_3:
adrp x0, Lfn0fail39_3location
add x0, x0, :lo12:Lfn0fail39_3location
bl fen_set_location
mov x1, #3
b ownedLfn0end
ownedLfn0fail60_1:
adrp x0, Lfn0fail60_1location
add x0, x0, :lo12:Lfn0fail60_1location
bl fen_set_location
mov x1, #1
b ownedLfn0end
ownedLfn0fail63_1:
adrp x0, Lfn0fail63_1location
add x0, x0, :lo12:Lfn0fail63_1location
bl fen_set_location
mov x1, #1
b ownedLfn0end
ownedLfn0fail66_1:
adrp x0, Lfn0fail66_1location
add x0, x0, :lo12:Lfn0fail66_1location
bl fen_set_location
mov x1, #1
b ownedLfn0end
ownedLfn0fail58_3:
adrp x0, Lfn0fail58_3location
add x0, x0, :lo12:Lfn0fail58_3location
bl fen_set_location
mov x1, #3
b ownedLfn0end
ownedLfn0fail77_1:
adrp x0, Lfn0fail77_1location
add x0, x0, :lo12:Lfn0fail77_1location
bl fen_set_location
mov x1, #1
b ownedLfn0end
ownedLfn0fail80_1:
adrp x0, Lfn0fail80_1location
add x0, x0, :lo12:Lfn0fail80_1location
bl fen_set_location
mov x1, #1
b ownedLfn0end
ownedLfn0fail83_1:
adrp x0, Lfn0fail83_1location
add x0, x0, :lo12:Lfn0fail83_1location
bl fen_set_location
mov x1, #1
b ownedLfn0end
ownedLfn0fail72_3:
adrp x0, Lfn0fail72_3location
add x0, x0, :lo12:Lfn0fail72_3location
bl fen_set_location
mov x1, #3
b ownedLfn0end
ownedLfn0end:
bl fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
ownedLfn1:
ldp x8, x9, [x0, #0]
ldp x10, x11, [x0, #16]
ownedLfn1fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
stp x19, x20, [sp, #-16]!
stp x21, x22, [sp, #-16]!
stp x23, xzr, [sp, #-16]!
sub sp, sp, #96
stp xzr, xzr, [sp, #56]
stp xzr, xzr, [sp, #72]
str x8, [sp, #48]
mov x19, x9
mov x20, x10
mov x21, x11
add x0, sp, #16
add x1, sp, #48
mov x2, #5
bl fen_enter
ownedLfn1loop:
ldr x0, [sp, #48]
ldr w0, [x0, #72]
cmp w0, #9
b.eq ownedLfn1match118arm9
cmp w0, #10
b.eq ownedLfn1match118arm10
cmp w0, #11
b.eq ownedLfn1match118arm11
cmp w0, #12
b.eq ownedLfn1match118arm12
brk #0
ownedLfn1match118arm9:
bl fen_leave_result
adrp x8, Lconstant0
add x8, x8, :lo12:Lconstant0
mov x9, x19
mov x10, x20
mov x11, x21
ldp x19, x20, [x29, #-16]
ldp x21, x22, [x29, #-32]
ldp x23, xzr, [x29, #-48]
mov sp, x29
ldp x29, x30, [sp], #16
b ownedLfn0fields
b ownedLfn1match118end
ownedLfn1match118arm10:
mov x0, x19
asr x2, x0, #63
add x0, x0, x2, lsr #63
asr x0, x0, #1
lsl x2, x0, #1
cmp x0, x2, asr #1
b.ne ownedLfn1fail136_1
mov x0, x2
str x0, [sp, #88]
ldr x0, [sp, #48]
ldr x0, [x0, #0]
ldr x2, [sp, #88]
cmp x0, x2
b.ne ownedLfn1if133else
bl fen_leave_result
ldr x8, [sp, #48]
mov x9, x19
mov x10, x20
mov x11, x21
ldp x19, x20, [x29, #-16]
ldp x21, x22, [x29, #-32]
ldp x23, xzr, [x29, #-48]
mov sp, x29
ldp x29, x30, [sp], #16
b ownedLfn0fields
b ownedLfn1if133done
ownedLfn1if133else:
ldr x0, [sp, #48]
ldr x0, [x0, #0]
cmp x0, #0
neg x2, x0
and x2, x2, #15
and x0, x0, #15
csneg x0, x0, x2, ge
asr x2, x0, #63
add x0, x0, x2, lsr #63
asr x0, x0, #1
mov x22, x0
cmp x0, #4
b.ge ownedLfn1if160else
mov x0, x22
cmp x0, #2
b.ge ownedLfn1if164else
mov x0, x22
cmp x0, #1
b.ge ownedLfn1if168else
mov x0, #255
mov x1, #12
bl fen_allocate_full
cbz x0, ownedLfn1fail172_3
ldr x2, [sp, #48]
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #0]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #16]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #32]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #48]
str x0, [sp, #56]
b ownedLfn1if168done
ownedLfn1if168else:
mov x0, #255
mov x1, #12
bl fen_allocate_full
cbz x0, ownedLfn1fail181_3
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
ldr x3, [sp, #48]
stp x2, x3, [x0, #0]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #16]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #32]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #48]
str x0, [sp, #56]
ownedLfn1if168done:
str x0, [sp, #64]
b ownedLfn1if164done
ownedLfn1if164else:
mov x0, x22
cmp x0, #3
b.ge ownedLfn1if190else
mov x0, #255
mov x1, #12
bl fen_allocate_full
cbz x0, ownedLfn1fail194_3
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #0]
ldr x2, [sp, #48]
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #16]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #32]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #48]
str x0, [sp, #56]
b ownedLfn1if190done
ownedLfn1if190else:
mov x0, #255
mov x1, #12
bl fen_allocate_full
cbz x0, ownedLfn1fail203_3
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #0]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
ldr x3, [sp, #48]
stp x2, x3, [x0, #16]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #32]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #48]
str x0, [sp, #56]
ownedLfn1if190done:
str x0, [sp, #64]
ownedLfn1if164done:
str x0, [sp, #72]
b ownedLfn1if160done
ownedLfn1if160else:
mov x0, x22
cmp x0, #6
b.ge ownedLfn1if212else
mov x0, x22
cmp x0, #5
b.ge ownedLfn1if216else
mov x0, #255
mov x1, #12
bl fen_allocate_full
cbz x0, ownedLfn1fail220_3
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #0]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #16]
ldr x2, [sp, #48]
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #32]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #48]
str x0, [sp, #56]
b ownedLfn1if216done
ownedLfn1if216else:
mov x0, #255
mov x1, #12
bl fen_allocate_full
cbz x0, ownedLfn1fail229_3
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #0]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #16]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
ldr x3, [sp, #48]
stp x2, x3, [x0, #32]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #48]
str x0, [sp, #56]
ownedLfn1if216done:
str x0, [sp, #64]
b ownedLfn1if212done
ownedLfn1if212else:
mov x0, x22
cmp x0, #7
b.ge ownedLfn1if238else
mov x0, #255
mov x1, #12
bl fen_allocate_full
cbz x0, ownedLfn1fail242_3
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #0]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #16]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #32]
ldr x2, [sp, #48]
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #48]
str x0, [sp, #56]
b ownedLfn1if238done
ownedLfn1if238else:
mov x0, #255
mov x1, #12
bl fen_allocate_full
cbz x0, ownedLfn1fail251_3
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #0]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #16]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
adrp x3, Lconstant0
add x3, x3, :lo12:Lconstant0
stp x2, x3, [x0, #32]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
ldr x3, [sp, #48]
stp x2, x3, [x0, #48]
str x0, [sp, #56]
ownedLfn1if238done:
str x0, [sp, #64]
ownedLfn1if212done:
str x0, [sp, #72]
ownedLfn1if160done:
str x0, [sp, #80]
ldr x8, [sp, #80]
str x8, [sp, #48]
stp xzr, xzr, [sp, #56]
stp xzr, xzr, [sp, #72]
b ownedLfn1loop
ownedLfn1if133done:
b ownedLfn1match118end
ownedLfn1match118arm11:
ldr x0, [sp, #48]
b ownedLfn1match118end
ownedLfn1match118arm12:
mov x0, x19
cmp x0, #0
neg x2, x0
and x2, x2, #15
and x0, x0, #15
csneg x0, x0, x2, ge
asr x2, x0, #63
add x0, x0, x2, lsr #63
asr x0, x0, #1
mov x23, x0
cmp x0, #4
b.ge ownedLfn1if287else
mov x0, x23
cmp x0, #2
b.ge ownedLfn1if291else
mov x0, x23
cmp x0, #1
b.ge ownedLfn1if295else
ldr x8, [sp, #48]
ldr x8, [x8, #0]
mov x9, x19
mov x10, x20
mov x11, x21
bl ownedLfn0fields
cbnz x1, ownedLfn1end
str x0, [sp, #56]
mov x0, #255
mov x1, #12
tbz x28, #1, 8f
ldr x0, [sp, #48]
b 9f
8:
bl fen_allocate_full
9:
cbz x0, ownedLfn1fail299_3
ldr x2, [sp, #56]
ldr x3, [sp, #48]
ldr x3, [x3, #8]
stp x2, x3, [x0, #0]
ldr x4, [sp, #48]
ldp x2, x3, [x4, #16]
stp x2, x3, [x0, #16]
ldp x2, x3, [x4, #32]
stp x2, x3, [x0, #32]
ldp x2, x3, [x4, #48]
stp x2, x3, [x0, #48]
b ownedLfn1if295done
ownedLfn1if295else:
ldr x8, [sp, #48]
ldr x8, [x8, #8]
mov x9, x19
mov x10, x20
mov x11, x21
bl ownedLfn0fields
cbnz x1, ownedLfn1end
str x0, [sp, #56]
mov x0, #255
mov x1, #12
tbz x28, #1, 8f
ldr x0, [sp, #48]
b 9f
8:
bl fen_allocate_full
9:
cbz x0, ownedLfn1fail313_3
ldr x2, [sp, #48]
ldr x2, [x2, #0]
ldr x3, [sp, #56]
stp x2, x3, [x0, #0]
ldr x4, [sp, #48]
ldp x2, x3, [x4, #16]
stp x2, x3, [x0, #16]
ldp x2, x3, [x4, #32]
stp x2, x3, [x0, #32]
ldp x2, x3, [x4, #48]
stp x2, x3, [x0, #48]
ownedLfn1if295done:
b ownedLfn1if291done
ownedLfn1if291else:
mov x0, x23
cmp x0, #3
b.ge ownedLfn1if327else
ldr x8, [sp, #48]
ldr x8, [x8, #16]
mov x9, x19
mov x10, x20
mov x11, x21
bl ownedLfn0fields
cbnz x1, ownedLfn1end
str x0, [sp, #56]
mov x0, #255
mov x1, #12
tbz x28, #1, 8f
ldr x0, [sp, #48]
b 9f
8:
bl fen_allocate_full
9:
cbz x0, ownedLfn1fail331_3
ldr x4, [sp, #48]
ldp x2, x3, [x4, #0]
stp x2, x3, [x0, #0]
ldr x2, [sp, #56]
ldr x3, [x4, #24]
stp x2, x3, [x0, #16]
ldp x2, x3, [x4, #32]
stp x2, x3, [x0, #32]
ldp x2, x3, [x4, #48]
stp x2, x3, [x0, #48]
b ownedLfn1if327done
ownedLfn1if327else:
ldr x8, [sp, #48]
ldr x8, [x8, #24]
mov x9, x19
mov x10, x20
mov x11, x21
bl ownedLfn0fields
cbnz x1, ownedLfn1end
str x0, [sp, #56]
mov x0, #255
mov x1, #12
tbz x28, #1, 8f
ldr x0, [sp, #48]
b 9f
8:
bl fen_allocate_full
9:
cbz x0, ownedLfn1fail345_3
ldr x4, [sp, #48]
ldp x2, x3, [x4, #0]
stp x2, x3, [x0, #0]
ldr x2, [x4, #16]
ldr x3, [sp, #56]
stp x2, x3, [x0, #16]
ldp x2, x3, [x4, #32]
stp x2, x3, [x0, #32]
ldp x2, x3, [x4, #48]
stp x2, x3, [x0, #48]
ownedLfn1if327done:
ownedLfn1if291done:
b ownedLfn1if287done
ownedLfn1if287else:
mov x0, x23
cmp x0, #6
b.ge ownedLfn1if359else
mov x0, x23
cmp x0, #5
b.ge ownedLfn1if363else
ldr x8, [sp, #48]
ldr x8, [x8, #32]
mov x9, x19
mov x10, x20
mov x11, x21
bl ownedLfn0fields
cbnz x1, ownedLfn1end
str x0, [sp, #56]
mov x0, #255
mov x1, #12
tbz x28, #1, 8f
ldr x0, [sp, #48]
b 9f
8:
bl fen_allocate_full
9:
cbz x0, ownedLfn1fail367_3
ldr x4, [sp, #48]
ldp x2, x3, [x4, #0]
stp x2, x3, [x0, #0]
ldp x2, x3, [x4, #16]
stp x2, x3, [x0, #16]
ldr x2, [sp, #56]
ldr x3, [x4, #40]
stp x2, x3, [x0, #32]
ldp x2, x3, [x4, #48]
stp x2, x3, [x0, #48]
b ownedLfn1if363done
ownedLfn1if363else:
ldr x8, [sp, #48]
ldr x8, [x8, #40]
mov x9, x19
mov x10, x20
mov x11, x21
bl ownedLfn0fields
cbnz x1, ownedLfn1end
str x0, [sp, #56]
mov x0, #255
mov x1, #12
tbz x28, #1, 8f
ldr x0, [sp, #48]
b 9f
8:
bl fen_allocate_full
9:
cbz x0, ownedLfn1fail381_3
ldr x4, [sp, #48]
ldp x2, x3, [x4, #0]
stp x2, x3, [x0, #0]
ldp x2, x3, [x4, #16]
stp x2, x3, [x0, #16]
ldr x2, [x4, #32]
ldr x3, [sp, #56]
stp x2, x3, [x0, #32]
ldp x2, x3, [x4, #48]
stp x2, x3, [x0, #48]
ownedLfn1if363done:
b ownedLfn1if359done
ownedLfn1if359else:
mov x0, x23
cmp x0, #7
b.ge ownedLfn1if395else
ldr x8, [sp, #48]
ldr x8, [x8, #48]
mov x9, x19
mov x10, x20
mov x11, x21
bl ownedLfn0fields
cbnz x1, ownedLfn1end
str x0, [sp, #56]
mov x0, #255
mov x1, #12
tbz x28, #1, 8f
ldr x0, [sp, #48]
b 9f
8:
bl fen_allocate_full
9:
cbz x0, ownedLfn1fail399_3
ldr x4, [sp, #48]
ldp x2, x3, [x4, #0]
stp x2, x3, [x0, #0]
ldp x2, x3, [x4, #16]
stp x2, x3, [x0, #16]
ldp x2, x3, [x4, #32]
stp x2, x3, [x0, #32]
ldr x2, [sp, #56]
ldr x3, [x4, #56]
stp x2, x3, [x0, #48]
b ownedLfn1if395done
ownedLfn1if395else:
ldr x8, [sp, #48]
ldr x8, [x8, #56]
mov x9, x19
mov x10, x20
mov x11, x21
bl ownedLfn0fields
cbnz x1, ownedLfn1end
str x0, [sp, #56]
mov x0, #255
mov x1, #12
tbz x28, #1, 8f
ldr x0, [sp, #48]
b 9f
8:
bl fen_allocate_full
9:
cbz x0, ownedLfn1fail413_3
ldr x4, [sp, #48]
ldp x2, x3, [x4, #0]
stp x2, x3, [x0, #0]
ldp x2, x3, [x4, #16]
stp x2, x3, [x0, #16]
ldp x2, x3, [x4, #32]
stp x2, x3, [x0, #32]
ldr x2, [x4, #48]
ldr x3, [sp, #56]
stp x2, x3, [x0, #48]
ownedLfn1if395done:
ownedLfn1if359done:
ownedLfn1if287done:
b ownedLfn1match118end
ownedLfn1match118end:
mov x1, #0
b ownedLfn1end
ownedLfn1fail136_1:
adrp x0, Lfn1fail136_1location
add x0, x0, :lo12:Lfn1fail136_1location
bl fen_set_location
mov x1, #1
b ownedLfn1end
ownedLfn1fail172_3:
adrp x0, Lfn1fail172_3location
add x0, x0, :lo12:Lfn1fail172_3location
bl fen_set_location
mov x1, #3
b ownedLfn1end
ownedLfn1fail181_3:
adrp x0, Lfn1fail181_3location
add x0, x0, :lo12:Lfn1fail181_3location
bl fen_set_location
mov x1, #3
b ownedLfn1end
ownedLfn1fail194_3:
adrp x0, Lfn1fail194_3location
add x0, x0, :lo12:Lfn1fail194_3location
bl fen_set_location
mov x1, #3
b ownedLfn1end
ownedLfn1fail203_3:
adrp x0, Lfn1fail203_3location
add x0, x0, :lo12:Lfn1fail203_3location
bl fen_set_location
mov x1, #3
b ownedLfn1end
ownedLfn1fail220_3:
adrp x0, Lfn1fail220_3location
add x0, x0, :lo12:Lfn1fail220_3location
bl fen_set_location
mov x1, #3
b ownedLfn1end
ownedLfn1fail229_3:
adrp x0, Lfn1fail229_3location
add x0, x0, :lo12:Lfn1fail229_3location
bl fen_set_location
mov x1, #3
b ownedLfn1end
ownedLfn1fail242_3:
adrp x0, Lfn1fail242_3location
add x0, x0, :lo12:Lfn1fail242_3location
bl fen_set_location
mov x1, #3
b ownedLfn1end
ownedLfn1fail251_3:
adrp x0, Lfn1fail251_3location
add x0, x0, :lo12:Lfn1fail251_3location
bl fen_set_location
mov x1, #3
b ownedLfn1end
ownedLfn1fail299_3:
adrp x0, Lfn1fail299_3location
add x0, x0, :lo12:Lfn1fail299_3location
bl fen_set_location
mov x1, #3
b ownedLfn1end
ownedLfn1fail313_3:
adrp x0, Lfn1fail313_3location
add x0, x0, :lo12:Lfn1fail313_3location
bl fen_set_location
mov x1, #3
b ownedLfn1end
ownedLfn1fail331_3:
adrp x0, Lfn1fail331_3location
add x0, x0, :lo12:Lfn1fail331_3location
bl fen_set_location
mov x1, #3
b ownedLfn1end
ownedLfn1fail345_3:
adrp x0, Lfn1fail345_3location
add x0, x0, :lo12:Lfn1fail345_3location
bl fen_set_location
mov x1, #3
b ownedLfn1end
ownedLfn1fail367_3:
adrp x0, Lfn1fail367_3location
add x0, x0, :lo12:Lfn1fail367_3location
bl fen_set_location
mov x1, #3
b ownedLfn1end
ownedLfn1fail381_3:
adrp x0, Lfn1fail381_3location
add x0, x0, :lo12:Lfn1fail381_3location
bl fen_set_location
mov x1, #3
b ownedLfn1end
ownedLfn1fail399_3:
adrp x0, Lfn1fail399_3location
add x0, x0, :lo12:Lfn1fail399_3location
bl fen_set_location
mov x1, #3
b ownedLfn1end
ownedLfn1fail413_3:
adrp x0, Lfn1fail413_3location
add x0, x0, :lo12:Lfn1fail413_3location
bl fen_set_location
mov x1, #3
b ownedLfn1end
ownedLfn1end:
bl fen_leave_result
ldp x19, x20, [x29, #-16]
ldp x21, x22, [x29, #-32]
ldp x23, xzr, [x29, #-48]
mov sp, x29
ldp x29, x30, [sp], #16
ret
