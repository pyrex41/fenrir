import sys,time,json,subprocess,os
from pathlib import Path
d,driver,launcher=map(Path,sys.argv[1:])
rows=[]
for i,k in enumerate(('spt','spt-c','spt-c','spt')):
    log=d/f'{i}.log'
    with log.open('w') as f:
        p=subprocess.Popen([sys.executable,launcher,d/k,'0','--guest-cpu','4'],stderr=f)
        try:
            for tick in range(200):
                lines=log.read_text().splitlines()
                if lines:break
                time.sleep(.1)
            addr=lines[0]
            trial=subprocess.run([driver,'-addr',addr,'-rate','5000','-seconds','10','-connections','16'],timeout=30,capture_output=True); assert trial.returncode in (0,1); sample=json.loads(trial.stdout)
            (d/f'{i}.json').write_text(json.dumps(sample))
            for tick in range(80):
                lanes=[json.loads(l) for l in log.read_text().splitlines()[1:] if l.startswith('{') and l.endswith('}')]
                if sum(l['calls'] for l in lanes)>=sample['Valid']+16:break
                time.sleep(.05)
            calls=sum(l['calls'] for l in lanes)
            assert calls==sample['Valid']+16 and not sample['Errors'] and not sample['Invalid']
            rows.append(dict(worker=k,calls=calls,held_us=sum(l['held_ns'] for l in lanes)/calls/1000,
                             wait_us=sum(l['wait_ns'] for l in lanes)/calls/1000))
        finally:
            p.terminate();p.wait(timeout=10)
(d/'summary.json').write_text(json.dumps(rows,indent=2))
