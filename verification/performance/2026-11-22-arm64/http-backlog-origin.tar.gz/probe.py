import http.server, threading, subprocess, time, json
from pathlib import Path
class Handler(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    count = 0
    def do_GET(self):
        Handler.count += 1
        if Handler.count in [4,5]:
            time.sleep(0.16)
        body,kind={"/missing":(b"", "text/plain"),"/":(b"fenrir\n","text/plain"),"/items/00012":(b"00012","text/plain"),"/status":(b'{"ok":true}\n',"application/json")}[self.path]
        self.send_response(404 if self.path=="/missing" else 200);self.send_header("Content-Length",str(len(body)));self.send_header("Content-Type",kind);self.end_headers();self.wfile.write(body)
    def log_message(self,*args): pass
s=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler)
threading.Thread(target=s.serve_forever,daemon=True).start()
data=subprocess.check_output(['./load','-addr',f'127.0.0.1:{s.server_port}','-seconds','2','-rate','20','-connections','1'],timeout=12)
Path('row.json').write_bytes(data);s.shutdown()
r=json.loads(data);print(r['SlowestLaneOrigin'],r['SlowestValid'])
assert r['Valid']==40 and r['SlowestLaneOrigin']['Index']<r['SlowestValid']['Index']
