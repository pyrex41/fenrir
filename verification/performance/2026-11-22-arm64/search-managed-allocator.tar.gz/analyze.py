from pathlib import Path
import itertools, json, random, statistics as stats
p = Path(__file__).resolve().parent
orders = [line.split() for line in (p/'orders').read_text().splitlines()]
rows = [line.split() for line in (p/'trials').read_text().splitlines()]
assert len(rows) == 96 and len(set(map(tuple, orders))) == 24
assert (p/'stress.log').read_text().split()[0] == '2000'
blocks = []
for i, order in enumerate(orders):
    block = rows[4*i:4*i+4]
    assert [r[0] for r in block] == order and all(r[1]=='50000' and int(r[2])>0 for r in block)
    blocks.append({name:int(ns) for name, _, ns in block})
ratios = [(b['managed']-b['representation'])/(b['program']-b['compact']) for b in blocks]
rng = random.Random(149)
boot = sorted(stats.median(rng.choices(ratios,k=len(ratios))) for _ in range(10000))
print(json.dumps(dict(blocks=len(blocks), median_ms={k:stats.median(b[k] for b in blocks)/1e6 for k in orders[0]}, managed_increment_gap_fraction=[stats.median(ratios),boot[249],boot[9749]]),indent=2))
