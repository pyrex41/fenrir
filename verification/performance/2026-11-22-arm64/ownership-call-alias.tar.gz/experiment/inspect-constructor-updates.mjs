// Report same-constructor rebuilds in validated match arms for ownership analysis.
// A field delta describes value construction. It does not establish uniqueness.
import {readFileSync} from 'node:fs';
import {validatePureCallArtifact} from '../tc0/pure-call-artifact.mjs';

const {artifact} = validatePureCallArtifact(readFileSync(process.argv[2]), ['int', '0'], {maxNodes: 2000});
const updates = [];
const owners = new Map();
for (const datatype of artifact.datatypes) {
  for (const ctor of datatype.constructors) {
    owners.set(ctor.name, owners.has(ctor.name) ? null : datatype.name);
  }
}

function inspectResult(node, name, fields, subject, functionName) {
  switch (node[0]) {
    case 'let':
      inspectResult(node[4], name, fields, subject, functionName);
      break;
    case 'if':
      for (const branch of node.slice(3))
        inspectResult(branch, name, fields, subject, functionName);
      break;
    case 'construct': {
      if (node[2] !== owners.get(name) || node[3] !== name) return;
      const changed = [];
      for (const [index, field] of node.slice(4).entries()) {
        if (field[0] !== 'var' || field[2] !== fields[index]) changed.push(index);
      }
      if (changed.length < fields.length) {
        updates.push({function: functionName, node: node[1], subject, datatype: node[2],
                      constructor: name, changed});
      }
      break;
    }
  }
}

function visit(node, functionName) {
  if (!Array.isArray(node)) return;
  if (node[0] === 'match' && node[2][0] === 'var') {
    for (const [name, fields, body] of node.slice(3))
      inspectResult(body, name, fields, node[2][2], functionName);
  }
  for (const child of node) visit(child, functionName);
}

for (const fn of artifact.functions) visit(fn.body, fn.name);
// For direct tuple calls, find reads of a binding or its direct let aliases in later operands
// or in expressions that can execute after the call. None found is inconclusive: heap aliases, captures,
// callers, other expression forms and alternative branches still matter.
function inspectCallUses(fn) {
  const calls = [];
  // The validator assigns distinct binder IDs. Resolve immutable variable-to-variable
  // lets in definition order; a use can only refer to a binder in lexical scope.
  const origins = new Map();
  const origin = binding => origins.get(binding) ?? binding;
  function collectAliases(node) {
    if (!Array.isArray(node)) return;
    if (node[0] === 'let' && node[3][0] === 'var')
      origins.set(node[2], origin(node[3][2]));
    for (const child of node) collectAliases(child);
  }
  collectAliases(fn.body);
  function reads(node, binding, found) {
    if (!Array.isArray(node)) return;
    if (node[0] === 'var' && origin(node[2]) === origin(binding)) found.push(node[1]);
    for (const child of node) reads(child, binding, found);
  }
  function scan(node, later) {
    if (!Array.isArray(node)) return;
    if (node[0] === 'let') {
      scan(node[3], [node[4], ...later]);
      scan(node[4], later);
      return;
    }
    if (node[0] === 'call' && node[3][0] === 'tuple') {
      const args = node[3].slice(2);
      for (const [index, arg] of args.entries()) {
        if (arg[0] !== 'var') continue;
        const uses = [];
        for (const expr of [...args.slice(index + 1), ...later]) reads(expr, arg[2], uses);
        // All argument values coexist at entry, including ones evaluated first.
        const sameBindingArguments = [];
        for (const [otherIndex, other] of args.entries()) {
          if (otherIndex !== index && other[0] === 'var' && origin(other[2]) === origin(arg[2]))
            sameBindingArguments.push(otherIndex);
        }
        if (uses.length || sameBindingArguments.length) {
          const finding = {caller: fn.name, callee: node[2], call: node[1],
                           argument: index, binding: arg[2], laterReads: uses};
          if (sameBindingArguments.length) finding.sameBindingArguments = sameBindingArguments;
          calls.push(finding);
        }
      }
    }
    // A call nested in an operand can complete before a sibling reads the
    // same binding. Carry that continuation into the nested expression.
    const start = {tuple: 2, apply: 2, construct: 4, prim: 3}[node[0]];
    if (typeof start === 'number') {
      const operands = node.slice(start);
      for (const [index, operand] of operands.entries())
        scan(operand, [...operands.slice(index + 1), ...later]);
      return;
    }
    if (node[0] === 'if' || node[0] === 'match') {
      const branches = node[0] === 'if' ? node.slice(3) : node.slice(3).map(arm => arm[2]);
      scan(node[2], [...branches, ...later]);
      for (const branch of branches) scan(branch, later);
      return;
    }
    for (const child of node) scan(child, later);
  }
  scan(fn.body, []);
  return calls;
}

const result = process.argv.includes('--call-uses') ? artifact.functions.flatMap(inspectCallUses) : updates;
console.log(JSON.stringify(result, null, 2));
