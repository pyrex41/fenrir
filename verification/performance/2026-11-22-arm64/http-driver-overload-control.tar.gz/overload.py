from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from runpy import run_path
from threading import Thread
from time import sleep
import json

root = Path(__file__).resolve().parent
suite = root / 'benchmarks/http'
class Slow(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    def do_GET(self):
        sleep(0.08)
        body = {'/': b'fenrir\n', '/items/00012': b'00012', '/status': b'{"ok":true}\n', '/missing': b''}[self.path]
        self.send_response(404 if self.path == '/missing' else 200)
        self.send_header('Content-Type','application/json' if self.path == '/status' else 'text/plain')
        self.send_header('Content-Length',str(len(body)))
        self.end_headers()
        self.wfile.write(body)
    def log_message(self,*args):
        pass
import sys
sys.path.insert(0,str(suite))
with HTTPServer(('127.0.0.1',0),Slow) as server:
    thread = Thread(target=server.serve_forever,daemon=True)
    thread.start()
    try:
        raw,_ = run_path(str(suite/'sweep.py'))['run_load']([root/'grid/load','-addr',
            f'127.0.0.1:{server.server_port}','-connections','1','-rate','1000','-seconds','1'],1,None)
    finally:
        server.shutdown()
        thread.join()
row = json.loads(raw)
result = run_path(str(suite/'assess-rate.py'))['assess'](row)
assert row['Scheduled']==1000 and row['Valid']+row['Missed']==1000 and 0<row['Valid']<1000
assert result['verdict']=='failed-response-criteria'
(root/'overload.json').write_bytes(raw)
print(row['Valid'],row['Missed'],result['verdict'])
