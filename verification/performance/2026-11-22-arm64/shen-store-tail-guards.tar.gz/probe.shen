(define svcp.aligned-good?
  _ [] [] [] _ _ -> true
  T [[N D] | Rs] [[N N _] | Js] [[K D [receipt T K D N N]] | Ks] Limit Previous ->
    (and (< N Limit)
         (and (number? K)
              (and (or (= Previous none) (< K Previous))
                   (svcp.aligned-good? T Rs Js Ks N K))))
  _ _ _ _ _ _ -> false)
(define probe.bound
  _ [] -> true
  K [[P | _] | _] -> (< P K))

(define probe.extend
  T [store Rs Js Ks N]
    [store [[N D] | Rs2] [[N N Status] | Js2] [[K D [receipt T K D N N]] | Ks2] Next] Guard ->
      (and (= Next (+ 1 N))
        (and (number? K)
          (and (probe.bound K Ks)
            (or (= Guard false) (and (= Rs Rs2) (and (= Js Js2) (= Ks Ks2)))))))
  _ _ _ _ -> false)

(define probe.full
  T [store R J K N] -> (svcp.aligned-good? T R J K N none))

(define probe.run
  Old New ->
    (output "~A ~A ~A ~A~%" (probe.full 0 Old) (probe.full 0 New)
      (probe.extend 0 Old New true) (probe.extend 0 Old New false)))

(let Old [store [[0 0]] [[0 0 pending]] [[10 0 [receipt 0 10 0 0 0]]] 1]
     Reports [[1 1] [0 0]]
     Jobs [[1 1 pending] [0 0 pending]]
     Keys [[11 1 [receipt 0 11 1 1 1]] [10 0 [receipt 0 10 0 0 0]]]
  (do (probe.run Old [store Reports Jobs Keys 2])
      (probe.run Old [store [[1 1] [0 1]] Jobs Keys 2])
      (probe.run Old [store Reports [[1 1 pending] [0 7 pending]] Keys 2])
      (probe.run Old [store Reports Jobs [[11 1 [receipt 0 11 1 1 1]] [10 0 [receipt 0 10 0 9 0]]] 2])))
