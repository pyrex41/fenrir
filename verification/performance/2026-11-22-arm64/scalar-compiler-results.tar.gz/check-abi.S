#ifdef __APPLE__
#define SYM(x) _##x
#else
#define SYM(x) x
#endif
.text
.globl SYM(fenrir_entry)
SYM(fenrir_entry):
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    .irp n,19,20,21,22,23,24,25,26
    mov x\n, #\n
    .endr
    bl SYM(fenrir_checked_entry)
    .irp n,19,20,21,22,23,24,25,26
    cmp x\n, #\n
    b.ne 1f
    .endr
    b 2f
1:  brk #1
2:  ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
