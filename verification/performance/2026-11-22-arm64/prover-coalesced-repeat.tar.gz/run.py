from pathlib import Path
import json,os,random,statistics,subprocess,sys
k=Path(sys.argv[1]);out=Path(__file__).parent
r=json.loads((k/'results/prover/report.json').read_bytes())
for lane,count in [('search',10)]:
 p=out/lane;p.mkdir();src=k/'results/prover'/lane
 lines=(src/'program.s').read_text().splitlines()
 a=lines.index('Lfn10:');b=lines.index('Lfn11:')
 body=lines[a:b]
 uses=[line for line in body if '#128]' in line and 'xzr' not in line]
 assert uses==['str x0, [sp, #128]','ldr x2, [sp, #128]']
 assert body.count('mov x2, #11')==1
 j=body.index('str x0, [sp, #128]')
 assert body[j-5:j]==['ldr x0, [sp, #112]','ldr x2, [sp, #120]','mov x1, x2','bl fen_bytes_concat','cbz x0, Lfn10fail900_3']
 assert body[j+1:j+5]==['mov x0, #1','mov x1, #12','bl fen_allocate','cbz x0, Lfn10fail899_3']
 lines[a:b]=[line.replace('#128]', '#120]').replace('mov x2, #11','mov x2, #10') for line in body if line!='str xzr, [sp, #128]']
 (p/'candidate.s').write_text('\n'.join(lines)+'\n');(p/'baseline.spt').write_bytes((src/'program.spt').read_bytes())
 order=[('baseline','candidate') if i%2==1 else ('candidate','baseline') for i in range(26)]
 shell='export PATH=/opt/solo5-install/bin:$PATH FENRIR_SOLO5_MAIN=/src/benchmarks/prover/timed-spt.c; sh /src/tools/aarch64/link-spt.sh candidate.s candidate.spt; '
 if lane=='check':shell+='solo5-spt candidate.spt --solo5:quiet 0; '
 shell+='for n do solo5-spt "$n.spt" --solo5:quiet 50000; done'
 cmd=['docker','run','--rm','--network','none','--platform','linux/arm64','--cpuset-cpus','4','--user',f'{os.getuid()}:{os.getgid()}','-v',f'{k}/src:/src:ro','-v',f'{p}:/work','-w','/work','--entrypoint','sh',r['container'],'-ec',shell,'sh',*[v for pair in order for v in pair]]
 raw=subprocess.check_output(cmd,text=True,timeout=300);(p/'console.txt').write_text(raw);it=iter(raw.splitlines())
 if lane=='check':assert int(next(it).split()[0])==18
 samples=[]
 for pair in order:
  row={}
  for name in pair:
   answer,ns=map(int,next(it).split());assert answer==count*50000 and ns>0;row[name]=ns
  samples.append(row)
 assert next(it,None) is None
 ratios=[s['candidate']/s['baseline'] for s in samples[2:]];rng=random.Random(1147);boot=sorted(statistics.median(rng.choices(ratios,k=len(ratios))) for _ in range(10000))
 result=dict(median=statistics.median(ratios),interval=[boot[249],boot[9749]],samples=samples);(p/'result.json').write_text(json.dumps(result,indent=2));print(lane,result['median'],result['interval'],flush=True)
