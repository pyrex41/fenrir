(define svc.lookup
  K [] -> none
  K [[K D Rc] | _] -> [some D Rc]
  K [_ | Rest] -> (svc.lookup K Rest))
(define probe.rows
  0 Acc -> Acc
  N Acc -> (probe.rows (- N 1) [[N 1 N] | Acc]))
(define probe.indexed
  K Max Rows -> (if (> K Max) none (svc.lookup K Rows)))
(define probe.repeat
  0 _ _ _ Acc -> Acc
  N Rows Max Indexed Acc ->
    (let K (+ Max N)
         R (if Indexed (probe.indexed K Max Rows) (svc.lookup K Rows))
      (probe.repeat (- N 1) Rows Max Indexed (+ Acc (if (= R none) 1 0)))))
(let Rows (probe.rows 60000 [])
     Args (tl (value *argv*))
     Indexed (= (hd Args) "indexed")
     Warm (probe.repeat 10 Rows 60000 Indexed 0)
     Begin (get-time run)
     Result (probe.repeat 2000 Rows 60000 Indexed 0)
     End (get-time run)
     Present (probe.indexed 60000 60000 Rows)
     Absent (probe.indexed 0 60000 Rows)
  (output "~A ~A ~A ~A ~A~%" Warm Result (- End Begin) (= Present [some 1 60000]) (= Absent none)))
