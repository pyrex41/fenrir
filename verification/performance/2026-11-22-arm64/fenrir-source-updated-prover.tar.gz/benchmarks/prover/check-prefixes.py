"""Verify unary-rule certificate runs across batching and inline-byte boundaries."""
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
from fenrir_driver import compiled

here = Path(__file__).resolve().parent
program = (here / "formula.fen").read_text() + (here / "search.fen").read_text()
program += """
(define wrap-neg {(Tuple I64 Formula) --> Formula}
  n goal -> (if (= n 0) goal (wrap-neg (- n 1) (Neg (Neg goal)))))
(define main {I64 --> Answer}
  input -> (let pairs (/ input 2)
                nodes (+ 3 (* 2 pairs))
                goal (wrap-neg pairs (Binary 2 (Atom 1) (Atom 1)))
             (search (More false goal Empty) 0 0 (if (= input (* pairs 2)) nodes (- nodes 1)))))
"""
target = sys.argv[1]
with compiled(here.parents[1], target, program) as command:
    for pairs in (*range(10), 26, 27, 28, 32, 64):
        proof = ("s" * (2 + 2 * pairs) + "x").encode()
        for truncated in (0, 1):
            actual = subprocess.check_output([*command, str(2 * pairs + truncated)], timeout=30)
            expected = b"Exhausted\n" if truncated else f"(Proof #x{proof.hex()} 0)\n".encode()
            if actual != expected:
                raise ValueError((pairs, truncated, actual, expected))
print(target, "30 exact-fuel and truncated-fuel cases passed")
