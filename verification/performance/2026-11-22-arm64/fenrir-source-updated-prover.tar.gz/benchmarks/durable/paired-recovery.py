"""Measure the shared Mac recovery scenario in rotated worker order."""
import argparse
import json
from pathlib import Path
import random
from runpy import run_path
import statistics

from_repeat = run_path(str(Path(__file__).with_name("repeat-recovery.py")))
checked = run_path(str(Path(__file__).with_name("compare-recovery.py")))["checked"]


def shared_components(sample):
    build = Path(sample["build"])
    hashes = sample["build_sha256"]
    components = {name: hashes[str(build / name)] for name in ("sqlite-port", "otp.txt")}
    # These OTP modules implement the supervisor, transport and persistent service.
    # The application worker and its image intentionally vary across implementations.
    service = Path(__file__).resolve().parents[2] / "host/service/src"
    for source in sorted(service.glob("*.erl")):
        name = source.with_suffix(".beam").name
        components[name] = hashes[str(build / "ebin" / name)]
    adapter = "fenrir_port_reference.beam"
    components[adapter] = hashes[str(build / "ebin" / adapter)]
    components["scenario"] = sample["scenario_sha256"]
    return components


def measure(builds, output, blocks, workload="recovery"):
    workers = {}
    expected = None
    for build in builds:
        history = checked(build)
        worker = history["worker_implementation"]
        contract = [history[key] for key in ("schema", "tenants", "scenario", "event_count", "events_sha256")]
        if worker in workers or expected is not None and contract != expected:
            raise ValueError("expected distinct workers with identical accepted histories")
        expected = contract
        workers[worker] = build
    subject = "fenrir-native-mac"
    if subject not in workers or len(workers) < 2:
        raise ValueError("expected Fenrir and at least one reference worker")
    output.mkdir(parents=True, exist_ok=False)
    names = list(workers)
    pairs = []
    paced_verdicts = {name: [] for name in names}
    runtime = None
    sqlite_connection = None
    shared = None
    builds_by_worker = {}
    schedule = None
    measured_contract = None
    for block in range(blocks):
        offset = block % len(names)
        order = names[offset:] + names[:offset]
        row = {}
        for name in order:
            dest = output / str(block) / name
            from_repeat["run"](workers[name], dest, 1, workload)
            measured = from_repeat["history_summary"](dest / "0/history.json")
            contract = [measured[k] for k in ("schema", "tenants", "scenario", "event_count", "events_sha256")]
            if measured_contract is not None and contract != measured_contract:
                raise ValueError(f"measured history differs at block {block}, worker {name}")
            measured_contract = contract
            sample = json.loads((dest / "summary.json").read_text())
            if sample["worker"] != name or sample["workload"] != workload or sample["samples"] != 1:
                raise ValueError(f"wrong measurement at block {block}, worker {name}")
            components = shared_components(sample)
            if shared is not None and components != shared:
                changed = sorted(k for k in shared.keys() | components.keys() if shared.get(k) != components.get(k))
                raise ValueError(f"block {block}, worker {name}: differing shared components: {', '.join(changed)}")
            shared = components
            identity = sample["build_sha256"]
            if name in builds_by_worker and builds_by_worker[name] != identity:
                raise ValueError(f"worker build changed at block {block}, worker {name}")
            builds_by_worker[name] = identity
            if runtime is not None and sample["runtime"] != runtime:
                raise ValueError(f"OTP runtime differs at block {block}, worker {name}")
            if sqlite_connection is not None and sample["sqlite_connection"] != sqlite_connection:
                raise ValueError(f"SQLite connection settings differ at block {block}, worker {name}")
            sqlite_connection = sample["sqlite_connection"]
            runtime = sample["runtime"]
            if schedule is not None and sample["schedule"] != schedule:
                raise ValueError("offered schedule differs across paired samples")
            schedule = sample["schedule"]
            if workload == "paced-commits":
                paced = json.loads((dest / "0/paced.json").read_text())
                if (paced["rate"], paced["seconds"]) != (schedule["rate"], schedule["seconds"]):
                    raise ValueError("paced assessment differs from offered schedule")
                paced_verdicts[name].append(paced["offered_rate_verdict"])
            row[name] = sample["median_us"]
        pairs.append(row)
    rng = random.Random(1147)
    ratios = {}
    for reference in names:
        if reference == subject:
            continue
        ratios[reference] = {}
        for metric in pairs[0][subject]:
            if any(row[reference][metric] == 0 for row in pairs):
                ratios[reference][metric] = None
                continue
            values = [row[subject][metric] / row[reference][metric] for row in pairs]
            medians = sorted(statistics.median(rng.choices(values, k=blocks)) for _ in range(10000))
            ratios[reference][metric] = dict(median=statistics.median(values),
                                             bootstrap95=[medians[249], medians[9749]])
    report = dict(workload=workload, schedule=schedule, blocks=blocks, runtime=runtime, sqlite_connection=sqlite_connection, shared_sha256=shared, build_sha256=builds_by_worker,
                  history_event_count=measured["event_count"], history_events_sha256=measured["events_sha256"], samples_us=pairs, fenrir_over_reference=ratios, bootstrap_seed=1147)
    if workload == "paced-commits":
        report["offered_rate_observations"] = paced_verdicts
        report["replicated_sustained_lower_bound"] = {
            name: schedule["rate"] if len(verdicts) >= 10 and
            all(v == "sustained-at-offered-rate" for v in verdicts) else None
            for name, verdicts in paced_verdicts.items()}
    (output / "paired.json").write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("builds", nargs="+", type=Path)
    parser.add_argument("--blocks", type=int, default=10)
    parser.add_argument("--workload", choices=["recovery", "backlog", "fresh-commits", "paced-commits"], default="recovery")
    args = parser.parse_args()
    if args.blocks < 1:
        parser.error("blocks must be positive")
    measure(args.builds, args.output, args.blocks, args.workload)
