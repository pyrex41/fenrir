"""Run alternating Solo5 durable-service pairs and verify every completed block."""
import argparse
import json
import os
from pathlib import Path
import random
from runpy import run_path
import statistics

here = Path(__file__).resolve().parent
root = here.parents[1]
compare = run_path(str(here / "compare-paced-spt.py"))["compare"]
run_group = run_path(str(here / "compare-recovery.py"))["run_group"]
workers = ("fenrir-native-spt", "c-native-spt")


def summarize(pairs):
    if not pairs:
        raise ValueError("expected at least one verified pair")
    shared = pairs[0]["shared"]
    digests = [sample["guest_sha256"] for sample in pairs[0]["samples"]]
    seen = set()
    ratios = []
    cleared = {worker: True for worker in workers}
    for pair in pairs:
        samples = pair["samples"]
        if (pair["shared"] != shared or [s["guest_sha256"] for s in samples] != digests
                or tuple(s["worker"] for s in samples) != workers):
            raise ValueError("pair conditions or guest images changed between blocks")
        for sample in samples:
            location = Path(sample["directory"]).resolve()
            if location in seen:
                raise ValueError("reused run directory")
            seen.add(location)
            cleared[sample["worker"]] &= sample["offered_rate_verdict"] == "sustained-at-offered-rate"
        if samples[1]["acknowledgement_p99_us"] <= 0:
            raise ValueError("reference p99 must be positive")
        ratios.append(samples[0]["acknowledgement_p99_us"] / samples[1]["acknowledgement_p99_us"])
    interval = None
    if len(pairs) >= 10:
        rng = random.Random(1147)
        bootstrap = sorted(statistics.median(rng.choices(ratios, k=len(pairs))) for _ in range(10000))
        interval = [bootstrap[249], bootstrap[9749]]
    return dict(blocks=len(pairs), rate=shared["rate"], seconds=shared["seconds"],
                replicated_sustained_lower_bound={w: shared["rate"] if cleared[w] and len(pairs) >= 10 else None
                                                  for w in workers},
                fenrir_over_c_p99_ratios=ratios, paired_median=statistics.median(ratios),
                bootstrap95=interval, bootstrap_seed=1147)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("--rate", type=int, required=True)
    parser.add_argument("--seconds", type=int, default=600)
    parser.add_argument("--blocks", type=int, default=10)
    parser.add_argument("--recheck", action="store_true",
                        help="replay the workers recorded in the existing campaign logs")
    args = parser.parse_args()
    if min(args.rate, args.seconds, args.blocks) < 1:
        parser.error("rate, duration and blocks must be positive")
    if args.recheck:
        if not args.output.is_dir():
            parser.error("recheck requires an existing campaign directory")
    else:
        args.output.mkdir(parents=True, exist_ok=False)
    env = dict(os.environ, FENRIR_COMMIT_RATE=str(args.rate), FENRIR_COMMIT_SECONDS=str(args.seconds))
    pairs = []
    for block in range(args.blocks):
        order = workers if block % 2 == 0 else workers[::-1]
        directories = {}
        for worker in order:
            log = args.output / f"{block}-{worker}.log"
            if not args.recheck:
                with log.open("x") as output:
                    run_group(["sh", root / "host/service/check-supervised-recovery.sh", worker, "paced-commits"],
                              max(300, args.seconds * 4 + 300), cwd=root, env=env,
                              stdout=output, stderr=output)
            with log.open() as output:
                line = output.readline().rstrip("\n")
            if not line.startswith("Recovery evidence: "):
                raise ValueError(f"missing run directory in {log}")
            directory = Path(line[len("Recovery evidence: "):])
            directories[worker] = directory
            if not args.recheck:
                env["FENRIR_RECOVERY_IMAGE"] = (directory / "container.id").read_text().strip()
        pair = compare(*(directories[w] for w in workers))
        pair["order"] = order
        if (pair["shared"]["rate"], pair["shared"]["seconds"]) != (args.rate, args.seconds):
            raise ValueError("recorded workload differs from requested rate or duration")
        pairs.append(pair)
        result = summarize(pairs)
        prefix = "rechecked-" if args.recheck else ""
        (args.output / f"{prefix}{block}.json").write_text(json.dumps(pair, indent=2) + "\n")
        summary_name = prefix + "summary"
        pending = args.output / (summary_name + ".pending")
        pending.write_text(json.dumps(result, indent=2) + "\n")
        pending.replace(args.output / (summary_name + ".json"))
        print(f"verified {block + 1}/{args.blocks} pairs at {args.rate} commits/s", flush=True)


if __name__ == "__main__":
    main()
