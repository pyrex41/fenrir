"""Compare checked histories for the same scenario across worker implementations."""
import argparse
import hashlib
import json
import os
import signal
from pathlib import Path
import subprocess
import tempfile

root = Path(__file__).resolve().parents[2]


def run_group(command, timeout, **options):
    # The shell checker launches Shen, and escript can launch native ports.
    with subprocess.Popen(command, start_new_session=True, **options) as child:
        try:
            status = child.wait(timeout)
        except BaseException:
            try:
                os.killpg(child.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            raise
        if status:
            raise subprocess.CalledProcessError(status, command)


def history_summary(path, snapshot=None):
    def read(source):
        data = source.read_bytes()
        if snapshot is not None:
            (snapshot / source.name).write_bytes(data)
        return json.loads(data)

    history = read(path)
    count = 0
    digest = hashlib.sha256()

    def consume(events):
        nonlocal count
        if not isinstance(events, list):
            raise ValueError("expected history events")
        for event in events:
            digest.update(json.dumps(event, sort_keys=True, separators=(",", ":")).encode())
            digest.update(b"\n")
        count += len(events)

    if history["schema"] == "fenrir.service.history/1-chunked":
        chunks = history.pop("chunks")
        total = history.pop("event_count")
        if type(chunks) is not int or type(total) is not int or not 0 <= chunks <= total:
            raise ValueError("invalid history chunk counts")
        for index in range(chunks):
            chunk = read(path.with_name(f"{path.name}.events.{index}"))
            if chunk["first"] != count or not chunk["events"]:
                raise ValueError("invalid history chunk extent")
            consume(chunk["events"])
        if total != count:
            raise ValueError("history event count differs")
        history["schema"] = "fenrir.service.history/1"
    else:
        consume(history.pop("events"))
    return dict(history, event_count=count, events_sha256=digest.hexdigest())


def checked(directory):
    history_path = (directory / "history.json").resolve()
    verdict = json.loads((directory / "check/verdicts.jsonl").read_bytes())
    with tempfile.TemporaryDirectory() as temporary:
        work = Path(temporary)
        snapshot = work / "history.json"
        history = history_summary(history_path, work)
        if (Path(verdict["history"]) != history_path or verdict["verdict"] != "accepted"
                or verdict["events"] != history["event_count"] or verdict["scenario"] != history["scenario"]):
            raise ValueError(f"{directory}: missing matching accepted verdict")
        timeout = 120
        if history["scenario"] == "paced-commits":
            # Fresh-key replay scans the growing model store at each submit.
            # Scale the deadline for long histories while bounding a stuck run.
            blocks = (history["event_count"] + 5999) // 6000
            timeout = min(1800, max(timeout, 4 * blocks * blocks))
        run_group(["sh", root / "harness/run-service-history.sh", snapshot, work / "check"],
                  timeout, stdout=subprocess.DEVNULL)
        fresh = json.loads((work / "check/verdicts.jsonl").read_bytes())
        if fresh["verdict"] != "accepted":
            raise ValueError(f"{directory}: current history rejected by model")
    return history


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directories", nargs="+", type=Path)
    runs = [checked(directory) for directory in parser.parse_args().directories]
    workers = [h["worker_implementation"] for h in runs]
    if len(set(workers)) != len(workers) or len(workers) < 2:
        raise ValueError("expected two or more different workers")
    for field in ("schema", "tenants", "scenario", "event_count", "events_sha256"):
        if any(h[field] != runs[0][field] for h in runs[1:]):
            raise ValueError(f"{field} differs across histories")
    print(f"{runs[0]['event_count']} matching events across {', '.join(workers)}")


if __name__ == "__main__":
    main()
