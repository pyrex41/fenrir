"""Compare observable traces of the frontend's handler fixtures with native execution."""
import hashlib
import json
import re
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[2]
fixtures = root / "tests/frontend/roundtrip"
out = Path(sys.argv[1]).resolve()
out.mkdir(parents=True, exist_ok=False)
report = []


def run(command, cwd):
    return subprocess.run(command, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                          text=True, timeout=120)


sources = ([fixtures / name for name in sys.argv[2:]] if len(sys.argv) > 2 else
           [p for p in sorted(fixtures.glob("*.fen")) if any(
               line.startswith("(effect ") for line in p.read_text().splitlines())])
if not sources:
    sys.exit(f"no handler fixtures found in {fixtures}")
for source in sources:
    case = out / source.stem
    case.mkdir()
    model = run(["sh", root / "frontend/fenrir.sh", "run", source.name], source.parent)
    (case / "shen.txt").write_text(model.stdout)
    expected = []
    expected_code = None
    for line in model.stdout.splitlines():
        if line.startswith(("emit ", "trap at:")):
            expected.append(line)
        elif line.startswith("outcome: deadlock: "):
            expected_code = 1
            expected.append(line[len("outcome: "):])
        elif line.startswith("outcome: Ok "):
            expected_code = 0
            expected.append(line[len("outcome: Ok "):])
        elif line.startswith("outcome: Trap "):
            expected_code = 1
            expected.append("trap: " + line[len("outcome: Trap "):])
    if expected_code is None or model.returncode != 0:
        raise ValueError((source, model.stdout))
    for target in ("macos-arm64", "solo5-arm64-spt"):
        work = case / target
        work.mkdir()
        image = work / "image"
        build = run([root / "bin/fenrir", "build", "--target", target, source.name, "-o", image], source.parent)
        (work / "build.txt").write_text(build.stdout)
        record = dict(fixture=source.name, target=target, expected=expected,
                      source_sha256=hashlib.sha256(source.read_bytes()).hexdigest())
        if build.returncode:
            record.update(status="build-failed", exit=build.returncode)
        else:
            actual = run(["sh", root / "tools/aarch64/run-image.sh", target, work, "0"], root)
            (work / "actual.txt").write_text(actual.stdout)
            lines = actual.stdout.splitlines()
            if expected_code == 1 and expected[-1].startswith("trap: ") and not any(line.startswith("trap at:") for line in expected):
                # The task oracle reports the trap class without its native source site.
                if lines and re.fullmatch(r"trap at: " + re.escape(source.name) + r":[1-9]\d*:[1-9]\d*", lines[-1]):
                    record["native_trap_site"] = lines.pop()
                else:
                    lines.append("missing native trap location")
            record.update(status="pass" if actual.returncode == expected_code and
                          lines == expected else "mismatch", exit=actual.returncode,
                          image_sha256=hashlib.sha256(image.read_bytes()).hexdigest())
        report.append(record)
        (out / "report.json").write_text(json.dumps(report, indent=2) + "\n")
        print(target, source.name, record["status"], flush=True)
sys.exit(int(any(row["status"] != "pass" for row in report)))
