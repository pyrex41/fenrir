# Fenrir alpha and performance plan for Apple Silicon and Solo5 ARM64

## 1. Release milestones

Functional alpha ships a direct ARM64 compiler that takes the same .fen source to a native macOS executable and a Solo5 guest. The guest runs under spt in an ARM64 Linux VM on Apple Silicon. A second engineer must be able to install the release, modify an application, build and run both targets, diagnose a native trap, and replay a recorded failure from the published instructions.

High-performance alpha requires the same release to pass the functional gates and the performance scorecard below. Rust joins Nim as a systems-performance reference across all four applications. Elixir and Erlang are references for concurrent HTTP serving, supervision, durable work, and recovery. The existing Erlang supervisor also serves as a shared component in controlled comparisons. Benchmark results must identify which parts of each system execute in which language.

## 2. Build the compiler and runtime in dependency order

| Stage | Deliverable and exit test |
|---|---|
| A0. Freeze the alpha contract | Version the existing S-expression surface and specify checked I64, bytes, algebraic data, matching, closures, recursion, local modules, declared effects, inferred finite effect sets, one-shot handlers, structured tasks, bounded channels, cancellation, and remote outcomes. Define overflow, exhaustion, cleanup, and observable I/O. Pin the Mac and VM environments. Freeze benchmark inputs, algorithms, comparator eligibility, and output checks before tuning. |
| A1. Compile one program end to end | Connect the Shen frontend to a validated typed intermediate representation and extend the existing direct ARM64 emitter. Share lowering and instruction selection. Give Darwin and Solo5 explicit startup, ABI, relocation, linking, and termination paths. Compile a recursive .fen program and its checked-overflow case on the Mac and execute the emitted instructions on both targets. Record source, compiler, runtime, and binary identities. |
| A2. Complete the pure native runtime | Implement unboxed integers where types permit, constructor layouts, bytes, tuples, matching, closure capture, indirect calls, and tail calls. Start with a precise non-moving tracing heap. Specify roots across calls, suspension, and host boundaries. Pass deep tail recursion, forced collection, shared-object retention, and bounded exhaustion tests. Build the prover and framed-log processor on both targets. |
| A3. Compile handlers and concurrency | Implement handler lookup, continuation frames, one-shot resumption, structured scope exit, join, cancellation, bounded channels, and cleanup on a single-threaded cooperative scheduler. Add deterministic scheduling and virtual time for replay, plus a monotonic clock adapter for live deadlines. Check observable traces against Shen, including cancellation during suspension, shutdown with a full channel, and timeout after commit. |
| A4. Run real services | Version a bounded host ABI for console, clocks, byte streams, and service transport. Supply Darwin adapters and reuse Solo5 devices, the Erlang supervisor, and SQLite. For the Solo5 web server, terminate TCP at host ingress and run HTTP parsing and routing in compiled Fenrir. Run the compiled durable service through the existing history checker. Measure ingress, guest, transport, and storage time separately. |
| A5. Package and qualify | Ship check, build, run, test, and replay commands, explicit target selection, source locations for errors and traps, a locked toolchain, a Mac release, and a reproducible VM launcher. Run the clean-machine exercise and produce source-bound receipts on both targets. Publish the scope of lowering proofs, differential tests, and outstanding refinement obligations. |

The existing ARM64 emitter, service implementation, and campaign records are the starting point. Keep Shen authoritative and identify which guarantees have proofs, which have bounded execution evidence, and which remain open. Formal ARM64 qualification requires an admitted profile and a qualifying run. Compiler roadmap (verification/aarch64/PLAN.md) · Service contract (host/service/CONTRACT.md) · ARM64 qualification proposal (campaigns/arm64/QUALIFICATION_PROPOSAL.md)

## 3. Applications and reference implementations

| Application | Correctness and workload | Required references and measurements |
|---|---|---|
| Propositional prover and certificate checker | Include provable formulas, countermodels, and search exhaustion. Freeze the calculus, search order, and memoization policy. Verify certificates and countermodels independently. Benchmark search and checking separately. | Shen/JIT, Koka, Nim, Rust. Measure explored nodes, nodes/s, certificates/s, peak memory, and cold CLI time. Rust supplies a tagged-enum and pattern-matching baseline. Shen/JIT supplies the symbolic-language baseline. |
| Bounded HTTP/1.1 web server | Serve static bytes, parameterized routes, and a small JSON response. Exercise fragmented input, keep-alive, malformed headers, oversized requests, slow readers, and disconnects. Use one corpus for parser/router tests and a real client for service load. | Koka, Nim, Rust for the parser/router. Nim and Rust for matched native services. Add an Elixir service using Bandit and Plug for the same externally visible endpoints, limits, and response bytes. Report parser throughput separately from requests/s, CPU/request, p50/p99, and memory under concurrent connections. |
| Distributed durable job service | Extend the tenant report example into ingress, ledger, and worker roles. Inject duplicate requests, lost replies, process death before and after commit, worker restart, and backlog drain. Check tenant isolation, retry consistency, durable acceptance, and the worker’s idempotency boundary. | Nim and Rust implement matched service logic with the same transactions, SQLite settings, transport, and fault schedule. Add an Erlang/OTP service with application logic in Erlang workers and an Elixir/OTP service using supervised workers. Measure commits/s, p99 acknowledgement, restart-to-first-success, backlog drain time, and retry amplification. Publish invalid histories even when throughput is high. |
| Streaming framed-log processor | Decode length-prefixed records across arbitrary chunks, validate them, aggregate by key, and emit a canonical summary. Include truncation, skewed keys, large fields, and input larger than the heap. Verify output digests and rejection offsets. | Shen/JIT, Koka, Nim, Rust. Measure MiB/s, allocations/MiB, peak memory, and time to first output. Require each implementation to obey the same streaming memory bound. |

The Mac reference entry points are:

| Workload | Rust | Elixir or Erlang |
|---|---|---|
| Prover | [Search and certificate checker](benchmarks/prover/reference.rs) | — |
| HTTP | [Router timing harness](benchmarks/http/router-time.rs) and [socket service](benchmarks/http/reference.rs) | [Elixir/Bandit service](benchmarks/http/elixir/serve.exs) |
| Durable jobs | [Native worker](benchmarks/durable/reference.rs) | [Erlang worker](benchmarks/durable/fenrir_erlang_reference.erl) and [Elixir worker](benchmarks/durable/elixir_reference.ex) |
| Framed log | [Streaming processor](benchmarks/framed-log/reference.rs) | — |

Use the BEAM references in two distinct experiments. For the durable-service comparison, hold the Erlang supervisor, transport, SQLite configuration, and history checker fixed while swapping application workers. This isolates the cost of the worker and its boundary. Then run each complete supervised deployment under the same external workload and failure schedule. This measures what an operator experiences, including restart and drain. The existing supervisor alone cannot supply the Erlang application baseline because it does not perform the same application work.

Keep the Rust comparisons idiomatic and equivalent. Use optimized release builds, explicit checked arithmetic wherever Fenrir requires traps, and equivalent limits on buffers, queues, and concurrency. Permit borrowing and zero-copy parsing when the input-lifetime contract allows them. Pin the Rust compiler, dependencies, allocator configuration, and build flags. For BEAM runs pin OTP, Elixir, libraries, scheduler count, and CPU allocation. Run single-core matched comparisons and report a separate equal-core deployment comparison for concurrent services. [Rust checked arithmetic](https://doc.rust-lang.org/std/primitive.i64.html#method.checked_add) · [Erlang/OTP supervision](https://www.erlang.org/doc/system/sup_princ.html) · [Elixir Supervisor](https://hexdocs.pm/elixir/Supervisor.html) · [Bandit](https://github.com/mtrudel/bandit)

## 4. Performance gates and measurement

- Native Mac kernels. Score proof search, certificate checking, HTTP parsing/routing, and framed-log processing equally. Divide Fenrir elapsed time by the fastest eligible pinned implementation for each kernel, including Rust. Require geometric mean ≤1.5× and every kernel ≤2.0×. Report every language’s result alongside the ratio, with output verification and work counts. [Shen/JIT](https://github.com/tizoc/shen-jit) · [Koka](https://github.com/koka-lang/koka) · [Nim memory managers](https://nim-lang.org/docs/mm.html)
- Solo5 kernels. Compile each kernel as an ARM64 guest and compare it with an optimized C guest using the same tender, device setup, input transfer, and timing boundaries. Apply the same 1.5× mean and 2.0× individual thresholds. Keep Rust, Nim, Koka, Shen/JIT, Elixir, and Erlang host timings labeled by execution environment. Alpha does not require porting those runtimes to Solo5.
- Services. For each Fenrir target, require ≥⅔ of the fastest matched reference’s sustainable throughput and p99 ≤1.5× that reference at 70% of the slower system’s measured capacity. Select the throughput reference once and use that same implementation for the latency comparison. On Solo5 use a matched guest behind the same ingress and storage path. Define sustainable capacity as ten minutes without growing backlog, fewer than 0.1% unexpected errors, and zero invalid histories. Report idiomatic Elixir/BEAM deployment results alongside the matched runs, including overload and recovery.
- Memory and experimental quality. Require peak memory ≤2× the matched speed reference on each single-process kernel. For services publish guest, VM, BEAM, and storage memory separately with the measurement method. Use one identified Apple Silicon machine, fixed resource budgets, rotated execution order, and at least ten paired samples. Separate compilation, VM or process startup, warm-up, and steady execution. Publish raw timings and paired 95% confidence intervals. Rerun inconclusive rows. An output mismatch invalidates the timing.
- Optimization sequence. Start with profiles from the four applications. Prioritize measured costs in boxing, copying, allocation, closure calls, handler dispatch, continuation frames, and register allocation. Accept an optimization only after rechecking the affected semantic fixtures and the full scorecard. Track cold-start and recovery independently of warm throughput.

## 5. Release decision

Functional alpha passes when all four released Fenrir applications build from source and pass on both targets, the clean-machine exercise succeeds, required fault and differential campaigns have complete receipts, and the advertised profile has no known wrong-code, isolation, corruption, or replay failures. State the SQLite durability settings and exact fault boundary behind each recovery claim.

High-performance alpha passes when that same release clears the kernel, service, latency, and memory gates with published reference implementations and reproducible results. Missing evidence remains UNKNOWN. HVT, other architectures, multicore Fenrir scheduling, an in-guest TCP stack, a public package registry, and whole-language machine-checked correctness remain later milestones.

First checkpoint: compile one recursive .fen program directly to both targets, then run one frozen prover corpus through Shen/JIT, Koka, Nim, and Rust with independent output validation. In parallel, capture the current OTP service’s commit, crash, restart, and drain history. That gives the project an executable compiler milestone, a credible CPU comparison, and a concrete service-recovery baseline before optimization begins.

To calculate the four-kernel elapsed score for one target, run
`python3 benchmarks/kernel-scorecard.py PROVER_REPORT ROUTER_REPORT STREAM_REPORT`
with the three JSON reports from the same build campaign. The report names
the framed-log profile, retains input report digests, and gives each kernel
equal weight. Its aggregate interval resamples paired elapsed ratios within
each kernel independently. The elapsed verdict requires the upper endpoint of each kernel’s paired 95% interval to be at most 2× and the geometric mean’s upper endpoint to be at most 1.5×. A lower endpoint above its ceiling fails that comparison. An interval crossing its ceiling calls for another run.
The combined kernel verdict also requires all four memory intervals to pass, matching host and hardware records, and the same shared compiler and runtime source hashes across the three reports. The scorecard checks the proof corpus and certificate digests against the versioned inputs in benchmarks/prover. A missing digest leaves input identity unverified. A different digest rejects the comparison. Older reports with missing identities can still show individual measurements. Service latency and clean-machine qualification have separate gates.

The scorecard also reconstructs the HTTP request heads and expected routing
fields, and the framed-log input and expected summary for the named profile.
The HTTP header digest and work counts, stream byte count, input digest, and
expected output must match to qualify. A missing identity leaves that check
unverified. Compare results for the same stream profile across compiler builds.

To reproduce a full kernel campaign from the checkout, run the following
commands serially on the same Apple Silicon host. Each output directory must
be new. Use the pinned Shen/JIT and Clang environment, Rust and Nim on PATH,
and the Koka compiler selected by `KOKA`. For example, when using the
packaged toolchain, prefix each command with `"$package/bin/fenrir-toolchain"`.

```sh
python3 benchmarks/run-kernels.py macos-arm64 build/kernels-mac
python3 benchmarks/run-kernels.py solo5-arm64-spt build/kernels-solo5
```

Each directory contains the three raw reports, build and validation logs,
and a scorecard referencing the reports by relative path. The Mac mixed
stream uses 80 rotated pairs. The Solo5 campaign resolves the tender image
once before launching the suites. A completed campaign can report a failed
or undetermined gate. Reports produced before the source manifest included
the result printer, canonical encoding, task-state header and shared Shen
frontend dependencies retain their timings with unverified source identity.
