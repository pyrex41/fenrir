import hashlib,itertools,json,random,statistics,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
report=json.loads((root/'report.json').read_text()); guests=['fenrir','c']
for name in guests:
    assert hashlib.sha256((root/(name+'.spt')).read_bytes()).hexdigest()==report['guest_sha256'][name]
assert hashlib.sha256((root/'fenrir-profile.spt').read_bytes()).hexdigest()==report['fenrir_heap']['binary_sha256']
frames=[bytes([0,6,k,k,1,2,3,255]) for k in [(37*i)%64 for i in range(64)]]
for run in (1,8,64):
    disk=b''.join(f*run for f in frames)*(2048//run)
    (root/str(run)).write_bytes(disk)
    assert len(disk)==report['bytes']
    if run==1: assert hashlib.sha256(disk).hexdigest()==report['input_sha256']
def invoke(items,profile=False):
    command=['docker','run','--rm','--network','none','--platform','linux/arm64','--cpuset-cpus','1','-v',f'{root}:/work:ro','-w','/work','--entrypoint','sh',report['container'],'-ec',
             'mode=$1; size=$2; shift 2; for item do cpu=${item%/*}; img=${item#*/}; cp "$cpu" /tmp/disk; /opt/solo5-install/bin/solo5-spt --block:input=/tmp/disk "$img.spt" --solo5:quiet "$mode$size" ; done','sh','p' if profile else 't',str(report['bytes']),*items]
    return subprocess.check_output(command,text=True,timeout=180)
orders=list(itertools.permutations((1,8,64)))*2
orders.insert(0,(1,8,64))
items=[f'{w}/{g}' for i,order in enumerate(orders) for j,w in enumerate(order) for g in (guests if (i+j)%2==0 else guests[::-1])]
raw=invoke(items);(root/'raw.txt').write_text(raw)
lines=iter(raw.splitlines()); rows=[]
for item in items:
    output=''.join(next(lines)+'\n' for _ in range(64))
    assert hashlib.sha256(output.encode()).hexdigest()==report['expected_output_sha256']
    tag,v=next(lines).split(); assert tag=='elapsed_ns' and int(v)>0
    rows.append((item,int(v)))
assert next(lines,None) is None
rng=random.Random(1147);result={}
for w in (8,64):
 for g in guests:
    blocks=[dict(rows[i:i+6]) for i in range(6,len(rows),6)]
    ratios=[b[f'{w}/{g}']/b[f'1/{g}'] for b in blocks]
    boot=sorted(statistics.median(rng.choices(ratios,k=len(ratios))) for _ in range(10000))
    result[f'{w}/{g}']=[statistics.median(ratios),boot[249],boot[9749]]
print(result,flush=True)
(root/'results.json').write_text(json.dumps(dict(orders=orders,rows=rows,ratios=result),indent=2))

raw=invoke([f"{w}/fenrir-profile" for w in (1,8,64)],True)
(root/"heap.txt").write_text(raw)
