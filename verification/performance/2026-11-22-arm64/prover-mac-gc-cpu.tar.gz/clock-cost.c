#include <stdio.h>
#include <stdint.h>
#include <time.h>
int main(void) {
    uint64_t sum = 0;
    for (int i = 0; i < 100000; i++) {
        uint64_t a = clock_gettime_nsec_np(CLOCK_PROCESS_CPUTIME_ID);
        sum += clock_gettime_nsec_np(CLOCK_PROCESS_CPUTIME_ID) - a;
    }
    printf("%.2f\n", sum / 100000.0);
}
