#define MAX_FORMULA 64
#define MAX_PROOF 256
#ifndef CORPUS_LIMITS_ONLY
static const bool checking = true;
static const test_case cases[] = {
  {{">aa", {2, 0, 0}}, "ssx", 100, 3, 0, PROOF},
  {{"|a!a", {2, 0, 0, 0}}, "sssx", 100, 4, 0, PROOF},
  {{">&a>abb", {6, 3, 0, 5, 0, 0, 0}}, "ssssbxx", 100, 7, 0, PROOF},
  {{">&a|bc|&ab&ac", {6, 3, 0, 5, 0, 0, 10, 9, 0, 0, 12, 0, 0}}, "ssssbbbsxsxbsxsxbbsxsxbssxssx", 100, 29, 0, PROOF},
  {{">&>ab>bc>ac", {8, 5, 4, 0, 0, 7, 0, 0, 10, 0, 0}}, "sssbbssxssxbsssxsssx", 200, 20, 0, PROOF},
  {{">>>abaa", {6, 5, 4, 0, 0, 0, 0}}, "sbssxsx", 200, 7, 0, PROOF}
};
#endif
