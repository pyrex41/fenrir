from pathlib import Path
from runpy import run_path
import hashlib,json,subprocess,sys
from tempfile import TemporaryDirectory
p=Path('benchmarks/prover').resolve();d=Path(__file__).resolve().parent
sys.path.insert(0,str(p));mod=run_path(str(p/'measure-spt.py'))
rows=json.loads((d/'counts.json').read_bytes())
with TemporaryDirectory() as tmp:
 t=Path(tmp);reference=p/'reference-representation.c';oracle=t/'oracle'
 subprocess.run(['rustc','-O','-C','overflow-checks=yes',p/'reference.rs','-o',oracle],check=True)
 corpus=p/'corpus-v1.txt';answers=subprocess.check_output([oracle,corpus],text=True)
 summary={}
 for lane,cases in [('search',rows),('check',[r for r in rows if r['kind']=='proof'])]:
  (t/'corpus.h').write_text(mod['c_table'](corpus,answers,lane))
  (t/'audit.c').write_text('''#include <stdint.h>
#include <stdio.h>
struct result {int64_t value; uint64_t status;};
extern struct result fenrir_entry(int64_t);
extern uint64_t representation_formula_allocations;
void representation_observe(unsigned i,unsigned kind,unsigned work,unsigned cells,unsigned copies) {
 printf("%u %u %u %u %u\\n",i,kind,work,cells,copies);
}
int main(void) {
 struct result r=fenrir_entry(1);
 printf("formulas %llu\\n", (unsigned long long)representation_formula_allocations);
 return r.status || r.value != '''+str(len(cases))+''';
}
''')
  subprocess.run(['clang','-std=c11','-O2','-fsanitize=undefined','-Wall','-Wextra','-Werror','-DREPRESENTATION_DIAGNOSTICS','-I',t,reference,t/'audit.c','-o',t/'audit'],check=True)
  observations=subprocess.check_output([t/'audit'],text=True).splitlines()
  assert observations.pop()==f"formulas {23 if lane=='search' else 21}"
  assert len(observations)==len(cases);last=0;details=[]
  for case,line in zip(cases,observations):
   i,kind,work,cells,copies=map(int,line.split());assert i==len(details)
   assert (kind,work,cells,copies-last)==(['proof','model','exhausted'].index(case['kind']),len(case['trace']),case['new_entries']+case['copied'],case['copied']),(case,line,last)
   details.append(dict(case=case['case'],work=work,cells=cells,copied=copies-last));last=copies
  summary[lane]=details
 (d/'control-check.json').write_text(json.dumps(dict(source_sha256=hashlib.sha256(reference.read_bytes()).hexdigest(),per_case=summary),indent=2)+'\n')
 print({lane:sum(c['copied'] for c in cases) for lane,cases in summary.items()})
