import collections, itertools, json, sys
from pathlib import Path
from runpy import run_path
root=Path.cwd()/'benchmarks/prover'
verify=run_path(str(root/'verify.py'))
rows=[]
def count(front,rear,facts,counters):
    while True:
        if not front and rear:
            front,rear=rear,()
        if not front:
            yield sum(1 << (ord(a)-97) for s,a in facts if s)
            return
        (sign,expr),*tail=front
        front=tuple(tail)
        if isinstance(expr,str):
            if (not sign,expr) in facts:
                yield 'x'
                return
            facts=facts|{(sign,expr)}
        else:
            op=expr[0]
            left=(not sign if op in ('!','>') else sign,expr[1])
            if op=='!' or (sign,op) in {(True,'&'),(False,'|'),(False,'>')}:
                add=(left,) if op=='!' else (left,(sign,expr[2]))
                counters['copied']+=len(rear)
                counters['new_entries']+=len(add)
                rear+=add
            else:
                yield 'b'
                counters['copied']+=len(rear)
                counters['new_entries']+=1
                for step in count(front,rear+(left,),facts,counters):
                    yield step
                    if isinstance(step,int):return
                counters['copied']+=len(rear)
                counters['new_entries']+=1
                rear+=((sign,expr[2]),)
                continue
        yield 's'
for line in (root/'corpus-v1.txt').read_text().splitlines():
    name,kind,budget,*tokens=line.split()
    goal=verify['formula'](iter(tokens)); c=collections.Counter(new_entries=1,copied=0)
    trace=list(itertools.islice(count(((False,goal),),(),frozenset(),c),int(budget)))
    expected=list(itertools.islice(verify['tableau_steps'](goal),int(budget)))
    assert trace==expected,(name,trace,expected)
    rows.append(dict(case=name,kind=kind,trace=trace,**c))
print(json.dumps(rows,indent=2))
