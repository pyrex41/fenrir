import itertools,json,random,subprocess,sys,tempfile
from pathlib import Path
from runpy import run_path
p=Path('benchmarks/prover').resolve();sys.path.insert(0,str(p))
m=run_path(str(p/'measure-spt.py'));v=run_path(str(p/'verify.py'));rng=random.Random(90113)
def tree(depth):
 if depth==0 or rng.randrange(5)==0:return [rng.choice('abcd')]
 op=rng.choice(['&','|','>','!'])
 return [op]+tree(depth-1)+([] if op=='!' else tree(depth-1))
cases=[];answers=[];tapes=[]
for i in range(240):
 tokens=tree(i%6);goal=v['formula'](iter(tokens));steps=v['tableau_steps'](goal);budget=(0,1,3,7,32,256,256)[i%7]
 taken=list(itertools.islice(steps,budget))
 if taken and isinstance(taken[-1],int):kind,w='model',str(taken[-1])
 elif next(steps,None) is None:kind,w='proof',''.join(taken)
 else:kind,w='exhausted','-'
 name=f'case-{i}';cases.append(' '.join([name,kind,str(budget),*tokens]));answers.append(f'{name} {kind} {len(taken)} {w}')
 if kind=='proof':tapes.append(w)
with tempfile.TemporaryDirectory() as tmp:
 t=Path(tmp);corpus=t/'corpus';corpus.write_text('\n'.join(cases)+'\n');rows='\n'.join(answers)
 v['check'](cases,answers)
 for lane in ['search','check']:
  subset=len(cases) if lane=='search' else len(tapes)
  (t/'corpus.h').write_text(m['c_table'](corpus,rows,lane));(t/'main.c').write_text('#include <stdint.h>\nstruct ret {int64_t v; uint64_t status;}; extern struct ret fenrir_entry(int64_t);int main(void){struct ret a=fenrir_entry(1), b=fenrir_entry(0);return a.status || b.status || a.v!='+str(subset)+' || b.v!='+str(3*len(tapes) if lane=='check' else 0)+';}')
  for name in ['reference','reference-representation']:
   subprocess.run(['clang','-O2','-fsanitize=undefined','-Wall','-Werror','-I',t,p/(name+'.c'),t/'main.c','-o',t/'test'],check=True)
   subprocess.run([t/'test'],check=True)
print(json.dumps(dict(seed=90113,search_cases=len(cases),proof_checks=len(tapes),mutation_rejections=3*len(tapes),work_units=sum(int(r.split()[2]) for r in answers),implementations=['compact C','persistent C'])))
