"""Assess one offered HTTP rate from the load driver's census and time series."""
import json
import math
import re
from pathlib import Path
import statistics
import sys


def darwin_cpu_limit(env):
    if "darwin_logical_cpu_max" not in env:
        return None
    count = env["darwin_logical_cpu_max"]
    if type(count) is not int or count < 1 or env.get("sample_origin_version") != 1:
        raise ValueError("expected a positive Darwin CPU count bound to the sample origin")
    return count


def verify_sample_origin(row, env, name, block, rate_index, environment_digest):
    """Validate worker assignment and rotated run order for versioned sweeps."""
    if "sample_origin_version" not in env and "Origin" not in row:
        return
    if env.get("solo5_memory_method") and (env["target"] != "solo5" or "Solo5Memory" not in row or row["Solo5Memory"] is None):
        raise ValueError("missing Solo5 memory observation")
    workers = {"mac": ("fenrir", "rust", "nim"), "solo5": ("fenrir", "c"),
               "elixir": ("elixir",)}[env["target"]]
    position = (workers.index(name) - block - rate_index) % len(workers)
    if env.get("sample_origin_version") != 1 or row.get("Origin") != dict(
            worker=name, position=position, environment_sha256=environment_digest):
        raise ValueError(f"sample origin differs for {name}, block {block}, rate index {rate_index}")


def solo5_memory(record):
    if record is None:
        return None
    if not re.fullmatch(r"[0-9a-f]{64}", record["container_id"]):
        raise ValueError("invalid measured container identity")
    for sample in (record["before"], record["after"]):
        rss, peak, total, available = (sample[key] for key in (
            "tender_rss_bytes", "tender_lifetime_hwm_bytes", "vm_total_bytes", "vm_available_bytes"))
        if any(type(n) is not int or n <= 0 for n in (rss, peak, total, available)):
            raise ValueError("invalid Solo5 memory counter")
        if peak < rss or available > total:
            raise ValueError("inconsistent Solo5 memory counters")
    if record["before"]["tender_lifetime_hwm_bytes"] > record["after"]["tender_lifetime_hwm_bytes"]:
        raise ValueError("tender lifetime high-water mark decreased")
    return record


def process_resources(record, completed):
    if record is None:
        return None
    samples = record["samples"]
    if len(samples) < 2:
        raise ValueError("process measurements need start and end samples")
    previous_time = previous_cpu = -1
    for sample in samples:
        time_ns, cpu, rss = (sample[k] for k in ("elapsed_ns", "cpu_seconds", "rss_bytes"))
        if (type(time_ns) is not int or time_ns <= previous_time or
                type(cpu) not in (float, int) or not math.isfinite(cpu) or cpu < max(0, previous_cpu) or
                type(rss) is not int or rss < 0):
            raise ValueError("invalid process resource sample")
        previous_time, previous_cpu = time_ns, cpu
    elapsed = (samples[-1]["elapsed_ns"] - samples[0]["elapsed_ns"]) / 1e9
    cpu = samples[-1]["cpu_seconds"] - samples[0]["cpu_seconds"]
    peak = max(s["rss_bytes"] for s in samples)
    cost = cpu * 1e6 / completed if completed else None
    reported_cost = record["cpu_us_per_completed"]
    cost_matches = reported_cost is None if cost is None else (
        type(reported_cost) in (float, int) and math.isclose(reported_cost, cost))
    if (not math.isclose(record["cpu_seconds"], cpu) or record["max_sampled_rss_bytes"] != peak
            or not cost_matches):
        raise ValueError("resource summary differs from process samples or request census")
    return dict(scope=record.get("scope"), sampled_seconds=elapsed, average_cpu_cores=cpu / elapsed,
                cpu_us_per_completed=cost, max_sampled_rss_bytes=peak)


def assess(r):
    # JSON booleans and fractional counts can otherwise pass integer comparisons
    # and even balance the final census while inventing partial requests.
    for key in ("Seconds", "Rate", "Connections", "Scheduled", "Valid", "Invalid",
                "Errors", "Missed", "ElapsedNs", "P50ns", "P99ns", "MaxNs"):
        if type(r[key]) is not int:
            raise ValueError("expected integer measurement for " + key)
    seconds, rate, lanes = (r[k] for k in ("Seconds", "Rate", "Connections"))
    if min(seconds, rate, lanes) < 1:
        raise ValueError("invalid workload")
    total = seconds * rate
    counts = [r[k] for k in ("Valid", "Invalid", "Errors", "Missed")]
    if min(counts) < 0 or sum(counts) != total or r["Scheduled"] != total:
        raise ValueError("inconsistent final request census")
    error_kinds = r.get("ErrorKinds")
    if error_kinds is not None and (any(type(n) is not int or n < 0 for n in error_kinds.values())
                                    or sum(error_kinds.values()) != r["Errors"]):
        raise ValueError("inconsistent transport error counts")
    phase_p99 = {}
    if "ValidRequestPhases" in r:
        phases = r["ValidRequestPhases"]
        if set(phases) != {"PreviousRequest", "Dispatch", "Fetch"}:
            raise ValueError("missing request timing phase")
        for phase, bins in phases.items():
            if len(bins) != 64 or any(type(n) is not int or n < 0 for n in bins) or sum(bins) != r["Valid"]:
                raise ValueError("inconsistent timing histogram for " + phase)
            rank = (99 * r["Valid"] + 99) // 100
            if rank:
                for index, count in enumerate(bins):
                    rank -= count
                    if rank <= 0:
                        phase_p99[phase] = (2**index - 1) / 1e6
                        break
    if r["ElapsedNs"] < seconds * 10**9:
        raise ValueError("run ended before the offered interval")
    if not 0 <= r["P50ns"] <= r["P99ns"] <= r["MaxNs"]:
        raise ValueError("inconsistent latency distribution")
    if "SlowestValid" in r:
        worst = r["SlowestValid"]
        fields = ("Index", "Lane", "ElapsedNs", "PreviousRequestNs", "DispatchNs", "FetchNs")
        if (not isinstance(worst, dict) or any(type(worst.get(k)) is not int or worst[k] < 0 for k in fields)
                or not r["Valid"] or worst["Index"] >= total or worst["Lane"] != worst["Index"] % lanes
                or worst["ElapsedNs"] != r["MaxNs"] or sum(worst[k] for k in fields[3:]) != r["MaxNs"]):
            raise ValueError("inconsistent slowest valid request")
    timeline = r["Timeline"]
    if len(timeline) != seconds:
        raise ValueError("missing timeline entries")
    previous = completed = 0
    previous_errors = 0
    late_seconds = []
    max_delay_ns = None
    previous_time = 0
    for second, row in enumerate(timeline, 1):
        if any(type(row[k]) is not int for k in ("Second", "Scheduled", "Completed", "Backlog")):
            raise ValueError("noninteger timeline at second " + str(second))
        scheduled, done = row["Scheduled"], row["Completed"]
        if (row["Second"] != second or not previous <= scheduled <= total
                or not completed <= done <= scheduled or row["Backlog"] != scheduled - done):
            raise ValueError("inconsistent timeline at second " + str(second))
        if scheduled < second * rate:
            raise ValueError("fewer requests scheduled than required by sample time")
        if error_kinds is not None:
            errors = row.get("Errors")
            if type(errors) is not int or not previous_errors <= errors <= r["Errors"]:
                raise ValueError("inconsistent sampled transport errors")
            previous_errors = errors
        if "ObservedNs" in row:
            when = row["ObservedNs"]
            if type(when) is not int or when < previous_time or not second * 10**9 <= when <= r["ElapsedNs"] or scheduled != min(
                    total, when * rate // 10**9 + 1):
                raise ValueError("inconsistent sampling clock")
            previous_time = when
            max_delay_ns = max(max_delay_ns or 0, when - second * 10**9)
            on_time = when < (second + 1) * 10**9
        elif second < seconds:
            on_time = scheduled < (second + 1) * rate
        else:
            # The offered count saturates. Only the end time can bound this
            # legacy sample once every request has been scheduled.
            on_time = r["ElapsedNs"] < (second + 1) * 10**9
        if not on_time:
            late_seconds.append(second)
        previous, completed = scheduled, done
    if previous != total or completed > total - r["Missed"]:
        raise ValueError("inconsistent terminal sample")
    backlog = [row["Backlog"] for row in timeline]
    windows = [backlog[i:i+60] for i in range(0, seconds, 60)]
    summaries = [dict(min=min(w), median=statistics.median(w), max=max(w), last=w[-1]) for w in windows]
    clears = all(min(w) <= lanes for w in windows) and backlog[-1] <= lanes
    error_fraction = (r["Errors"] + r["Missed"]) / total
    if r["Invalid"]:
        verdict = "invalid-response"
    elif error_fraction >= 0.001:
        verdict = "failed-response-criteria"
    elif seconds < 600:
        verdict = "short-run"
    elif late_seconds:
        verdict = "sampling-cadence-unconfirmed"
    elif not clears:
        verdict = "backlog-clearance-unconfirmed"
    else:
        verdict = "sustained-at-offered-rate"
    return dict(rate=rate, seconds=seconds, valid=r["Valid"], invalid=r["Invalid"],
                errors=r["Errors"], missed=r["Missed"], error_kinds=error_kinds,
                error_fraction=error_fraction, outstanding_at_cutoff=backlog[-1],
                late_sample_seconds=late_seconds, max_observed_sample_delay_ns=max_delay_ns,
                observed_clearance=clears, backlog_by_minute=summaries,
                p99_ms=r["P99ns"]/1e6, phase_p99_upper_ms=phase_p99, verdict=verdict,
                solo5_memory=solo5_memory(r.get("Solo5Memory")),
                process_resources=process_resources(r.get("ServerResources"), total - r["Missed"]))


if __name__ == "__main__":
    for name in sys.argv[1:]:
        print(json.dumps(dict(source=name, **assess(json.loads(Path(name).read_text())))))
