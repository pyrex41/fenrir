import json,subprocess,time
from pathlib import Path
p=Path(__file__).resolve().parent
package=Path('/nix/store/7xpd99idqnh1frvgaybv8rmbas4fh2i0-fenrir-0.1-dev')
script=package/'libexec/fenrir/benchmarks/prover/run-fenrir.py'
targets=['macos-arm64','solo5-arm64-spt']
with (p/'samples.jsonl').open('x') as f:
 for i in range(10):
  for target in targets[::1 if i%2==0 else -1]:
   start=time.monotonic_ns()
   result=subprocess.run([package/'bin/fenrir-toolchain','python3',script,target,'--formula','> a a','--budget','3'],capture_output=True,text=True,timeout=180,check=True)
   elapsed=time.monotonic_ns()-start
   assert result.stdout=='goal proof 3 ssx\n',result.stdout
   print(json.dumps(dict(block=i,target=target,elapsed_ns=elapsed,output=result.stdout)),file=f,flush=True)
