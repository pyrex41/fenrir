set -eu
export PATH=/opt/solo5-install/bin:$PATH
for s in balanced spine; do
 cd /work/$s
 cp /src/benchmarks/prover/reference.c compact.c
 cp /src/benchmarks/prover/reference-representation.c persistent.c
 FENRIR_SOLO5_MAIN=/work/compact-main.c sh /src/tools/aarch64/link-spt.sh compact.c compact.spt
 FENRIR_SOLO5_MAIN=/src/benchmarks/prover/timed-representation.c sh /src/tools/aarch64/link-spt.sh persistent.c persistent.spt
done
cd /work
for b in $(seq 0 12); do
 for v in compact persistent; do
  if [ $((b % 2)) = 1 ]; then order="spine balanced"; else order="balanced spine"; fi
  for s in $order; do
   raw=$(solo5-spt "$s/$v.spt" --solo5:quiet 1000)
   set -- $raw
   test "$1" = 1000 && test "$2" -gt 0 || exit 1
   echo "$b $v $s $raw" >> c-times.txt
  done
 done
done
