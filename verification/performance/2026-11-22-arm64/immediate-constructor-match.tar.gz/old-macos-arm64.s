.text
.p2align 2
.globl _fenrir_entry
_fenrir_entry:
Lfn0:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #112
stp xzr, xzr, [sp, #48]
str xzr, [sp, #64]
str x0, [sp, #72]
add x0, sp, #16
add x1, sp, #48
mov x2, #3
bl _fen_enter
ldr x0, [sp, #72]
cmp x0, #0
b.ne Lfn0if5else
adrp x0, Lconstant0@PAGE
add x0, x0, Lconstant0@PAGEOFF
b Lfn0if5done
Lfn0if5else:
adrp x0, Lconstant1@PAGE
add x0, x0, Lconstant1@PAGEOFF
Lfn0if5done:
str x0, [sp, #48]
adrp x2, Lconstant2@PAGE
add x2, x2, Lconstant2@PAGEOFF
mov x1, x2
bl _fen_bytes_concat
cbz x0, Lfn0fail4_3
str x0, [sp, #56]
movz x0, #1, lsl #0
ldr x2, [sp, #72]
cbz x2, Lfn0fail12_2
cmn x2, #1
b.ne 1f
negs x3, x0
b.vs Lfn0fail12_1
1:
sdiv x0, x0, x2
str x0, [sp, #80]
ldr x0, [sp, #72]
adds x0, x0, #1
b.vs Lfn0fail15_1
str x0, [sp, #88]
mov x0, #1
mov x1, #7
bl _fen_allocate_full
cbz x0, Lfn0fail3_3
ldr x2, [sp, #56]
ldr x3, [sp, #80]
stp x2, x3, [x0, #0]
ldr x2, [sp, #88]
str x2, [x0, #16]
str x0, [sp, #64]
ldr w0, [x0, #72]
cmp w0, #7
b.eq Lfn0match2arm7
cmp w0, #8
b.eq Lfn0match2arm8
brk #0
Lfn0match2arm7:
movz x0, #0, lsl #0
str x0, [sp, #96]
ldr x0, [sp, #64]
ldr x0, [x0, #0]
ldr x2, [sp, #96]
ldr x3, [x0]
cmp x2, x3
b.hs Lfn0fail21_4
ldr w3, [x0, #72]
cmn w3, #1
b.ne 1f
add x0, x0, #80
ldrb w0, [x0, x2]
b 2f
1:
mov x1, x2
bl _fen_bytes_index
2:
b Lfn0match2end
Lfn0match2arm8:
movn x0, #0, lsl #0
b Lfn0match2end
Lfn0match2end:
mov x1, #0
b Lfn0end
Lfn0fail4_3:
adrp x0, Lfn0fail4_3location@PAGE
add x0, x0, Lfn0fail4_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn0end
Lfn0fail12_2:
adrp x0, Lfn0fail12_2location@PAGE
add x0, x0, Lfn0fail12_2location@PAGEOFF
bl _fen_set_location
mov x1, #2
b Lfn0end
Lfn0fail12_1:
adrp x0, Lfn0fail12_1location@PAGE
add x0, x0, Lfn0fail12_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn0end
Lfn0fail15_1:
adrp x0, Lfn0fail15_1location@PAGE
add x0, x0, Lfn0fail15_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn0end
Lfn0fail3_3:
adrp x0, Lfn0fail3_3location@PAGE
add x0, x0, Lfn0fail3_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn0end
Lfn0fail21_4:
adrp x0, Lfn0fail21_4location@PAGE
add x0, x0, Lfn0fail21_4location@PAGEOFF
bl _fen_set_location
mov x1, #4
b Lfn0end
Lfn0end:
bl _fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
.text
.globl _fen_print_result
_fen_print_result:
b Lprint0
Lprint0:
b _fen_write_i64
.p2align 3
Lconstant0:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 42
.p2align 3
Lconstant1:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 41
.p2align 3
Lconstant2:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 0
Lfn0fail4_3location:
.byte 116,114,97,112,32,97,116,58,32,109,97,116,99,104,46,102,101,110,58,51,58,50,49,10,0
Lfn0fail12_2location:
.byte 116,114,97,112,32,97,116,58,32,109,97,116,99,104,46,102,101,110,58,52,58,50,49,10,0
Lfn0fail12_1location:
.byte 116,114,97,112,32,97,116,58,32,109,97,116,99,104,46,102,101,110,58,52,58,50,49,10,0
Lfn0fail15_1location:
.byte 116,114,97,112,32,97,116,58,32,109,97,116,99,104,46,102,101,110,58,52,58,50,57,10,0
Lfn0fail3_3location:
.byte 116,114,97,112,32,97,116,58,32,109,97,116,99,104,46,102,101,110,58,51,58,49,53,10,0
Lfn0fail21_4location:
.byte 116,114,97,112,32,97,116,58,32,109,97,116,99,104,46,102,101,110,58,53,58,51,49,10,0
