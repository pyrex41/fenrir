set -eu
for n in 1 0 9223372036854775807; do
 for v in old new; do
 status=0
 if [ "$1" = mac ]; then "./$v-mac" "$n" > "$v.mac.$n" 2>&1 || status=$?
 else /opt/solo5-install/bin/solo5-spt "$v.spt" --solo5:quiet "$n" > "$v.spt.$n" 2>&1 || status=$?
 fi
 echo "$status" >> "$v.$1.$n"
 done
 cmp "old.$1.$n" "new.$1.$n"
done
