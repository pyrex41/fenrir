#include <errno.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

struct outcome { int64_t value; uint64_t status; };
extern struct outcome fenrir_entry(int64_t argument);

extern const char *fen_trap_location;
extern const char *fen_schedule_request;
extern void fen_print_result(uintptr_t value);
void fen_write(const char *s, size_t n) { fwrite(s, 1, n, stdout); }
void fen_write_i64(int64_t n) { printf("%" PRId64, n); }

extern uint64_t (*fen_host_clock)(void);
extern void (*fen_host_wait)(uint64_t);
static uint64_t monotonic_ns(void) { return clock_gettime_nsec_np(CLOCK_MONOTONIC); }
static void wait_ns(uint64_t ns) {
    struct timespec delay = {ns / 1000000000, ns % 1000000000};
    nanosleep(&delay, NULL);
}

extern uint64_t fen_profile_allocations;
uint64_t fen_profile_clock_ns(void) { return monotonic_ns(); }
int main(int argc, char **argv) {
    if (argc != 2) return 2;
    struct outcome result = fenrir_entry(atoi(argv[1]));
    if (result.status) return 1;
    printf("%lld %llu\n", (long long)result.value, (unsigned long long)fen_profile_allocations);
    return 0;
}
