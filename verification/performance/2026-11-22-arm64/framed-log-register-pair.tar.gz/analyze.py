from pathlib import Path
import json,statistics as s,random,hashlib
p=Path(__file__).resolve().parent
blocks={}
for chunk in (p/'raw').read_text().split('trial ')[1:]:
 header,result=chunk.split('\n',1);i,k=header.split()
 output,time=result.rsplit('elapsed_ns ',1)
 assert hashlib.sha256(output.encode()).hexdigest()=='8f24e1a4ade355dfdd2a074ec07dc3209dad54f7ea5d8ee64b2168c89cccd038'
 blocks.setdefault(int(i),{})[k]=int(time)
assert len(blocks)==24
r=[b['candidate']/b['fenrir'] for b in blocks.values()]
rng=random.Random(121)
dist=sorted(s.median(rng.choices(r,k=len(r))) for _ in range(10000))
print(json.dumps(dict(blocks=len(r),median_ratio=s.median(r),interval=[dist[249],dist[9749]]),indent=2))
