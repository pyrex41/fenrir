import hashlib
import json
from pathlib import Path
import subprocess
from time import monotonic

root = Path(__file__).resolve().parent
jit = Path("/nix/store/8s3klm8jma95yg6knxvrilbqj0zh5z25-shen-jit-0.7")
history = Path((root / "list").read_text().strip())
expected = (root / "canonical-verdict.jsonl").read_bytes()
manifest = json.loads(history.read_bytes())
print("history", history, "header keys", list(manifest), flush=True)
parts = sorted(history.parent.glob(history.name + ".events.*"))
def hashes():
    return {f.name: hashlib.sha256(f.read_bytes()).hexdigest() for f in [history, *parts]}
initial = hashes()
(root / "input-hashes.json").write_text(json.dumps(initial, indent=2))
for block in range(4):
    order = ["canonical", "cached"] if block % 2 == 0 else ["cached", "canonical"]
    for variant in order:
        source = root / variant
        trial = root / f"{block}-{variant}"
        trial.mkdir()
        command = [jit / "bin/shen-jit", "script", source / "harness/service-history.shen",
                   jit / "lib", source, trial, "check", root / "list"]
        with (trial / "log").open("wb") as log:
            start = monotonic()
            subprocess.run(command, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                           timeout=2400, check=True)
            elapsed = monotonic() - start
        if (trial / "verdicts.jsonl").read_bytes() != expected or hashes() != initial:
            raise RuntimeError(f"input or verdict mismatch in {trial}")
        record = dict(block=block, variant=variant, seconds=elapsed, jit=str(jit))
        with (root / "times.jsonl").open("a") as output:
            print(json.dumps(record), file=output)
        print(record, flush=True)
