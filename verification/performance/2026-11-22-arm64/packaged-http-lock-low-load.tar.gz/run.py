import json, subprocess, sys, time
from pathlib import Path
from runpy import run_path
base=Path(__file__).resolve().parent
rate,seconds=map(int,sys.argv[1:])
out=base/f'run-{rate}-{seconds}'
out.mkdir()
with (out/'server.log').open('x') as sink:
    server=subprocess.Popen([base/'server','0'],stderr=sink)
    try:
        for _ in range(100):
            first=(out/'server.log').read_text().splitlines()
            if first:break
            if server.poll() is not None:raise RuntimeError('server exited before binding')
            time.sleep(.05)
        address=first[0]
        run=subprocess.run([base/'load','-addr',address,'-rate',str(rate),'-seconds',str(seconds),'-connections','16'],
                           capture_output=True,timeout=seconds+45)
        (out/'row.json').write_bytes(run.stdout)
        (out/'driver.log').write_bytes(run.stderr)
        if run.returncode not in (0,1):raise RuntimeError('load driver failed')
        row=json.loads(run.stdout)
        assessment=run_path(str(base.parents[1]/'benchmarks/http/assess-rate.py'))['assess'](row)
        if row['Invalid'] or row['Errors']:raise ValueError('cannot attribute partial or invalid requests')
        for _ in range(100):
            logs=(out/'server.log').read_text().splitlines()[1:]
            stats=[json.loads(line) for line in logs]
            calls=sum(s['calls'] for s in stats)
            if calls==row['Valid']+16:break
            time.sleep(.05)
        else:raise ValueError('incomplete server request accounting')
        summary=dict(assessment=assessment,calls_including_warmup=calls,connections_closed=len(stats),
                     total_ns={k:sum(s[k] for s in stats) for k in ('held_ns','wait_ns')})
        (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
        print(out, calls, summary['total_ns'],flush=True)
    finally:
        server.terminate()
        server.wait(timeout=5)
