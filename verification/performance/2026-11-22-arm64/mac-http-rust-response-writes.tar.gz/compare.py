import hashlib,json,runpy,subprocess
from contextlib import ExitStack
from pathlib import Path
p=Path(__file__).resolve().parent
old=Path.cwd()/'build/current-http-capacity-XZNo2pDw'
w=runpy.run_path('benchmarks/http/check-service.py')
assess=runpy.run_path('benchmarks/http/assess-rate.py')['assess']
driver=old/'rate-80000/load'
bins={'original':old/'bin/rust','candidate':p/'bin/rust'}
rows=[]
with ExitStack() as stack:
 addresses={k:stack.enter_context(w['server']([b,'127.0.0.1:0'])) for k,b in bins.items()}
 for a in addresses.values():w['check'](a)
 for block in range(10):
  for name in (list(bins) if block%2==0 else list(reversed(bins))):
   a=addresses[name]
   result=subprocess.run([driver,'-addr',f'{a[0]}:{a[1]}','-rate','80000','-seconds','15','-connections','16'],capture_output=True,timeout=45)
   assert result.returncode in [0,1],result.stderr
   r=json.loads(result.stdout)
   verdict=assess(r)
   assert r['Invalid']==0
   rows.append(dict(block=block,worker=name,raw=r,assessment=verdict))
   report=dict(samples=rows,binary_sha256={k:hashlib.sha256(v.read_bytes()).hexdigest() for k,v in {**bins,'driver':driver}.items()})
   temp=p/'paired.pending';temp.write_text(json.dumps(report));temp.replace(p/'paired.json')
