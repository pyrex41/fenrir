.text
.p2align 2
Lfn0:
ldp x8, x9, [x0, #0]
Lfn0fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #80
stp x8, x9, [sp, #48]
Lfn0loop:
ldr x0, [sp, #48]
cmp x0, #0
b.gt Lfn0if10else
ldr x0, [sp, #56]
b Lfn0if10done
Lfn0if10else:
ldr x0, [sp, #48]
subs x0, x0, #1
b.vs Lfn0fail17_1
str x0, [sp, #64]
ldr x0, [sp, #56]
adds x0, x0, #2
b.vs Lfn0fail20_1
str x0, [sp, #72]
ldr x8, [sp, #64]
ldr x9, [sp, #72]
str x8, [sp, #48]
str x9, [sp, #56]
b Lfn0loop
Lfn0if10done:
mov x1, #0
b Lfn0end
Lfn0fail17_1:
adrp x0, Lfn0fail17_1location
add x0, x0, :lo12:Lfn0fail17_1location
bl fen_set_location
mov x1, #1
b Lfn0end
Lfn0fail20_1:
adrp x0, Lfn0fail20_1location
add x0, x0, :lo12:Lfn0fail20_1location
bl fen_set_location
mov x1, #1
b Lfn0end
Lfn0end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
.globl fenrir_entry
fenrir_entry:
Lfn1:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
str x0, [sp, #48]
movz x0, #7, lsl #0
str x0, [sp, #56]
ldr x8, [sp, #48]
ldr x9, [sp, #56]
mov sp, x29
ldp x29, x30, [sp], #16
b Lfn0fields
mov x1, #0
b Lfn1end
Lfn1end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
.text
.globl fen_print_result
fen_print_result:
b Lprint0
Lprint0:
b fen_write_i64
Lfn0fail17_1location:
.byte 116,114,97,112,32,97,116,58,32,114,101,99,117,114,115,105,118,101,46,102,101,110,58,50,58,52,48,10,0
Lfn0fail20_1location:
.byte 116,114,97,112,32,97,116,58,32,114,101,99,117,114,115,105,118,101,46,102,101,110,58,50,58,52,56,10,0
