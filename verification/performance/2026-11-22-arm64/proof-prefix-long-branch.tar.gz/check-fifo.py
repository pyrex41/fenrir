import sys
from pathlib import Path
import subprocess

here = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(here))
from fenrir_driver import compiled
from verify import tableau_steps

# Every generated goal has a fork and two nested binary obligations.
def atom(i):
    return "ab"[i % 2]

def op(i):
    return "&|>"[i % 3]

program = (here/"formula.fen").read_text() + (here/"search.fen").read_text()
program += """
(define mod {(Tuple I64 I64) --> I64} a b -> (- a (* b (/ a b))))
(define leaf {I64 --> Formula} n -> (Atom (if (= (mod n 2) 0) 1 2)))
(define main {I64 --> Answer} input ->
 (let n (/ input 256) fuel (mod input 256)
      x (Binary (mod n 3) (leaf n) (Neg (leaf (/ n 2))))
      y (Binary (mod (/ n 3) 3) (Neg (leaf (/ n 4))) (leaf (/ n 8)))
      goal (Binary (mod (/ n 9) 3) x y)
   (search (More false goal Empty) 0 0 fuel)))
"""
target = sys.argv[2]
with compiled(here.parents[1],target,program) as command:
    count=0
    for i in range(27):
        goal=(op(i//9),(op(i),atom(i),("!",atom(i//2))),(op(i//3),("!",atom(i//4)),atom(i//8)))
        steps=list(tableau_steps(goal))
        for fuel in [len(steps)-1,len(steps),len(steps)+7]:
            remaining=fuel-len(steps)
            if remaining<0:
                expected="Exhausted"
            elif isinstance(steps[-1],int):
                expected=f"(Model {steps[-1]} {remaining})"
            else:
                expected=f"(Proof #x{''.join(steps).encode().hex()} {remaining})"
            actual=subprocess.check_output([*command,str(i*256+fuel)],text=True,timeout=30).strip()
            assert actual==expected,(i,fuel,actual,expected)
            count+=1
print(target,count,"FIFO search observations matched")
