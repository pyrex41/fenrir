set -eu
out=$(cd "$1" && pwd)
pkg=$(cat "$out/identity")
cd "$out"
python3 "$pkg/libexec/fenrir/tests/native/wide-match-frame.py" wide.fen
for target in macos-arm64 solo5-arm64-spt; do
 mkdir "$target"
 "$pkg/bin/fenrir" build --target "$target" wide.fen -o "$target/image"
done
for n in $(seq 0 15); do macos-arm64/image "$n"; done > macos-arm64/outputs
docker run --rm --platform linux/arm64 --network none -v "$out/solo5-arm64-spt:/guest:ro" --entrypoint sh fenrir-track1-solo5:38e0c348be23-arm64 -ec '
for n in $(seq 0 15); do /opt/solo5-install/bin/solo5-spt /guest/image --solo5:quiet "$n"; done' > solo5-arm64-spt/outputs
for n in $(seq 0 15); do echo "$((28+2*n))"; done > expected
for target in macos-arm64 solo5-arm64-spt; do cmp expected "$target/outputs"; done
