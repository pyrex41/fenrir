"""Bound lane waiting in the observed p99 tail using marginal phase counts."""
import json
from pathlib import Path
import sys

for path in map(Path, sys.argv[1:]):
    r=json.loads(path.read_text())
    n=r["Valid"]
    # A bits.Len64 bin j >= 1 starts at 2**(j-1) nanoseconds.
    bins=r["ValidRequestPhases"]
    assert all(sum(counts)==n for counts in bins.values())
    rank=(99*n+99)//100
    tail=n-rank+1
    # Choose powers of two so the excluded populations can be counted exactly.
    excluded=sum(bins["Fetch"][24:])+sum(bins["Dispatch"][22:])
    minimum=r["P99ns"]-(2**23-1)-(2**21-1)
    print(json.dumps(dict(sample=path.name,rank=rank,tail_at_least=tail,
                          excluded_at_most=excluded,waiting_ns_at_least=max(0,minimum),
                          matching_at_least=max(0,tail-excluded))))
