.text
.p2align 2
Lfn0:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
str x0, [sp, #48]
ldr x0, [sp, #48]
cmp x0, #1
b.ne Lfn0if2else
mov x0, #0
mov x1, #0
bl fen_allocate
cbz x0, Lfn0fail6_3
adr x2, Llambda6
str x2, [x0]
ldr x2, [sp, #48]
str x2, [x0, #8]
b Lfn0if2done
Lfn0if2else:
mov x0, #0
mov x1, #0
bl fen_allocate
cbz x0, Lfn0fail11_3
adr x2, Llambda11
str x2, [x0]
Lfn0if2done:
mov x1, #0
b Lfn0end
Lfn0fail6_3:
adrp x0, Lfn0fail6_3location
add x0, x0, :lo12:Lfn0fail6_3location
bl fen_set_location
mov x1, #3
b Lfn0end
Lfn0fail11_3:
adrp x0, Lfn0fail11_3location
add x0, x0, :lo12:Lfn0fail11_3location
bl fen_set_location
mov x1, #3
b Lfn0end
Lfn0end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn1:
ldp x8, x9, [x0, #0]
Lfn1fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
stp x19, x20, [sp, #-16]!
sub sp, sp, #80
str xzr, [sp, #48]
mov x19, x8
mov x20, x9
add x0, sp, #16
add x1, sp, #48
mov x2, #1
bl fen_enter
Lfn1loop:
mov x0, x19
cmp x0, #0
b.ne Lfn1if26else
mov x0, x20
b Lfn1if26done
Lfn1if26else:
mov x0, x19
bl Lfn0
cbnz x1, Lfn1end
str x0, [sp, #48]
mov x0, x19
subs x0, x0, #1
b.vs Lfn1fail37_1
str x0, [sp, #56]
mov x0, x20
ldr x1, [sp, #48]
ldr x2, [x1]
blr x2
cbnz x1, Lfn1end
str x0, [sp, #64]
ldr x8, [sp, #56]
ldr x9, [sp, #64]
mov x19, x8
mov x20, x9
str xzr, [sp, #48]
b Lfn1loop
Lfn1if26done:
mov x1, #0
b Lfn1end
Lfn1fail37_1:
adrp x0, Lfn1fail37_1location
add x0, x0, :lo12:Lfn1fail37_1location
bl fen_set_location
mov x1, #1
b Lfn1end
Lfn1end:
bl fen_leave_result
ldp x19, x20, [x29, #-16]
mov sp, x29
ldp x29, x30, [sp], #16
ret
.globl fenrir_entry
fenrir_entry:
Lfn2:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
str x0, [sp, #48]
movz x0, #0, lsl #0
str x0, [sp, #56]
ldr x8, [sp, #48]
ldr x9, [sp, #56]
mov sp, x29
ldp x29, x30, [sp], #16
b Lfn1fields
mov x1, #0
b Lfn2end
Lfn2end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Llambda6:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
ldr x2, [x1, #8]
str x2, [sp, #56]
str x0, [sp, #48]
ldr x0, [sp, #48]
ldr x2, [sp, #56]
adds x0, x0, x2
b.vs Llambda6fail8_1
mov x1, #0
b Llambda6end
Llambda6fail8_1:
adrp x0, Llambda6fail8_1location
add x0, x0, :lo12:Llambda6fail8_1location
bl fen_set_location
mov x1, #1
b Llambda6end
Llambda6end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Llambda11:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
str x0, [sp, #48]
ldr x0, [sp, #48]
adds x0, x0, #2
b.vs Llambda11fail13_1
mov x1, #0
b Llambda11end
Llambda11fail13_1:
adrp x0, Llambda11fail13_1location
add x0, x0, :lo12:Llambda11fail13_1location
bl fen_set_location
mov x1, #1
b Llambda11end
Llambda11end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
.text
.globl fen_print_result
fen_print_result:
b Lprint0
Lprint0:
b fen_write_i64
Lfn0fail6_3location:
.byte 116,114,97,112,32,97,116,58,32,99,108,111,115,117,114,101,115,46,102,101,110,58,50,58,50,48,10,0
Lfn0fail11_3location:
.byte 116,114,97,112,32,97,116,58,32,99,108,111,115,117,114,101,115,46,102,101,110,58,51,58,50,48,10,0
Lfn1fail37_1location:
.byte 116,114,97,112,32,97,116,58,32,99,108,111,115,117,114,101,115,46,102,101,110,58,55,58,50,54,10,0
Llambda6fail8_1location:
.byte 116,114,97,112,32,97,116,58,32,99,108,111,115,117,114,101,115,46,102,101,110,58,50,58,51,56,10,0
Llambda11fail13_1location:
.byte 116,114,97,112,32,97,116,58,32,99,108,111,115,117,114,101,115,46,102,101,110,58,51,58,51,56,10,0
