from pathlib import Path
from statistics import median
import json,random
p=Path(__file__).resolve().parent
data={}
for line in (p/'raw').read_text().splitlines():
    block,n,ns,outcome=line.split(' ',3)
    key=int(block),int(n)
    assert key not in data
    proof=('s'*(int(n)+2)+'x').encode().hex()
    assert outcome==('Exhausted' if int(n)%2 else f'(Proof #x{proof} 0)')
    data[key]=int(ns)/1000
assert len(data)==144
rng=random.Random(168)
results={}
for n in (52,54,128):
    pairs=[(data[i,n],data[i,n+1]) for i in range(24)]
    diff=[a-b for a,b in pairs]
    boot=sorted(median(rng.choices(diff,k=24)) for _ in range(10000))
    results[n+3]=dict(full_ns=median(a for a,b in pairs),short_ns=median(b for a,b in pairs),
                      median_increment_ns=median(diff),interval_ns=[boot[249],boot[9749]])
print(json.dumps(results,indent=2))
