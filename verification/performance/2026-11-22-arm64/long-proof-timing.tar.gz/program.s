.text
.p2align 2
Lfn0:
ldp x8, x9, [x0, #0]
Lfn0fields:
ldr w2, [x8, #72]
cmp w2, #10
b.ne Lfn0frame
mov x0, x9
mov x1, #0
ret
Lfn0frame:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #80
stp xzr, xzr, [sp, #64]
stp x8, x9, [sp, #48]
add x0, sp, #16
add x1, sp, #48
mov x2, #4
bl fen_enter
Lfn0loop:
ldr x0, [sp, #48]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn0match10arm10
cmp w0, #11
b.eq Lfn0match10arm11
brk #0
Lfn0match10arm10:
ldr x0, [sp, #56]
b Lfn0match10end
Lfn0match10arm11:
ldr x0, [sp, #48]
ldr x0, [x0, #16]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn0match16arm10
cmp w0, #11
b.eq Lfn0match16arm11
brk #0
Lfn0match16arm10:
mov x0, #6
mov x1, #11
bl fen_allocate
cbz x0, Lfn0fail18_3
ldr x4, [sp, #48]
ldp x2, x3, [x4, #0]
stp x2, x3, [x0, #0]
ldr x2, [sp, #56]
str x2, [x0, #16]
b Lfn0match16end
Lfn0match16arm11:
ldr x8, [sp, #48]
ldr x8, [x8, #16]
ldr x8, [x8, #16]
ldr x9, [sp, #56]
bl Lfn0fields
cbnz x1, Lfn0end
str x0, [sp, #64]
mov x0, #6
mov x1, #11
bl fen_allocate
cbz x0, Lfn0fail28_3
ldr x4, [sp, #48]
ldr x4, [x4, #16]
ldp x2, x3, [x4, #0]
stp x2, x3, [x0, #0]
ldr x2, [sp, #64]
str x2, [x0, #16]
str x0, [sp, #72]
mov x0, #6
mov x1, #11
bl fen_allocate
cbz x0, Lfn0fail25_3
ldr x4, [sp, #48]
ldp x2, x3, [x4, #0]
stp x2, x3, [x0, #0]
ldr x2, [sp, #72]
str x2, [x0, #16]
b Lfn0match16end
Lfn0match16end:
b Lfn0match10end
Lfn0match10end:
mov x1, #0
b Lfn0end
Lfn0fail18_3:
adrp x0, Lfn0fail18_3location
add x0, x0, :lo12:Lfn0fail18_3location
bl fen_set_location
mov x1, #3
b Lfn0end
Lfn0fail28_3:
adrp x0, Lfn0fail28_3location
add x0, x0, :lo12:Lfn0fail28_3location
bl fen_set_location
mov x1, #3
b Lfn0end
Lfn0fail25_3:
adrp x0, Lfn0fail25_3location
add x0, x0, :lo12:Lfn0fail25_3location
bl fen_set_location
mov x1, #3
b Lfn0end
Lfn0end:
bl fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn1:
ldp x8, x9, [x0, #0]
ldr x10, [x0, #16]
Lfn1fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #80
str xzr, [sp, #64]
str x8, [sp, #48]
str x9, [sp, #72]
str x10, [sp, #56]
add x0, sp, #16
add x1, sp, #48
mov x2, #3
bl fen_enter
Lfn1loop:
mov x0, #6
mov x1, #11
bl fen_allocate
cbz x0, Lfn1fail52_3
ldr x2, [sp, #72]
ldr x3, [sp, #56]
stp x2, x3, [x0, #0]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
str x2, [x0, #16]
str x0, [sp, #64]
bl fen_leave_result
ldr x8, [sp, #48]
ldr x9, [sp, #64]
mov sp, x29
ldp x29, x30, [sp], #16
b Lfn0fields
mov x1, #0
b Lfn1end
Lfn1fail52_3:
adrp x0, Lfn1fail52_3location
add x0, x0, :lo12:Lfn1fail52_3location
bl fen_set_location
mov x1, #3
b Lfn1end
Lfn1end:
bl fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn2:
ldp x8, x9, [x0, #0]
Lfn2fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
stp x8, x9, [sp, #48]
Lfn2loop:
ldr x0, [sp, #48]
ldr x2, [sp, #56]
cmp x0, x2
b.ge Lfn2if66else
movz x0, #0, lsl #0
b Lfn2if66done
Lfn2if66else:
ldr x0, [sp, #48]
ldr x2, [sp, #56]
cbz x2, Lfn2fail73_2
cmn x2, #1
b.ne 1f
negs x3, x0
b.vs Lfn2fail73_1
1:
sdiv x0, x0, x2
cmp x0, #0
neg x2, x0
and x2, x2, #1
and x0, x0, #1
csneg x0, x0, x2, ge
cmp x0, #1
cset x0, eq
Lfn2if66done:
mov x1, #0
b Lfn2end
Lfn2fail73_2:
adrp x0, Lfn2fail73_2location
add x0, x0, :lo12:Lfn2fail73_2location
bl fen_set_location
mov x1, #2
b Lfn2end
Lfn2fail73_1:
adrp x0, Lfn2fail73_1location
add x0, x0, :lo12:Lfn2fail73_1location
bl fen_set_location
mov x1, #1
b Lfn2end
Lfn2end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn3:
ldp x8, x9, [x0, #0]
Lfn3fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
stp x8, x9, [sp, #48]
Lfn3loop:
ldr x0, [sp, #48]
ldr x2, [sp, #56]
cmp x0, x2
b.ge Lfn3if95else
ldr x0, [sp, #48]
ldr x2, [sp, #56]
adds x0, x0, x2
b.vs Lfn3fail99_1
b Lfn3if95done
Lfn3if95else:
ldr x8, [sp, #48]
ldr x9, [sp, #56]
bl Lfn2fields
cbnz x1, Lfn3end
cbz x0, Lfn3if102else
ldr x0, [sp, #48]
b Lfn3if102done
Lfn3if102else:
ldr x0, [sp, #48]
ldr x2, [sp, #56]
adds x0, x0, x2
b.vs Lfn3fail108_1
Lfn3if102done:
Lfn3if95done:
mov x1, #0
b Lfn3end
Lfn3fail99_1:
adrp x0, Lfn3fail99_1location
add x0, x0, :lo12:Lfn3fail99_1location
bl fen_set_location
mov x1, #1
b Lfn3end
Lfn3fail108_1:
adrp x0, Lfn3fail108_1location
add x0, x0, :lo12:Lfn3fail108_1location
bl fen_set_location
mov x1, #1
b Lfn3end
Lfn3end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn4:
ldp x8, x9, [x0, #0]
Lfn4fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
stp x19, xzr, [sp, #-16]!
sub sp, sp, #128
stp xzr, xzr, [sp, #56]
stp xzr, xzr, [sp, #72]
stp xzr, xzr, [sp, #88]
str xzr, [sp, #104]
mov x19, x8
str x9, [sp, #48]
add x0, sp, #16
add x1, sp, #48
mov x2, #8
bl fen_enter
Lfn4loop:
mov x0, x19
cmp x0, #8
b.lt Lfn4if121else
mov x0, x19
subs x0, x0, #8
b.vs Lfn4fail127_1
str x0, [sp, #112]
adrp x0, Lconstant1
add x0, x0, :lo12:Lconstant1
ldr x2, [sp, #48]
mov x1, x2
bl fen_bytes_concat
cbz x0, Lfn4fail130_3
str x0, [sp, #56]
ldr x8, [sp, #112]
ldr x9, [sp, #56]
mov x19, x8
str x9, [sp, #48]
stp xzr, xzr, [sp, #56]
stp xzr, xzr, [sp, #72]
stp xzr, xzr, [sp, #88]
str xzr, [sp, #104]
b Lfn4loop
b Lfn4if121done
Lfn4if121else:
mov x0, x19
cmp x0, #0
b.ne Lfn4if133else
ldr x0, [sp, #48]
b Lfn4if133done
Lfn4if133else:
mov x0, x19
cmp x0, #4
b.ge Lfn4if139else
mov x0, x19
cmp x0, #2
b.ge Lfn4if143else
adrp x0, Lconstant2
add x0, x0, :lo12:Lconstant2
b Lfn4if143done
Lfn4if143else:
mov x0, x19
cmp x0, #2
b.ne Lfn4if148else
adrp x0, Lconstant3
add x0, x0, :lo12:Lconstant3
b Lfn4if148done
Lfn4if148else:
adrp x0, Lconstant4
add x0, x0, :lo12:Lconstant4
Lfn4if148done:
str x0, [sp, #64]
Lfn4if143done:
str x0, [sp, #72]
b Lfn4if139done
Lfn4if139else:
mov x0, x19
cmp x0, #6
b.ge Lfn4if154else
mov x0, x19
cmp x0, #4
b.ne Lfn4if158else
adrp x0, Lconstant5
add x0, x0, :lo12:Lconstant5
b Lfn4if158done
Lfn4if158else:
adrp x0, Lconstant6
add x0, x0, :lo12:Lconstant6
Lfn4if158done:
str x0, [sp, #80]
b Lfn4if154done
Lfn4if154else:
mov x0, x19
cmp x0, #6
b.ne Lfn4if164else
adrp x0, Lconstant7
add x0, x0, :lo12:Lconstant7
b Lfn4if164done
Lfn4if164else:
adrp x0, Lconstant8
add x0, x0, :lo12:Lconstant8
Lfn4if164done:
str x0, [sp, #88]
Lfn4if154done:
str x0, [sp, #96]
Lfn4if139done:
str x0, [sp, #104]
ldr x2, [sp, #48]
mov x1, x2
bl fen_bytes_concat
cbz x0, Lfn4fail138_3
Lfn4if133done:
Lfn4if121done:
mov x1, #0
b Lfn4end
Lfn4fail127_1:
adrp x0, Lfn4fail127_1location
add x0, x0, :lo12:Lfn4fail127_1location
bl fen_set_location
mov x1, #1
b Lfn4end
Lfn4fail130_3:
adrp x0, Lfn4fail130_3location
add x0, x0, :lo12:Lfn4fail130_3location
bl fen_set_location
mov x1, #3
b Lfn4end
Lfn4fail138_3:
adrp x0, Lfn4fail138_3location
add x0, x0, :lo12:Lfn4fail138_3location
bl fen_set_location
mov x1, #3
b Lfn4end
Lfn4end:
bl fen_leave_result
ldp x19, xzr, [x29, #-16]
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn5:
ldp x8, x9, [x0, #0]
ldp x10, x11, [x0, #16]
ldp x12, x13, [x0, #32]
Lfn5fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
stp x19, x20, [sp, #-16]!
stp x21, x22, [sp, #-16]!
stp x23, x24, [sp, #-16]!
sub sp, sp, #240
stp xzr, xzr, [sp, #64]
stp xzr, xzr, [sp, #80]
stp xzr, xzr, [sp, #96]
stp xzr, xzr, [sp, #112]
stp xzr, xzr, [sp, #128]
stp xzr, xzr, [sp, #144]
stp x8, x9, [sp, #48]
mov x21, x10
mov x22, x11
mov x23, x12
mov x19, x13
add x0, sp, #16
add x1, sp, #48
mov x2, #14
bl fen_enter
Lfn5loop:
mov x0, x23
cmp x0, #0
b.ne Lfn5if197else
adrp x0, Lconstant9
add x0, x0, :lo12:Lconstant9
b Lfn5if197done
Lfn5if197else:
mov x0, x23
subs x0, x0, #1
b.vs Lfn5fail204_1
mov x20, x0
ldr x0, [sp, #48]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn5match207arm10
cmp w0, #11
b.eq Lfn5match207arm11
brk #0
Lfn5match207arm10:
ldr x0, [sp, #56]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn5match209arm10
cmp w0, #11
b.eq Lfn5match209arm11
brk #0
Lfn5match209arm10:
mov x0, #0
mov x1, #13
bl fen_allocate
cbz x0, Lfn5fail211_3
mov x2, x21
mov x3, x20
stp x2, x3, [x0, #0]
b Lfn5match209end
Lfn5match209arm11:
ldr x8, [sp, #56]
adrp x9, Lconstant0
add x9, x9, :lo12:Lconstant0
str x8, [sp, #48]
str x9, [sp, #56]
stp xzr, xzr, [sp, #64]
stp xzr, xzr, [sp, #80]
stp xzr, xzr, [sp, #96]
stp xzr, xzr, [sp, #112]
stp xzr, xzr, [sp, #128]
stp xzr, xzr, [sp, #144]
b Lfn5loop
b Lfn5match209end
Lfn5match209end:
b Lfn5match207end
Lfn5match207arm11:
ldr x0, [sp, #48]
ldr x0, [x0, #8]
ldr w0, [x0, #72]
cmp w0, #7
b.eq Lfn5match228arm7
cmp w0, #8
b.eq Lfn5match228arm8
cmp w0, #9
b.eq Lfn5match228arm9
brk #0
Lfn5match228arm7:
ldr x0, [sp, #48]
ldr x0, [x0, #0]
cbz x0, Lfn5if234else
mov x0, x22
b Lfn5if234done
Lfn5if234else:
mov x0, x21
Lfn5if234done:
str x0, [sp, #160]
ldr x8, [sp, #160]
ldr x9, [sp, #48]
ldr x9, [x9, #8]
ldr x9, [x9, #0]
bl Lfn2fields
cbnz x1, Lfn5end
cbz x0, Lfn5if231else
mov x8, x19
adrp x9, Lconstant10
add x9, x9, :lo12:Lconstant10
bl Lfn4fields
cbnz x1, Lfn5end
str x0, [sp, #64]
mov x0, #1
mov x1, #12
bl fen_allocate
cbz x0, Lfn5fail239_3
ldr x2, [sp, #64]
mov x3, x20
stp x2, x3, [x0, #0]
b Lfn5if231done
Lfn5if231else:
ldr x0, [sp, #48]
ldr x0, [x0, #0]
cbz x0, Lfn5if249else
mov x8, x21
ldr x9, [sp, #48]
ldr x9, [x9, #8]
ldr x9, [x9, #0]
bl Lfn3fields
cbnz x1, Lfn5end
b Lfn5if249done
Lfn5if249else:
mov x0, x21
Lfn5if249done:
str x0, [sp, #168]
ldr x0, [sp, #48]
ldr x0, [x0, #0]
cbz x0, Lfn5if256else
mov x0, x22
b Lfn5if256done
Lfn5if256else:
mov x8, x22
ldr x9, [sp, #48]
ldr x9, [x9, #8]
ldr x9, [x9, #0]
bl Lfn3fields
cbnz x1, Lfn5end
Lfn5if256done:
str x0, [sp, #176]
mov x0, x19
adds x0, x0, #1
b.vs Lfn5fail264_1
str x0, [sp, #184]
ldr x8, [sp, #48]
ldr x8, [x8, #16]
ldr x9, [sp, #168]
ldr x10, [sp, #176]
mov x11, x20
ldr x12, [sp, #184]
str x8, [sp, #48]
mov x21, x9
mov x22, x10
mov x23, x11
mov x19, x12
stp xzr, xzr, [sp, #64]
stp xzr, xzr, [sp, #80]
stp xzr, xzr, [sp, #96]
stp xzr, xzr, [sp, #112]
stp xzr, xzr, [sp, #128]
stp xzr, xzr, [sp, #144]
b Lfn5loop
Lfn5if231done:
b Lfn5match228end
Lfn5match228arm8:
ldr x0, [sp, #48]
ldr x0, [x0, #0]
eor x0, x0, #1
str x0, [sp, #192]
ldr x8, [sp, #56]
ldr x9, [sp, #192]
ldr x10, [sp, #48]
ldr x10, [x10, #8]
ldr x10, [x10, #0]
bl Lfn1fields
cbnz x1, Lfn5end
str x0, [sp, #72]
mov x0, x19
adds x0, x0, #1
b.vs Lfn5fail280_1
str x0, [sp, #200]
ldr x8, [sp, #48]
ldr x8, [x8, #16]
ldr x9, [sp, #72]
mov x10, x20
ldr x11, [sp, #200]
str x8, [sp, #48]
str x9, [sp, #56]
mov x23, x10
mov x19, x11
stp xzr, xzr, [sp, #64]
stp xzr, xzr, [sp, #80]
stp xzr, xzr, [sp, #96]
stp xzr, xzr, [sp, #112]
stp xzr, xzr, [sp, #128]
stp xzr, xzr, [sp, #144]
b Lfn5loop
b Lfn5match228end
Lfn5match228arm9:
ldr x0, [sp, #48]
ldr x0, [x0, #8]
ldr x0, [x0, #0]
cmp x0, #2
b.ne Lfn5if288else
ldr x0, [sp, #48]
ldr x0, [x0, #0]
eor x0, x0, #1
b Lfn5if288done
Lfn5if288else:
ldr x0, [sp, #48]
ldr x0, [x0, #0]
Lfn5if288done:
mov x24, x0
ldr x0, [sp, #48]
ldr x0, [x0, #8]
ldr x0, [x0, #0]
cmp x0, #0
cset x0, eq
ldr x2, [sp, #48]
ldr x2, [x2, #0]
cmp x0, x2
b.ne Lfn5if295else
mov x0, #6
mov x1, #11
bl fen_allocate
cbz x0, Lfn5fail310_3
ldr x2, [sp, #48]
ldr x2, [x2, #0]
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #16]
stp x2, x3, [x0, #0]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
str x2, [x0, #16]
str x0, [sp, #80]
mov x0, #6
mov x1, #11
bl fen_allocate
cbz x0, Lfn5fail307_3
mov x2, x24
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #8]
stp x2, x3, [x0, #0]
ldr x2, [sp, #80]
str x2, [x0, #16]
str x0, [sp, #88]
ldr x8, [sp, #56]
ldr x9, [sp, #88]
bl Lfn0fields
cbnz x1, Lfn5end
str x0, [sp, #96]
mov x0, x19
adds x0, x0, #1
b.vs Lfn5fail317_1
str x0, [sp, #208]
ldr x8, [sp, #48]
ldr x8, [x8, #16]
ldr x9, [sp, #96]
mov x10, x20
ldr x11, [sp, #208]
str x8, [sp, #48]
str x9, [sp, #56]
mov x23, x10
mov x19, x11
stp xzr, xzr, [sp, #64]
stp xzr, xzr, [sp, #80]
stp xzr, xzr, [sp, #96]
stp xzr, xzr, [sp, #112]
stp xzr, xzr, [sp, #128]
stp xzr, xzr, [sp, #144]
b Lfn5loop
b Lfn5if295done
Lfn5if295else:
ldr x8, [sp, #56]
mov x9, x24
ldr x10, [sp, #48]
ldr x10, [x10, #8]
ldr x10, [x10, #8]
bl Lfn1fields
cbnz x1, Lfn5end
str x0, [sp, #104]
movz x0, #0, lsl #0
str x0, [sp, #216]
ldr x8, [sp, #48]
ldr x8, [x8, #16]
ldr x9, [sp, #104]
mov x10, x21
mov x11, x22
mov x12, x20
ldr x13, [sp, #216]
bl Lfn5fields
cbnz x1, Lfn5end
str x0, [sp, #112]
ldr w0, [x0, #72]
cmp w0, #12
b.eq Lfn5match334arm12
cmp w0, #13
b.eq Lfn5match334arm13
cmp w0, #14
b.eq Lfn5match334arm14
brk #0
Lfn5match334arm12:
ldr x8, [sp, #56]
ldr x9, [sp, #48]
ldr x9, [x9, #0]
ldr x10, [sp, #48]
ldr x10, [x10, #8]
ldr x10, [x10, #16]
bl Lfn1fields
cbnz x1, Lfn5end
str x0, [sp, #120]
movz x0, #0, lsl #0
str x0, [sp, #224]
ldr x8, [sp, #48]
ldr x8, [x8, #16]
ldr x9, [sp, #120]
mov x10, x21
mov x11, x22
ldr x12, [sp, #112]
ldr x12, [x12, #8]
ldr x13, [sp, #224]
bl Lfn5fields
cbnz x1, Lfn5end
str x0, [sp, #128]
ldr w0, [x0, #72]
cmp w0, #12
b.eq Lfn5match352arm12
cmp w0, #13
b.eq Lfn5match352arm13
cmp w0, #14
b.eq Lfn5match352arm14
brk #0
Lfn5match352arm12:
ldr x0, [sp, #112]
ldr x0, [x0, #0]
ldr x2, [sp, #128]
ldr x2, [x2, #0]
mov x1, x2
bl fen_bytes_concat
cbz x0, Lfn5fail362_3
str x0, [sp, #136]
adrp x0, Lconstant11
add x0, x0, :lo12:Lconstant11
ldr x2, [sp, #136]
mov x1, x2
bl fen_bytes_concat
cbz x0, Lfn5fail360_3
str x0, [sp, #144]
mov x8, x19
ldr x9, [sp, #144]
bl Lfn4fields
cbnz x1, Lfn5end
str x0, [sp, #152]
mov x0, #1
mov x1, #12
bl fen_allocate
cbz x0, Lfn5fail356_3
ldr x2, [sp, #152]
ldr x3, [sp, #128]
ldr x3, [x3, #8]
stp x2, x3, [x0, #0]
b Lfn5match352end
Lfn5match352arm13:
ldr x0, [sp, #128]
b Lfn5match352end
Lfn5match352arm14:
ldr x0, [sp, #128]
b Lfn5match352end
Lfn5match352end:
b Lfn5match334end
Lfn5match334arm13:
ldr x0, [sp, #112]
b Lfn5match334end
Lfn5match334arm14:
ldr x0, [sp, #112]
b Lfn5match334end
Lfn5match334end:
Lfn5if295done:
b Lfn5match228end
Lfn5match228end:
b Lfn5match207end
Lfn5match207end:
Lfn5if197done:
mov x1, #0
b Lfn5end
Lfn5fail204_1:
adrp x0, Lfn5fail204_1location
add x0, x0, :lo12:Lfn5fail204_1location
bl fen_set_location
mov x1, #1
b Lfn5end
Lfn5fail211_3:
adrp x0, Lfn5fail211_3location
add x0, x0, :lo12:Lfn5fail211_3location
bl fen_set_location
mov x1, #3
b Lfn5end
Lfn5fail239_3:
adrp x0, Lfn5fail239_3location
add x0, x0, :lo12:Lfn5fail239_3location
bl fen_set_location
mov x1, #3
b Lfn5end
Lfn5fail264_1:
adrp x0, Lfn5fail264_1location
add x0, x0, :lo12:Lfn5fail264_1location
bl fen_set_location
mov x1, #1
b Lfn5end
Lfn5fail280_1:
adrp x0, Lfn5fail280_1location
add x0, x0, :lo12:Lfn5fail280_1location
bl fen_set_location
mov x1, #1
b Lfn5end
Lfn5fail310_3:
adrp x0, Lfn5fail310_3location
add x0, x0, :lo12:Lfn5fail310_3location
bl fen_set_location
mov x1, #3
b Lfn5end
Lfn5fail307_3:
adrp x0, Lfn5fail307_3location
add x0, x0, :lo12:Lfn5fail307_3location
bl fen_set_location
mov x1, #3
b Lfn5end
Lfn5fail317_1:
adrp x0, Lfn5fail317_1location
add x0, x0, :lo12:Lfn5fail317_1location
bl fen_set_location
mov x1, #1
b Lfn5end
Lfn5fail362_3:
adrp x0, Lfn5fail362_3location
add x0, x0, :lo12:Lfn5fail362_3location
bl fen_set_location
mov x1, #3
b Lfn5end
Lfn5fail360_3:
adrp x0, Lfn5fail360_3location
add x0, x0, :lo12:Lfn5fail360_3location
bl fen_set_location
mov x1, #3
b Lfn5end
Lfn5fail356_3:
adrp x0, Lfn5fail356_3location
add x0, x0, :lo12:Lfn5fail356_3location
bl fen_set_location
mov x1, #3
b Lfn5end
Lfn5end:
bl fen_leave_result
ldp x19, x20, [x29, #-16]
ldp x21, x22, [x29, #-32]
ldp x23, x24, [x29, #-48]
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn6:
ldp x8, x9, [x0, #0]
ldp x10, x11, [x0, #16]
Lfn6fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #96
stp x8, x9, [sp, #48]
stp x10, x11, [sp, #64]
Lfn6loop:
movz x0, #0, lsl #0
str x0, [sp, #80]
ldr x8, [sp, #48]
adrp x9, Lconstant0
add x9, x9, :lo12:Lconstant0
ldr x10, [sp, #56]
ldr x11, [sp, #64]
ldr x12, [sp, #72]
ldr x13, [sp, #80]
mov sp, x29
ldp x29, x30, [sp], #16
b Lfn5fields
mov x1, #0
b Lfn6end
Lfn6end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn7:
ldp x8, x9, [x0, #0]
Lfn7fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
stp x19, xzr, [sp, #-16]!
sub sp, sp, #80
stp xzr, xzr, [sp, #56]
mov x19, x8
str x9, [sp, #48]
add x0, sp, #16
add x1, sp, #48
mov x2, #3
bl fen_enter
Lfn7loop:
mov x0, x19
cmp x0, #0
b.ne Lfn7if410else
ldr x0, [sp, #48]
b Lfn7if410done
Lfn7if410else:
mov x0, x19
subs x0, x0, #1
b.vs Lfn7fail417_1
str x0, [sp, #72]
mov x0, #1
mov x1, #8
bl fen_allocate
cbz x0, Lfn7fail421_3
ldr x2, [sp, #48]
str x2, [x0, #0]
str x0, [sp, #56]
mov x0, #1
mov x1, #8
bl fen_allocate
cbz x0, Lfn7fail420_3
ldr x2, [sp, #56]
str x2, [x0, #0]
str x0, [sp, #64]
ldr x8, [sp, #72]
ldr x9, [sp, #64]
mov x19, x8
str x9, [sp, #48]
stp xzr, xzr, [sp, #56]
b Lfn7loop
Lfn7if410done:
mov x1, #0
b Lfn7end
Lfn7fail417_1:
adrp x0, Lfn7fail417_1location
add x0, x0, :lo12:Lfn7fail417_1location
bl fen_set_location
mov x1, #1
b Lfn7end
Lfn7fail421_3:
adrp x0, Lfn7fail421_3location
add x0, x0, :lo12:Lfn7fail421_3location
bl fen_set_location
mov x1, #3
b Lfn7end
Lfn7fail420_3:
adrp x0, Lfn7fail420_3location
add x0, x0, :lo12:Lfn7fail420_3location
bl fen_set_location
mov x1, #3
b Lfn7end
Lfn7end:
bl fen_leave_result
ldp x19, xzr, [x29, #-16]
mov sp, x29
ldp x29, x30, [sp], #16
ret
.globl fenrir_entry
fenrir_entry:
Lfn8:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #144
stp xzr, xzr, [sp, #48]
str x0, [sp, #64]
add x0, sp, #16
add x1, sp, #48
mov x2, #2
bl fen_enter
ldr x0, [sp, #64]
asr x2, x0, #63
add x0, x0, x2, lsr #63
asr x0, x0, #1
str x0, [sp, #72]
movz x0, #3, lsl #0
str x0, [sp, #80]
ldr x0, [sp, #72]
lsl x2, x0, #1
cmp x0, x2, asr #1
b.ne Lfn8fail434_1
mov x0, x2
str x0, [sp, #88]
ldr x0, [sp, #80]
ldr x2, [sp, #88]
adds x0, x0, x2
b.vs Lfn8fail432_1
str x0, [sp, #96]
ldr x8, [sp, #72]
adrp x9, Lconstant13
add x9, x9, :lo12:Lconstant13
bl Lfn7fields
cbnz x1, Lfn8end
str x0, [sp, #48]
movz x0, #0, lsl #0
str x0, [sp, #104]
mov x0, #6
mov x1, #11
bl fen_allocate
cbz x0, Lfn8fail450_3
ldr x2, [sp, #104]
ldr x3, [sp, #48]
stp x2, x3, [x0, #0]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
str x2, [x0, #16]
str x0, [sp, #56]
movz x0, #0, lsl #0
str x0, [sp, #112]
movz x0, #0, lsl #0
str x0, [sp, #120]
ldr x0, [sp, #72]
lsl x2, x0, #1
cmp x0, x2, asr #1
b.ne Lfn8fail459_1
mov x0, x2
str x0, [sp, #128]
ldr x0, [sp, #64]
ldr x2, [sp, #128]
cmp x0, x2
b.ne Lfn8if456else
ldr x0, [sp, #96]
b Lfn8if456done
Lfn8if456else:
ldr x0, [sp, #96]
subs x0, x0, #1
b.vs Lfn8fail463_1
Lfn8if456done:
str x0, [sp, #136]
bl fen_leave_result
ldr x8, [sp, #56]
ldr x9, [sp, #112]
ldr x10, [sp, #120]
ldr x11, [sp, #136]
mov sp, x29
ldp x29, x30, [sp], #16
b Lfn6fields
mov x1, #0
b Lfn8end
Lfn8fail434_1:
adrp x0, Lfn8fail434_1location
add x0, x0, :lo12:Lfn8fail434_1location
bl fen_set_location
mov x1, #1
b Lfn8end
Lfn8fail432_1:
adrp x0, Lfn8fail432_1location
add x0, x0, :lo12:Lfn8fail432_1location
bl fen_set_location
mov x1, #1
b Lfn8end
Lfn8fail450_3:
adrp x0, Lfn8fail450_3location
add x0, x0, :lo12:Lfn8fail450_3location
bl fen_set_location
mov x1, #3
b Lfn8end
Lfn8fail459_1:
adrp x0, Lfn8fail459_1location
add x0, x0, :lo12:Lfn8fail459_1location
bl fen_set_location
mov x1, #1
b Lfn8end
Lfn8fail463_1:
adrp x0, Lfn8fail463_1location
add x0, x0, :lo12:Lfn8fail463_1location
bl fen_set_location
mov x1, #1
b Lfn8end
Lfn8end:
bl fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
.text
.globl fen_print_result
fen_print_result:
b Lprint0
Lprint0:
stp x19, x30, [sp, #-16]!
mov x19, x0
bl fen_tag
mov x1, #12
cmp x0, x1
b.eq Lprint0v12
mov x1, #13
cmp x0, x1
b.eq Lprint0v13
mov x1, #14
cmp x0, x1
b.eq Lprint0v14
brk #0
Lprint0v12:
adrp x0, Lstr0
add x0, x0, :lo12:Lstr0
mov x1, #6
bl fen_write
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #0]
bl Lprint1
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #8]
bl Lprint2
adrp x0, Lstr2
add x0, x0, :lo12:Lstr2
mov x1, #1
bl fen_write
b Lprint0done
Lprint0v13:
adrp x0, Lstr3
add x0, x0, :lo12:Lstr3
mov x1, #6
bl fen_write
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #0]
bl Lprint2
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #8]
bl Lprint2
adrp x0, Lstr2
add x0, x0, :lo12:Lstr2
mov x1, #1
bl fen_write
b Lprint0done
Lprint0v14:
adrp x0, Lstr4
add x0, x0, :lo12:Lstr4
mov x1, #9
bl fen_write
b Lprint0done
Lprint0done:
ldp x19, x30, [sp], #16
ret
Lprint1:
b fen_print_bytes
Lprint2:
b fen_write_i64
Lstr0:
.byte 40,80,114,111,111,102
Lstr1:
.byte 32
Lstr2:
.byte 41
Lstr3:
.byte 40,77,111,100,101,108
Lstr4:
.byte 69,120,104,97,117,115,116,101,100
Lfn0fail18_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,98,101,46,102,101,110,58,56,58,49,55,10,0
Lfn0fail28_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,98,101,46,102,101,110,58,57,58,52,48,10,0
Lfn0fail25_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,98,101,46,102,101,110,58,57,58,50,55,10,0
.p2align 3
Lconstant0:
.zero 72
.long 10
.byte 0,2,0,0
Lfn1fail52_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,98,101,46,102,101,110,58,49,50,58,51,49,10,0
Lfn2fail73_2location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,98,101,46,102,101,110,58,49,54,58,51,49,10,0
Lfn2fail73_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,98,101,46,102,101,110,58,49,54,58,51,49,10,0
Lfn3fail99_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,98,101,46,102,101,110,58,50,48,58,51,50,10,0
Lfn3fail108_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,98,101,46,102,101,110,58,50,49,58,52,53,10,0
.p2align 3
Lconstant1:
.quad 8
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,115,115,115,115
.p2align 3
Lconstant2:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115
.p2align 3
Lconstant3:
.quad 2
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115
.p2align 3
Lconstant4:
.quad 3
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115
.p2align 3
Lconstant5:
.quad 4
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115
.p2align 3
Lconstant6:
.quad 5
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,115
.p2align 3
Lconstant7:
.quad 6
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,115,115
.p2align 3
Lconstant8:
.quad 7
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,115,115,115
Lfn4fail127_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,98,101,46,102,101,110,58,50,54,58,50,48,10,0
Lfn4fail130_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,98,101,46,102,101,110,58,50,54,58,51,50,10,0
Lfn4fail138_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,98,101,46,102,101,110,58,50,56,58,55,10,0
.p2align 3
Lconstant9:
.zero 72
.long 14
.byte 0,2,0,0
.p2align 3
Lconstant10:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 120
.p2align 3
Lconstant11:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 98
Lfn5fail204_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,98,101,46,102,101,110,58,51,55,58,49,53,10,0
Lfn5fail211_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,98,101,46,102,101,110,58,51,57,58,52,49,10,0
Lfn5fail239_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,98,101,46,102,101,110,58,52,52,58,49,57,10,0
Lfn5fail264_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,98,101,46,102,101,110,58,52,54,58,56,52,10,0
Lfn5fail280_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,98,101,46,102,101,110,58,52,55,58,57,48,10,0
Lfn5fail310_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,98,101,46,102,101,110,58,53,49,58,55,52,10,0
Lfn5fail307_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,98,101,46,102,101,110,58,53,49,58,53,57,10,0
Lfn5fail317_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,98,101,46,102,101,110,58,53,50,58,53,51,10,0
Lfn5fail362_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,98,101,46,102,101,110,58,53,56,58,57,56,10,0
Lfn5fail360_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,98,101,46,102,101,110,58,53,56,58,56,48,10,0
Lfn5fail356_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,98,101,46,102,101,110,58,53,56,58,53,50,10,0
Lfn7fail417_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,98,101,46,102,101,110,58,54,56,58,52,48,10,0
Lfn7fail421_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,98,101,46,102,101,110,58,54,56,58,53,51,10,0
Lfn7fail420_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,98,101,46,102,101,110,58,54,56,58,52,56,10,0
.p2align 3
Lconstant12:
.quad 1
.zero 64
.long 7
.byte 0,2,0,0
.section .rodata
.p2align 3
Lconstant13:
.quad 2
.quad Lconstant12
.quad Lconstant12
.zero 48
.long 9
.byte 6,2,0,0
.text
Lfn8fail434_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,98,101,46,102,101,110,58,55,49,58,50,56,10,0
Lfn8fail432_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,98,101,46,102,101,110,58,55,49,58,50,51,10,0
Lfn8fail450_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,98,101,46,102,101,110,58,55,51,58,50,50,10,0
Lfn8fail459_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,98,101,46,102,101,110,58,55,51,58,54,51,10,0
Lfn8fail463_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,98,101,46,102,101,110,58,55,51,58,56,50,10,0
