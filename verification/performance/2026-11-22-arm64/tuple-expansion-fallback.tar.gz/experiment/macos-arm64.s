.text
.p2align 2
Lfn0:
ldp x8, x9, [x0, #0]
Lfn0fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
stp x8, x9, [sp, #48]
Lfn0loop:
ldr x0, [sp, #48]
ldr x2, [sp, #56]
adds x0, x0, x2
b.vs Lfn0fail10_1
mov x1, #0
b Lfn0end
Lfn0fail10_1:
adrp x0, Lfn0fail10_1location@PAGE
add x0, x0, Lfn0fail10_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn0end
Lfn0end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn1:
ldp x8, x9, [x0, #0]
Lfn1fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #80
stp x8, x9, [sp, #48]
Lfn1loop:
ldr x8, [sp, #48]
ldr x9, [sp, #56]
bl Lfn0fields
cbnz x1, Lfn1end
str x0, [sp, #64]
ldr x8, [sp, #56]
ldr x9, [sp, #48]
bl Lfn0fields
cbnz x1, Lfn1end
str x0, [sp, #72]
ldr x0, [sp, #64]
ldr x2, [sp, #72]
adds x0, x0, x2
b.vs Lfn1fail23_1
mov x1, #0
b Lfn1end
Lfn1fail23_1:
adrp x0, Lfn1fail23_1location@PAGE
add x0, x0, Lfn1fail23_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn1end
Lfn1end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn2:
ldp x8, x9, [x0, #0]
Lfn2fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #80
stp x8, x9, [sp, #48]
Lfn2loop:
ldr x8, [sp, #48]
ldr x9, [sp, #56]
bl Lfn1fields
cbnz x1, Lfn2end
str x0, [sp, #64]
ldr x8, [sp, #56]
ldr x9, [sp, #48]
bl Lfn1fields
cbnz x1, Lfn2end
str x0, [sp, #72]
ldr x0, [sp, #64]
ldr x2, [sp, #72]
adds x0, x0, x2
b.vs Lfn2fail42_1
mov x1, #0
b Lfn2end
Lfn2fail42_1:
adrp x0, Lfn2fail42_1location@PAGE
add x0, x0, Lfn2fail42_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn2end
Lfn2end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn3:
ldp x8, x9, [x0, #0]
Lfn3fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #80
stp x8, x9, [sp, #48]
Lfn3loop:
ldr x8, [sp, #48]
ldr x9, [sp, #56]
bl Lfn2fields
cbnz x1, Lfn3end
str x0, [sp, #64]
ldr x8, [sp, #56]
ldr x9, [sp, #48]
bl Lfn2fields
cbnz x1, Lfn3end
str x0, [sp, #72]
ldr x0, [sp, #64]
ldr x2, [sp, #72]
adds x0, x0, x2
b.vs Lfn3fail61_1
mov x1, #0
b Lfn3end
Lfn3fail61_1:
adrp x0, Lfn3fail61_1location@PAGE
add x0, x0, Lfn3fail61_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn3end
Lfn3end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn4:
ldp x8, x9, [x0, #0]
Lfn4fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #80
stp x8, x9, [sp, #48]
Lfn4loop:
ldr x8, [sp, #48]
ldr x9, [sp, #56]
bl Lfn3fields
cbnz x1, Lfn4end
str x0, [sp, #64]
ldr x8, [sp, #56]
ldr x9, [sp, #48]
bl Lfn3fields
cbnz x1, Lfn4end
str x0, [sp, #72]
ldr x0, [sp, #64]
ldr x2, [sp, #72]
adds x0, x0, x2
b.vs Lfn4fail80_1
mov x1, #0
b Lfn4end
Lfn4fail80_1:
adrp x0, Lfn4fail80_1location@PAGE
add x0, x0, Lfn4fail80_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn4end
Lfn4end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn5:
ldp x8, x9, [x0, #0]
Lfn5fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #80
stp x8, x9, [sp, #48]
Lfn5loop:
ldr x8, [sp, #48]
ldr x9, [sp, #56]
bl Lfn4fields
cbnz x1, Lfn5end
str x0, [sp, #64]
ldr x8, [sp, #56]
ldr x9, [sp, #48]
bl Lfn4fields
cbnz x1, Lfn5end
str x0, [sp, #72]
ldr x0, [sp, #64]
ldr x2, [sp, #72]
adds x0, x0, x2
b.vs Lfn5fail99_1
mov x1, #0
b Lfn5end
Lfn5fail99_1:
adrp x0, Lfn5fail99_1location@PAGE
add x0, x0, Lfn5fail99_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn5end
Lfn5end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn6:
ldp x8, x9, [x0, #0]
Lfn6fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #80
stp x8, x9, [sp, #48]
Lfn6loop:
ldr x8, [sp, #48]
ldr x9, [sp, #56]
bl Lfn5fields
cbnz x1, Lfn6end
str x0, [sp, #64]
ldr x8, [sp, #56]
ldr x9, [sp, #48]
bl Lfn5fields
cbnz x1, Lfn6end
str x0, [sp, #72]
ldr x0, [sp, #64]
ldr x2, [sp, #72]
adds x0, x0, x2
b.vs Lfn6fail118_1
mov x1, #0
b Lfn6end
Lfn6fail118_1:
adrp x0, Lfn6fail118_1location@PAGE
add x0, x0, Lfn6fail118_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn6end
Lfn6end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn7:
ldp x8, x9, [x0, #0]
Lfn7fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #80
stp x8, x9, [sp, #48]
Lfn7loop:
ldr x8, [sp, #48]
ldr x9, [sp, #56]
bl Lfn6fields
cbnz x1, Lfn7end
str x0, [sp, #64]
ldr x8, [sp, #56]
ldr x9, [sp, #48]
bl Lfn6fields
cbnz x1, Lfn7end
str x0, [sp, #72]
ldr x0, [sp, #64]
ldr x2, [sp, #72]
adds x0, x0, x2
b.vs Lfn7fail137_1
mov x1, #0
b Lfn7end
Lfn7fail137_1:
adrp x0, Lfn7fail137_1location@PAGE
add x0, x0, Lfn7fail137_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn7end
Lfn7end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn8:
ldp x8, x9, [x0, #0]
Lfn8fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #80
stp x8, x9, [sp, #48]
Lfn8loop:
ldr x8, [sp, #48]
ldr x9, [sp, #56]
bl Lfn7fields
cbnz x1, Lfn8end
str x0, [sp, #64]
ldr x8, [sp, #56]
ldr x9, [sp, #48]
bl Lfn7fields
cbnz x1, Lfn8end
str x0, [sp, #72]
ldr x0, [sp, #64]
ldr x2, [sp, #72]
adds x0, x0, x2
b.vs Lfn8fail156_1
mov x1, #0
b Lfn8end
Lfn8fail156_1:
adrp x0, Lfn8fail156_1location@PAGE
add x0, x0, Lfn8fail156_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn8end
Lfn8end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn9:
ldp x8, x9, [x0, #0]
Lfn9fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #80
stp x8, x9, [sp, #48]
Lfn9loop:
ldr x8, [sp, #48]
ldr x9, [sp, #56]
bl Lfn8fields
cbnz x1, Lfn9end
str x0, [sp, #64]
ldr x8, [sp, #56]
ldr x9, [sp, #48]
bl Lfn8fields
cbnz x1, Lfn9end
str x0, [sp, #72]
ldr x0, [sp, #64]
ldr x2, [sp, #72]
adds x0, x0, x2
b.vs Lfn9fail175_1
mov x1, #0
b Lfn9end
Lfn9fail175_1:
adrp x0, Lfn9fail175_1location@PAGE
add x0, x0, Lfn9fail175_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn9end
Lfn9end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn10:
ldp x8, x9, [x0, #0]
Lfn10fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #80
stp x8, x9, [sp, #48]
Lfn10loop:
ldr x8, [sp, #48]
ldr x9, [sp, #56]
bl Lfn9fields
cbnz x1, Lfn10end
str x0, [sp, #64]
ldr x8, [sp, #56]
ldr x9, [sp, #48]
bl Lfn9fields
cbnz x1, Lfn10end
str x0, [sp, #72]
ldr x0, [sp, #64]
ldr x2, [sp, #72]
adds x0, x0, x2
b.vs Lfn10fail194_1
mov x1, #0
b Lfn10end
Lfn10fail194_1:
adrp x0, Lfn10fail194_1location@PAGE
add x0, x0, Lfn10fail194_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn10end
Lfn10end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn11:
ldp x8, x9, [x0, #0]
Lfn11fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #80
stp x8, x9, [sp, #48]
Lfn11loop:
ldr x8, [sp, #48]
ldr x9, [sp, #56]
bl Lfn10fields
cbnz x1, Lfn11end
str x0, [sp, #64]
ldr x8, [sp, #56]
ldr x9, [sp, #48]
bl Lfn10fields
cbnz x1, Lfn11end
str x0, [sp, #72]
ldr x0, [sp, #64]
ldr x2, [sp, #72]
adds x0, x0, x2
b.vs Lfn11fail213_1
mov x1, #0
b Lfn11end
Lfn11fail213_1:
adrp x0, Lfn11fail213_1location@PAGE
add x0, x0, Lfn11fail213_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn11end
Lfn11end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
.globl _fenrir_entry
_fenrir_entry:
Lfn12:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
str x0, [sp, #48]
movz x0, #1, lsl #0
str x0, [sp, #56]
ldr x8, [sp, #48]
ldr x9, [sp, #56]
mov sp, x29
ldp x29, x30, [sp], #16
b Lfn11fields
mov x1, #0
b Lfn12end
Lfn12end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
.text
.globl _fen_print_result
_fen_print_result:
b Lprint0
Lprint0:
b _fen_write_i64
Lfn0fail10_1location:
.byte 116,114,97,112,32,97,116,58,32,101,120,112,97,110,115,105,111,110,46,102,101,110,58,49,58,53,48,10,0
Lfn1fail23_1location:
.byte 116,114,97,112,32,97,116,58,32,101,120,112,97,110,115,105,111,110,46,102,101,110,58,50,58,53,48,10,0
Lfn2fail42_1location:
.byte 116,114,97,112,32,97,116,58,32,101,120,112,97,110,115,105,111,110,46,102,101,110,58,51,58,53,48,10,0
Lfn3fail61_1location:
.byte 116,114,97,112,32,97,116,58,32,101,120,112,97,110,115,105,111,110,46,102,101,110,58,52,58,53,48,10,0
Lfn4fail80_1location:
.byte 116,114,97,112,32,97,116,58,32,101,120,112,97,110,115,105,111,110,46,102,101,110,58,53,58,53,48,10,0
Lfn5fail99_1location:
.byte 116,114,97,112,32,97,116,58,32,101,120,112,97,110,115,105,111,110,46,102,101,110,58,54,58,53,48,10,0
Lfn6fail118_1location:
.byte 116,114,97,112,32,97,116,58,32,101,120,112,97,110,115,105,111,110,46,102,101,110,58,55,58,53,48,10,0
Lfn7fail137_1location:
.byte 116,114,97,112,32,97,116,58,32,101,120,112,97,110,115,105,111,110,46,102,101,110,58,56,58,53,48,10,0
Lfn8fail156_1location:
.byte 116,114,97,112,32,97,116,58,32,101,120,112,97,110,115,105,111,110,46,102,101,110,58,57,58,53,48,10,0
Lfn9fail175_1location:
.byte 116,114,97,112,32,97,116,58,32,101,120,112,97,110,115,105,111,110,46,102,101,110,58,49,48,58,53,48,10,0
Lfn10fail194_1location:
.byte 116,114,97,112,32,97,116,58,32,101,120,112,97,110,115,105,111,110,46,102,101,110,58,49,49,58,53,49,10,0
Lfn11fail213_1location:
.byte 116,114,97,112,32,97,116,58,32,101,120,112,97,110,115,105,111,110,46,102,101,110,58,49,50,58,53,49,10,0
