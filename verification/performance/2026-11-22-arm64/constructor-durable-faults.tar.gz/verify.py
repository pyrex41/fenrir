import json, sqlite3, shutil, tempfile
from pathlib import Path
root=Path(__file__).resolve().parent
out=root/'receipts'
out.mkdir(exist_ok=True)
for workload in ('recovery','rollback','backlog','wide-backlog','timeout-after-commit'):
    histories=[]
    tables=[]
    for target in ('mac','spt'):
        log=(root.parent/'ctor-app-rehearsal-fPJJ39dB'/'run' if workload=='recovery' else root)/f'{workload}-{target}.log'
        src=Path(next(l.removeprefix('Recovery evidence: ') for l in log.read_text().splitlines() if l.startswith('Recovery evidence: ')))
        dest=out/workload/target
        dest.mkdir(parents=True,exist_ok=True)
        for name in ('history.json','check/verdicts.jsonl','native.sha256','container.id','fault.json','timings.json'):
            if (src/name).exists(): shutil.copyfile(src/name,dest/Path(name).name)
        h=json.loads((dest/'history.json').read_bytes())
        v=json.loads((dest/'verdicts.jsonl').read_bytes())
        assert v['verdict']=='accepted' and len(h['events'])==v['events']
        histories.append(h['events'])
        with tempfile.TemporaryDirectory() as tmp:
            for name in ('jobs.db','jobs.db-wal'):
                if (src/name).exists(): shutil.copyfile(src/name,Path(tmp)/name)
            db=sqlite3.connect(Path(tmp)/'jobs.db')
            snap=sqlite3.connect(dest/'snapshot.db')
            db.backup(snap)
            assert snap.execute('pragma integrity_check').fetchall()==[('ok',)]
            tables.append({t:sorted(snap.execute('select * from '+t).fetchall()) for t in ('jobs','reports','request_keys','tenants','meta')})
            snap.close()
            db.close()
    assert histories[0]==histories[1]
    assert tables[0]==tables[1], workload
    print(workload,len(histories[0]),{k:len(v) for k,v in tables[0].items()})
