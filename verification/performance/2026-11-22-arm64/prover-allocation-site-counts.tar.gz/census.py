import json,pathlib,re,sys,subprocess,os
root=pathlib.Path(sys.argv[1]);out=pathlib.Path(__file__).parent
report=json.loads((root/'results/prover/report.json').read_bytes())
for lane,cases in [('search',10),('check',6)]:
 src=root/'results/prover'/lane; dst=out/lane;dst.mkdir()
 code=(src/'program.s').read_text();assert not re.search(r'\b[wx](16|17)\b',code)
 names=[f['name'] for f in json.loads((src/'artifact').read_bytes())['functions']]
 body=[];edges=[];caller='entry'
 for ln,line in enumerate(code.splitlines(),1):
  f=re.fullmatch(r'Lfn(\d+):',line)
  if f:caller=names[int(f[1])]
  if line=='fenrir_entry:':caller='entry'
  c=re.fullmatch(r'bl (fen_allocate(?:_full)?|fen_bytes_concat|fen_enter)',line)
  if c:
   i=len(edges);edges.append(dict(line=ln,caller=caller,callee=c[1]))
   body.extend(['adrp x16, counts','add x16, x16, :lo12:counts',f'ldr x17, [x16, #{8*i}]','add x17, x17, #1',f'str x17, [x16, #{8*i}]'])
  body.append(line)
 (dst/'instrumented.s').write_text('\n'.join(body)+'\n');launcher=(root/'src/benchmarks/prover/timed-spt.c').read_text().replace('int solo5_app_main',f'uint64_t counts[{len(edges)}];\nint solo5_app_main').replace('    return SOLO5_EXIT_SUCCESS;',f'    for (int i=0;i<{len(edges)};i++) {{ fen_write_i64(counts[i]); fen_write("\\n",1); }}\n    return SOLO5_EXIT_SUCCESS;');(dst/'main.c').write_text(launcher)
 cmd=['docker','run','--rm','--network','none','--platform','linux/arm64','--cpuset-cpus','4','--user',f'{os.getuid()}:{os.getgid()}','-v',f'{root}/src:/src:ro','-v',f'{dst}:/w','-w','/w','--entrypoint','sh',report['container'],'-ec','export PATH=/opt/solo5-install/bin:$PATH FENRIR_SOLO5_MAIN=/w/main.c; sh /src/tools/aarch64/link-spt.sh instrumented.s guest; for n in 1 100; do solo5-spt guest --solo5:quiet "$n"; done']
 raw=subprocess.check_output(cmd,text=True,timeout=180);(dst/'console.txt').write_text(raw);lines=iter(raw.splitlines())
 for n in (1,100):
  assert int(next(lines).split()[0])==cases*n
  for e in edges:e[str(n)]=int(next(lines))
 assert next(lines,None) is None
 (dst/'edges.json').write_text(json.dumps(edges,indent=2))
 from collections import Counter
 totals=Counter()
 for e in edges:
  assert e['100']==100*e['1']
  totals[e['callee'],e['caller']]+=e['1']
 print(lane,totals.most_common())
