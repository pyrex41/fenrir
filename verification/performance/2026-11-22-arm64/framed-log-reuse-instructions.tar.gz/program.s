.text
.p2align 2
Lfn0:
adrp x16, Lcount0
ldr x17, [x16, :lo12:Lcount0]
add x17, x17, #1
str x17, [x16, :lo12:Lcount0]
ldp x8, x9, [x0, #0]
adrp x16, Lcount0
ldr x17, [x16, :lo12:Lcount0]
add x17, x17, #1
str x17, [x16, :lo12:Lcount0]
ldp x10, x11, [x0, #16]
Lfn0fields:
adrp x16, Lcount1
ldr x17, [x16, :lo12:Lcount1]
add x17, x17, #1
str x17, [x16, :lo12:Lcount1]
stp x29, x30, [sp, #-16]!
adrp x16, Lcount2
ldr x17, [x16, :lo12:Lcount2]
add x17, x17, #1
str x17, [x16, :lo12:Lcount2]
mov x29, sp
adrp x16, Lcount3
ldr x17, [x16, :lo12:Lcount3]
add x17, x17, #1
str x17, [x16, :lo12:Lcount3]
sub sp, sp, #208
adrp x16, Lcount1
ldr x17, [x16, :lo12:Lcount1]
add x17, x17, #1
str x17, [x16, :lo12:Lcount1]
stp x8, x9, [sp, #48]
adrp x16, Lcount1
ldr x17, [x16, :lo12:Lcount1]
add x17, x17, #1
str x17, [x16, :lo12:Lcount1]
stp x10, x11, [sp, #64]
adrp x16, Lcount4
ldr x17, [x16, :lo12:Lcount4]
add x17, x17, #1
str x17, [x16, :lo12:Lcount4]
add x0, sp, #16
adrp x16, Lcount4
ldr x17, [x16, :lo12:Lcount4]
add x17, x17, #1
str x17, [x16, :lo12:Lcount4]
add x1, sp, #48
adrp x16, Lcount2
ldr x17, [x16, :lo12:Lcount2]
add x17, x17, #1
str x17, [x16, :lo12:Lcount2]
mov x2, #1
adrp x16, Lcount5
ldr x17, [x16, :lo12:Lcount5]
add x17, x17, #1
str x17, [x16, :lo12:Lcount5]
bl fen_enter
Lfn0loop:
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x0, [sp, #56]
adrp x16, Lcount7
ldr x17, [x16, :lo12:Lcount7]
add x17, x17, #1
str x17, [x16, :lo12:Lcount7]
asr x2, x0, #63
adrp x16, Lcount4
ldr x17, [x16, :lo12:Lcount4]
add x17, x17, #1
str x17, [x16, :lo12:Lcount4]
add x0, x0, x2, lsr #63
adrp x16, Lcount7
ldr x17, [x16, :lo12:Lcount7]
add x17, x17, #1
str x17, [x16, :lo12:Lcount7]
asr x0, x0, #1
adrp x16, Lcount8
ldr x17, [x16, :lo12:Lcount8]
add x17, x17, #1
str x17, [x16, :lo12:Lcount8]
lsl x2, x0, #1
adrp x16, Lcount9
ldr x17, [x16, :lo12:Lcount9]
add x17, x17, #1
str x17, [x16, :lo12:Lcount9]
cmp x0, x2, asr #1
adrp x16, Lcount10
ldr x17, [x16, :lo12:Lcount10]
add x17, x17, #1
str x17, [x16, :lo12:Lcount10]
b.ne Lfn0fail20_1
adrp x16, Lcount2
ldr x17, [x16, :lo12:Lcount2]
add x17, x17, #1
str x17, [x16, :lo12:Lcount2]
mov x0, x2
adrp x16, Lcount11
ldr x17, [x16, :lo12:Lcount11]
add x17, x17, #1
str x17, [x16, :lo12:Lcount11]
str x0, [sp, #80]
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x0, [sp, #48]
adrp x16, Lcount12
ldr x17, [x16, :lo12:Lcount12]
add x17, x17, #1
str x17, [x16, :lo12:Lcount12]
ldr w0, [x0, #72]
adrp x16, Lcount9
ldr x17, [x16, :lo12:Lcount9]
add x17, x17, #1
str x17, [x16, :lo12:Lcount9]
cmp w0, #9
adrp x16, Lcount13
ldr x17, [x16, :lo12:Lcount13]
add x17, x17, #1
str x17, [x16, :lo12:Lcount13]
b.eq Lfn0match25arm9
adrp x16, Lcount9
ldr x17, [x16, :lo12:Lcount9]
add x17, x17, #1
str x17, [x16, :lo12:Lcount9]
cmp w0, #10
adrp x16, Lcount13
ldr x17, [x16, :lo12:Lcount13]
add x17, x17, #1
str x17, [x16, :lo12:Lcount13]
b.eq Lfn0match25arm10
adrp x16, Lcount9
ldr x17, [x16, :lo12:Lcount9]
add x17, x17, #1
str x17, [x16, :lo12:Lcount9]
cmp w0, #11
adrp x16, Lcount13
ldr x17, [x16, :lo12:Lcount13]
add x17, x17, #1
str x17, [x16, :lo12:Lcount13]
b.eq Lfn0match25arm11
adrp x16, Lcount9
ldr x17, [x16, :lo12:Lcount9]
add x17, x17, #1
str x17, [x16, :lo12:Lcount9]
cmp w0, #12
adrp x16, Lcount13
ldr x17, [x16, :lo12:Lcount13]
add x17, x17, #1
str x17, [x16, :lo12:Lcount13]
b.eq Lfn0match25arm12
adrp x16, Lcount14
ldr x17, [x16, :lo12:Lcount14]
add x17, x17, #1
str x17, [x16, :lo12:Lcount14]
brk #0
Lfn0match25arm9:
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x0, [sp, #56]
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x2, [sp, #80]
adrp x16, Lcount9
ldr x17, [x16, :lo12:Lcount9]
add x17, x17, #1
str x17, [x16, :lo12:Lcount9]
cmp x0, x2
adrp x16, Lcount10
ldr x17, [x16, :lo12:Lcount10]
add x17, x17, #1
str x17, [x16, :lo12:Lcount10]
b.ne Lfn0if27else
adrp x16, Lcount15
ldr x17, [x16, :lo12:Lcount15]
add x17, x17, #1
str x17, [x16, :lo12:Lcount15]
movz x0, #1, lsl #0
adrp x16, Lcount11
ldr x17, [x16, :lo12:Lcount11]
add x17, x17, #1
str x17, [x16, :lo12:Lcount11]
str x0, [sp, #88]
adrp x16, Lcount15
ldr x17, [x16, :lo12:Lcount15]
add x17, x17, #1
str x17, [x16, :lo12:Lcount15]
movz x0, #0, lsl #0
adrp x16, Lcount11
ldr x17, [x16, :lo12:Lcount11]
add x17, x17, #1
str x17, [x16, :lo12:Lcount11]
str x0, [sp, #96]
adrp x16, Lcount15
ldr x17, [x16, :lo12:Lcount15]
add x17, x17, #1
str x17, [x16, :lo12:Lcount15]
movz x0, #0, lsl #0
adrp x16, Lcount11
ldr x17, [x16, :lo12:Lcount11]
add x17, x17, #1
str x17, [x16, :lo12:Lcount11]
str x0, [sp, #104]
adrp x16, Lcount15
ldr x17, [x16, :lo12:Lcount15]
add x17, x17, #1
str x17, [x16, :lo12:Lcount15]
movz x0, #0, lsl #0
adrp x16, Lcount11
ldr x17, [x16, :lo12:Lcount11]
add x17, x17, #1
str x17, [x16, :lo12:Lcount11]
str x0, [sp, #112]
adrp x16, Lcount2
ldr x17, [x16, :lo12:Lcount2]
add x17, x17, #1
str x17, [x16, :lo12:Lcount2]
mov x0, #0
adrp x16, Lcount2
ldr x17, [x16, :lo12:Lcount2]
add x17, x17, #1
str x17, [x16, :lo12:Lcount2]
mov x1, #10
adrp x16, Lcount16
ldr x17, [x16, :lo12:Lcount16]
add x17, x17, #1
str x17, [x16, :lo12:Lcount16]
bl fen_allocate
adrp x16, Lcount17
ldr x17, [x16, :lo12:Lcount17]
add x17, x17, #1
str x17, [x16, :lo12:Lcount17]
cbz x0, Lfn0fail31_3
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x2, [sp, #80]
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x3, [sp, #88]
adrp x16, Lcount18
ldr x17, [x16, :lo12:Lcount18]
add x17, x17, #1
str x17, [x16, :lo12:Lcount18]
stp x2, x3, [x0, #0]
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x2, [sp, #64]
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x3, [sp, #72]
adrp x16, Lcount18
ldr x17, [x16, :lo12:Lcount18]
add x17, x17, #1
str x17, [x16, :lo12:Lcount18]
stp x2, x3, [x0, #16]
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x2, [sp, #96]
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x3, [sp, #104]
adrp x16, Lcount18
ldr x17, [x16, :lo12:Lcount18]
add x17, x17, #1
str x17, [x16, :lo12:Lcount18]
stp x2, x3, [x0, #32]
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x2, [sp, #112]
adrp x16, Lcount19
ldr x17, [x16, :lo12:Lcount19]
add x17, x17, #1
str x17, [x16, :lo12:Lcount19]
str x2, [x0, #48]
adrp x16, Lcount20
ldr x17, [x16, :lo12:Lcount20]
add x17, x17, #1
str x17, [x16, :lo12:Lcount20]
b Lfn0if27done
Lfn0if27else:
adrp x16, Lcount15
ldr x17, [x16, :lo12:Lcount15]
add x17, x17, #1
str x17, [x16, :lo12:Lcount15]
movz x0, #0, lsl #0
adrp x16, Lcount11
ldr x17, [x16, :lo12:Lcount11]
add x17, x17, #1
str x17, [x16, :lo12:Lcount11]
str x0, [sp, #120]
adrp x16, Lcount15
ldr x17, [x16, :lo12:Lcount15]
add x17, x17, #1
str x17, [x16, :lo12:Lcount15]
movz x0, #0, lsl #0
adrp x16, Lcount11
ldr x17, [x16, :lo12:Lcount11]
add x17, x17, #1
str x17, [x16, :lo12:Lcount11]
str x0, [sp, #128]
adrp x16, Lcount15
ldr x17, [x16, :lo12:Lcount15]
add x17, x17, #1
str x17, [x16, :lo12:Lcount15]
movz x0, #0, lsl #0
adrp x16, Lcount11
ldr x17, [x16, :lo12:Lcount11]
add x17, x17, #1
str x17, [x16, :lo12:Lcount11]
str x0, [sp, #136]
adrp x16, Lcount15
ldr x17, [x16, :lo12:Lcount15]
add x17, x17, #1
str x17, [x16, :lo12:Lcount15]
movz x0, #1, lsl #0
adrp x16, Lcount11
ldr x17, [x16, :lo12:Lcount11]
add x17, x17, #1
str x17, [x16, :lo12:Lcount11]
str x0, [sp, #144]
adrp x16, Lcount2
ldr x17, [x16, :lo12:Lcount2]
add x17, x17, #1
str x17, [x16, :lo12:Lcount2]
mov x0, #0
adrp x16, Lcount2
ldr x17, [x16, :lo12:Lcount2]
add x17, x17, #1
str x17, [x16, :lo12:Lcount2]
mov x1, #10
adrp x16, Lcount16
ldr x17, [x16, :lo12:Lcount16]
add x17, x17, #1
str x17, [x16, :lo12:Lcount16]
bl fen_allocate
adrp x16, Lcount17
ldr x17, [x16, :lo12:Lcount17]
add x17, x17, #1
str x17, [x16, :lo12:Lcount17]
cbz x0, Lfn0fail39_3
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x2, [sp, #80]
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x3, [sp, #120]
adrp x16, Lcount18
ldr x17, [x16, :lo12:Lcount18]
add x17, x17, #1
str x17, [x16, :lo12:Lcount18]
stp x2, x3, [x0, #0]
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x2, [sp, #128]
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x3, [sp, #136]
adrp x16, Lcount18
ldr x17, [x16, :lo12:Lcount18]
add x17, x17, #1
str x17, [x16, :lo12:Lcount18]
stp x2, x3, [x0, #16]
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x2, [sp, #144]
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x3, [sp, #64]
adrp x16, Lcount18
ldr x17, [x16, :lo12:Lcount18]
add x17, x17, #1
str x17, [x16, :lo12:Lcount18]
stp x2, x3, [x0, #32]
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x2, [sp, #72]
adrp x16, Lcount19
ldr x17, [x16, :lo12:Lcount19]
add x17, x17, #1
str x17, [x16, :lo12:Lcount19]
str x2, [x0, #48]
Lfn0if27done:
adrp x16, Lcount20
ldr x17, [x16, :lo12:Lcount20]
add x17, x17, #1
str x17, [x16, :lo12:Lcount20]
b Lfn0match25end
Lfn0match25arm10:
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x0, [sp, #56]
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x2, [sp, #80]
adrp x16, Lcount9
ldr x17, [x16, :lo12:Lcount9]
add x17, x17, #1
str x17, [x16, :lo12:Lcount9]
cmp x0, x2
adrp x16, Lcount10
ldr x17, [x16, :lo12:Lcount10]
add x17, x17, #1
str x17, [x16, :lo12:Lcount10]
b.ne Lfn0if54else
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x0, [sp, #48]
adrp x16, Lcount12
ldr x17, [x16, :lo12:Lcount12]
add x17, x17, #1
str x17, [x16, :lo12:Lcount12]
ldr x0, [x0, #8]
adrp x16, Lcount21
ldr x17, [x16, :lo12:Lcount21]
add x17, x17, #1
str x17, [x16, :lo12:Lcount21]
adds x0, x0, #1
adrp x16, Lcount22
ldr x17, [x16, :lo12:Lcount22]
add x17, x17, #1
str x17, [x16, :lo12:Lcount22]
b.vs Lfn0fail60_1
adrp x16, Lcount11
ldr x17, [x16, :lo12:Lcount11]
add x17, x17, #1
str x17, [x16, :lo12:Lcount11]
str x0, [sp, #152]
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x0, [sp, #48]
adrp x16, Lcount12
ldr x17, [x16, :lo12:Lcount12]
add x17, x17, #1
str x17, [x16, :lo12:Lcount12]
ldr x0, [x0, #16]
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x2, [sp, #64]
adrp x16, Lcount21
ldr x17, [x16, :lo12:Lcount21]
add x17, x17, #1
str x17, [x16, :lo12:Lcount21]
adds x0, x0, x2
adrp x16, Lcount22
ldr x17, [x16, :lo12:Lcount22]
add x17, x17, #1
str x17, [x16, :lo12:Lcount22]
b.vs Lfn0fail63_1
adrp x16, Lcount11
ldr x17, [x16, :lo12:Lcount11]
add x17, x17, #1
str x17, [x16, :lo12:Lcount11]
str x0, [sp, #160]
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x0, [sp, #48]
adrp x16, Lcount12
ldr x17, [x16, :lo12:Lcount12]
add x17, x17, #1
str x17, [x16, :lo12:Lcount12]
ldr x0, [x0, #24]
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x2, [sp, #72]
adrp x16, Lcount21
ldr x17, [x16, :lo12:Lcount21]
add x17, x17, #1
str x17, [x16, :lo12:Lcount21]
adds x0, x0, x2
adrp x16, Lcount22
ldr x17, [x16, :lo12:Lcount22]
add x17, x17, #1
str x17, [x16, :lo12:Lcount22]
b.vs Lfn0fail66_1
adrp x16, Lcount11
ldr x17, [x16, :lo12:Lcount11]
add x17, x17, #1
str x17, [x16, :lo12:Lcount11]
str x0, [sp, #168]
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x0, [sp, #48]
adrp x16, Lcount23
ldr x17, [x16, :lo12:Lcount23]
add x17, x17, #1
str x17, [x16, :lo12:Lcount23]
ldp x2, x3, [sp, #152]
adrp x16, Lcount18
ldr x17, [x16, :lo12:Lcount18]
add x17, x17, #1
str x17, [x16, :lo12:Lcount18]
stp x2, x3, [x0, #8]
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x2, [sp, #168]
adrp x16, Lcount19
ldr x17, [x16, :lo12:Lcount19]
add x17, x17, #1
str x17, [x16, :lo12:Lcount19]
str x2, [x0, #24]
adrp x16, Lcount20
ldr x17, [x16, :lo12:Lcount20]
add x17, x17, #1
str x17, [x16, :lo12:Lcount20]
b Lfn0if54done
Lfn0if54else:
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x0, [sp, #48]
adrp x16, Lcount12
ldr x17, [x16, :lo12:Lcount12]
add x17, x17, #1
str x17, [x16, :lo12:Lcount12]
ldr x0, [x0, #32]
adrp x16, Lcount21
ldr x17, [x16, :lo12:Lcount21]
add x17, x17, #1
str x17, [x16, :lo12:Lcount21]
adds x0, x0, #1
adrp x16, Lcount22
ldr x17, [x16, :lo12:Lcount22]
add x17, x17, #1
str x17, [x16, :lo12:Lcount22]
b.vs Lfn0fail77_1
adrp x16, Lcount11
ldr x17, [x16, :lo12:Lcount11]
add x17, x17, #1
str x17, [x16, :lo12:Lcount11]
str x0, [sp, #176]
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x0, [sp, #48]
adrp x16, Lcount12
ldr x17, [x16, :lo12:Lcount12]
add x17, x17, #1
str x17, [x16, :lo12:Lcount12]
ldr x0, [x0, #40]
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x2, [sp, #64]
adrp x16, Lcount21
ldr x17, [x16, :lo12:Lcount21]
add x17, x17, #1
str x17, [x16, :lo12:Lcount21]
adds x0, x0, x2
adrp x16, Lcount22
ldr x17, [x16, :lo12:Lcount22]
add x17, x17, #1
str x17, [x16, :lo12:Lcount22]
b.vs Lfn0fail80_1
adrp x16, Lcount11
ldr x17, [x16, :lo12:Lcount11]
add x17, x17, #1
str x17, [x16, :lo12:Lcount11]
str x0, [sp, #184]
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x0, [sp, #48]
adrp x16, Lcount12
ldr x17, [x16, :lo12:Lcount12]
add x17, x17, #1
str x17, [x16, :lo12:Lcount12]
ldr x0, [x0, #48]
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x2, [sp, #72]
adrp x16, Lcount21
ldr x17, [x16, :lo12:Lcount21]
add x17, x17, #1
str x17, [x16, :lo12:Lcount21]
adds x0, x0, x2
adrp x16, Lcount22
ldr x17, [x16, :lo12:Lcount22]
add x17, x17, #1
str x17, [x16, :lo12:Lcount22]
b.vs Lfn0fail83_1
adrp x16, Lcount11
ldr x17, [x16, :lo12:Lcount11]
add x17, x17, #1
str x17, [x16, :lo12:Lcount11]
str x0, [sp, #192]
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x0, [sp, #48]
adrp x16, Lcount23
ldr x17, [x16, :lo12:Lcount23]
add x17, x17, #1
str x17, [x16, :lo12:Lcount23]
ldp x2, x3, [sp, #176]
adrp x16, Lcount18
ldr x17, [x16, :lo12:Lcount18]
add x17, x17, #1
str x17, [x16, :lo12:Lcount18]
stp x2, x3, [x0, #32]
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x2, [sp, #192]
adrp x16, Lcount19
ldr x17, [x16, :lo12:Lcount19]
add x17, x17, #1
str x17, [x16, :lo12:Lcount19]
str x2, [x0, #48]
Lfn0if54done:
adrp x16, Lcount20
ldr x17, [x16, :lo12:Lcount20]
add x17, x17, #1
str x17, [x16, :lo12:Lcount20]
b Lfn0match25end
Lfn0match25arm11:
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x0, [sp, #48]
adrp x16, Lcount20
ldr x17, [x16, :lo12:Lcount20]
add x17, x17, #1
str x17, [x16, :lo12:Lcount20]
b Lfn0match25end
Lfn0match25arm12:
adrp x16, Lcount6
ldr x17, [x16, :lo12:Lcount6]
add x17, x17, #1
str x17, [x16, :lo12:Lcount6]
ldr x0, [sp, #48]
adrp x16, Lcount20
ldr x17, [x16, :lo12:Lcount20]
add x17, x17, #1
str x17, [x16, :lo12:Lcount20]
b Lfn0match25end
Lfn0match25end:
adrp x16, Lcount2
ldr x17, [x16, :lo12:Lcount2]
add x17, x17, #1
str x17, [x16, :lo12:Lcount2]
mov x1, #0
adrp x16, Lcount20
ldr x17, [x16, :lo12:Lcount20]
add x17, x17, #1
str x17, [x16, :lo12:Lcount20]
b Lfn0end
Lfn0fail20_1:
adrp x16, Lcount24
ldr x17, [x16, :lo12:Lcount24]
add x17, x17, #1
str x17, [x16, :lo12:Lcount24]
adrp x0, Lfn0fail20_1location
adrp x16, Lcount4
ldr x17, [x16, :lo12:Lcount4]
add x17, x17, #1
str x17, [x16, :lo12:Lcount4]
add x0, x0, :lo12:Lfn0fail20_1location
adrp x16, Lcount25
ldr x17, [x16, :lo12:Lcount25]
add x17, x17, #1
str x17, [x16, :lo12:Lcount25]
bl fen_set_location
adrp x16, Lcount2
ldr x17, [x16, :lo12:Lcount2]
add x17, x17, #1
str x17, [x16, :lo12:Lcount2]
mov x1, #1
adrp x16, Lcount20
ldr x17, [x16, :lo12:Lcount20]
add x17, x17, #1
str x17, [x16, :lo12:Lcount20]
b Lfn0end
Lfn0fail31_3:
adrp x16, Lcount24
ldr x17, [x16, :lo12:Lcount24]
add x17, x17, #1
str x17, [x16, :lo12:Lcount24]
adrp x0, Lfn0fail31_3location
adrp x16, Lcount4
ldr x17, [x16, :lo12:Lcount4]
add x17, x17, #1
str x17, [x16, :lo12:Lcount4]
add x0, x0, :lo12:Lfn0fail31_3location
adrp x16, Lcount25
ldr x17, [x16, :lo12:Lcount25]
add x17, x17, #1
str x17, [x16, :lo12:Lcount25]
bl fen_set_location
adrp x16, Lcount2
ldr x17, [x16, :lo12:Lcount2]
add x17, x17, #1
str x17, [x16, :lo12:Lcount2]
mov x1, #3
adrp x16, Lcount20
ldr x17, [x16, :lo12:Lcount20]
add x17, x17, #1
str x17, [x16, :lo12:Lcount20]
b Lfn0end
Lfn0fail39_3:
adrp x16, Lcount24
ldr x17, [x16, :lo12:Lcount24]
add x17, x17, #1
str x17, [x16, :lo12:Lcount24]
adrp x0, Lfn0fail39_3location
adrp x16, Lcount4
ldr x17, [x16, :lo12:Lcount4]
add x17, x17, #1
str x17, [x16, :lo12:Lcount4]
add x0, x0, :lo12:Lfn0fail39_3location
adrp x16, Lcount25
ldr x17, [x16, :lo12:Lcount25]
add x17, x17, #1
str x17, [x16, :lo12:Lcount25]
bl fen_set_location
adrp x16, Lcount2
ldr x17, [x16, :lo12:Lcount2]
add x17, x17, #1
str x17, [x16, :lo12:Lcount2]
mov x1, #3
adrp x16, Lcount20
ldr x17, [x16, :lo12:Lcount20]
add x17, x17, #1
str x17, [x16, :lo12:Lcount20]
b Lfn0end
Lfn0fail60_1:
adrp x16, Lcount24
ldr x17, [x16, :lo12:Lcount24]
add x17, x17, #1
str x17, [x16, :lo12:Lcount24]
adrp x0, Lfn0fail60_1location
adrp x16, Lcount4
ldr x17, [x16, :lo12:Lcount4]
add x17, x17, #1
str x17, [x16, :lo12:Lcount4]
add x0, x0, :lo12:Lfn0fail60_1location
adrp x16, Lcount25
ldr x17, [x16, :lo12:Lcount25]
add x17, x17, #1
str x17, [x16, :lo12:Lcount25]
bl fen_set_location
adrp x16, Lcount2
ldr x17, [x16, :lo12:Lcount2]
add x17, x17, #1
str x17, [x16, :lo12:Lcount2]
mov x1, #1
adrp x16, Lcount20
ldr x17, [x16, :lo12:Lcount20]
add x17, x17, #1
str x17, [x16, :lo12:Lcount20]
b Lfn0end
Lfn0fail63_1:
adrp x16, Lcount24
ldr x17, [x16, :lo12:Lcount24]
add x17, x17, #1
str x17, [x16, :lo12:Lcount24]
adrp x0, Lfn0fail63_1location
adrp x16, Lcount4
ldr x17, [x16, :lo12:Lcount4]
add x17, x17, #1
str x17, [x16, :lo12:Lcount4]
add x0, x0, :lo12:Lfn0fail63_1location
adrp x16, Lcount25
ldr x17, [x16, :lo12:Lcount25]
add x17, x17, #1
str x17, [x16, :lo12:Lcount25]
bl fen_set_location
adrp x16, Lcount2
ldr x17, [x16, :lo12:Lcount2]
add x17, x17, #1
str x17, [x16, :lo12:Lcount2]
mov x1, #1
adrp x16, Lcount20
ldr x17, [x16, :lo12:Lcount20]
add x17, x17, #1
str x17, [x16, :lo12:Lcount20]
b Lfn0end
Lfn0fail66_1:
adrp x16, Lcount24
ldr x17, [x16, :lo12:Lcount24]
add x17, x17, #1
str x17, [x16, :lo12:Lcount24]
adrp x0, Lfn0fail66_1location
adrp x16, Lcount4
ldr x17, [x16, :lo12:Lcount4]
add x17, x17, #1
str x17, [x16, :lo12:Lcount4]
add x0, x0, :lo12:Lfn0fail66_1location
adrp x16, Lcount25
ldr x17, [x16, :lo12:Lcount25]
add x17, x17, #1
str x17, [x16, :lo12:Lcount25]
bl fen_set_location
adrp x16, Lcount2
ldr x17, [x16, :lo12:Lcount2]
add x17, x17, #1
str x17, [x16, :lo12:Lcount2]
mov x1, #1
adrp x16, Lcount20
ldr x17, [x16, :lo12:Lcount20]
add x17, x17, #1
str x17, [x16, :lo12:Lcount20]
b Lfn0end
Lfn0fail58_3:
adrp x16, Lcount24
ldr x17, [x16, :lo12:Lcount24]
add x17, x17, #1
str x17, [x16, :lo12:Lcount24]
adrp x0, Lfn0fail58_3location
adrp x16, Lcount4
ldr x17, [x16, :lo12:Lcount4]
add x17, x17, #1
str x17, [x16, :lo12:Lcount4]
add x0, x0, :lo12:Lfn0fail58_3location
adrp x16, Lcount25
ldr x17, [x16, :lo12:Lcount25]
add x17, x17, #1
str x17, [x16, :lo12:Lcount25]
bl fen_set_location
adrp x16, Lcount2
ldr x17, [x16, :lo12:Lcount2]
add x17, x17, #1
str x17, [x16, :lo12:Lcount2]
mov x1, #3
adrp x16, Lcount20
ldr x17, [x16, :lo12:Lcount20]
add x17, x17, #1
str x17, [x16, :lo12:Lcount20]
b Lfn0end
Lfn0fail77_1:
adrp x16, Lcount24
ldr x17, [x16, :lo12:Lcount24]
add x17, x17, #1
str x17, [x16, :lo12:Lcount24]
adrp x0, Lfn0fail77_1location
adrp x16, Lcount4
ldr x17, [x16, :lo12:Lcount4]
add x17, x17, #1
str x17, [x16, :lo12:Lcount4]
add x0, x0, :lo12:Lfn0fail77_1location
adrp x16, Lcount25
ldr x17, [x16, :lo12:Lcount25]
add x17, x17, #1
str x17, [x16, :lo12:Lcount25]
bl fen_set_location
adrp x16, Lcount2
ldr x17, [x16, :lo12:Lcount2]
add x17, x17, #1
str x17, [x16, :lo12:Lcount2]
mov x1, #1
adrp x16, Lcount20
ldr x17, [x16, :lo12:Lcount20]
add x17, x17, #1
str x17, [x16, :lo12:Lcount20]
b Lfn0end
Lfn0fail80_1:
adrp x16, Lcount24
ldr x17, [x16, :lo12:Lcount24]
add x17, x17, #1
str x17, [x16, :lo12:Lcount24]
adrp x0, Lfn0fail80_1location
adrp x16, Lcount4
ldr x17, [x16, :lo12:Lcount4]
add x17, x17, #1
str x17, [x16, :lo12:Lcount4]
add x0, x0, :lo12:Lfn0fail80_1location
adrp x16, Lcount25
ldr x17, [x16, :lo12:Lcount25]
add x17, x17, #1
str x17, [x16, :lo12:Lcount25]
bl fen_set_location
adrp x16, Lcount2
ldr x17, [x16, :lo12:Lcount2]
add x17, x17, #1
str x17, [x16, :lo12:Lcount2]
mov x1, #1
adrp x16, Lcount20
ldr x17, [x16, :lo12:Lcount20]
add x17, x17, #1
str x17, [x16, :lo12:Lcount20]
b Lfn0end
Lfn0fail83_1:
adrp x16, Lcount24
ldr x17, [x16, :lo12:Lcount24]
add x17, x17, #1
str x17, [x16, :lo12:Lcount24]
adrp x0, Lfn0fail83_1location
adrp x16, Lcount4
ldr x17, [x16, :lo12:Lcount4]
add x17, x17, #1
str x17, [x16, :lo12:Lcount4]
add x0, x0, :lo12:Lfn0fail83_1location
adrp x16, Lcount25
ldr x17, [x16, :lo12:Lcount25]
add x17, x17, #1
str x17, [x16, :lo12:Lcount25]
bl fen_set_location
adrp x16, Lcount2
ldr x17, [x16, :lo12:Lcount2]
add x17, x17, #1
str x17, [x16, :lo12:Lcount2]
mov x1, #1
adrp x16, Lcount20
ldr x17, [x16, :lo12:Lcount20]
add x17, x17, #1
str x17, [x16, :lo12:Lcount20]
b Lfn0end
Lfn0fail72_3:
adrp x16, Lcount24
ldr x17, [x16, :lo12:Lcount24]
add x17, x17, #1
str x17, [x16, :lo12:Lcount24]
adrp x0, Lfn0fail72_3location
adrp x16, Lcount4
ldr x17, [x16, :lo12:Lcount4]
add x17, x17, #1
str x17, [x16, :lo12:Lcount4]
add x0, x0, :lo12:Lfn0fail72_3location
adrp x16, Lcount25
ldr x17, [x16, :lo12:Lcount25]
add x17, x17, #1
str x17, [x16, :lo12:Lcount25]
bl fen_set_location
adrp x16, Lcount2
ldr x17, [x16, :lo12:Lcount2]
add x17, x17, #1
str x17, [x16, :lo12:Lcount2]
mov x1, #3
adrp x16, Lcount20
ldr x17, [x16, :lo12:Lcount20]
add x17, x17, #1
str x17, [x16, :lo12:Lcount20]
b Lfn0end
Lfn0end:
adrp x16, Lcount26
ldr x17, [x16, :lo12:Lcount26]
add x17, x17, #1
str x17, [x16, :lo12:Lcount26]
bl fen_leave_result
adrp x16, Lcount2
ldr x17, [x16, :lo12:Lcount2]
add x17, x17, #1
str x17, [x16, :lo12:Lcount2]
mov sp, x29
adrp x16, Lcount23
ldr x17, [x16, :lo12:Lcount23]
add x17, x17, #1
str x17, [x16, :lo12:Lcount23]
ldp x29, x30, [sp], #16
adrp x16, Lcount27
ldr x17, [x16, :lo12:Lcount27]
add x17, x17, #1
str x17, [x16, :lo12:Lcount27]
ret
Lfn1:
adrp x16, Lcount28
ldr x17, [x16, :lo12:Lcount28]
add x17, x17, #1
str x17, [x16, :lo12:Lcount28]
ldp x8, x9, [x0, #0]
adrp x16, Lcount28
ldr x17, [x16, :lo12:Lcount28]
add x17, x17, #1
str x17, [x16, :lo12:Lcount28]
ldp x10, x11, [x0, #16]
Lfn1fields:
adrp x16, Lcount29
ldr x17, [x16, :lo12:Lcount29]
add x17, x17, #1
str x17, [x16, :lo12:Lcount29]
stp x29, x30, [sp, #-16]!
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x29, sp
adrp x16, Lcount29
ldr x17, [x16, :lo12:Lcount29]
add x17, x17, #1
str x17, [x16, :lo12:Lcount29]
stp x19, x20, [sp, #-16]!
adrp x16, Lcount29
ldr x17, [x16, :lo12:Lcount29]
add x17, x17, #1
str x17, [x16, :lo12:Lcount29]
stp x21, x22, [sp, #-16]!
adrp x16, Lcount29
ldr x17, [x16, :lo12:Lcount29]
add x17, x17, #1
str x17, [x16, :lo12:Lcount29]
stp x23, xzr, [sp, #-16]!
adrp x16, Lcount31
ldr x17, [x16, :lo12:Lcount31]
add x17, x17, #1
str x17, [x16, :lo12:Lcount31]
sub sp, sp, #256
adrp x16, Lcount29
ldr x17, [x16, :lo12:Lcount29]
add x17, x17, #1
str x17, [x16, :lo12:Lcount29]
stp xzr, xzr, [sp, #56]
adrp x16, Lcount29
ldr x17, [x16, :lo12:Lcount29]
add x17, x17, #1
str x17, [x16, :lo12:Lcount29]
stp xzr, xzr, [sp, #72]
adrp x16, Lcount29
ldr x17, [x16, :lo12:Lcount29]
add x17, x17, #1
str x17, [x16, :lo12:Lcount29]
stp xzr, xzr, [sp, #88]
adrp x16, Lcount29
ldr x17, [x16, :lo12:Lcount29]
add x17, x17, #1
str x17, [x16, :lo12:Lcount29]
stp xzr, xzr, [sp, #104]
adrp x16, Lcount29
ldr x17, [x16, :lo12:Lcount29]
add x17, x17, #1
str x17, [x16, :lo12:Lcount29]
stp xzr, xzr, [sp, #120]
adrp x16, Lcount29
ldr x17, [x16, :lo12:Lcount29]
add x17, x17, #1
str x17, [x16, :lo12:Lcount29]
stp xzr, xzr, [sp, #136]
adrp x16, Lcount29
ldr x17, [x16, :lo12:Lcount29]
add x17, x17, #1
str x17, [x16, :lo12:Lcount29]
stp xzr, xzr, [sp, #152]
adrp x16, Lcount29
ldr x17, [x16, :lo12:Lcount29]
add x17, x17, #1
str x17, [x16, :lo12:Lcount29]
stp xzr, xzr, [sp, #168]
adrp x16, Lcount29
ldr x17, [x16, :lo12:Lcount29]
add x17, x17, #1
str x17, [x16, :lo12:Lcount29]
stp xzr, xzr, [sp, #184]
adrp x16, Lcount29
ldr x17, [x16, :lo12:Lcount29]
add x17, x17, #1
str x17, [x16, :lo12:Lcount29]
stp xzr, xzr, [sp, #200]
adrp x16, Lcount29
ldr x17, [x16, :lo12:Lcount29]
add x17, x17, #1
str x17, [x16, :lo12:Lcount29]
stp xzr, xzr, [sp, #216]
adrp x16, Lcount32
ldr x17, [x16, :lo12:Lcount32]
add x17, x17, #1
str x17, [x16, :lo12:Lcount32]
str xzr, [sp, #232]
adrp x16, Lcount32
ldr x17, [x16, :lo12:Lcount32]
add x17, x17, #1
str x17, [x16, :lo12:Lcount32]
str x8, [sp, #48]
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x19, x9
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x20, x10
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x21, x11
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x0, sp, #16
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x1, sp, #48
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x2, #24
adrp x16, Lcount34
ldr x17, [x16, :lo12:Lcount34]
add x17, x17, #1
str x17, [x16, :lo12:Lcount34]
bl fen_enter
Lfn1loop:
adrp x16, Lcount35
ldr x17, [x16, :lo12:Lcount35]
add x17, x17, #1
str x17, [x16, :lo12:Lcount35]
ldr x0, [sp, #48]
adrp x16, Lcount36
ldr x17, [x16, :lo12:Lcount36]
add x17, x17, #1
str x17, [x16, :lo12:Lcount36]
ldr w0, [x0, #72]
adrp x16, Lcount37
ldr x17, [x16, :lo12:Lcount37]
add x17, x17, #1
str x17, [x16, :lo12:Lcount37]
cmp w0, #9
adrp x16, Lcount38
ldr x17, [x16, :lo12:Lcount38]
add x17, x17, #1
str x17, [x16, :lo12:Lcount38]
b.eq Lfn1match118arm9
adrp x16, Lcount37
ldr x17, [x16, :lo12:Lcount37]
add x17, x17, #1
str x17, [x16, :lo12:Lcount37]
cmp w0, #10
adrp x16, Lcount38
ldr x17, [x16, :lo12:Lcount38]
add x17, x17, #1
str x17, [x16, :lo12:Lcount38]
b.eq Lfn1match118arm10
adrp x16, Lcount37
ldr x17, [x16, :lo12:Lcount37]
add x17, x17, #1
str x17, [x16, :lo12:Lcount37]
cmp w0, #11
adrp x16, Lcount38
ldr x17, [x16, :lo12:Lcount38]
add x17, x17, #1
str x17, [x16, :lo12:Lcount38]
b.eq Lfn1match118arm11
adrp x16, Lcount37
ldr x17, [x16, :lo12:Lcount37]
add x17, x17, #1
str x17, [x16, :lo12:Lcount37]
cmp w0, #12
adrp x16, Lcount38
ldr x17, [x16, :lo12:Lcount38]
add x17, x17, #1
str x17, [x16, :lo12:Lcount38]
b.eq Lfn1match118arm12
adrp x16, Lcount39
ldr x17, [x16, :lo12:Lcount39]
add x17, x17, #1
str x17, [x16, :lo12:Lcount39]
brk #0
Lfn1match118arm9:
adrp x16, Lcount40
ldr x17, [x16, :lo12:Lcount40]
add x17, x17, #1
str x17, [x16, :lo12:Lcount40]
bl fen_leave_result
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x8, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x8, x8, :lo12:Lconstant0
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x9, x19
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x10, x20
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x11, x21
adrp x16, Lcount28
ldr x17, [x16, :lo12:Lcount28]
add x17, x17, #1
str x17, [x16, :lo12:Lcount28]
ldp x19, x20, [x29, #-16]
adrp x16, Lcount28
ldr x17, [x16, :lo12:Lcount28]
add x17, x17, #1
str x17, [x16, :lo12:Lcount28]
ldp x21, x22, [x29, #-32]
adrp x16, Lcount28
ldr x17, [x16, :lo12:Lcount28]
add x17, x17, #1
str x17, [x16, :lo12:Lcount28]
ldp x23, xzr, [x29, #-48]
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov sp, x29
adrp x16, Lcount42
ldr x17, [x16, :lo12:Lcount42]
add x17, x17, #1
str x17, [x16, :lo12:Lcount42]
ldp x29, x30, [sp], #16
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn0fields
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1match118end
Lfn1match118arm10:
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x0, x19
adrp x16, Lcount44
ldr x17, [x16, :lo12:Lcount44]
add x17, x17, #1
str x17, [x16, :lo12:Lcount44]
asr x2, x0, #63
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x0, x0, x2, lsr #63
adrp x16, Lcount44
ldr x17, [x16, :lo12:Lcount44]
add x17, x17, #1
str x17, [x16, :lo12:Lcount44]
asr x0, x0, #1
adrp x16, Lcount45
ldr x17, [x16, :lo12:Lcount45]
add x17, x17, #1
str x17, [x16, :lo12:Lcount45]
lsl x2, x0, #1
adrp x16, Lcount37
ldr x17, [x16, :lo12:Lcount37]
add x17, x17, #1
str x17, [x16, :lo12:Lcount37]
cmp x0, x2, asr #1
adrp x16, Lcount46
ldr x17, [x16, :lo12:Lcount46]
add x17, x17, #1
str x17, [x16, :lo12:Lcount46]
b.ne Lfn1fail136_1
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x0, x2
adrp x16, Lcount32
ldr x17, [x16, :lo12:Lcount32]
add x17, x17, #1
str x17, [x16, :lo12:Lcount32]
str x0, [sp, #240]
adrp x16, Lcount35
ldr x17, [x16, :lo12:Lcount35]
add x17, x17, #1
str x17, [x16, :lo12:Lcount35]
ldr x0, [sp, #48]
adrp x16, Lcount36
ldr x17, [x16, :lo12:Lcount36]
add x17, x17, #1
str x17, [x16, :lo12:Lcount36]
ldr x0, [x0, #0]
adrp x16, Lcount35
ldr x17, [x16, :lo12:Lcount35]
add x17, x17, #1
str x17, [x16, :lo12:Lcount35]
ldr x2, [sp, #240]
adrp x16, Lcount37
ldr x17, [x16, :lo12:Lcount37]
add x17, x17, #1
str x17, [x16, :lo12:Lcount37]
cmp x0, x2
adrp x16, Lcount46
ldr x17, [x16, :lo12:Lcount46]
add x17, x17, #1
str x17, [x16, :lo12:Lcount46]
b.ne Lfn1if133else
adrp x16, Lcount40
ldr x17, [x16, :lo12:Lcount40]
add x17, x17, #1
str x17, [x16, :lo12:Lcount40]
bl fen_leave_result
adrp x16, Lcount35
ldr x17, [x16, :lo12:Lcount35]
add x17, x17, #1
str x17, [x16, :lo12:Lcount35]
ldr x8, [sp, #48]
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x9, x19
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x10, x20
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x11, x21
adrp x16, Lcount28
ldr x17, [x16, :lo12:Lcount28]
add x17, x17, #1
str x17, [x16, :lo12:Lcount28]
ldp x19, x20, [x29, #-16]
adrp x16, Lcount28
ldr x17, [x16, :lo12:Lcount28]
add x17, x17, #1
str x17, [x16, :lo12:Lcount28]
ldp x21, x22, [x29, #-32]
adrp x16, Lcount28
ldr x17, [x16, :lo12:Lcount28]
add x17, x17, #1
str x17, [x16, :lo12:Lcount28]
ldp x23, xzr, [x29, #-48]
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov sp, x29
adrp x16, Lcount42
ldr x17, [x16, :lo12:Lcount42]
add x17, x17, #1
str x17, [x16, :lo12:Lcount42]
ldp x29, x30, [sp], #16
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn0fields
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1if133done
Lfn1if133else:
adrp x16, Lcount35
ldr x17, [x16, :lo12:Lcount35]
add x17, x17, #1
str x17, [x16, :lo12:Lcount35]
ldr x0, [sp, #48]
adrp x16, Lcount36
ldr x17, [x16, :lo12:Lcount36]
add x17, x17, #1
str x17, [x16, :lo12:Lcount36]
ldr x0, [x0, #0]
adrp x16, Lcount37
ldr x17, [x16, :lo12:Lcount37]
add x17, x17, #1
str x17, [x16, :lo12:Lcount37]
cmp x0, #0
adrp x16, Lcount47
ldr x17, [x16, :lo12:Lcount47]
add x17, x17, #1
str x17, [x16, :lo12:Lcount47]
neg x2, x0
adrp x16, Lcount48
ldr x17, [x16, :lo12:Lcount48]
add x17, x17, #1
str x17, [x16, :lo12:Lcount48]
and x2, x2, #15
adrp x16, Lcount48
ldr x17, [x16, :lo12:Lcount48]
add x17, x17, #1
str x17, [x16, :lo12:Lcount48]
and x0, x0, #15
adrp x16, Lcount49
ldr x17, [x16, :lo12:Lcount49]
add x17, x17, #1
str x17, [x16, :lo12:Lcount49]
csneg x0, x0, x2, ge
adrp x16, Lcount44
ldr x17, [x16, :lo12:Lcount44]
add x17, x17, #1
str x17, [x16, :lo12:Lcount44]
asr x2, x0, #63
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x0, x0, x2, lsr #63
adrp x16, Lcount44
ldr x17, [x16, :lo12:Lcount44]
add x17, x17, #1
str x17, [x16, :lo12:Lcount44]
asr x0, x0, #1
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x22, x0
adrp x16, Lcount37
ldr x17, [x16, :lo12:Lcount37]
add x17, x17, #1
str x17, [x16, :lo12:Lcount37]
cmp x0, #4
adrp x16, Lcount50
ldr x17, [x16, :lo12:Lcount50]
add x17, x17, #1
str x17, [x16, :lo12:Lcount50]
b.ge Lfn1if160else
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x0, x22
adrp x16, Lcount37
ldr x17, [x16, :lo12:Lcount37]
add x17, x17, #1
str x17, [x16, :lo12:Lcount37]
cmp x0, #2
adrp x16, Lcount50
ldr x17, [x16, :lo12:Lcount50]
add x17, x17, #1
str x17, [x16, :lo12:Lcount50]
b.ge Lfn1if164else
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x0, x22
adrp x16, Lcount37
ldr x17, [x16, :lo12:Lcount37]
add x17, x17, #1
str x17, [x16, :lo12:Lcount37]
cmp x0, #1
adrp x16, Lcount50
ldr x17, [x16, :lo12:Lcount50]
add x17, x17, #1
str x17, [x16, :lo12:Lcount50]
b.ge Lfn1if168else
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x0, #255
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x1, #12
adrp x16, Lcount51
ldr x17, [x16, :lo12:Lcount51]
add x17, x17, #1
str x17, [x16, :lo12:Lcount51]
bl fen_allocate_full
adrp x16, Lcount52
ldr x17, [x16, :lo12:Lcount52]
add x17, x17, #1
str x17, [x16, :lo12:Lcount52]
cbz x0, Lfn1fail172_3
adrp x16, Lcount35
ldr x17, [x16, :lo12:Lcount35]
add x17, x17, #1
str x17, [x16, :lo12:Lcount35]
ldr x2, [sp, #48]
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x3, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x3, x3, :lo12:Lconstant0
adrp x16, Lcount53
ldr x17, [x16, :lo12:Lcount53]
add x17, x17, #1
str x17, [x16, :lo12:Lcount53]
stp x2, x3, [x0, #0]
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x2, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x2, x2, :lo12:Lconstant0
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x3, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x3, x3, :lo12:Lconstant0
adrp x16, Lcount53
ldr x17, [x16, :lo12:Lcount53]
add x17, x17, #1
str x17, [x16, :lo12:Lcount53]
stp x2, x3, [x0, #16]
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x2, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x2, x2, :lo12:Lconstant0
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x3, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x3, x3, :lo12:Lconstant0
adrp x16, Lcount53
ldr x17, [x16, :lo12:Lcount53]
add x17, x17, #1
str x17, [x16, :lo12:Lcount53]
stp x2, x3, [x0, #32]
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x2, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x2, x2, :lo12:Lconstant0
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x3, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x3, x3, :lo12:Lconstant0
adrp x16, Lcount53
ldr x17, [x16, :lo12:Lcount53]
add x17, x17, #1
str x17, [x16, :lo12:Lcount53]
stp x2, x3, [x0, #48]
adrp x16, Lcount32
ldr x17, [x16, :lo12:Lcount32]
add x17, x17, #1
str x17, [x16, :lo12:Lcount32]
str x0, [sp, #56]
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1if168done
Lfn1if168else:
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x0, #255
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x1, #12
adrp x16, Lcount51
ldr x17, [x16, :lo12:Lcount51]
add x17, x17, #1
str x17, [x16, :lo12:Lcount51]
bl fen_allocate_full
adrp x16, Lcount52
ldr x17, [x16, :lo12:Lcount52]
add x17, x17, #1
str x17, [x16, :lo12:Lcount52]
cbz x0, Lfn1fail181_3
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x2, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x2, x2, :lo12:Lconstant0
adrp x16, Lcount35
ldr x17, [x16, :lo12:Lcount35]
add x17, x17, #1
str x17, [x16, :lo12:Lcount35]
ldr x3, [sp, #48]
adrp x16, Lcount53
ldr x17, [x16, :lo12:Lcount53]
add x17, x17, #1
str x17, [x16, :lo12:Lcount53]
stp x2, x3, [x0, #0]
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x2, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x2, x2, :lo12:Lconstant0
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x3, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x3, x3, :lo12:Lconstant0
adrp x16, Lcount53
ldr x17, [x16, :lo12:Lcount53]
add x17, x17, #1
str x17, [x16, :lo12:Lcount53]
stp x2, x3, [x0, #16]
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x2, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x2, x2, :lo12:Lconstant0
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x3, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x3, x3, :lo12:Lconstant0
adrp x16, Lcount53
ldr x17, [x16, :lo12:Lcount53]
add x17, x17, #1
str x17, [x16, :lo12:Lcount53]
stp x2, x3, [x0, #32]
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x2, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x2, x2, :lo12:Lconstant0
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x3, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x3, x3, :lo12:Lconstant0
adrp x16, Lcount53
ldr x17, [x16, :lo12:Lcount53]
add x17, x17, #1
str x17, [x16, :lo12:Lcount53]
stp x2, x3, [x0, #48]
adrp x16, Lcount32
ldr x17, [x16, :lo12:Lcount32]
add x17, x17, #1
str x17, [x16, :lo12:Lcount32]
str x0, [sp, #64]
Lfn1if168done:
adrp x16, Lcount32
ldr x17, [x16, :lo12:Lcount32]
add x17, x17, #1
str x17, [x16, :lo12:Lcount32]
str x0, [sp, #72]
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1if164done
Lfn1if164else:
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x0, x22
adrp x16, Lcount37
ldr x17, [x16, :lo12:Lcount37]
add x17, x17, #1
str x17, [x16, :lo12:Lcount37]
cmp x0, #3
adrp x16, Lcount50
ldr x17, [x16, :lo12:Lcount50]
add x17, x17, #1
str x17, [x16, :lo12:Lcount50]
b.ge Lfn1if190else
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x0, #255
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x1, #12
adrp x16, Lcount51
ldr x17, [x16, :lo12:Lcount51]
add x17, x17, #1
str x17, [x16, :lo12:Lcount51]
bl fen_allocate_full
adrp x16, Lcount52
ldr x17, [x16, :lo12:Lcount52]
add x17, x17, #1
str x17, [x16, :lo12:Lcount52]
cbz x0, Lfn1fail194_3
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x2, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x2, x2, :lo12:Lconstant0
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x3, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x3, x3, :lo12:Lconstant0
adrp x16, Lcount53
ldr x17, [x16, :lo12:Lcount53]
add x17, x17, #1
str x17, [x16, :lo12:Lcount53]
stp x2, x3, [x0, #0]
adrp x16, Lcount35
ldr x17, [x16, :lo12:Lcount35]
add x17, x17, #1
str x17, [x16, :lo12:Lcount35]
ldr x2, [sp, #48]
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x3, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x3, x3, :lo12:Lconstant0
adrp x16, Lcount53
ldr x17, [x16, :lo12:Lcount53]
add x17, x17, #1
str x17, [x16, :lo12:Lcount53]
stp x2, x3, [x0, #16]
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x2, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x2, x2, :lo12:Lconstant0
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x3, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x3, x3, :lo12:Lconstant0
adrp x16, Lcount53
ldr x17, [x16, :lo12:Lcount53]
add x17, x17, #1
str x17, [x16, :lo12:Lcount53]
stp x2, x3, [x0, #32]
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x2, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x2, x2, :lo12:Lconstant0
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x3, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x3, x3, :lo12:Lconstant0
adrp x16, Lcount53
ldr x17, [x16, :lo12:Lcount53]
add x17, x17, #1
str x17, [x16, :lo12:Lcount53]
stp x2, x3, [x0, #48]
adrp x16, Lcount32
ldr x17, [x16, :lo12:Lcount32]
add x17, x17, #1
str x17, [x16, :lo12:Lcount32]
str x0, [sp, #80]
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1if190done
Lfn1if190else:
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x0, #255
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x1, #12
adrp x16, Lcount51
ldr x17, [x16, :lo12:Lcount51]
add x17, x17, #1
str x17, [x16, :lo12:Lcount51]
bl fen_allocate_full
adrp x16, Lcount52
ldr x17, [x16, :lo12:Lcount52]
add x17, x17, #1
str x17, [x16, :lo12:Lcount52]
cbz x0, Lfn1fail203_3
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x2, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x2, x2, :lo12:Lconstant0
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x3, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x3, x3, :lo12:Lconstant0
adrp x16, Lcount53
ldr x17, [x16, :lo12:Lcount53]
add x17, x17, #1
str x17, [x16, :lo12:Lcount53]
stp x2, x3, [x0, #0]
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x2, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x2, x2, :lo12:Lconstant0
adrp x16, Lcount35
ldr x17, [x16, :lo12:Lcount35]
add x17, x17, #1
str x17, [x16, :lo12:Lcount35]
ldr x3, [sp, #48]
adrp x16, Lcount53
ldr x17, [x16, :lo12:Lcount53]
add x17, x17, #1
str x17, [x16, :lo12:Lcount53]
stp x2, x3, [x0, #16]
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x2, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x2, x2, :lo12:Lconstant0
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x3, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x3, x3, :lo12:Lconstant0
adrp x16, Lcount53
ldr x17, [x16, :lo12:Lcount53]
add x17, x17, #1
str x17, [x16, :lo12:Lcount53]
stp x2, x3, [x0, #32]
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x2, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x2, x2, :lo12:Lconstant0
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x3, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x3, x3, :lo12:Lconstant0
adrp x16, Lcount53
ldr x17, [x16, :lo12:Lcount53]
add x17, x17, #1
str x17, [x16, :lo12:Lcount53]
stp x2, x3, [x0, #48]
adrp x16, Lcount32
ldr x17, [x16, :lo12:Lcount32]
add x17, x17, #1
str x17, [x16, :lo12:Lcount32]
str x0, [sp, #88]
Lfn1if190done:
adrp x16, Lcount32
ldr x17, [x16, :lo12:Lcount32]
add x17, x17, #1
str x17, [x16, :lo12:Lcount32]
str x0, [sp, #96]
Lfn1if164done:
adrp x16, Lcount32
ldr x17, [x16, :lo12:Lcount32]
add x17, x17, #1
str x17, [x16, :lo12:Lcount32]
str x0, [sp, #104]
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1if160done
Lfn1if160else:
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x0, x22
adrp x16, Lcount37
ldr x17, [x16, :lo12:Lcount37]
add x17, x17, #1
str x17, [x16, :lo12:Lcount37]
cmp x0, #6
adrp x16, Lcount50
ldr x17, [x16, :lo12:Lcount50]
add x17, x17, #1
str x17, [x16, :lo12:Lcount50]
b.ge Lfn1if212else
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x0, x22
adrp x16, Lcount37
ldr x17, [x16, :lo12:Lcount37]
add x17, x17, #1
str x17, [x16, :lo12:Lcount37]
cmp x0, #5
adrp x16, Lcount50
ldr x17, [x16, :lo12:Lcount50]
add x17, x17, #1
str x17, [x16, :lo12:Lcount50]
b.ge Lfn1if216else
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x0, #255
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x1, #12
adrp x16, Lcount51
ldr x17, [x16, :lo12:Lcount51]
add x17, x17, #1
str x17, [x16, :lo12:Lcount51]
bl fen_allocate_full
adrp x16, Lcount52
ldr x17, [x16, :lo12:Lcount52]
add x17, x17, #1
str x17, [x16, :lo12:Lcount52]
cbz x0, Lfn1fail220_3
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x2, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x2, x2, :lo12:Lconstant0
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x3, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x3, x3, :lo12:Lconstant0
adrp x16, Lcount53
ldr x17, [x16, :lo12:Lcount53]
add x17, x17, #1
str x17, [x16, :lo12:Lcount53]
stp x2, x3, [x0, #0]
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x2, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x2, x2, :lo12:Lconstant0
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x3, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x3, x3, :lo12:Lconstant0
adrp x16, Lcount53
ldr x17, [x16, :lo12:Lcount53]
add x17, x17, #1
str x17, [x16, :lo12:Lcount53]
stp x2, x3, [x0, #16]
adrp x16, Lcount35
ldr x17, [x16, :lo12:Lcount35]
add x17, x17, #1
str x17, [x16, :lo12:Lcount35]
ldr x2, [sp, #48]
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x3, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x3, x3, :lo12:Lconstant0
adrp x16, Lcount53
ldr x17, [x16, :lo12:Lcount53]
add x17, x17, #1
str x17, [x16, :lo12:Lcount53]
stp x2, x3, [x0, #32]
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x2, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x2, x2, :lo12:Lconstant0
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x3, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x3, x3, :lo12:Lconstant0
adrp x16, Lcount53
ldr x17, [x16, :lo12:Lcount53]
add x17, x17, #1
str x17, [x16, :lo12:Lcount53]
stp x2, x3, [x0, #48]
adrp x16, Lcount32
ldr x17, [x16, :lo12:Lcount32]
add x17, x17, #1
str x17, [x16, :lo12:Lcount32]
str x0, [sp, #112]
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1if216done
Lfn1if216else:
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x0, #255
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x1, #12
adrp x16, Lcount51
ldr x17, [x16, :lo12:Lcount51]
add x17, x17, #1
str x17, [x16, :lo12:Lcount51]
bl fen_allocate_full
adrp x16, Lcount52
ldr x17, [x16, :lo12:Lcount52]
add x17, x17, #1
str x17, [x16, :lo12:Lcount52]
cbz x0, Lfn1fail229_3
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x2, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x2, x2, :lo12:Lconstant0
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x3, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x3, x3, :lo12:Lconstant0
adrp x16, Lcount53
ldr x17, [x16, :lo12:Lcount53]
add x17, x17, #1
str x17, [x16, :lo12:Lcount53]
stp x2, x3, [x0, #0]
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x2, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x2, x2, :lo12:Lconstant0
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x3, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x3, x3, :lo12:Lconstant0
adrp x16, Lcount53
ldr x17, [x16, :lo12:Lcount53]
add x17, x17, #1
str x17, [x16, :lo12:Lcount53]
stp x2, x3, [x0, #16]
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x2, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x2, x2, :lo12:Lconstant0
adrp x16, Lcount35
ldr x17, [x16, :lo12:Lcount35]
add x17, x17, #1
str x17, [x16, :lo12:Lcount35]
ldr x3, [sp, #48]
adrp x16, Lcount53
ldr x17, [x16, :lo12:Lcount53]
add x17, x17, #1
str x17, [x16, :lo12:Lcount53]
stp x2, x3, [x0, #32]
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x2, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x2, x2, :lo12:Lconstant0
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x3, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x3, x3, :lo12:Lconstant0
adrp x16, Lcount53
ldr x17, [x16, :lo12:Lcount53]
add x17, x17, #1
str x17, [x16, :lo12:Lcount53]
stp x2, x3, [x0, #48]
adrp x16, Lcount32
ldr x17, [x16, :lo12:Lcount32]
add x17, x17, #1
str x17, [x16, :lo12:Lcount32]
str x0, [sp, #120]
Lfn1if216done:
adrp x16, Lcount32
ldr x17, [x16, :lo12:Lcount32]
add x17, x17, #1
str x17, [x16, :lo12:Lcount32]
str x0, [sp, #128]
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1if212done
Lfn1if212else:
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x0, x22
adrp x16, Lcount37
ldr x17, [x16, :lo12:Lcount37]
add x17, x17, #1
str x17, [x16, :lo12:Lcount37]
cmp x0, #7
adrp x16, Lcount50
ldr x17, [x16, :lo12:Lcount50]
add x17, x17, #1
str x17, [x16, :lo12:Lcount50]
b.ge Lfn1if238else
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x0, #255
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x1, #12
adrp x16, Lcount51
ldr x17, [x16, :lo12:Lcount51]
add x17, x17, #1
str x17, [x16, :lo12:Lcount51]
bl fen_allocate_full
adrp x16, Lcount52
ldr x17, [x16, :lo12:Lcount52]
add x17, x17, #1
str x17, [x16, :lo12:Lcount52]
cbz x0, Lfn1fail242_3
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x2, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x2, x2, :lo12:Lconstant0
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x3, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x3, x3, :lo12:Lconstant0
adrp x16, Lcount53
ldr x17, [x16, :lo12:Lcount53]
add x17, x17, #1
str x17, [x16, :lo12:Lcount53]
stp x2, x3, [x0, #0]
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x2, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x2, x2, :lo12:Lconstant0
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x3, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x3, x3, :lo12:Lconstant0
adrp x16, Lcount53
ldr x17, [x16, :lo12:Lcount53]
add x17, x17, #1
str x17, [x16, :lo12:Lcount53]
stp x2, x3, [x0, #16]
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x2, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x2, x2, :lo12:Lconstant0
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x3, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x3, x3, :lo12:Lconstant0
adrp x16, Lcount53
ldr x17, [x16, :lo12:Lcount53]
add x17, x17, #1
str x17, [x16, :lo12:Lcount53]
stp x2, x3, [x0, #32]
adrp x16, Lcount35
ldr x17, [x16, :lo12:Lcount35]
add x17, x17, #1
str x17, [x16, :lo12:Lcount35]
ldr x2, [sp, #48]
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x3, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x3, x3, :lo12:Lconstant0
adrp x16, Lcount53
ldr x17, [x16, :lo12:Lcount53]
add x17, x17, #1
str x17, [x16, :lo12:Lcount53]
stp x2, x3, [x0, #48]
adrp x16, Lcount32
ldr x17, [x16, :lo12:Lcount32]
add x17, x17, #1
str x17, [x16, :lo12:Lcount32]
str x0, [sp, #136]
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1if238done
Lfn1if238else:
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x0, #255
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x1, #12
adrp x16, Lcount51
ldr x17, [x16, :lo12:Lcount51]
add x17, x17, #1
str x17, [x16, :lo12:Lcount51]
bl fen_allocate_full
adrp x16, Lcount52
ldr x17, [x16, :lo12:Lcount52]
add x17, x17, #1
str x17, [x16, :lo12:Lcount52]
cbz x0, Lfn1fail251_3
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x2, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x2, x2, :lo12:Lconstant0
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x3, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x3, x3, :lo12:Lconstant0
adrp x16, Lcount53
ldr x17, [x16, :lo12:Lcount53]
add x17, x17, #1
str x17, [x16, :lo12:Lcount53]
stp x2, x3, [x0, #0]
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x2, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x2, x2, :lo12:Lconstant0
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x3, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x3, x3, :lo12:Lconstant0
adrp x16, Lcount53
ldr x17, [x16, :lo12:Lcount53]
add x17, x17, #1
str x17, [x16, :lo12:Lcount53]
stp x2, x3, [x0, #16]
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x2, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x2, x2, :lo12:Lconstant0
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x3, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x3, x3, :lo12:Lconstant0
adrp x16, Lcount53
ldr x17, [x16, :lo12:Lcount53]
add x17, x17, #1
str x17, [x16, :lo12:Lcount53]
stp x2, x3, [x0, #32]
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x2, Lconstant0
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x2, x2, :lo12:Lconstant0
adrp x16, Lcount35
ldr x17, [x16, :lo12:Lcount35]
add x17, x17, #1
str x17, [x16, :lo12:Lcount35]
ldr x3, [sp, #48]
adrp x16, Lcount53
ldr x17, [x16, :lo12:Lcount53]
add x17, x17, #1
str x17, [x16, :lo12:Lcount53]
stp x2, x3, [x0, #48]
adrp x16, Lcount32
ldr x17, [x16, :lo12:Lcount32]
add x17, x17, #1
str x17, [x16, :lo12:Lcount32]
str x0, [sp, #144]
Lfn1if238done:
adrp x16, Lcount32
ldr x17, [x16, :lo12:Lcount32]
add x17, x17, #1
str x17, [x16, :lo12:Lcount32]
str x0, [sp, #152]
Lfn1if212done:
adrp x16, Lcount32
ldr x17, [x16, :lo12:Lcount32]
add x17, x17, #1
str x17, [x16, :lo12:Lcount32]
str x0, [sp, #160]
Lfn1if160done:
adrp x16, Lcount32
ldr x17, [x16, :lo12:Lcount32]
add x17, x17, #1
str x17, [x16, :lo12:Lcount32]
str x0, [sp, #168]
adrp x16, Lcount35
ldr x17, [x16, :lo12:Lcount35]
add x17, x17, #1
str x17, [x16, :lo12:Lcount35]
ldr x8, [sp, #168]
adrp x16, Lcount32
ldr x17, [x16, :lo12:Lcount32]
add x17, x17, #1
str x17, [x16, :lo12:Lcount32]
str x8, [sp, #48]
adrp x16, Lcount29
ldr x17, [x16, :lo12:Lcount29]
add x17, x17, #1
str x17, [x16, :lo12:Lcount29]
stp xzr, xzr, [sp, #56]
adrp x16, Lcount29
ldr x17, [x16, :lo12:Lcount29]
add x17, x17, #1
str x17, [x16, :lo12:Lcount29]
stp xzr, xzr, [sp, #72]
adrp x16, Lcount29
ldr x17, [x16, :lo12:Lcount29]
add x17, x17, #1
str x17, [x16, :lo12:Lcount29]
stp xzr, xzr, [sp, #88]
adrp x16, Lcount29
ldr x17, [x16, :lo12:Lcount29]
add x17, x17, #1
str x17, [x16, :lo12:Lcount29]
stp xzr, xzr, [sp, #104]
adrp x16, Lcount29
ldr x17, [x16, :lo12:Lcount29]
add x17, x17, #1
str x17, [x16, :lo12:Lcount29]
stp xzr, xzr, [sp, #120]
adrp x16, Lcount29
ldr x17, [x16, :lo12:Lcount29]
add x17, x17, #1
str x17, [x16, :lo12:Lcount29]
stp xzr, xzr, [sp, #136]
adrp x16, Lcount29
ldr x17, [x16, :lo12:Lcount29]
add x17, x17, #1
str x17, [x16, :lo12:Lcount29]
stp xzr, xzr, [sp, #152]
adrp x16, Lcount29
ldr x17, [x16, :lo12:Lcount29]
add x17, x17, #1
str x17, [x16, :lo12:Lcount29]
stp xzr, xzr, [sp, #168]
adrp x16, Lcount29
ldr x17, [x16, :lo12:Lcount29]
add x17, x17, #1
str x17, [x16, :lo12:Lcount29]
stp xzr, xzr, [sp, #184]
adrp x16, Lcount29
ldr x17, [x16, :lo12:Lcount29]
add x17, x17, #1
str x17, [x16, :lo12:Lcount29]
stp xzr, xzr, [sp, #200]
adrp x16, Lcount29
ldr x17, [x16, :lo12:Lcount29]
add x17, x17, #1
str x17, [x16, :lo12:Lcount29]
stp xzr, xzr, [sp, #216]
adrp x16, Lcount32
ldr x17, [x16, :lo12:Lcount32]
add x17, x17, #1
str x17, [x16, :lo12:Lcount32]
str xzr, [sp, #232]
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1loop
Lfn1if133done:
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1match118end
Lfn1match118arm11:
adrp x16, Lcount35
ldr x17, [x16, :lo12:Lcount35]
add x17, x17, #1
str x17, [x16, :lo12:Lcount35]
ldr x0, [sp, #48]
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1match118end
Lfn1match118arm12:
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x0, x19
adrp x16, Lcount37
ldr x17, [x16, :lo12:Lcount37]
add x17, x17, #1
str x17, [x16, :lo12:Lcount37]
cmp x0, #0
adrp x16, Lcount47
ldr x17, [x16, :lo12:Lcount47]
add x17, x17, #1
str x17, [x16, :lo12:Lcount47]
neg x2, x0
adrp x16, Lcount48
ldr x17, [x16, :lo12:Lcount48]
add x17, x17, #1
str x17, [x16, :lo12:Lcount48]
and x2, x2, #15
adrp x16, Lcount48
ldr x17, [x16, :lo12:Lcount48]
add x17, x17, #1
str x17, [x16, :lo12:Lcount48]
and x0, x0, #15
adrp x16, Lcount49
ldr x17, [x16, :lo12:Lcount49]
add x17, x17, #1
str x17, [x16, :lo12:Lcount49]
csneg x0, x0, x2, ge
adrp x16, Lcount44
ldr x17, [x16, :lo12:Lcount44]
add x17, x17, #1
str x17, [x16, :lo12:Lcount44]
asr x2, x0, #63
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x0, x0, x2, lsr #63
adrp x16, Lcount44
ldr x17, [x16, :lo12:Lcount44]
add x17, x17, #1
str x17, [x16, :lo12:Lcount44]
asr x0, x0, #1
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x23, x0
adrp x16, Lcount37
ldr x17, [x16, :lo12:Lcount37]
add x17, x17, #1
str x17, [x16, :lo12:Lcount37]
cmp x0, #4
adrp x16, Lcount50
ldr x17, [x16, :lo12:Lcount50]
add x17, x17, #1
str x17, [x16, :lo12:Lcount50]
b.ge Lfn1if287else
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x0, x23
adrp x16, Lcount37
ldr x17, [x16, :lo12:Lcount37]
add x17, x17, #1
str x17, [x16, :lo12:Lcount37]
cmp x0, #2
adrp x16, Lcount50
ldr x17, [x16, :lo12:Lcount50]
add x17, x17, #1
str x17, [x16, :lo12:Lcount50]
b.ge Lfn1if291else
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x0, x23
adrp x16, Lcount37
ldr x17, [x16, :lo12:Lcount37]
add x17, x17, #1
str x17, [x16, :lo12:Lcount37]
cmp x0, #1
adrp x16, Lcount50
ldr x17, [x16, :lo12:Lcount50]
add x17, x17, #1
str x17, [x16, :lo12:Lcount50]
b.ge Lfn1if295else
adrp x16, Lcount35
ldr x17, [x16, :lo12:Lcount35]
add x17, x17, #1
str x17, [x16, :lo12:Lcount35]
ldr x8, [sp, #48]
adrp x16, Lcount36
ldr x17, [x16, :lo12:Lcount36]
add x17, x17, #1
str x17, [x16, :lo12:Lcount36]
ldr x8, [x8, #0]
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x9, x19
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x10, x20
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x11, x21
adrp x16, Lcount54
ldr x17, [x16, :lo12:Lcount54]
add x17, x17, #1
str x17, [x16, :lo12:Lcount54]
bl Lfn0fields
adrp x16, Lcount55
ldr x17, [x16, :lo12:Lcount55]
add x17, x17, #1
str x17, [x16, :lo12:Lcount55]
cbnz x1, Lfn1end
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x2, x0
adrp x16, Lcount35
ldr x17, [x16, :lo12:Lcount35]
add x17, x17, #1
str x17, [x16, :lo12:Lcount35]
ldr x0, [sp, #48]
adrp x16, Lcount56
ldr x17, [x16, :lo12:Lcount56]
add x17, x17, #1
str x17, [x16, :lo12:Lcount56]
str x2, [x0, #0]
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1if295done
Lfn1if295else:
adrp x16, Lcount35
ldr x17, [x16, :lo12:Lcount35]
add x17, x17, #1
str x17, [x16, :lo12:Lcount35]
ldr x8, [sp, #48]
adrp x16, Lcount36
ldr x17, [x16, :lo12:Lcount36]
add x17, x17, #1
str x17, [x16, :lo12:Lcount36]
ldr x8, [x8, #8]
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x9, x19
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x10, x20
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x11, x21
adrp x16, Lcount54
ldr x17, [x16, :lo12:Lcount54]
add x17, x17, #1
str x17, [x16, :lo12:Lcount54]
bl Lfn0fields
adrp x16, Lcount55
ldr x17, [x16, :lo12:Lcount55]
add x17, x17, #1
str x17, [x16, :lo12:Lcount55]
cbnz x1, Lfn1end
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x2, x0
adrp x16, Lcount35
ldr x17, [x16, :lo12:Lcount35]
add x17, x17, #1
str x17, [x16, :lo12:Lcount35]
ldr x0, [sp, #48]
adrp x16, Lcount56
ldr x17, [x16, :lo12:Lcount56]
add x17, x17, #1
str x17, [x16, :lo12:Lcount56]
str x2, [x0, #8]
Lfn1if295done:
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1if291done
Lfn1if291else:
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x0, x23
adrp x16, Lcount37
ldr x17, [x16, :lo12:Lcount37]
add x17, x17, #1
str x17, [x16, :lo12:Lcount37]
cmp x0, #3
adrp x16, Lcount50
ldr x17, [x16, :lo12:Lcount50]
add x17, x17, #1
str x17, [x16, :lo12:Lcount50]
b.ge Lfn1if327else
adrp x16, Lcount35
ldr x17, [x16, :lo12:Lcount35]
add x17, x17, #1
str x17, [x16, :lo12:Lcount35]
ldr x8, [sp, #48]
adrp x16, Lcount36
ldr x17, [x16, :lo12:Lcount36]
add x17, x17, #1
str x17, [x16, :lo12:Lcount36]
ldr x8, [x8, #16]
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x9, x19
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x10, x20
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x11, x21
adrp x16, Lcount54
ldr x17, [x16, :lo12:Lcount54]
add x17, x17, #1
str x17, [x16, :lo12:Lcount54]
bl Lfn0fields
adrp x16, Lcount55
ldr x17, [x16, :lo12:Lcount55]
add x17, x17, #1
str x17, [x16, :lo12:Lcount55]
cbnz x1, Lfn1end
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x2, x0
adrp x16, Lcount35
ldr x17, [x16, :lo12:Lcount35]
add x17, x17, #1
str x17, [x16, :lo12:Lcount35]
ldr x0, [sp, #48]
adrp x16, Lcount56
ldr x17, [x16, :lo12:Lcount56]
add x17, x17, #1
str x17, [x16, :lo12:Lcount56]
str x2, [x0, #16]
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1if327done
Lfn1if327else:
adrp x16, Lcount35
ldr x17, [x16, :lo12:Lcount35]
add x17, x17, #1
str x17, [x16, :lo12:Lcount35]
ldr x8, [sp, #48]
adrp x16, Lcount36
ldr x17, [x16, :lo12:Lcount36]
add x17, x17, #1
str x17, [x16, :lo12:Lcount36]
ldr x8, [x8, #24]
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x9, x19
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x10, x20
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x11, x21
adrp x16, Lcount54
ldr x17, [x16, :lo12:Lcount54]
add x17, x17, #1
str x17, [x16, :lo12:Lcount54]
bl Lfn0fields
adrp x16, Lcount55
ldr x17, [x16, :lo12:Lcount55]
add x17, x17, #1
str x17, [x16, :lo12:Lcount55]
cbnz x1, Lfn1end
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x2, x0
adrp x16, Lcount35
ldr x17, [x16, :lo12:Lcount35]
add x17, x17, #1
str x17, [x16, :lo12:Lcount35]
ldr x0, [sp, #48]
adrp x16, Lcount56
ldr x17, [x16, :lo12:Lcount56]
add x17, x17, #1
str x17, [x16, :lo12:Lcount56]
str x2, [x0, #24]
Lfn1if327done:
Lfn1if291done:
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1if287done
Lfn1if287else:
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x0, x23
adrp x16, Lcount37
ldr x17, [x16, :lo12:Lcount37]
add x17, x17, #1
str x17, [x16, :lo12:Lcount37]
cmp x0, #6
adrp x16, Lcount50
ldr x17, [x16, :lo12:Lcount50]
add x17, x17, #1
str x17, [x16, :lo12:Lcount50]
b.ge Lfn1if359else
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x0, x23
adrp x16, Lcount37
ldr x17, [x16, :lo12:Lcount37]
add x17, x17, #1
str x17, [x16, :lo12:Lcount37]
cmp x0, #5
adrp x16, Lcount50
ldr x17, [x16, :lo12:Lcount50]
add x17, x17, #1
str x17, [x16, :lo12:Lcount50]
b.ge Lfn1if363else
adrp x16, Lcount35
ldr x17, [x16, :lo12:Lcount35]
add x17, x17, #1
str x17, [x16, :lo12:Lcount35]
ldr x8, [sp, #48]
adrp x16, Lcount36
ldr x17, [x16, :lo12:Lcount36]
add x17, x17, #1
str x17, [x16, :lo12:Lcount36]
ldr x8, [x8, #32]
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x9, x19
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x10, x20
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x11, x21
adrp x16, Lcount54
ldr x17, [x16, :lo12:Lcount54]
add x17, x17, #1
str x17, [x16, :lo12:Lcount54]
bl Lfn0fields
adrp x16, Lcount55
ldr x17, [x16, :lo12:Lcount55]
add x17, x17, #1
str x17, [x16, :lo12:Lcount55]
cbnz x1, Lfn1end
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x2, x0
adrp x16, Lcount35
ldr x17, [x16, :lo12:Lcount35]
add x17, x17, #1
str x17, [x16, :lo12:Lcount35]
ldr x0, [sp, #48]
adrp x16, Lcount56
ldr x17, [x16, :lo12:Lcount56]
add x17, x17, #1
str x17, [x16, :lo12:Lcount56]
str x2, [x0, #32]
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1if363done
Lfn1if363else:
adrp x16, Lcount35
ldr x17, [x16, :lo12:Lcount35]
add x17, x17, #1
str x17, [x16, :lo12:Lcount35]
ldr x8, [sp, #48]
adrp x16, Lcount36
ldr x17, [x16, :lo12:Lcount36]
add x17, x17, #1
str x17, [x16, :lo12:Lcount36]
ldr x8, [x8, #40]
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x9, x19
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x10, x20
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x11, x21
adrp x16, Lcount54
ldr x17, [x16, :lo12:Lcount54]
add x17, x17, #1
str x17, [x16, :lo12:Lcount54]
bl Lfn0fields
adrp x16, Lcount55
ldr x17, [x16, :lo12:Lcount55]
add x17, x17, #1
str x17, [x16, :lo12:Lcount55]
cbnz x1, Lfn1end
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x2, x0
adrp x16, Lcount35
ldr x17, [x16, :lo12:Lcount35]
add x17, x17, #1
str x17, [x16, :lo12:Lcount35]
ldr x0, [sp, #48]
adrp x16, Lcount56
ldr x17, [x16, :lo12:Lcount56]
add x17, x17, #1
str x17, [x16, :lo12:Lcount56]
str x2, [x0, #40]
Lfn1if363done:
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1if359done
Lfn1if359else:
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x0, x23
adrp x16, Lcount37
ldr x17, [x16, :lo12:Lcount37]
add x17, x17, #1
str x17, [x16, :lo12:Lcount37]
cmp x0, #7
adrp x16, Lcount50
ldr x17, [x16, :lo12:Lcount50]
add x17, x17, #1
str x17, [x16, :lo12:Lcount50]
b.ge Lfn1if395else
adrp x16, Lcount35
ldr x17, [x16, :lo12:Lcount35]
add x17, x17, #1
str x17, [x16, :lo12:Lcount35]
ldr x8, [sp, #48]
adrp x16, Lcount36
ldr x17, [x16, :lo12:Lcount36]
add x17, x17, #1
str x17, [x16, :lo12:Lcount36]
ldr x8, [x8, #48]
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x9, x19
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x10, x20
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x11, x21
adrp x16, Lcount54
ldr x17, [x16, :lo12:Lcount54]
add x17, x17, #1
str x17, [x16, :lo12:Lcount54]
bl Lfn0fields
adrp x16, Lcount55
ldr x17, [x16, :lo12:Lcount55]
add x17, x17, #1
str x17, [x16, :lo12:Lcount55]
cbnz x1, Lfn1end
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x2, x0
adrp x16, Lcount35
ldr x17, [x16, :lo12:Lcount35]
add x17, x17, #1
str x17, [x16, :lo12:Lcount35]
ldr x0, [sp, #48]
adrp x16, Lcount56
ldr x17, [x16, :lo12:Lcount56]
add x17, x17, #1
str x17, [x16, :lo12:Lcount56]
str x2, [x0, #48]
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1if395done
Lfn1if395else:
adrp x16, Lcount35
ldr x17, [x16, :lo12:Lcount35]
add x17, x17, #1
str x17, [x16, :lo12:Lcount35]
ldr x8, [sp, #48]
adrp x16, Lcount36
ldr x17, [x16, :lo12:Lcount36]
add x17, x17, #1
str x17, [x16, :lo12:Lcount36]
ldr x8, [x8, #56]
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x9, x19
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x10, x20
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x11, x21
adrp x16, Lcount54
ldr x17, [x16, :lo12:Lcount54]
add x17, x17, #1
str x17, [x16, :lo12:Lcount54]
bl Lfn0fields
adrp x16, Lcount55
ldr x17, [x16, :lo12:Lcount55]
add x17, x17, #1
str x17, [x16, :lo12:Lcount55]
cbnz x1, Lfn1end
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x2, x0
adrp x16, Lcount35
ldr x17, [x16, :lo12:Lcount35]
add x17, x17, #1
str x17, [x16, :lo12:Lcount35]
ldr x0, [sp, #48]
adrp x16, Lcount56
ldr x17, [x16, :lo12:Lcount56]
add x17, x17, #1
str x17, [x16, :lo12:Lcount56]
str x2, [x0, #56]
Lfn1if395done:
Lfn1if359done:
Lfn1if287done:
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1match118end
Lfn1match118end:
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x1, #0
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1end
Lfn1fail136_1:
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x0, Lfn1fail136_1location
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x0, x0, :lo12:Lfn1fail136_1location
adrp x16, Lcount57
ldr x17, [x16, :lo12:Lcount57]
add x17, x17, #1
str x17, [x16, :lo12:Lcount57]
bl fen_set_location
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x1, #1
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1end
Lfn1fail172_3:
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x0, Lfn1fail172_3location
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x0, x0, :lo12:Lfn1fail172_3location
adrp x16, Lcount57
ldr x17, [x16, :lo12:Lcount57]
add x17, x17, #1
str x17, [x16, :lo12:Lcount57]
bl fen_set_location
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x1, #3
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1end
Lfn1fail181_3:
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x0, Lfn1fail181_3location
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x0, x0, :lo12:Lfn1fail181_3location
adrp x16, Lcount57
ldr x17, [x16, :lo12:Lcount57]
add x17, x17, #1
str x17, [x16, :lo12:Lcount57]
bl fen_set_location
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x1, #3
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1end
Lfn1fail194_3:
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x0, Lfn1fail194_3location
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x0, x0, :lo12:Lfn1fail194_3location
adrp x16, Lcount57
ldr x17, [x16, :lo12:Lcount57]
add x17, x17, #1
str x17, [x16, :lo12:Lcount57]
bl fen_set_location
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x1, #3
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1end
Lfn1fail203_3:
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x0, Lfn1fail203_3location
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x0, x0, :lo12:Lfn1fail203_3location
adrp x16, Lcount57
ldr x17, [x16, :lo12:Lcount57]
add x17, x17, #1
str x17, [x16, :lo12:Lcount57]
bl fen_set_location
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x1, #3
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1end
Lfn1fail220_3:
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x0, Lfn1fail220_3location
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x0, x0, :lo12:Lfn1fail220_3location
adrp x16, Lcount57
ldr x17, [x16, :lo12:Lcount57]
add x17, x17, #1
str x17, [x16, :lo12:Lcount57]
bl fen_set_location
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x1, #3
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1end
Lfn1fail229_3:
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x0, Lfn1fail229_3location
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x0, x0, :lo12:Lfn1fail229_3location
adrp x16, Lcount57
ldr x17, [x16, :lo12:Lcount57]
add x17, x17, #1
str x17, [x16, :lo12:Lcount57]
bl fen_set_location
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x1, #3
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1end
Lfn1fail242_3:
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x0, Lfn1fail242_3location
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x0, x0, :lo12:Lfn1fail242_3location
adrp x16, Lcount57
ldr x17, [x16, :lo12:Lcount57]
add x17, x17, #1
str x17, [x16, :lo12:Lcount57]
bl fen_set_location
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x1, #3
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1end
Lfn1fail251_3:
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x0, Lfn1fail251_3location
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x0, x0, :lo12:Lfn1fail251_3location
adrp x16, Lcount57
ldr x17, [x16, :lo12:Lcount57]
add x17, x17, #1
str x17, [x16, :lo12:Lcount57]
bl fen_set_location
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x1, #3
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1end
Lfn1fail299_3:
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x0, Lfn1fail299_3location
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x0, x0, :lo12:Lfn1fail299_3location
adrp x16, Lcount57
ldr x17, [x16, :lo12:Lcount57]
add x17, x17, #1
str x17, [x16, :lo12:Lcount57]
bl fen_set_location
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x1, #3
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1end
Lfn1fail313_3:
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x0, Lfn1fail313_3location
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x0, x0, :lo12:Lfn1fail313_3location
adrp x16, Lcount57
ldr x17, [x16, :lo12:Lcount57]
add x17, x17, #1
str x17, [x16, :lo12:Lcount57]
bl fen_set_location
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x1, #3
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1end
Lfn1fail331_3:
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x0, Lfn1fail331_3location
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x0, x0, :lo12:Lfn1fail331_3location
adrp x16, Lcount57
ldr x17, [x16, :lo12:Lcount57]
add x17, x17, #1
str x17, [x16, :lo12:Lcount57]
bl fen_set_location
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x1, #3
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1end
Lfn1fail345_3:
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x0, Lfn1fail345_3location
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x0, x0, :lo12:Lfn1fail345_3location
adrp x16, Lcount57
ldr x17, [x16, :lo12:Lcount57]
add x17, x17, #1
str x17, [x16, :lo12:Lcount57]
bl fen_set_location
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x1, #3
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1end
Lfn1fail367_3:
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x0, Lfn1fail367_3location
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x0, x0, :lo12:Lfn1fail367_3location
adrp x16, Lcount57
ldr x17, [x16, :lo12:Lcount57]
add x17, x17, #1
str x17, [x16, :lo12:Lcount57]
bl fen_set_location
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x1, #3
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1end
Lfn1fail381_3:
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x0, Lfn1fail381_3location
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x0, x0, :lo12:Lfn1fail381_3location
adrp x16, Lcount57
ldr x17, [x16, :lo12:Lcount57]
add x17, x17, #1
str x17, [x16, :lo12:Lcount57]
bl fen_set_location
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x1, #3
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1end
Lfn1fail399_3:
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x0, Lfn1fail399_3location
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x0, x0, :lo12:Lfn1fail399_3location
adrp x16, Lcount57
ldr x17, [x16, :lo12:Lcount57]
add x17, x17, #1
str x17, [x16, :lo12:Lcount57]
bl fen_set_location
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x1, #3
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1end
Lfn1fail413_3:
adrp x16, Lcount41
ldr x17, [x16, :lo12:Lcount41]
add x17, x17, #1
str x17, [x16, :lo12:Lcount41]
adrp x0, Lfn1fail413_3location
adrp x16, Lcount33
ldr x17, [x16, :lo12:Lcount33]
add x17, x17, #1
str x17, [x16, :lo12:Lcount33]
add x0, x0, :lo12:Lfn1fail413_3location
adrp x16, Lcount57
ldr x17, [x16, :lo12:Lcount57]
add x17, x17, #1
str x17, [x16, :lo12:Lcount57]
bl fen_set_location
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov x1, #3
adrp x16, Lcount43
ldr x17, [x16, :lo12:Lcount43]
add x17, x17, #1
str x17, [x16, :lo12:Lcount43]
b Lfn1end
Lfn1end:
adrp x16, Lcount40
ldr x17, [x16, :lo12:Lcount40]
add x17, x17, #1
str x17, [x16, :lo12:Lcount40]
bl fen_leave_result
adrp x16, Lcount28
ldr x17, [x16, :lo12:Lcount28]
add x17, x17, #1
str x17, [x16, :lo12:Lcount28]
ldp x19, x20, [x29, #-16]
adrp x16, Lcount28
ldr x17, [x16, :lo12:Lcount28]
add x17, x17, #1
str x17, [x16, :lo12:Lcount28]
ldp x21, x22, [x29, #-32]
adrp x16, Lcount28
ldr x17, [x16, :lo12:Lcount28]
add x17, x17, #1
str x17, [x16, :lo12:Lcount28]
ldp x23, xzr, [x29, #-48]
adrp x16, Lcount30
ldr x17, [x16, :lo12:Lcount30]
add x17, x17, #1
str x17, [x16, :lo12:Lcount30]
mov sp, x29
adrp x16, Lcount42
ldr x17, [x16, :lo12:Lcount42]
add x17, x17, #1
str x17, [x16, :lo12:Lcount42]
ldp x29, x30, [sp], #16
adrp x16, Lcount58
ldr x17, [x16, :lo12:Lcount58]
add x17, x17, #1
str x17, [x16, :lo12:Lcount58]
ret
Lfn2:
adrp x16, Lcount59
ldr x17, [x16, :lo12:Lcount59]
add x17, x17, #1
str x17, [x16, :lo12:Lcount59]
ldp x8, x9, [x0, #0]
adrp x16, Lcount59
ldr x17, [x16, :lo12:Lcount59]
add x17, x17, #1
str x17, [x16, :lo12:Lcount59]
ldp x10, x11, [x0, #16]
Lfn2fields:
adrp x16, Lcount60
ldr x17, [x16, :lo12:Lcount60]
add x17, x17, #1
str x17, [x16, :lo12:Lcount60]
stp x29, x30, [sp, #-16]!
adrp x16, Lcount61
ldr x17, [x16, :lo12:Lcount61]
add x17, x17, #1
str x17, [x16, :lo12:Lcount61]
mov x29, sp
adrp x16, Lcount60
ldr x17, [x16, :lo12:Lcount60]
add x17, x17, #1
str x17, [x16, :lo12:Lcount60]
stp x19, x20, [sp, #-16]!
adrp x16, Lcount60
ldr x17, [x16, :lo12:Lcount60]
add x17, x17, #1
str x17, [x16, :lo12:Lcount60]
stp x21, x22, [sp, #-16]!
adrp x16, Lcount62
ldr x17, [x16, :lo12:Lcount62]
add x17, x17, #1
str x17, [x16, :lo12:Lcount62]
sub sp, sp, #96
adrp x16, Lcount60
ldr x17, [x16, :lo12:Lcount60]
add x17, x17, #1
str x17, [x16, :lo12:Lcount60]
stp xzr, xzr, [sp, #56]
adrp x16, Lcount60
ldr x17, [x16, :lo12:Lcount60]
add x17, x17, #1
str x17, [x16, :lo12:Lcount60]
stp xzr, xzr, [sp, #72]
adrp x16, Lcount63
ldr x17, [x16, :lo12:Lcount63]
add x17, x17, #1
str x17, [x16, :lo12:Lcount63]
str x8, [sp, #48]
adrp x16, Lcount61
ldr x17, [x16, :lo12:Lcount61]
add x17, x17, #1
str x17, [x16, :lo12:Lcount61]
mov x19, x9
adrp x16, Lcount61
ldr x17, [x16, :lo12:Lcount61]
add x17, x17, #1
str x17, [x16, :lo12:Lcount61]
mov x20, x10
adrp x16, Lcount61
ldr x17, [x16, :lo12:Lcount61]
add x17, x17, #1
str x17, [x16, :lo12:Lcount61]
mov x21, x11
adrp x16, Lcount64
ldr x17, [x16, :lo12:Lcount64]
add x17, x17, #1
str x17, [x16, :lo12:Lcount64]
add x0, sp, #16
adrp x16, Lcount64
ldr x17, [x16, :lo12:Lcount64]
add x17, x17, #1
str x17, [x16, :lo12:Lcount64]
add x1, sp, #48
adrp x16, Lcount61
ldr x17, [x16, :lo12:Lcount61]
add x17, x17, #1
str x17, [x16, :lo12:Lcount61]
mov x2, #5
adrp x16, Lcount65
ldr x17, [x16, :lo12:Lcount65]
add x17, x17, #1
str x17, [x16, :lo12:Lcount65]
bl fen_enter
Lfn2loop:
adrp x16, Lcount66
ldr x17, [x16, :lo12:Lcount66]
add x17, x17, #1
str x17, [x16, :lo12:Lcount66]
ldr x0, [sp, #48]
adrp x16, Lcount67
ldr x17, [x16, :lo12:Lcount67]
add x17, x17, #1
str x17, [x16, :lo12:Lcount67]
ldr w0, [x0, #72]
adrp x16, Lcount68
ldr x17, [x16, :lo12:Lcount68]
add x17, x17, #1
str x17, [x16, :lo12:Lcount68]
cmp w0, #9
adrp x16, Lcount69
ldr x17, [x16, :lo12:Lcount69]
add x17, x17, #1
str x17, [x16, :lo12:Lcount69]
b.eq Lfn2match445arm9
adrp x16, Lcount68
ldr x17, [x16, :lo12:Lcount68]
add x17, x17, #1
str x17, [x16, :lo12:Lcount68]
cmp w0, #10
adrp x16, Lcount69
ldr x17, [x16, :lo12:Lcount69]
add x17, x17, #1
str x17, [x16, :lo12:Lcount69]
b.eq Lfn2match445arm10
adrp x16, Lcount68
ldr x17, [x16, :lo12:Lcount68]
add x17, x17, #1
str x17, [x16, :lo12:Lcount68]
cmp w0, #12
adrp x16, Lcount69
ldr x17, [x16, :lo12:Lcount69]
add x17, x17, #1
str x17, [x16, :lo12:Lcount69]
b.eq Lfn2match445arm12
adrp x16, Lcount68
ldr x17, [x16, :lo12:Lcount68]
add x17, x17, #1
str x17, [x16, :lo12:Lcount68]
cmp w0, #11
adrp x16, Lcount69
ldr x17, [x16, :lo12:Lcount69]
add x17, x17, #1
str x17, [x16, :lo12:Lcount69]
b.eq Lfn2match445arm11
adrp x16, Lcount70
ldr x17, [x16, :lo12:Lcount70]
add x17, x17, #1
str x17, [x16, :lo12:Lcount70]
brk #0
Lfn2match445arm9:
adrp x16, Lcount71
ldr x17, [x16, :lo12:Lcount71]
add x17, x17, #1
str x17, [x16, :lo12:Lcount71]
adrp x8, Lconstant1
adrp x16, Lcount64
ldr x17, [x16, :lo12:Lcount64]
add x17, x17, #1
str x17, [x16, :lo12:Lcount64]
add x8, x8, :lo12:Lconstant1
adrp x16, Lcount63
ldr x17, [x16, :lo12:Lcount63]
add x17, x17, #1
str x17, [x16, :lo12:Lcount63]
str x8, [sp, #48]
adrp x16, Lcount60
ldr x17, [x16, :lo12:Lcount60]
add x17, x17, #1
str x17, [x16, :lo12:Lcount60]
stp xzr, xzr, [sp, #56]
adrp x16, Lcount60
ldr x17, [x16, :lo12:Lcount60]
add x17, x17, #1
str x17, [x16, :lo12:Lcount60]
stp xzr, xzr, [sp, #72]
adrp x16, Lcount72
ldr x17, [x16, :lo12:Lcount72]
add x17, x17, #1
str x17, [x16, :lo12:Lcount72]
b Lfn2loop
adrp x16, Lcount72
ldr x17, [x16, :lo12:Lcount72]
add x17, x17, #1
str x17, [x16, :lo12:Lcount72]
b Lfn2match445end
Lfn2match445arm10:
adrp x16, Lcount66
ldr x17, [x16, :lo12:Lcount66]
add x17, x17, #1
str x17, [x16, :lo12:Lcount66]
ldr x0, [sp, #48]
adrp x16, Lcount72
ldr x17, [x16, :lo12:Lcount72]
add x17, x17, #1
str x17, [x16, :lo12:Lcount72]
b Lfn2match445end
Lfn2match445arm12:
adrp x16, Lcount66
ldr x17, [x16, :lo12:Lcount66]
add x17, x17, #1
str x17, [x16, :lo12:Lcount66]
ldr x0, [sp, #48]
adrp x16, Lcount72
ldr x17, [x16, :lo12:Lcount72]
add x17, x17, #1
str x17, [x16, :lo12:Lcount72]
b Lfn2match445end
Lfn2match445arm11:
adrp x16, Lcount61
ldr x17, [x16, :lo12:Lcount61]
add x17, x17, #1
str x17, [x16, :lo12:Lcount61]
mov x0, x19
adrp x16, Lcount73
ldr x17, [x16, :lo12:Lcount73]
add x17, x17, #1
str x17, [x16, :lo12:Lcount73]
asr x2, x0, #63
adrp x16, Lcount64
ldr x17, [x16, :lo12:Lcount64]
add x17, x17, #1
str x17, [x16, :lo12:Lcount64]
add x0, x0, x2, lsr #60
adrp x16, Lcount73
ldr x17, [x16, :lo12:Lcount73]
add x17, x17, #1
str x17, [x16, :lo12:Lcount73]
asr x0, x0, #4
adrp x16, Lcount61
ldr x17, [x16, :lo12:Lcount61]
add x17, x17, #1
str x17, [x16, :lo12:Lcount61]
mov x22, x0
adrp x16, Lcount68
ldr x17, [x16, :lo12:Lcount68]
add x17, x17, #1
str x17, [x16, :lo12:Lcount68]
cmp x0, #2
adrp x16, Lcount74
ldr x17, [x16, :lo12:Lcount74]
add x17, x17, #1
str x17, [x16, :lo12:Lcount74]
b.ge Lfn2if483else
adrp x16, Lcount61
ldr x17, [x16, :lo12:Lcount61]
add x17, x17, #1
str x17, [x16, :lo12:Lcount61]
mov x0, x22
adrp x16, Lcount68
ldr x17, [x16, :lo12:Lcount68]
add x17, x17, #1
str x17, [x16, :lo12:Lcount68]
cmp x0, #1
adrp x16, Lcount74
ldr x17, [x16, :lo12:Lcount74]
add x17, x17, #1
str x17, [x16, :lo12:Lcount74]
b.ge Lfn2if487else
adrp x16, Lcount66
ldr x17, [x16, :lo12:Lcount66]
add x17, x17, #1
str x17, [x16, :lo12:Lcount66]
ldr x8, [sp, #48]
adrp x16, Lcount67
ldr x17, [x16, :lo12:Lcount67]
add x17, x17, #1
str x17, [x16, :lo12:Lcount67]
ldr x8, [x8, #0]
adrp x16, Lcount61
ldr x17, [x16, :lo12:Lcount61]
add x17, x17, #1
str x17, [x16, :lo12:Lcount61]
mov x9, x19
adrp x16, Lcount61
ldr x17, [x16, :lo12:Lcount61]
add x17, x17, #1
str x17, [x16, :lo12:Lcount61]
mov x10, x20
adrp x16, Lcount61
ldr x17, [x16, :lo12:Lcount61]
add x17, x17, #1
str x17, [x16, :lo12:Lcount61]
mov x11, x21
adrp x16, Lcount75
ldr x17, [x16, :lo12:Lcount75]
add x17, x17, #1
str x17, [x16, :lo12:Lcount75]
bl Lfn1fields
adrp x16, Lcount76
ldr x17, [x16, :lo12:Lcount76]
add x17, x17, #1
str x17, [x16, :lo12:Lcount76]
cbnz x1, Lfn2end
adrp x16, Lcount63
ldr x17, [x16, :lo12:Lcount63]
add x17, x17, #1
str x17, [x16, :lo12:Lcount63]
str x0, [sp, #56]
adrp x16, Lcount61
ldr x17, [x16, :lo12:Lcount61]
add x17, x17, #1
str x17, [x16, :lo12:Lcount61]
mov x0, #15
adrp x16, Lcount61
ldr x17, [x16, :lo12:Lcount61]
add x17, x17, #1
str x17, [x16, :lo12:Lcount61]
mov x1, #11
adrp x16, Lcount77
ldr x17, [x16, :lo12:Lcount77]
add x17, x17, #1
str x17, [x16, :lo12:Lcount77]
bl fen_allocate
adrp x16, Lcount78
ldr x17, [x16, :lo12:Lcount78]
add x17, x17, #1
str x17, [x16, :lo12:Lcount78]
cbz x0, Lfn2fail491_3
adrp x16, Lcount66
ldr x17, [x16, :lo12:Lcount66]
add x17, x17, #1
str x17, [x16, :lo12:Lcount66]
ldr x2, [sp, #56]
adrp x16, Lcount66
ldr x17, [x16, :lo12:Lcount66]
add x17, x17, #1
str x17, [x16, :lo12:Lcount66]
ldr x3, [sp, #48]
adrp x16, Lcount67
ldr x17, [x16, :lo12:Lcount67]
add x17, x17, #1
str x17, [x16, :lo12:Lcount67]
ldr x3, [x3, #8]
adrp x16, Lcount79
ldr x17, [x16, :lo12:Lcount79]
add x17, x17, #1
str x17, [x16, :lo12:Lcount79]
stp x2, x3, [x0, #0]
adrp x16, Lcount66
ldr x17, [x16, :lo12:Lcount66]
add x17, x17, #1
str x17, [x16, :lo12:Lcount66]
ldr x4, [sp, #48]
adrp x16, Lcount59
ldr x17, [x16, :lo12:Lcount59]
add x17, x17, #1
str x17, [x16, :lo12:Lcount59]
ldp x2, x3, [x4, #16]
adrp x16, Lcount79
ldr x17, [x16, :lo12:Lcount79]
add x17, x17, #1
str x17, [x16, :lo12:Lcount79]
stp x2, x3, [x0, #16]
adrp x16, Lcount72
ldr x17, [x16, :lo12:Lcount72]
add x17, x17, #1
str x17, [x16, :lo12:Lcount72]
b Lfn2if487done
Lfn2if487else:
adrp x16, Lcount66
ldr x17, [x16, :lo12:Lcount66]
add x17, x17, #1
str x17, [x16, :lo12:Lcount66]
ldr x8, [sp, #48]
adrp x16, Lcount67
ldr x17, [x16, :lo12:Lcount67]
add x17, x17, #1
str x17, [x16, :lo12:Lcount67]
ldr x8, [x8, #8]
adrp x16, Lcount61
ldr x17, [x16, :lo12:Lcount61]
add x17, x17, #1
str x17, [x16, :lo12:Lcount61]
mov x9, x19
adrp x16, Lcount61
ldr x17, [x16, :lo12:Lcount61]
add x17, x17, #1
str x17, [x16, :lo12:Lcount61]
mov x10, x20
adrp x16, Lcount61
ldr x17, [x16, :lo12:Lcount61]
add x17, x17, #1
str x17, [x16, :lo12:Lcount61]
mov x11, x21
adrp x16, Lcount75
ldr x17, [x16, :lo12:Lcount75]
add x17, x17, #1
str x17, [x16, :lo12:Lcount75]
bl Lfn1fields
adrp x16, Lcount76
ldr x17, [x16, :lo12:Lcount76]
add x17, x17, #1
str x17, [x16, :lo12:Lcount76]
cbnz x1, Lfn2end
adrp x16, Lcount63
ldr x17, [x16, :lo12:Lcount63]
add x17, x17, #1
str x17, [x16, :lo12:Lcount63]
str x0, [sp, #64]
adrp x16, Lcount61
ldr x17, [x16, :lo12:Lcount61]
add x17, x17, #1
str x17, [x16, :lo12:Lcount61]
mov x0, #15
adrp x16, Lcount61
ldr x17, [x16, :lo12:Lcount61]
add x17, x17, #1
str x17, [x16, :lo12:Lcount61]
mov x1, #11
adrp x16, Lcount77
ldr x17, [x16, :lo12:Lcount77]
add x17, x17, #1
str x17, [x16, :lo12:Lcount77]
bl fen_allocate
adrp x16, Lcount78
ldr x17, [x16, :lo12:Lcount78]
add x17, x17, #1
str x17, [x16, :lo12:Lcount78]
cbz x0, Lfn2fail501_3
adrp x16, Lcount66
ldr x17, [x16, :lo12:Lcount66]
add x17, x17, #1
str x17, [x16, :lo12:Lcount66]
ldr x2, [sp, #48]
adrp x16, Lcount67
ldr x17, [x16, :lo12:Lcount67]
add x17, x17, #1
str x17, [x16, :lo12:Lcount67]
ldr x2, [x2, #0]
adrp x16, Lcount66
ldr x17, [x16, :lo12:Lcount66]
add x17, x17, #1
str x17, [x16, :lo12:Lcount66]
ldr x3, [sp, #64]
adrp x16, Lcount79
ldr x17, [x16, :lo12:Lcount79]
add x17, x17, #1
str x17, [x16, :lo12:Lcount79]
stp x2, x3, [x0, #0]
adrp x16, Lcount66
ldr x17, [x16, :lo12:Lcount66]
add x17, x17, #1
str x17, [x16, :lo12:Lcount66]
ldr x4, [sp, #48]
adrp x16, Lcount59
ldr x17, [x16, :lo12:Lcount59]
add x17, x17, #1
str x17, [x16, :lo12:Lcount59]
ldp x2, x3, [x4, #16]
adrp x16, Lcount79
ldr x17, [x16, :lo12:Lcount79]
add x17, x17, #1
str x17, [x16, :lo12:Lcount79]
stp x2, x3, [x0, #16]
Lfn2if487done:
adrp x16, Lcount72
ldr x17, [x16, :lo12:Lcount72]
add x17, x17, #1
str x17, [x16, :lo12:Lcount72]
b Lfn2if483done
Lfn2if483else:
adrp x16, Lcount61
ldr x17, [x16, :lo12:Lcount61]
add x17, x17, #1
str x17, [x16, :lo12:Lcount61]
mov x0, x22
adrp x16, Lcount68
ldr x17, [x16, :lo12:Lcount68]
add x17, x17, #1
str x17, [x16, :lo12:Lcount68]
cmp x0, #3
adrp x16, Lcount74
ldr x17, [x16, :lo12:Lcount74]
add x17, x17, #1
str x17, [x16, :lo12:Lcount74]
b.ge Lfn2if511else
adrp x16, Lcount66
ldr x17, [x16, :lo12:Lcount66]
add x17, x17, #1
str x17, [x16, :lo12:Lcount66]
ldr x8, [sp, #48]
adrp x16, Lcount67
ldr x17, [x16, :lo12:Lcount67]
add x17, x17, #1
str x17, [x16, :lo12:Lcount67]
ldr x8, [x8, #16]
adrp x16, Lcount61
ldr x17, [x16, :lo12:Lcount61]
add x17, x17, #1
str x17, [x16, :lo12:Lcount61]
mov x9, x19
adrp x16, Lcount61
ldr x17, [x16, :lo12:Lcount61]
add x17, x17, #1
str x17, [x16, :lo12:Lcount61]
mov x10, x20
adrp x16, Lcount61
ldr x17, [x16, :lo12:Lcount61]
add x17, x17, #1
str x17, [x16, :lo12:Lcount61]
mov x11, x21
adrp x16, Lcount75
ldr x17, [x16, :lo12:Lcount75]
add x17, x17, #1
str x17, [x16, :lo12:Lcount75]
bl Lfn1fields
adrp x16, Lcount76
ldr x17, [x16, :lo12:Lcount76]
add x17, x17, #1
str x17, [x16, :lo12:Lcount76]
cbnz x1, Lfn2end
adrp x16, Lcount63
ldr x17, [x16, :lo12:Lcount63]
add x17, x17, #1
str x17, [x16, :lo12:Lcount63]
str x0, [sp, #72]
adrp x16, Lcount61
ldr x17, [x16, :lo12:Lcount61]
add x17, x17, #1
str x17, [x16, :lo12:Lcount61]
mov x0, #15
adrp x16, Lcount61
ldr x17, [x16, :lo12:Lcount61]
add x17, x17, #1
str x17, [x16, :lo12:Lcount61]
mov x1, #11
adrp x16, Lcount77
ldr x17, [x16, :lo12:Lcount77]
add x17, x17, #1
str x17, [x16, :lo12:Lcount77]
bl fen_allocate
adrp x16, Lcount78
ldr x17, [x16, :lo12:Lcount78]
add x17, x17, #1
str x17, [x16, :lo12:Lcount78]
cbz x0, Lfn2fail515_3
adrp x16, Lcount66
ldr x17, [x16, :lo12:Lcount66]
add x17, x17, #1
str x17, [x16, :lo12:Lcount66]
ldr x4, [sp, #48]
adrp x16, Lcount59
ldr x17, [x16, :lo12:Lcount59]
add x17, x17, #1
str x17, [x16, :lo12:Lcount59]
ldp x2, x3, [x4, #0]
adrp x16, Lcount79
ldr x17, [x16, :lo12:Lcount79]
add x17, x17, #1
str x17, [x16, :lo12:Lcount79]
stp x2, x3, [x0, #0]
adrp x16, Lcount66
ldr x17, [x16, :lo12:Lcount66]
add x17, x17, #1
str x17, [x16, :lo12:Lcount66]
ldr x2, [sp, #72]
adrp x16, Lcount67
ldr x17, [x16, :lo12:Lcount67]
add x17, x17, #1
str x17, [x16, :lo12:Lcount67]
ldr x3, [x4, #24]
adrp x16, Lcount79
ldr x17, [x16, :lo12:Lcount79]
add x17, x17, #1
str x17, [x16, :lo12:Lcount79]
stp x2, x3, [x0, #16]
adrp x16, Lcount72
ldr x17, [x16, :lo12:Lcount72]
add x17, x17, #1
str x17, [x16, :lo12:Lcount72]
b Lfn2if511done
Lfn2if511else:
adrp x16, Lcount66
ldr x17, [x16, :lo12:Lcount66]
add x17, x17, #1
str x17, [x16, :lo12:Lcount66]
ldr x8, [sp, #48]
adrp x16, Lcount67
ldr x17, [x16, :lo12:Lcount67]
add x17, x17, #1
str x17, [x16, :lo12:Lcount67]
ldr x8, [x8, #24]
adrp x16, Lcount61
ldr x17, [x16, :lo12:Lcount61]
add x17, x17, #1
str x17, [x16, :lo12:Lcount61]
mov x9, x19
adrp x16, Lcount61
ldr x17, [x16, :lo12:Lcount61]
add x17, x17, #1
str x17, [x16, :lo12:Lcount61]
mov x10, x20
adrp x16, Lcount61
ldr x17, [x16, :lo12:Lcount61]
add x17, x17, #1
str x17, [x16, :lo12:Lcount61]
mov x11, x21
adrp x16, Lcount75
ldr x17, [x16, :lo12:Lcount75]
add x17, x17, #1
str x17, [x16, :lo12:Lcount75]
bl Lfn1fields
adrp x16, Lcount76
ldr x17, [x16, :lo12:Lcount76]
add x17, x17, #1
str x17, [x16, :lo12:Lcount76]
cbnz x1, Lfn2end
adrp x16, Lcount63
ldr x17, [x16, :lo12:Lcount63]
add x17, x17, #1
str x17, [x16, :lo12:Lcount63]
str x0, [sp, #80]
adrp x16, Lcount61
ldr x17, [x16, :lo12:Lcount61]
add x17, x17, #1
str x17, [x16, :lo12:Lcount61]
mov x0, #15
adrp x16, Lcount61
ldr x17, [x16, :lo12:Lcount61]
add x17, x17, #1
str x17, [x16, :lo12:Lcount61]
mov x1, #11
adrp x16, Lcount77
ldr x17, [x16, :lo12:Lcount77]
add x17, x17, #1
str x17, [x16, :lo12:Lcount77]
bl fen_allocate
adrp x16, Lcount78
ldr x17, [x16, :lo12:Lcount78]
add x17, x17, #1
str x17, [x16, :lo12:Lcount78]
cbz x0, Lfn2fail525_3
adrp x16, Lcount66
ldr x17, [x16, :lo12:Lcount66]
add x17, x17, #1
str x17, [x16, :lo12:Lcount66]
ldr x4, [sp, #48]
adrp x16, Lcount59
ldr x17, [x16, :lo12:Lcount59]
add x17, x17, #1
str x17, [x16, :lo12:Lcount59]
ldp x2, x3, [x4, #0]
adrp x16, Lcount79
ldr x17, [x16, :lo12:Lcount79]
add x17, x17, #1
str x17, [x16, :lo12:Lcount79]
stp x2, x3, [x0, #0]
adrp x16, Lcount67
ldr x17, [x16, :lo12:Lcount67]
add x17, x17, #1
str x17, [x16, :lo12:Lcount67]
ldr x2, [x4, #16]
adrp x16, Lcount66
ldr x17, [x16, :lo12:Lcount66]
add x17, x17, #1
str x17, [x16, :lo12:Lcount66]
ldr x3, [sp, #80]
adrp x16, Lcount79
ldr x17, [x16, :lo12:Lcount79]
add x17, x17, #1
str x17, [x16, :lo12:Lcount79]
stp x2, x3, [x0, #16]
Lfn2if511done:
Lfn2if483done:
adrp x16, Lcount72
ldr x17, [x16, :lo12:Lcount72]
add x17, x17, #1
str x17, [x16, :lo12:Lcount72]
b Lfn2match445end
Lfn2match445end:
adrp x16, Lcount61
ldr x17, [x16, :lo12:Lcount61]
add x17, x17, #1
str x17, [x16, :lo12:Lcount61]
mov x1, #0
adrp x16, Lcount72
ldr x17, [x16, :lo12:Lcount72]
add x17, x17, #1
str x17, [x16, :lo12:Lcount72]
b Lfn2end
Lfn2fail491_3:
adrp x16, Lcount71
ldr x17, [x16, :lo12:Lcount71]
add x17, x17, #1
str x17, [x16, :lo12:Lcount71]
adrp x0, Lfn2fail491_3location
adrp x16, Lcount64
ldr x17, [x16, :lo12:Lcount64]
add x17, x17, #1
str x17, [x16, :lo12:Lcount64]
add x0, x0, :lo12:Lfn2fail491_3location
adrp x16, Lcount80
ldr x17, [x16, :lo12:Lcount80]
add x17, x17, #1
str x17, [x16, :lo12:Lcount80]
bl fen_set_location
adrp x16, Lcount61
ldr x17, [x16, :lo12:Lcount61]
add x17, x17, #1
str x17, [x16, :lo12:Lcount61]
mov x1, #3
adrp x16, Lcount72
ldr x17, [x16, :lo12:Lcount72]
add x17, x17, #1
str x17, [x16, :lo12:Lcount72]
b Lfn2end
Lfn2fail501_3:
adrp x16, Lcount71
ldr x17, [x16, :lo12:Lcount71]
add x17, x17, #1
str x17, [x16, :lo12:Lcount71]
adrp x0, Lfn2fail501_3location
adrp x16, Lcount64
ldr x17, [x16, :lo12:Lcount64]
add x17, x17, #1
str x17, [x16, :lo12:Lcount64]
add x0, x0, :lo12:Lfn2fail501_3location
adrp x16, Lcount80
ldr x17, [x16, :lo12:Lcount80]
add x17, x17, #1
str x17, [x16, :lo12:Lcount80]
bl fen_set_location
adrp x16, Lcount61
ldr x17, [x16, :lo12:Lcount61]
add x17, x17, #1
str x17, [x16, :lo12:Lcount61]
mov x1, #3
adrp x16, Lcount72
ldr x17, [x16, :lo12:Lcount72]
add x17, x17, #1
str x17, [x16, :lo12:Lcount72]
b Lfn2end
Lfn2fail515_3:
adrp x16, Lcount71
ldr x17, [x16, :lo12:Lcount71]
add x17, x17, #1
str x17, [x16, :lo12:Lcount71]
adrp x0, Lfn2fail515_3location
adrp x16, Lcount64
ldr x17, [x16, :lo12:Lcount64]
add x17, x17, #1
str x17, [x16, :lo12:Lcount64]
add x0, x0, :lo12:Lfn2fail515_3location
adrp x16, Lcount80
ldr x17, [x16, :lo12:Lcount80]
add x17, x17, #1
str x17, [x16, :lo12:Lcount80]
bl fen_set_location
adrp x16, Lcount61
ldr x17, [x16, :lo12:Lcount61]
add x17, x17, #1
str x17, [x16, :lo12:Lcount61]
mov x1, #3
adrp x16, Lcount72
ldr x17, [x16, :lo12:Lcount72]
add x17, x17, #1
str x17, [x16, :lo12:Lcount72]
b Lfn2end
Lfn2fail525_3:
adrp x16, Lcount71
ldr x17, [x16, :lo12:Lcount71]
add x17, x17, #1
str x17, [x16, :lo12:Lcount71]
adrp x0, Lfn2fail525_3location
adrp x16, Lcount64
ldr x17, [x16, :lo12:Lcount64]
add x17, x17, #1
str x17, [x16, :lo12:Lcount64]
add x0, x0, :lo12:Lfn2fail525_3location
adrp x16, Lcount80
ldr x17, [x16, :lo12:Lcount80]
add x17, x17, #1
str x17, [x16, :lo12:Lcount80]
bl fen_set_location
adrp x16, Lcount61
ldr x17, [x16, :lo12:Lcount61]
add x17, x17, #1
str x17, [x16, :lo12:Lcount61]
mov x1, #3
adrp x16, Lcount72
ldr x17, [x16, :lo12:Lcount72]
add x17, x17, #1
str x17, [x16, :lo12:Lcount72]
b Lfn2end
Lfn2end:
adrp x16, Lcount81
ldr x17, [x16, :lo12:Lcount81]
add x17, x17, #1
str x17, [x16, :lo12:Lcount81]
bl fen_leave_result
adrp x16, Lcount59
ldr x17, [x16, :lo12:Lcount59]
add x17, x17, #1
str x17, [x16, :lo12:Lcount59]
ldp x19, x20, [x29, #-16]
adrp x16, Lcount59
ldr x17, [x16, :lo12:Lcount59]
add x17, x17, #1
str x17, [x16, :lo12:Lcount59]
ldp x21, x22, [x29, #-32]
adrp x16, Lcount61
ldr x17, [x16, :lo12:Lcount61]
add x17, x17, #1
str x17, [x16, :lo12:Lcount61]
mov sp, x29
adrp x16, Lcount82
ldr x17, [x16, :lo12:Lcount82]
add x17, x17, #1
str x17, [x16, :lo12:Lcount82]
ldp x29, x30, [sp], #16
adrp x16, Lcount83
ldr x17, [x16, :lo12:Lcount83]
add x17, x17, #1
str x17, [x16, :lo12:Lcount83]
ret
Lfn3:
adrp x16, Lcount84
ldr x17, [x16, :lo12:Lcount84]
add x17, x17, #1
str x17, [x16, :lo12:Lcount84]
ldp x8, x9, [x0, #0]
Lfn3fields:
adrp x16, Lcount85
ldr x17, [x16, :lo12:Lcount85]
add x17, x17, #1
str x17, [x16, :lo12:Lcount85]
ldr w2, [x8, #72]
adrp x16, Lcount86
ldr x17, [x16, :lo12:Lcount86]
add x17, x17, #1
str x17, [x16, :lo12:Lcount86]
cmp w2, #9
adrp x16, Lcount87
ldr x17, [x16, :lo12:Lcount87]
add x17, x17, #1
str x17, [x16, :lo12:Lcount87]
b.ne Lfn3frame
adrp x16, Lcount88
ldr x17, [x16, :lo12:Lcount88]
add x17, x17, #1
str x17, [x16, :lo12:Lcount88]
mov x0, x9
adrp x16, Lcount88
ldr x17, [x16, :lo12:Lcount88]
add x17, x17, #1
str x17, [x16, :lo12:Lcount88]
mov x1, #0
adrp x16, Lcount89
ldr x17, [x16, :lo12:Lcount89]
add x17, x17, #1
str x17, [x16, :lo12:Lcount89]
ret
Lfn3frame:
adrp x16, Lcount90
ldr x17, [x16, :lo12:Lcount90]
add x17, x17, #1
str x17, [x16, :lo12:Lcount90]
stp x29, x30, [sp, #-16]!
adrp x16, Lcount88
ldr x17, [x16, :lo12:Lcount88]
add x17, x17, #1
str x17, [x16, :lo12:Lcount88]
mov x29, sp
adrp x16, Lcount91
ldr x17, [x16, :lo12:Lcount91]
add x17, x17, #1
str x17, [x16, :lo12:Lcount91]
sub sp, sp, #176
adrp x16, Lcount90
ldr x17, [x16, :lo12:Lcount90]
add x17, x17, #1
str x17, [x16, :lo12:Lcount90]
stp xzr, xzr, [sp, #64]
adrp x16, Lcount90
ldr x17, [x16, :lo12:Lcount90]
add x17, x17, #1
str x17, [x16, :lo12:Lcount90]
stp xzr, xzr, [sp, #80]
adrp x16, Lcount90
ldr x17, [x16, :lo12:Lcount90]
add x17, x17, #1
str x17, [x16, :lo12:Lcount90]
stp xzr, xzr, [sp, #96]
adrp x16, Lcount90
ldr x17, [x16, :lo12:Lcount90]
add x17, x17, #1
str x17, [x16, :lo12:Lcount90]
stp xzr, xzr, [sp, #112]
adrp x16, Lcount90
ldr x17, [x16, :lo12:Lcount90]
add x17, x17, #1
str x17, [x16, :lo12:Lcount90]
stp xzr, xzr, [sp, #128]
adrp x16, Lcount90
ldr x17, [x16, :lo12:Lcount90]
add x17, x17, #1
str x17, [x16, :lo12:Lcount90]
stp xzr, xzr, [sp, #144]
adrp x16, Lcount90
ldr x17, [x16, :lo12:Lcount90]
add x17, x17, #1
str x17, [x16, :lo12:Lcount90]
stp x8, x9, [sp, #48]
adrp x16, Lcount92
ldr x17, [x16, :lo12:Lcount92]
add x17, x17, #1
str x17, [x16, :lo12:Lcount92]
add x0, sp, #16
adrp x16, Lcount92
ldr x17, [x16, :lo12:Lcount92]
add x17, x17, #1
str x17, [x16, :lo12:Lcount92]
add x1, sp, #48
adrp x16, Lcount88
ldr x17, [x16, :lo12:Lcount88]
add x17, x17, #1
str x17, [x16, :lo12:Lcount88]
mov x2, #14
adrp x16, Lcount93
ldr x17, [x16, :lo12:Lcount93]
add x17, x17, #1
str x17, [x16, :lo12:Lcount93]
bl fen_enter
Lfn3loop:
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x0, [sp, #48]
adrp x16, Lcount85
ldr x17, [x16, :lo12:Lcount85]
add x17, x17, #1
str x17, [x16, :lo12:Lcount85]
ldr w0, [x0, #72]
adrp x16, Lcount86
ldr x17, [x16, :lo12:Lcount86]
add x17, x17, #1
str x17, [x16, :lo12:Lcount86]
cmp w0, #9
adrp x16, Lcount95
ldr x17, [x16, :lo12:Lcount95]
add x17, x17, #1
str x17, [x16, :lo12:Lcount95]
b.eq Lfn3match545arm9
adrp x16, Lcount86
ldr x17, [x16, :lo12:Lcount86]
add x17, x17, #1
str x17, [x16, :lo12:Lcount86]
cmp w0, #10
adrp x16, Lcount95
ldr x17, [x16, :lo12:Lcount95]
add x17, x17, #1
str x17, [x16, :lo12:Lcount95]
b.eq Lfn3match545arm10
adrp x16, Lcount86
ldr x17, [x16, :lo12:Lcount86]
add x17, x17, #1
str x17, [x16, :lo12:Lcount86]
cmp w0, #11
adrp x16, Lcount95
ldr x17, [x16, :lo12:Lcount95]
add x17, x17, #1
str x17, [x16, :lo12:Lcount95]
b.eq Lfn3match545arm11
adrp x16, Lcount86
ldr x17, [x16, :lo12:Lcount86]
add x17, x17, #1
str x17, [x16, :lo12:Lcount86]
cmp w0, #12
adrp x16, Lcount95
ldr x17, [x16, :lo12:Lcount95]
add x17, x17, #1
str x17, [x16, :lo12:Lcount95]
b.eq Lfn3match545arm12
adrp x16, Lcount96
ldr x17, [x16, :lo12:Lcount96]
add x17, x17, #1
str x17, [x16, :lo12:Lcount96]
brk #0
Lfn3match545arm9:
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x0, [sp, #56]
adrp x16, Lcount97
ldr x17, [x16, :lo12:Lcount97]
add x17, x17, #1
str x17, [x16, :lo12:Lcount97]
b Lfn3match545end
Lfn3match545arm10:
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x0, [sp, #48]
adrp x16, Lcount85
ldr x17, [x16, :lo12:Lcount85]
add x17, x17, #1
str x17, [x16, :lo12:Lcount85]
ldr x0, [x0, #32]
adrp x16, Lcount86
ldr x17, [x16, :lo12:Lcount86]
add x17, x17, #1
str x17, [x16, :lo12:Lcount86]
cmp x0, #0
adrp x16, Lcount87
ldr x17, [x16, :lo12:Lcount87]
add x17, x17, #1
str x17, [x16, :lo12:Lcount87]
b.ne Lfn3if557else
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x0, [sp, #56]
adrp x16, Lcount97
ldr x17, [x16, :lo12:Lcount97]
add x17, x17, #1
str x17, [x16, :lo12:Lcount97]
b Lfn3if557done
Lfn3if557else:
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x0, [sp, #48]
adrp x16, Lcount85
ldr x17, [x16, :lo12:Lcount85]
add x17, x17, #1
str x17, [x16, :lo12:Lcount85]
ldr x0, [x0, #0]
adrp x16, Lcount98
ldr x17, [x16, :lo12:Lcount98]
add x17, x17, #1
str x17, [x16, :lo12:Lcount98]
adds x0, x0, #1
adrp x16, Lcount99
ldr x17, [x16, :lo12:Lcount99]
add x17, x17, #1
str x17, [x16, :lo12:Lcount99]
b.vs Lfn3fail563_1
adrp x16, Lcount100
ldr x17, [x16, :lo12:Lcount100]
add x17, x17, #1
str x17, [x16, :lo12:Lcount100]
str x0, [sp, #160]
adrp x16, Lcount88
ldr x17, [x16, :lo12:Lcount88]
add x17, x17, #1
str x17, [x16, :lo12:Lcount88]
mov x0, #16
adrp x16, Lcount88
ldr x17, [x16, :lo12:Lcount88]
add x17, x17, #1
str x17, [x16, :lo12:Lcount88]
mov x1, #8
adrp x16, Lcount101
ldr x17, [x16, :lo12:Lcount101]
add x17, x17, #1
str x17, [x16, :lo12:Lcount101]
bl fen_allocate
adrp x16, Lcount102
ldr x17, [x16, :lo12:Lcount102]
add x17, x17, #1
str x17, [x16, :lo12:Lcount102]
cbz x0, Lfn3fail562_3
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x2, [sp, #160]
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x3, [sp, #48]
adrp x16, Lcount85
ldr x17, [x16, :lo12:Lcount85]
add x17, x17, #1
str x17, [x16, :lo12:Lcount85]
ldr x3, [x3, #32]
adrp x16, Lcount103
ldr x17, [x16, :lo12:Lcount103]
add x17, x17, #1
str x17, [x16, :lo12:Lcount103]
stp x2, x3, [x0, #0]
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x4, [sp, #48]
adrp x16, Lcount84
ldr x17, [x16, :lo12:Lcount84]
add x17, x17, #1
str x17, [x16, :lo12:Lcount84]
ldp x2, x3, [x4, #40]
adrp x16, Lcount103
ldr x17, [x16, :lo12:Lcount103]
add x17, x17, #1
str x17, [x16, :lo12:Lcount103]
stp x2, x3, [x0, #16]
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x2, [sp, #56]
adrp x16, Lcount104
ldr x17, [x16, :lo12:Lcount104]
add x17, x17, #1
str x17, [x16, :lo12:Lcount104]
str x2, [x0, #32]
adrp x16, Lcount100
ldr x17, [x16, :lo12:Lcount100]
add x17, x17, #1
str x17, [x16, :lo12:Lcount100]
str x0, [sp, #64]
Lfn3if557done:
adrp x16, Lcount100
ldr x17, [x16, :lo12:Lcount100]
add x17, x17, #1
str x17, [x16, :lo12:Lcount100]
str x0, [sp, #72]
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x0, [sp, #48]
adrp x16, Lcount85
ldr x17, [x16, :lo12:Lcount85]
add x17, x17, #1
str x17, [x16, :lo12:Lcount85]
ldr x0, [x0, #8]
adrp x16, Lcount86
ldr x17, [x16, :lo12:Lcount86]
add x17, x17, #1
str x17, [x16, :lo12:Lcount86]
cmp x0, #0
adrp x16, Lcount87
ldr x17, [x16, :lo12:Lcount87]
add x17, x17, #1
str x17, [x16, :lo12:Lcount87]
b.ne Lfn3if570else
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x0, [sp, #72]
adrp x16, Lcount97
ldr x17, [x16, :lo12:Lcount97]
add x17, x17, #1
str x17, [x16, :lo12:Lcount97]
b Lfn3if570done
Lfn3if570else:
adrp x16, Lcount88
ldr x17, [x16, :lo12:Lcount88]
add x17, x17, #1
str x17, [x16, :lo12:Lcount88]
mov x0, #16
adrp x16, Lcount88
ldr x17, [x16, :lo12:Lcount88]
add x17, x17, #1
str x17, [x16, :lo12:Lcount88]
mov x1, #8
adrp x16, Lcount101
ldr x17, [x16, :lo12:Lcount101]
add x17, x17, #1
str x17, [x16, :lo12:Lcount101]
bl fen_allocate
adrp x16, Lcount102
ldr x17, [x16, :lo12:Lcount102]
add x17, x17, #1
str x17, [x16, :lo12:Lcount102]
cbz x0, Lfn3fail575_3
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x4, [sp, #48]
adrp x16, Lcount84
ldr x17, [x16, :lo12:Lcount84]
add x17, x17, #1
str x17, [x16, :lo12:Lcount84]
ldp x2, x3, [x4, #0]
adrp x16, Lcount103
ldr x17, [x16, :lo12:Lcount103]
add x17, x17, #1
str x17, [x16, :lo12:Lcount103]
stp x2, x3, [x0, #0]
adrp x16, Lcount84
ldr x17, [x16, :lo12:Lcount84]
add x17, x17, #1
str x17, [x16, :lo12:Lcount84]
ldp x2, x3, [x4, #16]
adrp x16, Lcount103
ldr x17, [x16, :lo12:Lcount103]
add x17, x17, #1
str x17, [x16, :lo12:Lcount103]
stp x2, x3, [x0, #16]
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x2, [sp, #72]
adrp x16, Lcount104
ldr x17, [x16, :lo12:Lcount104]
add x17, x17, #1
str x17, [x16, :lo12:Lcount104]
str x2, [x0, #32]
Lfn3if570done:
adrp x16, Lcount97
ldr x17, [x16, :lo12:Lcount97]
add x17, x17, #1
str x17, [x16, :lo12:Lcount97]
b Lfn3match545end
Lfn3match545arm11:
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x8, [sp, #48]
adrp x16, Lcount85
ldr x17, [x16, :lo12:Lcount85]
add x17, x17, #1
str x17, [x16, :lo12:Lcount85]
ldr x8, [x8, #24]
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x9, [sp, #56]
adrp x16, Lcount105
ldr x17, [x16, :lo12:Lcount105]
add x17, x17, #1
str x17, [x16, :lo12:Lcount105]
bl Lfn3fields
adrp x16, Lcount106
ldr x17, [x16, :lo12:Lcount106]
add x17, x17, #1
str x17, [x16, :lo12:Lcount106]
cbnz x1, Lfn3end
adrp x16, Lcount100
ldr x17, [x16, :lo12:Lcount100]
add x17, x17, #1
str x17, [x16, :lo12:Lcount100]
str x0, [sp, #80]
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x8, [sp, #48]
adrp x16, Lcount85
ldr x17, [x16, :lo12:Lcount85]
add x17, x17, #1
str x17, [x16, :lo12:Lcount85]
ldr x8, [x8, #16]
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x9, [sp, #80]
adrp x16, Lcount105
ldr x17, [x16, :lo12:Lcount105]
add x17, x17, #1
str x17, [x16, :lo12:Lcount105]
bl Lfn3fields
adrp x16, Lcount106
ldr x17, [x16, :lo12:Lcount106]
add x17, x17, #1
str x17, [x16, :lo12:Lcount106]
cbnz x1, Lfn3end
adrp x16, Lcount100
ldr x17, [x16, :lo12:Lcount100]
add x17, x17, #1
str x17, [x16, :lo12:Lcount100]
str x0, [sp, #88]
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x8, [sp, #48]
adrp x16, Lcount85
ldr x17, [x16, :lo12:Lcount85]
add x17, x17, #1
str x17, [x16, :lo12:Lcount85]
ldr x8, [x8, #8]
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x9, [sp, #88]
adrp x16, Lcount105
ldr x17, [x16, :lo12:Lcount105]
add x17, x17, #1
str x17, [x16, :lo12:Lcount105]
bl Lfn3fields
adrp x16, Lcount106
ldr x17, [x16, :lo12:Lcount106]
add x17, x17, #1
str x17, [x16, :lo12:Lcount106]
cbnz x1, Lfn3end
adrp x16, Lcount100
ldr x17, [x16, :lo12:Lcount100]
add x17, x17, #1
str x17, [x16, :lo12:Lcount100]
str x0, [sp, #96]
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x8, [sp, #48]
adrp x16, Lcount85
ldr x17, [x16, :lo12:Lcount85]
add x17, x17, #1
str x17, [x16, :lo12:Lcount85]
ldr x8, [x8, #0]
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x9, [sp, #96]
adrp x16, Lcount100
ldr x17, [x16, :lo12:Lcount100]
add x17, x17, #1
str x17, [x16, :lo12:Lcount100]
str x8, [sp, #48]
adrp x16, Lcount100
ldr x17, [x16, :lo12:Lcount100]
add x17, x17, #1
str x17, [x16, :lo12:Lcount100]
str x9, [sp, #56]
adrp x16, Lcount90
ldr x17, [x16, :lo12:Lcount90]
add x17, x17, #1
str x17, [x16, :lo12:Lcount90]
stp xzr, xzr, [sp, #64]
adrp x16, Lcount90
ldr x17, [x16, :lo12:Lcount90]
add x17, x17, #1
str x17, [x16, :lo12:Lcount90]
stp xzr, xzr, [sp, #80]
adrp x16, Lcount90
ldr x17, [x16, :lo12:Lcount90]
add x17, x17, #1
str x17, [x16, :lo12:Lcount90]
stp xzr, xzr, [sp, #96]
adrp x16, Lcount90
ldr x17, [x16, :lo12:Lcount90]
add x17, x17, #1
str x17, [x16, :lo12:Lcount90]
stp xzr, xzr, [sp, #112]
adrp x16, Lcount90
ldr x17, [x16, :lo12:Lcount90]
add x17, x17, #1
str x17, [x16, :lo12:Lcount90]
stp xzr, xzr, [sp, #128]
adrp x16, Lcount90
ldr x17, [x16, :lo12:Lcount90]
add x17, x17, #1
str x17, [x16, :lo12:Lcount90]
stp xzr, xzr, [sp, #144]
adrp x16, Lcount97
ldr x17, [x16, :lo12:Lcount97]
add x17, x17, #1
str x17, [x16, :lo12:Lcount97]
b Lfn3loop
adrp x16, Lcount97
ldr x17, [x16, :lo12:Lcount97]
add x17, x17, #1
str x17, [x16, :lo12:Lcount97]
b Lfn3match545end
Lfn3match545arm12:
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x8, [sp, #48]
adrp x16, Lcount85
ldr x17, [x16, :lo12:Lcount85]
add x17, x17, #1
str x17, [x16, :lo12:Lcount85]
ldr x8, [x8, #56]
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x9, [sp, #56]
adrp x16, Lcount105
ldr x17, [x16, :lo12:Lcount105]
add x17, x17, #1
str x17, [x16, :lo12:Lcount105]
bl Lfn3fields
adrp x16, Lcount106
ldr x17, [x16, :lo12:Lcount106]
add x17, x17, #1
str x17, [x16, :lo12:Lcount106]
cbnz x1, Lfn3end
adrp x16, Lcount100
ldr x17, [x16, :lo12:Lcount100]
add x17, x17, #1
str x17, [x16, :lo12:Lcount100]
str x0, [sp, #104]
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x8, [sp, #48]
adrp x16, Lcount85
ldr x17, [x16, :lo12:Lcount85]
add x17, x17, #1
str x17, [x16, :lo12:Lcount85]
ldr x8, [x8, #48]
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x9, [sp, #104]
adrp x16, Lcount105
ldr x17, [x16, :lo12:Lcount105]
add x17, x17, #1
str x17, [x16, :lo12:Lcount105]
bl Lfn3fields
adrp x16, Lcount106
ldr x17, [x16, :lo12:Lcount106]
add x17, x17, #1
str x17, [x16, :lo12:Lcount106]
cbnz x1, Lfn3end
adrp x16, Lcount100
ldr x17, [x16, :lo12:Lcount100]
add x17, x17, #1
str x17, [x16, :lo12:Lcount100]
str x0, [sp, #112]
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x8, [sp, #48]
adrp x16, Lcount85
ldr x17, [x16, :lo12:Lcount85]
add x17, x17, #1
str x17, [x16, :lo12:Lcount85]
ldr x8, [x8, #40]
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x9, [sp, #112]
adrp x16, Lcount105
ldr x17, [x16, :lo12:Lcount105]
add x17, x17, #1
str x17, [x16, :lo12:Lcount105]
bl Lfn3fields
adrp x16, Lcount106
ldr x17, [x16, :lo12:Lcount106]
add x17, x17, #1
str x17, [x16, :lo12:Lcount106]
cbnz x1, Lfn3end
adrp x16, Lcount100
ldr x17, [x16, :lo12:Lcount100]
add x17, x17, #1
str x17, [x16, :lo12:Lcount100]
str x0, [sp, #120]
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x8, [sp, #48]
adrp x16, Lcount85
ldr x17, [x16, :lo12:Lcount85]
add x17, x17, #1
str x17, [x16, :lo12:Lcount85]
ldr x8, [x8, #32]
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x9, [sp, #120]
adrp x16, Lcount105
ldr x17, [x16, :lo12:Lcount105]
add x17, x17, #1
str x17, [x16, :lo12:Lcount105]
bl Lfn3fields
adrp x16, Lcount106
ldr x17, [x16, :lo12:Lcount106]
add x17, x17, #1
str x17, [x16, :lo12:Lcount106]
cbnz x1, Lfn3end
adrp x16, Lcount100
ldr x17, [x16, :lo12:Lcount100]
add x17, x17, #1
str x17, [x16, :lo12:Lcount100]
str x0, [sp, #128]
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x8, [sp, #48]
adrp x16, Lcount85
ldr x17, [x16, :lo12:Lcount85]
add x17, x17, #1
str x17, [x16, :lo12:Lcount85]
ldr x8, [x8, #24]
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x9, [sp, #128]
adrp x16, Lcount105
ldr x17, [x16, :lo12:Lcount105]
add x17, x17, #1
str x17, [x16, :lo12:Lcount105]
bl Lfn3fields
adrp x16, Lcount106
ldr x17, [x16, :lo12:Lcount106]
add x17, x17, #1
str x17, [x16, :lo12:Lcount106]
cbnz x1, Lfn3end
adrp x16, Lcount100
ldr x17, [x16, :lo12:Lcount100]
add x17, x17, #1
str x17, [x16, :lo12:Lcount100]
str x0, [sp, #136]
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x8, [sp, #48]
adrp x16, Lcount85
ldr x17, [x16, :lo12:Lcount85]
add x17, x17, #1
str x17, [x16, :lo12:Lcount85]
ldr x8, [x8, #16]
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x9, [sp, #136]
adrp x16, Lcount105
ldr x17, [x16, :lo12:Lcount105]
add x17, x17, #1
str x17, [x16, :lo12:Lcount105]
bl Lfn3fields
adrp x16, Lcount106
ldr x17, [x16, :lo12:Lcount106]
add x17, x17, #1
str x17, [x16, :lo12:Lcount106]
cbnz x1, Lfn3end
adrp x16, Lcount100
ldr x17, [x16, :lo12:Lcount100]
add x17, x17, #1
str x17, [x16, :lo12:Lcount100]
str x0, [sp, #144]
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x8, [sp, #48]
adrp x16, Lcount85
ldr x17, [x16, :lo12:Lcount85]
add x17, x17, #1
str x17, [x16, :lo12:Lcount85]
ldr x8, [x8, #8]
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x9, [sp, #144]
adrp x16, Lcount105
ldr x17, [x16, :lo12:Lcount105]
add x17, x17, #1
str x17, [x16, :lo12:Lcount105]
bl Lfn3fields
adrp x16, Lcount106
ldr x17, [x16, :lo12:Lcount106]
add x17, x17, #1
str x17, [x16, :lo12:Lcount106]
cbnz x1, Lfn3end
adrp x16, Lcount100
ldr x17, [x16, :lo12:Lcount100]
add x17, x17, #1
str x17, [x16, :lo12:Lcount100]
str x0, [sp, #152]
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x8, [sp, #48]
adrp x16, Lcount85
ldr x17, [x16, :lo12:Lcount85]
add x17, x17, #1
str x17, [x16, :lo12:Lcount85]
ldr x8, [x8, #0]
adrp x16, Lcount94
ldr x17, [x16, :lo12:Lcount94]
add x17, x17, #1
str x17, [x16, :lo12:Lcount94]
ldr x9, [sp, #152]
adrp x16, Lcount100
ldr x17, [x16, :lo12:Lcount100]
add x17, x17, #1
str x17, [x16, :lo12:Lcount100]
str x8, [sp, #48]
adrp x16, Lcount100
ldr x17, [x16, :lo12:Lcount100]
add x17, x17, #1
str x17, [x16, :lo12:Lcount100]
str x9, [sp, #56]
adrp x16, Lcount90
ldr x17, [x16, :lo12:Lcount90]
add x17, x17, #1
str x17, [x16, :lo12:Lcount90]
stp xzr, xzr, [sp, #64]
adrp x16, Lcount90
ldr x17, [x16, :lo12:Lcount90]
add x17, x17, #1
str x17, [x16, :lo12:Lcount90]
stp xzr, xzr, [sp, #80]
adrp x16, Lcount90
ldr x17, [x16, :lo12:Lcount90]
add x17, x17, #1
str x17, [x16, :lo12:Lcount90]
stp xzr, xzr, [sp, #96]
adrp x16, Lcount90
ldr x17, [x16, :lo12:Lcount90]
add x17, x17, #1
str x17, [x16, :lo12:Lcount90]
stp xzr, xzr, [sp, #112]
adrp x16, Lcount90
ldr x17, [x16, :lo12:Lcount90]
add x17, x17, #1
str x17, [x16, :lo12:Lcount90]
stp xzr, xzr, [sp, #128]
adrp x16, Lcount90
ldr x17, [x16, :lo12:Lcount90]
add x17, x17, #1
str x17, [x16, :lo12:Lcount90]
stp xzr, xzr, [sp, #144]
adrp x16, Lcount97
ldr x17, [x16, :lo12:Lcount97]
add x17, x17, #1
str x17, [x16, :lo12:Lcount97]
b Lfn3loop
adrp x16, Lcount97
ldr x17, [x16, :lo12:Lcount97]
add x17, x17, #1
str x17, [x16, :lo12:Lcount97]
b Lfn3match545end
Lfn3match545end:
adrp x16, Lcount88
ldr x17, [x16, :lo12:Lcount88]
add x17, x17, #1
str x17, [x16, :lo12:Lcount88]
mov x1, #0
adrp x16, Lcount97
ldr x17, [x16, :lo12:Lcount97]
add x17, x17, #1
str x17, [x16, :lo12:Lcount97]
b Lfn3end
Lfn3fail563_1:
adrp x16, Lcount107
ldr x17, [x16, :lo12:Lcount107]
add x17, x17, #1
str x17, [x16, :lo12:Lcount107]
adrp x0, Lfn3fail563_1location
adrp x16, Lcount92
ldr x17, [x16, :lo12:Lcount92]
add x17, x17, #1
str x17, [x16, :lo12:Lcount92]
add x0, x0, :lo12:Lfn3fail563_1location
adrp x16, Lcount108
ldr x17, [x16, :lo12:Lcount108]
add x17, x17, #1
str x17, [x16, :lo12:Lcount108]
bl fen_set_location
adrp x16, Lcount88
ldr x17, [x16, :lo12:Lcount88]
add x17, x17, #1
str x17, [x16, :lo12:Lcount88]
mov x1, #1
adrp x16, Lcount97
ldr x17, [x16, :lo12:Lcount97]
add x17, x17, #1
str x17, [x16, :lo12:Lcount97]
b Lfn3end
Lfn3fail562_3:
adrp x16, Lcount107
ldr x17, [x16, :lo12:Lcount107]
add x17, x17, #1
str x17, [x16, :lo12:Lcount107]
adrp x0, Lfn3fail562_3location
adrp x16, Lcount92
ldr x17, [x16, :lo12:Lcount92]
add x17, x17, #1
str x17, [x16, :lo12:Lcount92]
add x0, x0, :lo12:Lfn3fail562_3location
adrp x16, Lcount108
ldr x17, [x16, :lo12:Lcount108]
add x17, x17, #1
str x17, [x16, :lo12:Lcount108]
bl fen_set_location
adrp x16, Lcount88
ldr x17, [x16, :lo12:Lcount88]
add x17, x17, #1
str x17, [x16, :lo12:Lcount88]
mov x1, #3
adrp x16, Lcount97
ldr x17, [x16, :lo12:Lcount97]
add x17, x17, #1
str x17, [x16, :lo12:Lcount97]
b Lfn3end
Lfn3fail575_3:
adrp x16, Lcount107
ldr x17, [x16, :lo12:Lcount107]
add x17, x17, #1
str x17, [x16, :lo12:Lcount107]
adrp x0, Lfn3fail575_3location
adrp x16, Lcount92
ldr x17, [x16, :lo12:Lcount92]
add x17, x17, #1
str x17, [x16, :lo12:Lcount92]
add x0, x0, :lo12:Lfn3fail575_3location
adrp x16, Lcount108
ldr x17, [x16, :lo12:Lcount108]
add x17, x17, #1
str x17, [x16, :lo12:Lcount108]
bl fen_set_location
adrp x16, Lcount88
ldr x17, [x16, :lo12:Lcount88]
add x17, x17, #1
str x17, [x16, :lo12:Lcount88]
mov x1, #3
adrp x16, Lcount97
ldr x17, [x16, :lo12:Lcount97]
add x17, x17, #1
str x17, [x16, :lo12:Lcount97]
b Lfn3end
Lfn3end:
adrp x16, Lcount109
ldr x17, [x16, :lo12:Lcount109]
add x17, x17, #1
str x17, [x16, :lo12:Lcount109]
bl fen_leave_result
adrp x16, Lcount88
ldr x17, [x16, :lo12:Lcount88]
add x17, x17, #1
str x17, [x16, :lo12:Lcount88]
mov sp, x29
adrp x16, Lcount110
ldr x17, [x16, :lo12:Lcount110]
add x17, x17, #1
str x17, [x16, :lo12:Lcount110]
ldp x29, x30, [sp], #16
adrp x16, Lcount89
ldr x17, [x16, :lo12:Lcount89]
add x17, x17, #1
str x17, [x16, :lo12:Lcount89]
ret
Lfn4:
adrp x16, Lcount111
ldr x17, [x16, :lo12:Lcount111]
add x17, x17, #1
str x17, [x16, :lo12:Lcount111]
ldp x8, x9, [x0, #0]
adrp x16, Lcount111
ldr x17, [x16, :lo12:Lcount111]
add x17, x17, #1
str x17, [x16, :lo12:Lcount111]
ldp x10, x11, [x0, #16]
Lfn4fields:
adrp x16, Lcount112
ldr x17, [x16, :lo12:Lcount112]
add x17, x17, #1
str x17, [x16, :lo12:Lcount112]
stp x29, x30, [sp, #-16]!
adrp x16, Lcount113
ldr x17, [x16, :lo12:Lcount113]
add x17, x17, #1
str x17, [x16, :lo12:Lcount113]
mov x29, sp
adrp x16, Lcount114
ldr x17, [x16, :lo12:Lcount114]
add x17, x17, #1
str x17, [x16, :lo12:Lcount114]
sub sp, sp, #112
adrp x16, Lcount112
ldr x17, [x16, :lo12:Lcount112]
add x17, x17, #1
str x17, [x16, :lo12:Lcount112]
stp x8, x9, [sp, #48]
adrp x16, Lcount112
ldr x17, [x16, :lo12:Lcount112]
add x17, x17, #1
str x17, [x16, :lo12:Lcount112]
stp x10, x11, [sp, #64]
adrp x16, Lcount115
ldr x17, [x16, :lo12:Lcount115]
add x17, x17, #1
str x17, [x16, :lo12:Lcount115]
ldr x0, [sp, #48]
adrp x16, Lcount115
ldr x17, [x16, :lo12:Lcount115]
add x17, x17, #1
str x17, [x16, :lo12:Lcount115]
ldr x1, [sp, #56]
adrp x16, Lcount115
ldr x17, [x16, :lo12:Lcount115]
add x17, x17, #1
str x17, [x16, :lo12:Lcount115]
ldr x2, [sp, #64]
adrp x16, Lcount115
ldr x17, [x16, :lo12:Lcount115]
add x17, x17, #1
str x17, [x16, :lo12:Lcount115]
ldr x3, [sp, #72]
adrp x16, Lcount116
ldr x17, [x16, :lo12:Lcount116]
add x17, x17, #1
str x17, [x16, :lo12:Lcount116]
bl fen_try_byte_sum
adrp x16, Lcount117
ldr x17, [x16, :lo12:Lcount117]
add x17, x17, #1
str x17, [x16, :lo12:Lcount117]
cbz x1, Lfn4loop
adrp x16, Lcount113
ldr x17, [x16, :lo12:Lcount113]
add x17, x17, #1
str x17, [x16, :lo12:Lcount113]
mov x1, #0
adrp x16, Lcount118
ldr x17, [x16, :lo12:Lcount118]
add x17, x17, #1
str x17, [x16, :lo12:Lcount118]
b Lfn4end
Lfn4loop:
adrp x16, Lcount115
ldr x17, [x16, :lo12:Lcount115]
add x17, x17, #1
str x17, [x16, :lo12:Lcount115]
ldr x0, [sp, #56]
adrp x16, Lcount115
ldr x17, [x16, :lo12:Lcount115]
add x17, x17, #1
str x17, [x16, :lo12:Lcount115]
ldr x2, [sp, #64]
adrp x16, Lcount119
ldr x17, [x16, :lo12:Lcount119]
add x17, x17, #1
str x17, [x16, :lo12:Lcount119]
cmp x0, x2
adrp x16, Lcount120
ldr x17, [x16, :lo12:Lcount120]
add x17, x17, #1
str x17, [x16, :lo12:Lcount120]
b.ne Lfn4if649else
adrp x16, Lcount115
ldr x17, [x16, :lo12:Lcount115]
add x17, x17, #1
str x17, [x16, :lo12:Lcount115]
ldr x0, [sp, #72]
adrp x16, Lcount118
ldr x17, [x16, :lo12:Lcount118]
add x17, x17, #1
str x17, [x16, :lo12:Lcount118]
b Lfn4if649done
Lfn4if649else:
adrp x16, Lcount115
ldr x17, [x16, :lo12:Lcount115]
add x17, x17, #1
str x17, [x16, :lo12:Lcount115]
ldr x0, [sp, #56]
adrp x16, Lcount121
ldr x17, [x16, :lo12:Lcount121]
add x17, x17, #1
str x17, [x16, :lo12:Lcount121]
adds x0, x0, #1
adrp x16, Lcount122
ldr x17, [x16, :lo12:Lcount122]
add x17, x17, #1
str x17, [x16, :lo12:Lcount122]
b.vs Lfn4fail657_1
adrp x16, Lcount123
ldr x17, [x16, :lo12:Lcount123]
add x17, x17, #1
str x17, [x16, :lo12:Lcount123]
str x0, [sp, #80]
adrp x16, Lcount115
ldr x17, [x16, :lo12:Lcount115]
add x17, x17, #1
str x17, [x16, :lo12:Lcount115]
ldr x0, [sp, #48]
adrp x16, Lcount115
ldr x17, [x16, :lo12:Lcount115]
add x17, x17, #1
str x17, [x16, :lo12:Lcount115]
ldr x2, [sp, #56]
adrp x16, Lcount124
ldr x17, [x16, :lo12:Lcount124]
add x17, x17, #1
str x17, [x16, :lo12:Lcount124]
ldr x3, [x0]
adrp x16, Lcount119
ldr x17, [x16, :lo12:Lcount119]
add x17, x17, #1
str x17, [x16, :lo12:Lcount119]
cmp x2, x3
adrp x16, Lcount125
ldr x17, [x16, :lo12:Lcount125]
add x17, x17, #1
str x17, [x16, :lo12:Lcount125]
b.hs Lfn4fail663_4
adrp x16, Lcount124
ldr x17, [x16, :lo12:Lcount124]
add x17, x17, #1
str x17, [x16, :lo12:Lcount124]
ldr w3, [x0, #72]
adrp x16, Lcount126
ldr x17, [x16, :lo12:Lcount126]
add x17, x17, #1
str x17, [x16, :lo12:Lcount126]
cmn w3, #1
adrp x16, Lcount120
ldr x17, [x16, :lo12:Lcount120]
add x17, x17, #1
str x17, [x16, :lo12:Lcount120]
b.ne 1f
adrp x16, Lcount127
ldr x17, [x16, :lo12:Lcount127]
add x17, x17, #1
str x17, [x16, :lo12:Lcount127]
add x0, x0, #80
adrp x16, Lcount128
ldr x17, [x16, :lo12:Lcount128]
add x17, x17, #1
str x17, [x16, :lo12:Lcount128]
ldrb w0, [x0, x2]
adrp x16, Lcount118
ldr x17, [x16, :lo12:Lcount118]
add x17, x17, #1
str x17, [x16, :lo12:Lcount118]
b 2f
1:
adrp x16, Lcount113
ldr x17, [x16, :lo12:Lcount113]
add x17, x17, #1
str x17, [x16, :lo12:Lcount113]
mov x1, x2
adrp x16, Lcount129
ldr x17, [x16, :lo12:Lcount129]
add x17, x17, #1
str x17, [x16, :lo12:Lcount129]
bl fen_bytes_index
2:
adrp x16, Lcount123
ldr x17, [x16, :lo12:Lcount123]
add x17, x17, #1
str x17, [x16, :lo12:Lcount123]
str x0, [sp, #88]
adrp x16, Lcount115
ldr x17, [x16, :lo12:Lcount115]
add x17, x17, #1
str x17, [x16, :lo12:Lcount115]
ldr x0, [sp, #72]
adrp x16, Lcount115
ldr x17, [x16, :lo12:Lcount115]
add x17, x17, #1
str x17, [x16, :lo12:Lcount115]
ldr x2, [sp, #88]
adrp x16, Lcount121
ldr x17, [x16, :lo12:Lcount121]
add x17, x17, #1
str x17, [x16, :lo12:Lcount121]
adds x0, x0, x2
adrp x16, Lcount122
ldr x17, [x16, :lo12:Lcount122]
add x17, x17, #1
str x17, [x16, :lo12:Lcount122]
b.vs Lfn4fail661_1
adrp x16, Lcount123
ldr x17, [x16, :lo12:Lcount123]
add x17, x17, #1
str x17, [x16, :lo12:Lcount123]
str x0, [sp, #96]
adrp x16, Lcount115
ldr x17, [x16, :lo12:Lcount115]
add x17, x17, #1
str x17, [x16, :lo12:Lcount115]
ldr x8, [sp, #80]
adrp x16, Lcount115
ldr x17, [x16, :lo12:Lcount115]
add x17, x17, #1
str x17, [x16, :lo12:Lcount115]
ldr x9, [sp, #96]
adrp x16, Lcount123
ldr x17, [x16, :lo12:Lcount123]
add x17, x17, #1
str x17, [x16, :lo12:Lcount123]
str x8, [sp, #56]
adrp x16, Lcount123
ldr x17, [x16, :lo12:Lcount123]
add x17, x17, #1
str x17, [x16, :lo12:Lcount123]
str x9, [sp, #72]
adrp x16, Lcount118
ldr x17, [x16, :lo12:Lcount118]
add x17, x17, #1
str x17, [x16, :lo12:Lcount118]
b Lfn4loop
Lfn4if649done:
adrp x16, Lcount113
ldr x17, [x16, :lo12:Lcount113]
add x17, x17, #1
str x17, [x16, :lo12:Lcount113]
mov x1, #0
adrp x16, Lcount118
ldr x17, [x16, :lo12:Lcount118]
add x17, x17, #1
str x17, [x16, :lo12:Lcount118]
b Lfn4end
Lfn4fail657_1:
adrp x16, Lcount130
ldr x17, [x16, :lo12:Lcount130]
add x17, x17, #1
str x17, [x16, :lo12:Lcount130]
adrp x0, Lfn4fail657_1location
adrp x16, Lcount127
ldr x17, [x16, :lo12:Lcount127]
add x17, x17, #1
str x17, [x16, :lo12:Lcount127]
add x0, x0, :lo12:Lfn4fail657_1location
adrp x16, Lcount131
ldr x17, [x16, :lo12:Lcount131]
add x17, x17, #1
str x17, [x16, :lo12:Lcount131]
bl fen_set_location
adrp x16, Lcount113
ldr x17, [x16, :lo12:Lcount113]
add x17, x17, #1
str x17, [x16, :lo12:Lcount113]
mov x1, #1
adrp x16, Lcount118
ldr x17, [x16, :lo12:Lcount118]
add x17, x17, #1
str x17, [x16, :lo12:Lcount118]
b Lfn4end
Lfn4fail663_4:
adrp x16, Lcount130
ldr x17, [x16, :lo12:Lcount130]
add x17, x17, #1
str x17, [x16, :lo12:Lcount130]
adrp x0, Lfn4fail663_4location
adrp x16, Lcount127
ldr x17, [x16, :lo12:Lcount127]
add x17, x17, #1
str x17, [x16, :lo12:Lcount127]
add x0, x0, :lo12:Lfn4fail663_4location
adrp x16, Lcount131
ldr x17, [x16, :lo12:Lcount131]
add x17, x17, #1
str x17, [x16, :lo12:Lcount131]
bl fen_set_location
adrp x16, Lcount113
ldr x17, [x16, :lo12:Lcount113]
add x17, x17, #1
str x17, [x16, :lo12:Lcount113]
mov x1, #4
adrp x16, Lcount118
ldr x17, [x16, :lo12:Lcount118]
add x17, x17, #1
str x17, [x16, :lo12:Lcount118]
b Lfn4end
Lfn4fail661_1:
adrp x16, Lcount130
ldr x17, [x16, :lo12:Lcount130]
add x17, x17, #1
str x17, [x16, :lo12:Lcount130]
adrp x0, Lfn4fail661_1location
adrp x16, Lcount127
ldr x17, [x16, :lo12:Lcount127]
add x17, x17, #1
str x17, [x16, :lo12:Lcount127]
add x0, x0, :lo12:Lfn4fail661_1location
adrp x16, Lcount131
ldr x17, [x16, :lo12:Lcount131]
add x17, x17, #1
str x17, [x16, :lo12:Lcount131]
bl fen_set_location
adrp x16, Lcount113
ldr x17, [x16, :lo12:Lcount113]
add x17, x17, #1
str x17, [x16, :lo12:Lcount113]
mov x1, #1
adrp x16, Lcount118
ldr x17, [x16, :lo12:Lcount118]
add x17, x17, #1
str x17, [x16, :lo12:Lcount118]
b Lfn4end
Lfn4end:
adrp x16, Lcount113
ldr x17, [x16, :lo12:Lcount113]
add x17, x17, #1
str x17, [x16, :lo12:Lcount113]
mov sp, x29
adrp x16, Lcount132
ldr x17, [x16, :lo12:Lcount132]
add x17, x17, #1
str x17, [x16, :lo12:Lcount132]
ldp x29, x30, [sp], #16
adrp x16, Lcount133
ldr x17, [x16, :lo12:Lcount133]
add x17, x17, #1
str x17, [x16, :lo12:Lcount133]
ret
Lfn5:
adrp x16, Lcount134
ldr x17, [x16, :lo12:Lcount134]
add x17, x17, #1
str x17, [x16, :lo12:Lcount134]
ldp x8, x9, [x0, #0]
adrp x16, Lcount134
ldr x17, [x16, :lo12:Lcount134]
add x17, x17, #1
str x17, [x16, :lo12:Lcount134]
ldp x10, x11, [x0, #16]
adrp x16, Lcount134
ldr x17, [x16, :lo12:Lcount134]
add x17, x17, #1
str x17, [x16, :lo12:Lcount134]
ldp x12, x13, [x0, #32]
adrp x16, Lcount135
ldr x17, [x16, :lo12:Lcount135]
add x17, x17, #1
str x17, [x16, :lo12:Lcount135]
ldr x14, [x0, #48]
Lfn5fields:
adrp x16, Lcount136
ldr x17, [x16, :lo12:Lcount136]
add x17, x17, #1
str x17, [x16, :lo12:Lcount136]
stp x29, x30, [sp, #-16]!
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x29, sp
adrp x16, Lcount136
ldr x17, [x16, :lo12:Lcount136]
add x17, x17, #1
str x17, [x16, :lo12:Lcount136]
stp x19, x20, [sp, #-16]!
adrp x16, Lcount136
ldr x17, [x16, :lo12:Lcount136]
add x17, x17, #1
str x17, [x16, :lo12:Lcount136]
stp x21, x22, [sp, #-16]!
adrp x16, Lcount136
ldr x17, [x16, :lo12:Lcount136]
add x17, x17, #1
str x17, [x16, :lo12:Lcount136]
stp x23, x24, [sp, #-16]!
adrp x16, Lcount136
ldr x17, [x16, :lo12:Lcount136]
add x17, x17, #1
str x17, [x16, :lo12:Lcount136]
stp x25, x26, [sp, #-16]!
adrp x16, Lcount138
ldr x17, [x16, :lo12:Lcount138]
add x17, x17, #1
str x17, [x16, :lo12:Lcount138]
sub sp, sp, #288
adrp x16, Lcount136
ldr x17, [x16, :lo12:Lcount136]
add x17, x17, #1
str x17, [x16, :lo12:Lcount136]
stp xzr, xzr, [sp, #88]
adrp x16, Lcount136
ldr x17, [x16, :lo12:Lcount136]
add x17, x17, #1
str x17, [x16, :lo12:Lcount136]
stp xzr, xzr, [sp, #104]
adrp x16, Lcount136
ldr x17, [x16, :lo12:Lcount136]
add x17, x17, #1
str x17, [x16, :lo12:Lcount136]
stp xzr, xzr, [sp, #120]
adrp x16, Lcount136
ldr x17, [x16, :lo12:Lcount136]
add x17, x17, #1
str x17, [x16, :lo12:Lcount136]
stp xzr, xzr, [sp, #136]
adrp x16, Lcount139
ldr x17, [x16, :lo12:Lcount139]
add x17, x17, #1
str x17, [x16, :lo12:Lcount139]
str xzr, [sp, #152]
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x19, x8
adrp x16, Lcount139
ldr x17, [x16, :lo12:Lcount139]
add x17, x17, #1
str x17, [x16, :lo12:Lcount139]
str x9, [sp, #48]
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x21, x10
adrp x16, Lcount136
ldr x17, [x16, :lo12:Lcount136]
add x17, x17, #1
str x17, [x16, :lo12:Lcount136]
stp x11, x12, [sp, #56]
adrp x16, Lcount136
ldr x17, [x16, :lo12:Lcount136]
add x17, x17, #1
str x17, [x16, :lo12:Lcount136]
stp x13, x14, [sp, #72]
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, sp, #16
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x1, sp, #48
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x2, #14
adrp x16, Lcount141
ldr x17, [x16, :lo12:Lcount141]
add x17, x17, #1
str x17, [x16, :lo12:Lcount141]
bl fen_enter
Lfn5loop:
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x0, [sp, #48]
adrp x16, Lcount135
ldr x17, [x16, :lo12:Lcount135]
add x17, x17, #1
str x17, [x16, :lo12:Lcount135]
ldr x0, [x0]
adrp x16, Lcount139
ldr x17, [x16, :lo12:Lcount139]
add x17, x17, #1
str x17, [x16, :lo12:Lcount139]
str x0, [sp, #160]
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x0, x21
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x2, [sp, #160]
adrp x16, Lcount143
ldr x17, [x16, :lo12:Lcount143]
add x17, x17, #1
str x17, [x16, :lo12:Lcount143]
cmp x0, x2
adrp x16, Lcount144
ldr x17, [x16, :lo12:Lcount144]
add x17, x17, #1
str x17, [x16, :lo12:Lcount144]
b.ne Lfn5if696else
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x0, #15
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #11
adrp x16, Lcount145
ldr x17, [x16, :lo12:Lcount145]
add x17, x17, #1
str x17, [x16, :lo12:Lcount145]
bl fen_allocate
adrp x16, Lcount146
ldr x17, [x16, :lo12:Lcount146]
add x17, x17, #1
str x17, [x16, :lo12:Lcount146]
cbz x0, Lfn5fail703_3
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x2, [sp, #56]
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x3, [sp, #64]
adrp x16, Lcount147
ldr x17, [x16, :lo12:Lcount147]
add x17, x17, #1
str x17, [x16, :lo12:Lcount147]
stp x2, x3, [x0, #0]
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x2, [sp, #72]
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x3, [sp, #80]
adrp x16, Lcount147
ldr x17, [x16, :lo12:Lcount147]
add x17, x17, #1
str x17, [x16, :lo12:Lcount147]
stp x2, x3, [x0, #16]
adrp x16, Lcount139
ldr x17, [x16, :lo12:Lcount139]
add x17, x17, #1
str x17, [x16, :lo12:Lcount139]
str x0, [sp, #88]
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x0, #2
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #13
adrp x16, Lcount145
ldr x17, [x16, :lo12:Lcount145]
add x17, x17, #1
str x17, [x16, :lo12:Lcount145]
bl fen_allocate
adrp x16, Lcount146
ldr x17, [x16, :lo12:Lcount146]
add x17, x17, #1
str x17, [x16, :lo12:Lcount146]
cbz x0, Lfn5fail701_3
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x2, x19
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x3, [sp, #88]
adrp x16, Lcount147
ldr x17, [x16, :lo12:Lcount147]
add x17, x17, #1
str x17, [x16, :lo12:Lcount147]
stp x2, x3, [x0, #0]
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5if696done
Lfn5if696else:
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x0, [sp, #48]
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x2, x21
adrp x16, Lcount135
ldr x17, [x16, :lo12:Lcount135]
add x17, x17, #1
str x17, [x16, :lo12:Lcount135]
ldr x3, [x0]
adrp x16, Lcount143
ldr x17, [x16, :lo12:Lcount143]
add x17, x17, #1
str x17, [x16, :lo12:Lcount143]
cmp x2, x3
adrp x16, Lcount149
ldr x17, [x16, :lo12:Lcount149]
add x17, x17, #1
str x17, [x16, :lo12:Lcount149]
b.hs Lfn5fail711_4
adrp x16, Lcount135
ldr x17, [x16, :lo12:Lcount135]
add x17, x17, #1
str x17, [x16, :lo12:Lcount135]
ldr w3, [x0, #72]
adrp x16, Lcount150
ldr x17, [x16, :lo12:Lcount150]
add x17, x17, #1
str x17, [x16, :lo12:Lcount150]
cmn w3, #1
adrp x16, Lcount144
ldr x17, [x16, :lo12:Lcount144]
add x17, x17, #1
str x17, [x16, :lo12:Lcount144]
b.ne 1f
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, x0, #80
adrp x16, Lcount151
ldr x17, [x16, :lo12:Lcount151]
add x17, x17, #1
str x17, [x16, :lo12:Lcount151]
ldrb w0, [x0, x2]
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b 2f
1:
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, x2
adrp x16, Lcount152
ldr x17, [x16, :lo12:Lcount152]
add x17, x17, #1
str x17, [x16, :lo12:Lcount152]
bl fen_bytes_index
2:
adrp x16, Lcount153
ldr x17, [x16, :lo12:Lcount153]
add x17, x17, #1
str x17, [x16, :lo12:Lcount153]
lsl x2, x0, #8
adrp x16, Lcount143
ldr x17, [x16, :lo12:Lcount143]
add x17, x17, #1
str x17, [x16, :lo12:Lcount143]
cmp x0, x2, asr #8
adrp x16, Lcount144
ldr x17, [x16, :lo12:Lcount144]
add x17, x17, #1
str x17, [x16, :lo12:Lcount144]
b.ne Lfn5fail710_1
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x0, x2
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x26, x0
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x0, [sp, #48]
adrp x16, Lcount135
ldr x17, [x16, :lo12:Lcount135]
add x17, x17, #1
str x17, [x16, :lo12:Lcount135]
ldr x0, [x0]
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x2, x21
adrp x16, Lcount154
ldr x17, [x16, :lo12:Lcount154]
add x17, x17, #1
str x17, [x16, :lo12:Lcount154]
subs x0, x0, x2
adrp x16, Lcount155
ldr x17, [x16, :lo12:Lcount155]
add x17, x17, #1
str x17, [x16, :lo12:Lcount155]
b.vs Lfn5fail717_1
adrp x16, Lcount143
ldr x17, [x16, :lo12:Lcount143]
add x17, x17, #1
str x17, [x16, :lo12:Lcount143]
cmp x0, #3
adrp x16, Lcount156
ldr x17, [x16, :lo12:Lcount156]
add x17, x17, #1
str x17, [x16, :lo12:Lcount156]
b.ge Lfn5if715else
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x0, x19
adrp x16, Lcount157
ldr x17, [x16, :lo12:Lcount157]
add x17, x17, #1
str x17, [x16, :lo12:Lcount157]
adds x0, x0, #1
adrp x16, Lcount155
ldr x17, [x16, :lo12:Lcount155]
add x17, x17, #1
str x17, [x16, :lo12:Lcount155]
b.vs Lfn5fail725_1
adrp x16, Lcount139
ldr x17, [x16, :lo12:Lcount139]
add x17, x17, #1
str x17, [x16, :lo12:Lcount139]
str x0, [sp, #168]
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x0, #15
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #11
adrp x16, Lcount145
ldr x17, [x16, :lo12:Lcount145]
add x17, x17, #1
str x17, [x16, :lo12:Lcount145]
bl fen_allocate
adrp x16, Lcount146
ldr x17, [x16, :lo12:Lcount146]
add x17, x17, #1
str x17, [x16, :lo12:Lcount146]
cbz x0, Lfn5fail729_3
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x2, [sp, #56]
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x3, [sp, #64]
adrp x16, Lcount147
ldr x17, [x16, :lo12:Lcount147]
add x17, x17, #1
str x17, [x16, :lo12:Lcount147]
stp x2, x3, [x0, #0]
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x2, [sp, #72]
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x3, [sp, #80]
adrp x16, Lcount147
ldr x17, [x16, :lo12:Lcount147]
add x17, x17, #1
str x17, [x16, :lo12:Lcount147]
stp x2, x3, [x0, #16]
adrp x16, Lcount139
ldr x17, [x16, :lo12:Lcount139]
add x17, x17, #1
str x17, [x16, :lo12:Lcount139]
str x0, [sp, #96]
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x0, #4
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #14
adrp x16, Lcount145
ldr x17, [x16, :lo12:Lcount145]
add x17, x17, #1
str x17, [x16, :lo12:Lcount145]
bl fen_allocate
adrp x16, Lcount146
ldr x17, [x16, :lo12:Lcount146]
add x17, x17, #1
str x17, [x16, :lo12:Lcount146]
cbz x0, Lfn5fail724_3
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x2, [sp, #168]
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x3, x26
adrp x16, Lcount147
ldr x17, [x16, :lo12:Lcount147]
add x17, x17, #1
str x17, [x16, :lo12:Lcount147]
stp x2, x3, [x0, #0]
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x2, [sp, #96]
adrp x16, Lcount158
ldr x17, [x16, :lo12:Lcount158]
add x17, x17, #1
str x17, [x16, :lo12:Lcount158]
str x2, [x0, #16]
adrp x16, Lcount139
ldr x17, [x16, :lo12:Lcount139]
add x17, x17, #1
str x17, [x16, :lo12:Lcount139]
str x0, [sp, #104]
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x0, x21
adrp x16, Lcount157
ldr x17, [x16, :lo12:Lcount157]
add x17, x17, #1
str x17, [x16, :lo12:Lcount157]
adds x0, x0, #1
adrp x16, Lcount155
ldr x17, [x16, :lo12:Lcount155]
add x17, x17, #1
str x17, [x16, :lo12:Lcount155]
b.vs Lfn5fail735_1
adrp x16, Lcount139
ldr x17, [x16, :lo12:Lcount139]
add x17, x17, #1
str x17, [x16, :lo12:Lcount139]
str x0, [sp, #176]
adrp x16, Lcount159
ldr x17, [x16, :lo12:Lcount159]
add x17, x17, #1
str x17, [x16, :lo12:Lcount159]
bl fen_leave_result
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x8, [sp, #104]
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x9, [sp, #48]
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x10, [sp, #176]
adrp x16, Lcount134
ldr x17, [x16, :lo12:Lcount134]
add x17, x17, #1
str x17, [x16, :lo12:Lcount134]
ldp x19, x20, [x29, #-16]
adrp x16, Lcount134
ldr x17, [x16, :lo12:Lcount134]
add x17, x17, #1
str x17, [x16, :lo12:Lcount134]
ldp x21, x22, [x29, #-32]
adrp x16, Lcount134
ldr x17, [x16, :lo12:Lcount134]
add x17, x17, #1
str x17, [x16, :lo12:Lcount134]
ldp x23, x24, [x29, #-48]
adrp x16, Lcount134
ldr x17, [x16, :lo12:Lcount134]
add x17, x17, #1
str x17, [x16, :lo12:Lcount134]
ldp x25, x26, [x29, #-64]
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov sp, x29
adrp x16, Lcount160
ldr x17, [x16, :lo12:Lcount160]
add x17, x17, #1
str x17, [x16, :lo12:Lcount160]
ldp x29, x30, [sp], #16
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn7fields
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5if715done
Lfn5if715else:
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x0, x21
adrp x16, Lcount157
ldr x17, [x16, :lo12:Lcount157]
add x17, x17, #1
str x17, [x16, :lo12:Lcount157]
adds x0, x0, #1
adrp x16, Lcount155
ldr x17, [x16, :lo12:Lcount155]
add x17, x17, #1
str x17, [x16, :lo12:Lcount155]
b.vs Lfn5fail744_1
adrp x16, Lcount139
ldr x17, [x16, :lo12:Lcount139]
add x17, x17, #1
str x17, [x16, :lo12:Lcount139]
str x0, [sp, #184]
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x0, [sp, #48]
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x2, [sp, #184]
adrp x16, Lcount135
ldr x17, [x16, :lo12:Lcount135]
add x17, x17, #1
str x17, [x16, :lo12:Lcount135]
ldr x3, [x0]
adrp x16, Lcount143
ldr x17, [x16, :lo12:Lcount143]
add x17, x17, #1
str x17, [x16, :lo12:Lcount143]
cmp x2, x3
adrp x16, Lcount149
ldr x17, [x16, :lo12:Lcount149]
add x17, x17, #1
str x17, [x16, :lo12:Lcount149]
b.hs Lfn5fail742_4
adrp x16, Lcount135
ldr x17, [x16, :lo12:Lcount135]
add x17, x17, #1
str x17, [x16, :lo12:Lcount135]
ldr w3, [x0, #72]
adrp x16, Lcount150
ldr x17, [x16, :lo12:Lcount150]
add x17, x17, #1
str x17, [x16, :lo12:Lcount150]
cmn w3, #1
adrp x16, Lcount144
ldr x17, [x16, :lo12:Lcount144]
add x17, x17, #1
str x17, [x16, :lo12:Lcount144]
b.ne 1f
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, x0, #80
adrp x16, Lcount151
ldr x17, [x16, :lo12:Lcount151]
add x17, x17, #1
str x17, [x16, :lo12:Lcount151]
ldrb w0, [x0, x2]
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b 2f
1:
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, x2
adrp x16, Lcount152
ldr x17, [x16, :lo12:Lcount152]
add x17, x17, #1
str x17, [x16, :lo12:Lcount152]
bl fen_bytes_index
2:
adrp x16, Lcount139
ldr x17, [x16, :lo12:Lcount139]
add x17, x17, #1
str x17, [x16, :lo12:Lcount139]
str x0, [sp, #192]
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x0, x26
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x2, [sp, #192]
adrp x16, Lcount157
ldr x17, [x16, :lo12:Lcount157]
add x17, x17, #1
str x17, [x16, :lo12:Lcount157]
adds x0, x0, x2
adrp x16, Lcount155
ldr x17, [x16, :lo12:Lcount155]
add x17, x17, #1
str x17, [x16, :lo12:Lcount155]
b.vs Lfn5fail740_1
adrp x16, Lcount139
ldr x17, [x16, :lo12:Lcount139]
add x17, x17, #1
str x17, [x16, :lo12:Lcount139]
str x0, [sp, #200]
adrp x16, Lcount143
ldr x17, [x16, :lo12:Lcount143]
add x17, x17, #1
str x17, [x16, :lo12:Lcount143]
cmp x0, #0
adrp x16, Lcount144
ldr x17, [x16, :lo12:Lcount144]
add x17, x17, #1
str x17, [x16, :lo12:Lcount144]
b.ne Lfn5if747else
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x0, #0
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #17
adrp x16, Lcount145
ldr x17, [x16, :lo12:Lcount145]
add x17, x17, #1
str x17, [x16, :lo12:Lcount145]
bl fen_allocate
adrp x16, Lcount146
ldr x17, [x16, :lo12:Lcount146]
add x17, x17, #1
str x17, [x16, :lo12:Lcount146]
cbz x0, Lfn5fail751_3
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x2, x19
adrp x16, Lcount158
ldr x17, [x16, :lo12:Lcount158]
add x17, x17, #1
str x17, [x16, :lo12:Lcount158]
str x2, [x0, #0]
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5if747done
Lfn5if747else:
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x0, x21
adrp x16, Lcount157
ldr x17, [x16, :lo12:Lcount157]
add x17, x17, #1
str x17, [x16, :lo12:Lcount157]
adds x0, x0, #2
adrp x16, Lcount155
ldr x17, [x16, :lo12:Lcount155]
add x17, x17, #1
str x17, [x16, :lo12:Lcount155]
b.vs Lfn5fail757_1
adrp x16, Lcount139
ldr x17, [x16, :lo12:Lcount139]
add x17, x17, #1
str x17, [x16, :lo12:Lcount139]
str x0, [sp, #208]
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x0, [sp, #48]
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x2, [sp, #208]
adrp x16, Lcount135
ldr x17, [x16, :lo12:Lcount135]
add x17, x17, #1
str x17, [x16, :lo12:Lcount135]
ldr x3, [x0]
adrp x16, Lcount143
ldr x17, [x16, :lo12:Lcount143]
add x17, x17, #1
str x17, [x16, :lo12:Lcount143]
cmp x2, x3
adrp x16, Lcount149
ldr x17, [x16, :lo12:Lcount149]
add x17, x17, #1
str x17, [x16, :lo12:Lcount149]
b.hs Lfn5fail755_4
adrp x16, Lcount135
ldr x17, [x16, :lo12:Lcount135]
add x17, x17, #1
str x17, [x16, :lo12:Lcount135]
ldr w3, [x0, #72]
adrp x16, Lcount150
ldr x17, [x16, :lo12:Lcount150]
add x17, x17, #1
str x17, [x16, :lo12:Lcount150]
cmn w3, #1
adrp x16, Lcount144
ldr x17, [x16, :lo12:Lcount144]
add x17, x17, #1
str x17, [x16, :lo12:Lcount144]
b.ne 1f
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, x0, #80
adrp x16, Lcount151
ldr x17, [x16, :lo12:Lcount151]
add x17, x17, #1
str x17, [x16, :lo12:Lcount151]
ldrb w0, [x0, x2]
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b 2f
1:
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, x2
adrp x16, Lcount152
ldr x17, [x16, :lo12:Lcount152]
add x17, x17, #1
str x17, [x16, :lo12:Lcount152]
bl fen_bytes_index
2:
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x22, x0
adrp x16, Lcount143
ldr x17, [x16, :lo12:Lcount143]
add x17, x17, #1
str x17, [x16, :lo12:Lcount143]
cmp x0, #63
adrp x16, Lcount161
ldr x17, [x16, :lo12:Lcount161]
add x17, x17, #1
str x17, [x16, :lo12:Lcount161]
b.le Lfn5if760else
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x0, x19
adrp x16, Lcount157
ldr x17, [x16, :lo12:Lcount157]
add x17, x17, #1
str x17, [x16, :lo12:Lcount157]
adds x0, x0, #2
adrp x16, Lcount155
ldr x17, [x16, :lo12:Lcount155]
add x17, x17, #1
str x17, [x16, :lo12:Lcount155]
b.vs Lfn5fail765_1
adrp x16, Lcount139
ldr x17, [x16, :lo12:Lcount139]
add x17, x17, #1
str x17, [x16, :lo12:Lcount139]
str x0, [sp, #216]
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x0, #0
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #17
adrp x16, Lcount145
ldr x17, [x16, :lo12:Lcount145]
add x17, x17, #1
str x17, [x16, :lo12:Lcount145]
bl fen_allocate
adrp x16, Lcount146
ldr x17, [x16, :lo12:Lcount146]
add x17, x17, #1
str x17, [x16, :lo12:Lcount146]
cbz x0, Lfn5fail764_3
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x2, [sp, #216]
adrp x16, Lcount158
ldr x17, [x16, :lo12:Lcount158]
add x17, x17, #1
str x17, [x16, :lo12:Lcount158]
str x2, [x0, #0]
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5if760done
Lfn5if760else:
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x0, x21
adrp x16, Lcount157
ldr x17, [x16, :lo12:Lcount157]
add x17, x17, #1
str x17, [x16, :lo12:Lcount157]
adds x0, x0, #3
adrp x16, Lcount155
ldr x17, [x16, :lo12:Lcount155]
add x17, x17, #1
str x17, [x16, :lo12:Lcount155]
b.vs Lfn5fail770_1
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x24, x0
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x0, [sp, #200]
adrp x16, Lcount154
ldr x17, [x16, :lo12:Lcount154]
add x17, x17, #1
str x17, [x16, :lo12:Lcount154]
subs x0, x0, #1
adrp x16, Lcount155
ldr x17, [x16, :lo12:Lcount155]
add x17, x17, #1
str x17, [x16, :lo12:Lcount155]
b.vs Lfn5fail775_1
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x20, x0
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x0, [sp, #48]
adrp x16, Lcount135
ldr x17, [x16, :lo12:Lcount135]
add x17, x17, #1
str x17, [x16, :lo12:Lcount135]
ldr x0, [x0]
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x2, x24
adrp x16, Lcount154
ldr x17, [x16, :lo12:Lcount154]
add x17, x17, #1
str x17, [x16, :lo12:Lcount154]
subs x0, x0, x2
adrp x16, Lcount155
ldr x17, [x16, :lo12:Lcount155]
add x17, x17, #1
str x17, [x16, :lo12:Lcount155]
b.vs Lfn5fail781_1
adrp x16, Lcount139
ldr x17, [x16, :lo12:Lcount139]
add x17, x17, #1
str x17, [x16, :lo12:Lcount139]
str x0, [sp, #224]
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x0, x20
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x2, [sp, #224]
adrp x16, Lcount143
ldr x17, [x16, :lo12:Lcount143]
add x17, x17, #1
str x17, [x16, :lo12:Lcount143]
cmp x0, x2
adrp x16, Lcount162
ldr x17, [x16, :lo12:Lcount162]
add x17, x17, #1
str x17, [x16, :lo12:Lcount162]
b.gt Lfn5if778else
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x0, x24
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x2, x20
adrp x16, Lcount157
ldr x17, [x16, :lo12:Lcount157]
add x17, x17, #1
str x17, [x16, :lo12:Lcount157]
adds x0, x0, x2
adrp x16, Lcount155
ldr x17, [x16, :lo12:Lcount155]
add x17, x17, #1
str x17, [x16, :lo12:Lcount155]
b.vs Lfn5fail787_1
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x23, x0
adrp x16, Lcount163
ldr x17, [x16, :lo12:Lcount163]
add x17, x17, #1
str x17, [x16, :lo12:Lcount163]
movz x0, #0, lsl #0
adrp x16, Lcount139
ldr x17, [x16, :lo12:Lcount139]
add x17, x17, #1
str x17, [x16, :lo12:Lcount139]
str x0, [sp, #232]
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x8, [sp, #48]
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x9, x24
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x10, x23
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x11, [sp, #232]
adrp x16, Lcount164
ldr x17, [x16, :lo12:Lcount164]
add x17, x17, #1
str x17, [x16, :lo12:Lcount164]
bl Lfn4fields
adrp x16, Lcount165
ldr x17, [x16, :lo12:Lcount165]
add x17, x17, #1
str x17, [x16, :lo12:Lcount165]
cbnz x1, Lfn5end
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x25, x0
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x0, x22
adrp x16, Lcount143
ldr x17, [x16, :lo12:Lcount143]
add x17, x17, #1
str x17, [x16, :lo12:Lcount143]
cmp x0, #32
adrp x16, Lcount156
ldr x17, [x16, :lo12:Lcount156]
add x17, x17, #1
str x17, [x16, :lo12:Lcount156]
b.ge Lfn5if798else
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x0, x22
adrp x16, Lcount143
ldr x17, [x16, :lo12:Lcount143]
add x17, x17, #1
str x17, [x16, :lo12:Lcount143]
cmp x0, #16
adrp x16, Lcount156
ldr x17, [x16, :lo12:Lcount156]
add x17, x17, #1
str x17, [x16, :lo12:Lcount156]
b.ge Lfn5if802else
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x0, x19
adrp x16, Lcount157
ldr x17, [x16, :lo12:Lcount157]
add x17, x17, #1
str x17, [x16, :lo12:Lcount157]
adds x0, x0, #3
adrp x16, Lcount155
ldr x17, [x16, :lo12:Lcount155]
add x17, x17, #1
str x17, [x16, :lo12:Lcount155]
b.vs Lfn5fail809_1
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x2, x20
adrp x16, Lcount157
ldr x17, [x16, :lo12:Lcount157]
add x17, x17, #1
str x17, [x16, :lo12:Lcount157]
adds x0, x0, x2
adrp x16, Lcount155
ldr x17, [x16, :lo12:Lcount155]
add x17, x17, #1
str x17, [x16, :lo12:Lcount155]
b.vs Lfn5fail808_1
adrp x16, Lcount139
ldr x17, [x16, :lo12:Lcount139]
add x17, x17, #1
str x17, [x16, :lo12:Lcount139]
str x0, [sp, #240]
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x8, [sp, #56]
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x9, x22
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x10, x20
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x11, x25
adrp x16, Lcount166
ldr x17, [x16, :lo12:Lcount166]
add x17, x17, #1
str x17, [x16, :lo12:Lcount166]
bl Lfn1fields
adrp x16, Lcount165
ldr x17, [x16, :lo12:Lcount165]
add x17, x17, #1
str x17, [x16, :lo12:Lcount165]
cbnz x1, Lfn5end
adrp x16, Lcount139
ldr x17, [x16, :lo12:Lcount139]
add x17, x17, #1
str x17, [x16, :lo12:Lcount139]
str x0, [sp, #112]
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x8, [sp, #240]
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x9, x23
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x10, [sp, #112]
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x19, x8
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x21, x9
adrp x16, Lcount139
ldr x17, [x16, :lo12:Lcount139]
add x17, x17, #1
str x17, [x16, :lo12:Lcount139]
str x10, [sp, #56]
adrp x16, Lcount136
ldr x17, [x16, :lo12:Lcount136]
add x17, x17, #1
str x17, [x16, :lo12:Lcount136]
stp xzr, xzr, [sp, #88]
adrp x16, Lcount136
ldr x17, [x16, :lo12:Lcount136]
add x17, x17, #1
str x17, [x16, :lo12:Lcount136]
stp xzr, xzr, [sp, #104]
adrp x16, Lcount136
ldr x17, [x16, :lo12:Lcount136]
add x17, x17, #1
str x17, [x16, :lo12:Lcount136]
stp xzr, xzr, [sp, #120]
adrp x16, Lcount136
ldr x17, [x16, :lo12:Lcount136]
add x17, x17, #1
str x17, [x16, :lo12:Lcount136]
stp xzr, xzr, [sp, #136]
adrp x16, Lcount139
ldr x17, [x16, :lo12:Lcount139]
add x17, x17, #1
str x17, [x16, :lo12:Lcount139]
str xzr, [sp, #152]
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5loop
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5if802done
Lfn5if802else:
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x0, x19
adrp x16, Lcount157
ldr x17, [x16, :lo12:Lcount157]
add x17, x17, #1
str x17, [x16, :lo12:Lcount157]
adds x0, x0, #3
adrp x16, Lcount155
ldr x17, [x16, :lo12:Lcount155]
add x17, x17, #1
str x17, [x16, :lo12:Lcount155]
b.vs Lfn5fail827_1
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x2, x20
adrp x16, Lcount157
ldr x17, [x16, :lo12:Lcount157]
add x17, x17, #1
str x17, [x16, :lo12:Lcount157]
adds x0, x0, x2
adrp x16, Lcount155
ldr x17, [x16, :lo12:Lcount155]
add x17, x17, #1
str x17, [x16, :lo12:Lcount155]
b.vs Lfn5fail826_1
adrp x16, Lcount139
ldr x17, [x16, :lo12:Lcount139]
add x17, x17, #1
str x17, [x16, :lo12:Lcount139]
str x0, [sp, #248]
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x8, [sp, #64]
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x9, x22
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x10, x20
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x11, x25
adrp x16, Lcount166
ldr x17, [x16, :lo12:Lcount166]
add x17, x17, #1
str x17, [x16, :lo12:Lcount166]
bl Lfn1fields
adrp x16, Lcount165
ldr x17, [x16, :lo12:Lcount165]
add x17, x17, #1
str x17, [x16, :lo12:Lcount165]
cbnz x1, Lfn5end
adrp x16, Lcount139
ldr x17, [x16, :lo12:Lcount139]
add x17, x17, #1
str x17, [x16, :lo12:Lcount139]
str x0, [sp, #120]
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x8, [sp, #248]
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x9, x23
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x10, [sp, #120]
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x19, x8
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x21, x9
adrp x16, Lcount139
ldr x17, [x16, :lo12:Lcount139]
add x17, x17, #1
str x17, [x16, :lo12:Lcount139]
str x10, [sp, #64]
adrp x16, Lcount136
ldr x17, [x16, :lo12:Lcount136]
add x17, x17, #1
str x17, [x16, :lo12:Lcount136]
stp xzr, xzr, [sp, #88]
adrp x16, Lcount136
ldr x17, [x16, :lo12:Lcount136]
add x17, x17, #1
str x17, [x16, :lo12:Lcount136]
stp xzr, xzr, [sp, #104]
adrp x16, Lcount136
ldr x17, [x16, :lo12:Lcount136]
add x17, x17, #1
str x17, [x16, :lo12:Lcount136]
stp xzr, xzr, [sp, #120]
adrp x16, Lcount136
ldr x17, [x16, :lo12:Lcount136]
add x17, x17, #1
str x17, [x16, :lo12:Lcount136]
stp xzr, xzr, [sp, #136]
adrp x16, Lcount139
ldr x17, [x16, :lo12:Lcount139]
add x17, x17, #1
str x17, [x16, :lo12:Lcount139]
str xzr, [sp, #152]
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5loop
Lfn5if802done:
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5if798done
Lfn5if798else:
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x0, x22
adrp x16, Lcount143
ldr x17, [x16, :lo12:Lcount143]
add x17, x17, #1
str x17, [x16, :lo12:Lcount143]
cmp x0, #48
adrp x16, Lcount156
ldr x17, [x16, :lo12:Lcount156]
add x17, x17, #1
str x17, [x16, :lo12:Lcount156]
b.ge Lfn5if842else
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x0, x19
adrp x16, Lcount157
ldr x17, [x16, :lo12:Lcount157]
add x17, x17, #1
str x17, [x16, :lo12:Lcount157]
adds x0, x0, #3
adrp x16, Lcount155
ldr x17, [x16, :lo12:Lcount155]
add x17, x17, #1
str x17, [x16, :lo12:Lcount155]
b.vs Lfn5fail849_1
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x2, x20
adrp x16, Lcount157
ldr x17, [x16, :lo12:Lcount157]
add x17, x17, #1
str x17, [x16, :lo12:Lcount157]
adds x0, x0, x2
adrp x16, Lcount155
ldr x17, [x16, :lo12:Lcount155]
add x17, x17, #1
str x17, [x16, :lo12:Lcount155]
b.vs Lfn5fail848_1
adrp x16, Lcount139
ldr x17, [x16, :lo12:Lcount139]
add x17, x17, #1
str x17, [x16, :lo12:Lcount139]
str x0, [sp, #256]
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x8, [sp, #72]
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x9, x22
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x10, x20
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x11, x25
adrp x16, Lcount166
ldr x17, [x16, :lo12:Lcount166]
add x17, x17, #1
str x17, [x16, :lo12:Lcount166]
bl Lfn1fields
adrp x16, Lcount165
ldr x17, [x16, :lo12:Lcount165]
add x17, x17, #1
str x17, [x16, :lo12:Lcount165]
cbnz x1, Lfn5end
adrp x16, Lcount139
ldr x17, [x16, :lo12:Lcount139]
add x17, x17, #1
str x17, [x16, :lo12:Lcount139]
str x0, [sp, #128]
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x8, [sp, #256]
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x9, x23
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x10, [sp, #128]
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x19, x8
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x21, x9
adrp x16, Lcount139
ldr x17, [x16, :lo12:Lcount139]
add x17, x17, #1
str x17, [x16, :lo12:Lcount139]
str x10, [sp, #72]
adrp x16, Lcount136
ldr x17, [x16, :lo12:Lcount136]
add x17, x17, #1
str x17, [x16, :lo12:Lcount136]
stp xzr, xzr, [sp, #88]
adrp x16, Lcount136
ldr x17, [x16, :lo12:Lcount136]
add x17, x17, #1
str x17, [x16, :lo12:Lcount136]
stp xzr, xzr, [sp, #104]
adrp x16, Lcount136
ldr x17, [x16, :lo12:Lcount136]
add x17, x17, #1
str x17, [x16, :lo12:Lcount136]
stp xzr, xzr, [sp, #120]
adrp x16, Lcount136
ldr x17, [x16, :lo12:Lcount136]
add x17, x17, #1
str x17, [x16, :lo12:Lcount136]
stp xzr, xzr, [sp, #136]
adrp x16, Lcount139
ldr x17, [x16, :lo12:Lcount139]
add x17, x17, #1
str x17, [x16, :lo12:Lcount139]
str xzr, [sp, #152]
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5loop
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5if842done
Lfn5if842else:
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x0, x19
adrp x16, Lcount157
ldr x17, [x16, :lo12:Lcount157]
add x17, x17, #1
str x17, [x16, :lo12:Lcount157]
adds x0, x0, #3
adrp x16, Lcount155
ldr x17, [x16, :lo12:Lcount155]
add x17, x17, #1
str x17, [x16, :lo12:Lcount155]
b.vs Lfn5fail867_1
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x2, x20
adrp x16, Lcount157
ldr x17, [x16, :lo12:Lcount157]
add x17, x17, #1
str x17, [x16, :lo12:Lcount157]
adds x0, x0, x2
adrp x16, Lcount155
ldr x17, [x16, :lo12:Lcount155]
add x17, x17, #1
str x17, [x16, :lo12:Lcount155]
b.vs Lfn5fail866_1
adrp x16, Lcount139
ldr x17, [x16, :lo12:Lcount139]
add x17, x17, #1
str x17, [x16, :lo12:Lcount139]
str x0, [sp, #264]
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x8, [sp, #80]
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x9, x22
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x10, x20
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x11, x25
adrp x16, Lcount166
ldr x17, [x16, :lo12:Lcount166]
add x17, x17, #1
str x17, [x16, :lo12:Lcount166]
bl Lfn1fields
adrp x16, Lcount165
ldr x17, [x16, :lo12:Lcount165]
add x17, x17, #1
str x17, [x16, :lo12:Lcount165]
cbnz x1, Lfn5end
adrp x16, Lcount139
ldr x17, [x16, :lo12:Lcount139]
add x17, x17, #1
str x17, [x16, :lo12:Lcount139]
str x0, [sp, #136]
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x8, [sp, #264]
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x9, x23
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x10, [sp, #136]
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x19, x8
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x21, x9
adrp x16, Lcount139
ldr x17, [x16, :lo12:Lcount139]
add x17, x17, #1
str x17, [x16, :lo12:Lcount139]
str x10, [sp, #80]
adrp x16, Lcount136
ldr x17, [x16, :lo12:Lcount136]
add x17, x17, #1
str x17, [x16, :lo12:Lcount136]
stp xzr, xzr, [sp, #88]
adrp x16, Lcount136
ldr x17, [x16, :lo12:Lcount136]
add x17, x17, #1
str x17, [x16, :lo12:Lcount136]
stp xzr, xzr, [sp, #104]
adrp x16, Lcount136
ldr x17, [x16, :lo12:Lcount136]
add x17, x17, #1
str x17, [x16, :lo12:Lcount136]
stp xzr, xzr, [sp, #120]
adrp x16, Lcount136
ldr x17, [x16, :lo12:Lcount136]
add x17, x17, #1
str x17, [x16, :lo12:Lcount136]
stp xzr, xzr, [sp, #136]
adrp x16, Lcount139
ldr x17, [x16, :lo12:Lcount139]
add x17, x17, #1
str x17, [x16, :lo12:Lcount139]
str xzr, [sp, #152]
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5loop
Lfn5if842done:
Lfn5if798done:
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5if778done
Lfn5if778else:
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x0, x19
adrp x16, Lcount157
ldr x17, [x16, :lo12:Lcount157]
add x17, x17, #1
str x17, [x16, :lo12:Lcount157]
adds x0, x0, #3
adrp x16, Lcount155
ldr x17, [x16, :lo12:Lcount155]
add x17, x17, #1
str x17, [x16, :lo12:Lcount155]
b.vs Lfn5fail885_1
adrp x16, Lcount139
ldr x17, [x16, :lo12:Lcount139]
add x17, x17, #1
str x17, [x16, :lo12:Lcount139]
str x0, [sp, #272]
adrp x16, Lcount163
ldr x17, [x16, :lo12:Lcount163]
add x17, x17, #1
str x17, [x16, :lo12:Lcount163]
movz x0, #0, lsl #0
adrp x16, Lcount139
ldr x17, [x16, :lo12:Lcount139]
add x17, x17, #1
str x17, [x16, :lo12:Lcount139]
str x0, [sp, #280]
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x0, #15
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #11
adrp x16, Lcount145
ldr x17, [x16, :lo12:Lcount145]
add x17, x17, #1
str x17, [x16, :lo12:Lcount145]
bl fen_allocate
adrp x16, Lcount146
ldr x17, [x16, :lo12:Lcount146]
add x17, x17, #1
str x17, [x16, :lo12:Lcount146]
cbz x0, Lfn5fail892_3
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x2, [sp, #56]
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x3, [sp, #64]
adrp x16, Lcount147
ldr x17, [x16, :lo12:Lcount147]
add x17, x17, #1
str x17, [x16, :lo12:Lcount147]
stp x2, x3, [x0, #0]
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x2, [sp, #72]
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x3, [sp, #80]
adrp x16, Lcount147
ldr x17, [x16, :lo12:Lcount147]
add x17, x17, #1
str x17, [x16, :lo12:Lcount147]
stp x2, x3, [x0, #16]
adrp x16, Lcount139
ldr x17, [x16, :lo12:Lcount139]
add x17, x17, #1
str x17, [x16, :lo12:Lcount139]
str x0, [sp, #144]
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x0, #32
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #16
adrp x16, Lcount145
ldr x17, [x16, :lo12:Lcount145]
add x17, x17, #1
str x17, [x16, :lo12:Lcount145]
bl fen_allocate
adrp x16, Lcount146
ldr x17, [x16, :lo12:Lcount146]
add x17, x17, #1
str x17, [x16, :lo12:Lcount146]
cbz x0, Lfn5fail884_3
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x2, [sp, #272]
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x3, x22
adrp x16, Lcount147
ldr x17, [x16, :lo12:Lcount147]
add x17, x17, #1
str x17, [x16, :lo12:Lcount147]
stp x2, x3, [x0, #0]
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x2, x20
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x3, x20
adrp x16, Lcount147
ldr x17, [x16, :lo12:Lcount147]
add x17, x17, #1
str x17, [x16, :lo12:Lcount147]
stp x2, x3, [x0, #16]
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x2, [sp, #280]
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x3, [sp, #144]
adrp x16, Lcount147
ldr x17, [x16, :lo12:Lcount147]
add x17, x17, #1
str x17, [x16, :lo12:Lcount147]
stp x2, x3, [x0, #32]
adrp x16, Lcount139
ldr x17, [x16, :lo12:Lcount139]
add x17, x17, #1
str x17, [x16, :lo12:Lcount139]
str x0, [sp, #152]
adrp x16, Lcount159
ldr x17, [x16, :lo12:Lcount159]
add x17, x17, #1
str x17, [x16, :lo12:Lcount159]
bl fen_leave_result
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x8, [sp, #152]
adrp x16, Lcount142
ldr x17, [x16, :lo12:Lcount142]
add x17, x17, #1
str x17, [x16, :lo12:Lcount142]
ldr x9, [sp, #48]
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x10, x24
adrp x16, Lcount134
ldr x17, [x16, :lo12:Lcount134]
add x17, x17, #1
str x17, [x16, :lo12:Lcount134]
ldp x19, x20, [x29, #-16]
adrp x16, Lcount134
ldr x17, [x16, :lo12:Lcount134]
add x17, x17, #1
str x17, [x16, :lo12:Lcount134]
ldp x21, x22, [x29, #-32]
adrp x16, Lcount134
ldr x17, [x16, :lo12:Lcount134]
add x17, x17, #1
str x17, [x16, :lo12:Lcount134]
ldp x23, x24, [x29, #-48]
adrp x16, Lcount134
ldr x17, [x16, :lo12:Lcount134]
add x17, x17, #1
str x17, [x16, :lo12:Lcount134]
ldp x25, x26, [x29, #-64]
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov sp, x29
adrp x16, Lcount160
ldr x17, [x16, :lo12:Lcount160]
add x17, x17, #1
str x17, [x16, :lo12:Lcount160]
ldp x29, x30, [sp], #16
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn7fields
Lfn5if778done:
Lfn5if760done:
Lfn5if747done:
Lfn5if715done:
Lfn5if696done:
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #0
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5end
Lfn5fail703_3:
adrp x16, Lcount167
ldr x17, [x16, :lo12:Lcount167]
add x17, x17, #1
str x17, [x16, :lo12:Lcount167]
adrp x0, Lfn5fail703_3location
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, x0, :lo12:Lfn5fail703_3location
adrp x16, Lcount168
ldr x17, [x16, :lo12:Lcount168]
add x17, x17, #1
str x17, [x16, :lo12:Lcount168]
bl fen_set_location
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #3
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5end
Lfn5fail701_3:
adrp x16, Lcount167
ldr x17, [x16, :lo12:Lcount167]
add x17, x17, #1
str x17, [x16, :lo12:Lcount167]
adrp x0, Lfn5fail701_3location
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, x0, :lo12:Lfn5fail701_3location
adrp x16, Lcount168
ldr x17, [x16, :lo12:Lcount168]
add x17, x17, #1
str x17, [x16, :lo12:Lcount168]
bl fen_set_location
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #3
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5end
Lfn5fail711_4:
adrp x16, Lcount167
ldr x17, [x16, :lo12:Lcount167]
add x17, x17, #1
str x17, [x16, :lo12:Lcount167]
adrp x0, Lfn5fail711_4location
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, x0, :lo12:Lfn5fail711_4location
adrp x16, Lcount168
ldr x17, [x16, :lo12:Lcount168]
add x17, x17, #1
str x17, [x16, :lo12:Lcount168]
bl fen_set_location
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #4
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5end
Lfn5fail710_1:
adrp x16, Lcount167
ldr x17, [x16, :lo12:Lcount167]
add x17, x17, #1
str x17, [x16, :lo12:Lcount167]
adrp x0, Lfn5fail710_1location
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, x0, :lo12:Lfn5fail710_1location
adrp x16, Lcount168
ldr x17, [x16, :lo12:Lcount168]
add x17, x17, #1
str x17, [x16, :lo12:Lcount168]
bl fen_set_location
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #1
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5end
Lfn5fail717_1:
adrp x16, Lcount167
ldr x17, [x16, :lo12:Lcount167]
add x17, x17, #1
str x17, [x16, :lo12:Lcount167]
adrp x0, Lfn5fail717_1location
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, x0, :lo12:Lfn5fail717_1location
adrp x16, Lcount168
ldr x17, [x16, :lo12:Lcount168]
add x17, x17, #1
str x17, [x16, :lo12:Lcount168]
bl fen_set_location
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #1
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5end
Lfn5fail725_1:
adrp x16, Lcount167
ldr x17, [x16, :lo12:Lcount167]
add x17, x17, #1
str x17, [x16, :lo12:Lcount167]
adrp x0, Lfn5fail725_1location
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, x0, :lo12:Lfn5fail725_1location
adrp x16, Lcount168
ldr x17, [x16, :lo12:Lcount168]
add x17, x17, #1
str x17, [x16, :lo12:Lcount168]
bl fen_set_location
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #1
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5end
Lfn5fail729_3:
adrp x16, Lcount167
ldr x17, [x16, :lo12:Lcount167]
add x17, x17, #1
str x17, [x16, :lo12:Lcount167]
adrp x0, Lfn5fail729_3location
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, x0, :lo12:Lfn5fail729_3location
adrp x16, Lcount168
ldr x17, [x16, :lo12:Lcount168]
add x17, x17, #1
str x17, [x16, :lo12:Lcount168]
bl fen_set_location
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #3
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5end
Lfn5fail724_3:
adrp x16, Lcount167
ldr x17, [x16, :lo12:Lcount167]
add x17, x17, #1
str x17, [x16, :lo12:Lcount167]
adrp x0, Lfn5fail724_3location
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, x0, :lo12:Lfn5fail724_3location
adrp x16, Lcount168
ldr x17, [x16, :lo12:Lcount168]
add x17, x17, #1
str x17, [x16, :lo12:Lcount168]
bl fen_set_location
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #3
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5end
Lfn5fail735_1:
adrp x16, Lcount167
ldr x17, [x16, :lo12:Lcount167]
add x17, x17, #1
str x17, [x16, :lo12:Lcount167]
adrp x0, Lfn5fail735_1location
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, x0, :lo12:Lfn5fail735_1location
adrp x16, Lcount168
ldr x17, [x16, :lo12:Lcount168]
add x17, x17, #1
str x17, [x16, :lo12:Lcount168]
bl fen_set_location
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #1
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5end
Lfn5fail744_1:
adrp x16, Lcount167
ldr x17, [x16, :lo12:Lcount167]
add x17, x17, #1
str x17, [x16, :lo12:Lcount167]
adrp x0, Lfn5fail744_1location
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, x0, :lo12:Lfn5fail744_1location
adrp x16, Lcount168
ldr x17, [x16, :lo12:Lcount168]
add x17, x17, #1
str x17, [x16, :lo12:Lcount168]
bl fen_set_location
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #1
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5end
Lfn5fail742_4:
adrp x16, Lcount167
ldr x17, [x16, :lo12:Lcount167]
add x17, x17, #1
str x17, [x16, :lo12:Lcount167]
adrp x0, Lfn5fail742_4location
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, x0, :lo12:Lfn5fail742_4location
adrp x16, Lcount168
ldr x17, [x16, :lo12:Lcount168]
add x17, x17, #1
str x17, [x16, :lo12:Lcount168]
bl fen_set_location
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #4
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5end
Lfn5fail740_1:
adrp x16, Lcount167
ldr x17, [x16, :lo12:Lcount167]
add x17, x17, #1
str x17, [x16, :lo12:Lcount167]
adrp x0, Lfn5fail740_1location
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, x0, :lo12:Lfn5fail740_1location
adrp x16, Lcount168
ldr x17, [x16, :lo12:Lcount168]
add x17, x17, #1
str x17, [x16, :lo12:Lcount168]
bl fen_set_location
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #1
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5end
Lfn5fail751_3:
adrp x16, Lcount167
ldr x17, [x16, :lo12:Lcount167]
add x17, x17, #1
str x17, [x16, :lo12:Lcount167]
adrp x0, Lfn5fail751_3location
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, x0, :lo12:Lfn5fail751_3location
adrp x16, Lcount168
ldr x17, [x16, :lo12:Lcount168]
add x17, x17, #1
str x17, [x16, :lo12:Lcount168]
bl fen_set_location
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #3
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5end
Lfn5fail757_1:
adrp x16, Lcount167
ldr x17, [x16, :lo12:Lcount167]
add x17, x17, #1
str x17, [x16, :lo12:Lcount167]
adrp x0, Lfn5fail757_1location
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, x0, :lo12:Lfn5fail757_1location
adrp x16, Lcount168
ldr x17, [x16, :lo12:Lcount168]
add x17, x17, #1
str x17, [x16, :lo12:Lcount168]
bl fen_set_location
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #1
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5end
Lfn5fail755_4:
adrp x16, Lcount167
ldr x17, [x16, :lo12:Lcount167]
add x17, x17, #1
str x17, [x16, :lo12:Lcount167]
adrp x0, Lfn5fail755_4location
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, x0, :lo12:Lfn5fail755_4location
adrp x16, Lcount168
ldr x17, [x16, :lo12:Lcount168]
add x17, x17, #1
str x17, [x16, :lo12:Lcount168]
bl fen_set_location
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #4
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5end
Lfn5fail765_1:
adrp x16, Lcount167
ldr x17, [x16, :lo12:Lcount167]
add x17, x17, #1
str x17, [x16, :lo12:Lcount167]
adrp x0, Lfn5fail765_1location
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, x0, :lo12:Lfn5fail765_1location
adrp x16, Lcount168
ldr x17, [x16, :lo12:Lcount168]
add x17, x17, #1
str x17, [x16, :lo12:Lcount168]
bl fen_set_location
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #1
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5end
Lfn5fail764_3:
adrp x16, Lcount167
ldr x17, [x16, :lo12:Lcount167]
add x17, x17, #1
str x17, [x16, :lo12:Lcount167]
adrp x0, Lfn5fail764_3location
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, x0, :lo12:Lfn5fail764_3location
adrp x16, Lcount168
ldr x17, [x16, :lo12:Lcount168]
add x17, x17, #1
str x17, [x16, :lo12:Lcount168]
bl fen_set_location
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #3
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5end
Lfn5fail770_1:
adrp x16, Lcount167
ldr x17, [x16, :lo12:Lcount167]
add x17, x17, #1
str x17, [x16, :lo12:Lcount167]
adrp x0, Lfn5fail770_1location
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, x0, :lo12:Lfn5fail770_1location
adrp x16, Lcount168
ldr x17, [x16, :lo12:Lcount168]
add x17, x17, #1
str x17, [x16, :lo12:Lcount168]
bl fen_set_location
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #1
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5end
Lfn5fail775_1:
adrp x16, Lcount167
ldr x17, [x16, :lo12:Lcount167]
add x17, x17, #1
str x17, [x16, :lo12:Lcount167]
adrp x0, Lfn5fail775_1location
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, x0, :lo12:Lfn5fail775_1location
adrp x16, Lcount168
ldr x17, [x16, :lo12:Lcount168]
add x17, x17, #1
str x17, [x16, :lo12:Lcount168]
bl fen_set_location
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #1
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5end
Lfn5fail781_1:
adrp x16, Lcount167
ldr x17, [x16, :lo12:Lcount167]
add x17, x17, #1
str x17, [x16, :lo12:Lcount167]
adrp x0, Lfn5fail781_1location
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, x0, :lo12:Lfn5fail781_1location
adrp x16, Lcount168
ldr x17, [x16, :lo12:Lcount168]
add x17, x17, #1
str x17, [x16, :lo12:Lcount168]
bl fen_set_location
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #1
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5end
Lfn5fail787_1:
adrp x16, Lcount167
ldr x17, [x16, :lo12:Lcount167]
add x17, x17, #1
str x17, [x16, :lo12:Lcount167]
adrp x0, Lfn5fail787_1location
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, x0, :lo12:Lfn5fail787_1location
adrp x16, Lcount168
ldr x17, [x16, :lo12:Lcount168]
add x17, x17, #1
str x17, [x16, :lo12:Lcount168]
bl fen_set_location
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #1
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5end
Lfn5fail809_1:
adrp x16, Lcount167
ldr x17, [x16, :lo12:Lcount167]
add x17, x17, #1
str x17, [x16, :lo12:Lcount167]
adrp x0, Lfn5fail809_1location
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, x0, :lo12:Lfn5fail809_1location
adrp x16, Lcount168
ldr x17, [x16, :lo12:Lcount168]
add x17, x17, #1
str x17, [x16, :lo12:Lcount168]
bl fen_set_location
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #1
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5end
Lfn5fail808_1:
adrp x16, Lcount167
ldr x17, [x16, :lo12:Lcount167]
add x17, x17, #1
str x17, [x16, :lo12:Lcount167]
adrp x0, Lfn5fail808_1location
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, x0, :lo12:Lfn5fail808_1location
adrp x16, Lcount168
ldr x17, [x16, :lo12:Lcount168]
add x17, x17, #1
str x17, [x16, :lo12:Lcount168]
bl fen_set_location
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #1
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5end
Lfn5fail827_1:
adrp x16, Lcount167
ldr x17, [x16, :lo12:Lcount167]
add x17, x17, #1
str x17, [x16, :lo12:Lcount167]
adrp x0, Lfn5fail827_1location
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, x0, :lo12:Lfn5fail827_1location
adrp x16, Lcount168
ldr x17, [x16, :lo12:Lcount168]
add x17, x17, #1
str x17, [x16, :lo12:Lcount168]
bl fen_set_location
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #1
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5end
Lfn5fail826_1:
adrp x16, Lcount167
ldr x17, [x16, :lo12:Lcount167]
add x17, x17, #1
str x17, [x16, :lo12:Lcount167]
adrp x0, Lfn5fail826_1location
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, x0, :lo12:Lfn5fail826_1location
adrp x16, Lcount168
ldr x17, [x16, :lo12:Lcount168]
add x17, x17, #1
str x17, [x16, :lo12:Lcount168]
bl fen_set_location
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #1
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5end
Lfn5fail849_1:
adrp x16, Lcount167
ldr x17, [x16, :lo12:Lcount167]
add x17, x17, #1
str x17, [x16, :lo12:Lcount167]
adrp x0, Lfn5fail849_1location
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, x0, :lo12:Lfn5fail849_1location
adrp x16, Lcount168
ldr x17, [x16, :lo12:Lcount168]
add x17, x17, #1
str x17, [x16, :lo12:Lcount168]
bl fen_set_location
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #1
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5end
Lfn5fail848_1:
adrp x16, Lcount167
ldr x17, [x16, :lo12:Lcount167]
add x17, x17, #1
str x17, [x16, :lo12:Lcount167]
adrp x0, Lfn5fail848_1location
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, x0, :lo12:Lfn5fail848_1location
adrp x16, Lcount168
ldr x17, [x16, :lo12:Lcount168]
add x17, x17, #1
str x17, [x16, :lo12:Lcount168]
bl fen_set_location
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #1
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5end
Lfn5fail867_1:
adrp x16, Lcount167
ldr x17, [x16, :lo12:Lcount167]
add x17, x17, #1
str x17, [x16, :lo12:Lcount167]
adrp x0, Lfn5fail867_1location
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, x0, :lo12:Lfn5fail867_1location
adrp x16, Lcount168
ldr x17, [x16, :lo12:Lcount168]
add x17, x17, #1
str x17, [x16, :lo12:Lcount168]
bl fen_set_location
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #1
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5end
Lfn5fail866_1:
adrp x16, Lcount167
ldr x17, [x16, :lo12:Lcount167]
add x17, x17, #1
str x17, [x16, :lo12:Lcount167]
adrp x0, Lfn5fail866_1location
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, x0, :lo12:Lfn5fail866_1location
adrp x16, Lcount168
ldr x17, [x16, :lo12:Lcount168]
add x17, x17, #1
str x17, [x16, :lo12:Lcount168]
bl fen_set_location
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #1
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5end
Lfn5fail885_1:
adrp x16, Lcount167
ldr x17, [x16, :lo12:Lcount167]
add x17, x17, #1
str x17, [x16, :lo12:Lcount167]
adrp x0, Lfn5fail885_1location
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, x0, :lo12:Lfn5fail885_1location
adrp x16, Lcount168
ldr x17, [x16, :lo12:Lcount168]
add x17, x17, #1
str x17, [x16, :lo12:Lcount168]
bl fen_set_location
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #1
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5end
Lfn5fail892_3:
adrp x16, Lcount167
ldr x17, [x16, :lo12:Lcount167]
add x17, x17, #1
str x17, [x16, :lo12:Lcount167]
adrp x0, Lfn5fail892_3location
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, x0, :lo12:Lfn5fail892_3location
adrp x16, Lcount168
ldr x17, [x16, :lo12:Lcount168]
add x17, x17, #1
str x17, [x16, :lo12:Lcount168]
bl fen_set_location
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #3
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5end
Lfn5fail884_3:
adrp x16, Lcount167
ldr x17, [x16, :lo12:Lcount167]
add x17, x17, #1
str x17, [x16, :lo12:Lcount167]
adrp x0, Lfn5fail884_3location
adrp x16, Lcount140
ldr x17, [x16, :lo12:Lcount140]
add x17, x17, #1
str x17, [x16, :lo12:Lcount140]
add x0, x0, :lo12:Lfn5fail884_3location
adrp x16, Lcount168
ldr x17, [x16, :lo12:Lcount168]
add x17, x17, #1
str x17, [x16, :lo12:Lcount168]
bl fen_set_location
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov x1, #3
adrp x16, Lcount148
ldr x17, [x16, :lo12:Lcount148]
add x17, x17, #1
str x17, [x16, :lo12:Lcount148]
b Lfn5end
Lfn5end:
adrp x16, Lcount159
ldr x17, [x16, :lo12:Lcount159]
add x17, x17, #1
str x17, [x16, :lo12:Lcount159]
bl fen_leave_result
adrp x16, Lcount134
ldr x17, [x16, :lo12:Lcount134]
add x17, x17, #1
str x17, [x16, :lo12:Lcount134]
ldp x19, x20, [x29, #-16]
adrp x16, Lcount134
ldr x17, [x16, :lo12:Lcount134]
add x17, x17, #1
str x17, [x16, :lo12:Lcount134]
ldp x21, x22, [x29, #-32]
adrp x16, Lcount134
ldr x17, [x16, :lo12:Lcount134]
add x17, x17, #1
str x17, [x16, :lo12:Lcount134]
ldp x23, x24, [x29, #-48]
adrp x16, Lcount134
ldr x17, [x16, :lo12:Lcount134]
add x17, x17, #1
str x17, [x16, :lo12:Lcount134]
ldp x25, x26, [x29, #-64]
adrp x16, Lcount137
ldr x17, [x16, :lo12:Lcount137]
add x17, x17, #1
str x17, [x16, :lo12:Lcount137]
mov sp, x29
adrp x16, Lcount160
ldr x17, [x16, :lo12:Lcount160]
add x17, x17, #1
str x17, [x16, :lo12:Lcount160]
ldp x29, x30, [sp], #16
adrp x16, Lcount169
ldr x17, [x16, :lo12:Lcount169]
add x17, x17, #1
str x17, [x16, :lo12:Lcount169]
ret
Lfn6:
adrp x16, Lcount170
ldr x17, [x16, :lo12:Lcount170]
add x17, x17, #1
str x17, [x16, :lo12:Lcount170]
ldp x8, x9, [x0, #0]
adrp x16, Lcount170
ldr x17, [x16, :lo12:Lcount170]
add x17, x17, #1
str x17, [x16, :lo12:Lcount170]
ldp x10, x11, [x0, #16]
Lfn6fields:
adrp x16, Lcount171
ldr x17, [x16, :lo12:Lcount171]
add x17, x17, #1
str x17, [x16, :lo12:Lcount171]
stp x29, x30, [sp, #-16]!
adrp x16, Lcount172
ldr x17, [x16, :lo12:Lcount172]
add x17, x17, #1
str x17, [x16, :lo12:Lcount172]
mov x29, sp
adrp x16, Lcount173
ldr x17, [x16, :lo12:Lcount173]
add x17, x17, #1
str x17, [x16, :lo12:Lcount173]
sub sp, sp, #80
adrp x16, Lcount174
ldr x17, [x16, :lo12:Lcount174]
add x17, x17, #1
str x17, [x16, :lo12:Lcount174]
str x8, [sp, #64]
adrp x16, Lcount171
ldr x17, [x16, :lo12:Lcount171]
add x17, x17, #1
str x17, [x16, :lo12:Lcount171]
stp x9, x10, [sp, #48]
adrp x16, Lcount174
ldr x17, [x16, :lo12:Lcount174]
add x17, x17, #1
str x17, [x16, :lo12:Lcount174]
str x11, [sp, #72]
adrp x16, Lcount175
ldr x17, [x16, :lo12:Lcount175]
add x17, x17, #1
str x17, [x16, :lo12:Lcount175]
add x0, sp, #16
adrp x16, Lcount175
ldr x17, [x16, :lo12:Lcount175]
add x17, x17, #1
str x17, [x16, :lo12:Lcount175]
add x1, sp, #48
adrp x16, Lcount172
ldr x17, [x16, :lo12:Lcount172]
add x17, x17, #1
str x17, [x16, :lo12:Lcount172]
mov x2, #2
adrp x16, Lcount176
ldr x17, [x16, :lo12:Lcount176]
add x17, x17, #1
str x17, [x16, :lo12:Lcount176]
bl fen_enter
Lfn6loop:
adrp x16, Lcount177
ldr x17, [x16, :lo12:Lcount177]
add x17, x17, #1
str x17, [x16, :lo12:Lcount177]
ldr x0, [sp, #48]
adrp x16, Lcount178
ldr x17, [x16, :lo12:Lcount178]
add x17, x17, #1
str x17, [x16, :lo12:Lcount178]
ldr w0, [x0, #72]
adrp x16, Lcount179
ldr x17, [x16, :lo12:Lcount179]
add x17, x17, #1
str x17, [x16, :lo12:Lcount179]
cmp w0, #9
adrp x16, Lcount180
ldr x17, [x16, :lo12:Lcount180]
add x17, x17, #1
str x17, [x16, :lo12:Lcount180]
b.eq Lfn6match917arm9
adrp x16, Lcount179
ldr x17, [x16, :lo12:Lcount179]
add x17, x17, #1
str x17, [x16, :lo12:Lcount179]
cmp w0, #11
adrp x16, Lcount180
ldr x17, [x16, :lo12:Lcount180]
add x17, x17, #1
str x17, [x16, :lo12:Lcount180]
b.eq Lfn6match917arm11
adrp x16, Lcount179
ldr x17, [x16, :lo12:Lcount179]
add x17, x17, #1
str x17, [x16, :lo12:Lcount179]
cmp w0, #12
adrp x16, Lcount180
ldr x17, [x16, :lo12:Lcount180]
add x17, x17, #1
str x17, [x16, :lo12:Lcount180]
b.eq Lfn6match917arm12
adrp x16, Lcount179
ldr x17, [x16, :lo12:Lcount179]
add x17, x17, #1
str x17, [x16, :lo12:Lcount179]
cmp w0, #10
adrp x16, Lcount180
ldr x17, [x16, :lo12:Lcount180]
add x17, x17, #1
str x17, [x16, :lo12:Lcount180]
b.eq Lfn6match917arm10
adrp x16, Lcount181
ldr x17, [x16, :lo12:Lcount181]
add x17, x17, #1
str x17, [x16, :lo12:Lcount181]
brk #0
Lfn6match917arm9:
adrp x16, Lcount182
ldr x17, [x16, :lo12:Lcount182]
add x17, x17, #1
str x17, [x16, :lo12:Lcount182]
bl fen_leave_result
adrp x16, Lcount177
ldr x17, [x16, :lo12:Lcount177]
add x17, x17, #1
str x17, [x16, :lo12:Lcount177]
ldr x8, [sp, #64]
adrp x16, Lcount177
ldr x17, [x16, :lo12:Lcount177]
add x17, x17, #1
str x17, [x16, :lo12:Lcount177]
ldr x9, [sp, #56]
adrp x16, Lcount177
ldr x17, [x16, :lo12:Lcount177]
add x17, x17, #1
str x17, [x16, :lo12:Lcount177]
ldr x10, [sp, #72]
adrp x16, Lcount183
ldr x17, [x16, :lo12:Lcount183]
add x17, x17, #1
str x17, [x16, :lo12:Lcount183]
adrp x11, Lconstant0
adrp x16, Lcount175
ldr x17, [x16, :lo12:Lcount175]
add x17, x17, #1
str x17, [x16, :lo12:Lcount175]
add x11, x11, :lo12:Lconstant0
adrp x16, Lcount183
ldr x17, [x16, :lo12:Lcount183]
add x17, x17, #1
str x17, [x16, :lo12:Lcount183]
adrp x12, Lconstant0
adrp x16, Lcount175
ldr x17, [x16, :lo12:Lcount175]
add x17, x17, #1
str x17, [x16, :lo12:Lcount175]
add x12, x12, :lo12:Lconstant0
adrp x16, Lcount183
ldr x17, [x16, :lo12:Lcount183]
add x17, x17, #1
str x17, [x16, :lo12:Lcount183]
adrp x13, Lconstant0
adrp x16, Lcount175
ldr x17, [x16, :lo12:Lcount175]
add x17, x17, #1
str x17, [x16, :lo12:Lcount175]
add x13, x13, :lo12:Lconstant0
adrp x16, Lcount183
ldr x17, [x16, :lo12:Lcount183]
add x17, x17, #1
str x17, [x16, :lo12:Lcount183]
adrp x14, Lconstant0
adrp x16, Lcount175
ldr x17, [x16, :lo12:Lcount175]
add x17, x17, #1
str x17, [x16, :lo12:Lcount175]
add x14, x14, :lo12:Lconstant0
adrp x16, Lcount172
ldr x17, [x16, :lo12:Lcount172]
add x17, x17, #1
str x17, [x16, :lo12:Lcount172]
mov sp, x29
adrp x16, Lcount184
ldr x17, [x16, :lo12:Lcount184]
add x17, x17, #1
str x17, [x16, :lo12:Lcount184]
ldp x29, x30, [sp], #16
adrp x16, Lcount185
ldr x17, [x16, :lo12:Lcount185]
add x17, x17, #1
str x17, [x16, :lo12:Lcount185]
b Lfn5fields
adrp x16, Lcount185
ldr x17, [x16, :lo12:Lcount185]
add x17, x17, #1
str x17, [x16, :lo12:Lcount185]
b Lfn6match917end
Lfn6match917arm11:
adrp x16, Lcount182
ldr x17, [x16, :lo12:Lcount182]
add x17, x17, #1
str x17, [x16, :lo12:Lcount182]
bl fen_leave_result
adrp x16, Lcount177
ldr x17, [x16, :lo12:Lcount177]
add x17, x17, #1
str x17, [x16, :lo12:Lcount177]
ldr x8, [sp, #64]
adrp x16, Lcount177
ldr x17, [x16, :lo12:Lcount177]
add x17, x17, #1
str x17, [x16, :lo12:Lcount177]
ldr x9, [sp, #56]
adrp x16, Lcount177
ldr x17, [x16, :lo12:Lcount177]
add x17, x17, #1
str x17, [x16, :lo12:Lcount177]
ldr x10, [sp, #72]
adrp x16, Lcount177
ldr x17, [x16, :lo12:Lcount177]
add x17, x17, #1
str x17, [x16, :lo12:Lcount177]
ldr x11, [sp, #48]
adrp x16, Lcount178
ldr x17, [x16, :lo12:Lcount178]
add x17, x17, #1
str x17, [x16, :lo12:Lcount178]
ldr x11, [x11, #0]
adrp x16, Lcount177
ldr x17, [x16, :lo12:Lcount177]
add x17, x17, #1
str x17, [x16, :lo12:Lcount177]
ldr x12, [sp, #48]
adrp x16, Lcount178
ldr x17, [x16, :lo12:Lcount178]
add x17, x17, #1
str x17, [x16, :lo12:Lcount178]
ldr x12, [x12, #8]
adrp x16, Lcount177
ldr x17, [x16, :lo12:Lcount177]
add x17, x17, #1
str x17, [x16, :lo12:Lcount177]
ldr x13, [sp, #48]
adrp x16, Lcount178
ldr x17, [x16, :lo12:Lcount178]
add x17, x17, #1
str x17, [x16, :lo12:Lcount178]
ldr x13, [x13, #16]
adrp x16, Lcount177
ldr x17, [x16, :lo12:Lcount177]
add x17, x17, #1
str x17, [x16, :lo12:Lcount177]
ldr x14, [sp, #48]
adrp x16, Lcount178
ldr x17, [x16, :lo12:Lcount178]
add x17, x17, #1
str x17, [x16, :lo12:Lcount178]
ldr x14, [x14, #24]
adrp x16, Lcount172
ldr x17, [x16, :lo12:Lcount172]
add x17, x17, #1
str x17, [x16, :lo12:Lcount172]
mov sp, x29
adrp x16, Lcount184
ldr x17, [x16, :lo12:Lcount184]
add x17, x17, #1
str x17, [x16, :lo12:Lcount184]
ldp x29, x30, [sp], #16
adrp x16, Lcount185
ldr x17, [x16, :lo12:Lcount185]
add x17, x17, #1
str x17, [x16, :lo12:Lcount185]
b Lfn5fields
adrp x16, Lcount185
ldr x17, [x16, :lo12:Lcount185]
add x17, x17, #1
str x17, [x16, :lo12:Lcount185]
b Lfn6match917end
Lfn6match917arm12:
adrp x16, Lcount172
ldr x17, [x16, :lo12:Lcount172]
add x17, x17, #1
str x17, [x16, :lo12:Lcount172]
mov x0, #0
adrp x16, Lcount172
ldr x17, [x16, :lo12:Lcount172]
add x17, x17, #1
str x17, [x16, :lo12:Lcount172]
mov x1, #17
adrp x16, Lcount186
ldr x17, [x16, :lo12:Lcount186]
add x17, x17, #1
str x17, [x16, :lo12:Lcount186]
bl fen_allocate
adrp x16, Lcount187
ldr x17, [x16, :lo12:Lcount187]
add x17, x17, #1
str x17, [x16, :lo12:Lcount187]
cbz x0, Lfn6fail949_3
adrp x16, Lcount177
ldr x17, [x16, :lo12:Lcount177]
add x17, x17, #1
str x17, [x16, :lo12:Lcount177]
ldr x2, [sp, #64]
adrp x16, Lcount188
ldr x17, [x16, :lo12:Lcount188]
add x17, x17, #1
str x17, [x16, :lo12:Lcount188]
str x2, [x0, #0]
adrp x16, Lcount185
ldr x17, [x16, :lo12:Lcount185]
add x17, x17, #1
str x17, [x16, :lo12:Lcount185]
b Lfn6match917end
Lfn6match917arm10:
adrp x16, Lcount172
ldr x17, [x16, :lo12:Lcount172]
add x17, x17, #1
str x17, [x16, :lo12:Lcount172]
mov x0, #0
adrp x16, Lcount172
ldr x17, [x16, :lo12:Lcount172]
add x17, x17, #1
str x17, [x16, :lo12:Lcount172]
mov x1, #17
adrp x16, Lcount186
ldr x17, [x16, :lo12:Lcount186]
add x17, x17, #1
str x17, [x16, :lo12:Lcount186]
bl fen_allocate
adrp x16, Lcount187
ldr x17, [x16, :lo12:Lcount187]
add x17, x17, #1
str x17, [x16, :lo12:Lcount187]
cbz x0, Lfn6fail958_3
adrp x16, Lcount177
ldr x17, [x16, :lo12:Lcount177]
add x17, x17, #1
str x17, [x16, :lo12:Lcount177]
ldr x2, [sp, #64]
adrp x16, Lcount188
ldr x17, [x16, :lo12:Lcount188]
add x17, x17, #1
str x17, [x16, :lo12:Lcount188]
str x2, [x0, #0]
adrp x16, Lcount185
ldr x17, [x16, :lo12:Lcount185]
add x17, x17, #1
str x17, [x16, :lo12:Lcount185]
b Lfn6match917end
Lfn6match917end:
adrp x16, Lcount172
ldr x17, [x16, :lo12:Lcount172]
add x17, x17, #1
str x17, [x16, :lo12:Lcount172]
mov x1, #0
adrp x16, Lcount185
ldr x17, [x16, :lo12:Lcount185]
add x17, x17, #1
str x17, [x16, :lo12:Lcount185]
b Lfn6end
Lfn6fail949_3:
adrp x16, Lcount183
ldr x17, [x16, :lo12:Lcount183]
add x17, x17, #1
str x17, [x16, :lo12:Lcount183]
adrp x0, Lfn6fail949_3location
adrp x16, Lcount175
ldr x17, [x16, :lo12:Lcount175]
add x17, x17, #1
str x17, [x16, :lo12:Lcount175]
add x0, x0, :lo12:Lfn6fail949_3location
adrp x16, Lcount189
ldr x17, [x16, :lo12:Lcount189]
add x17, x17, #1
str x17, [x16, :lo12:Lcount189]
bl fen_set_location
adrp x16, Lcount172
ldr x17, [x16, :lo12:Lcount172]
add x17, x17, #1
str x17, [x16, :lo12:Lcount172]
mov x1, #3
adrp x16, Lcount185
ldr x17, [x16, :lo12:Lcount185]
add x17, x17, #1
str x17, [x16, :lo12:Lcount185]
b Lfn6end
Lfn6fail958_3:
adrp x16, Lcount183
ldr x17, [x16, :lo12:Lcount183]
add x17, x17, #1
str x17, [x16, :lo12:Lcount183]
adrp x0, Lfn6fail958_3location
adrp x16, Lcount175
ldr x17, [x16, :lo12:Lcount175]
add x17, x17, #1
str x17, [x16, :lo12:Lcount175]
add x0, x0, :lo12:Lfn6fail958_3location
adrp x16, Lcount189
ldr x17, [x16, :lo12:Lcount189]
add x17, x17, #1
str x17, [x16, :lo12:Lcount189]
bl fen_set_location
adrp x16, Lcount172
ldr x17, [x16, :lo12:Lcount172]
add x17, x17, #1
str x17, [x16, :lo12:Lcount172]
mov x1, #3
adrp x16, Lcount185
ldr x17, [x16, :lo12:Lcount185]
add x17, x17, #1
str x17, [x16, :lo12:Lcount185]
b Lfn6end
Lfn6end:
adrp x16, Lcount182
ldr x17, [x16, :lo12:Lcount182]
add x17, x17, #1
str x17, [x16, :lo12:Lcount182]
bl fen_leave_result
adrp x16, Lcount172
ldr x17, [x16, :lo12:Lcount172]
add x17, x17, #1
str x17, [x16, :lo12:Lcount172]
mov sp, x29
adrp x16, Lcount184
ldr x17, [x16, :lo12:Lcount184]
add x17, x17, #1
str x17, [x16, :lo12:Lcount184]
ldp x29, x30, [sp], #16
adrp x16, Lcount190
ldr x17, [x16, :lo12:Lcount190]
add x17, x17, #1
str x17, [x16, :lo12:Lcount190]
ret
Lfn7:
adrp x16, Lcount191
ldr x17, [x16, :lo12:Lcount191]
add x17, x17, #1
str x17, [x16, :lo12:Lcount191]
ldp x8, x9, [x0, #0]
adrp x16, Lcount192
ldr x17, [x16, :lo12:Lcount192]
add x17, x17, #1
str x17, [x16, :lo12:Lcount192]
ldr x10, [x0, #16]
Lfn7fields:
adrp x16, Lcount193
ldr x17, [x16, :lo12:Lcount193]
add x17, x17, #1
str x17, [x16, :lo12:Lcount193]
stp x29, x30, [sp, #-16]!
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x29, sp
adrp x16, Lcount193
ldr x17, [x16, :lo12:Lcount193]
add x17, x17, #1
str x17, [x16, :lo12:Lcount193]
stp x19, x20, [sp, #-16]!
adrp x16, Lcount193
ldr x17, [x16, :lo12:Lcount193]
add x17, x17, #1
str x17, [x16, :lo12:Lcount193]
stp x21, x22, [sp, #-16]!
adrp x16, Lcount193
ldr x17, [x16, :lo12:Lcount193]
add x17, x17, #1
str x17, [x16, :lo12:Lcount193]
stp x23, xzr, [sp, #-16]!
adrp x16, Lcount195
ldr x17, [x16, :lo12:Lcount195]
add x17, x17, #1
str x17, [x16, :lo12:Lcount195]
sub sp, sp, #272
adrp x16, Lcount193
ldr x17, [x16, :lo12:Lcount193]
add x17, x17, #1
str x17, [x16, :lo12:Lcount193]
stp xzr, xzr, [sp, #64]
adrp x16, Lcount193
ldr x17, [x16, :lo12:Lcount193]
add x17, x17, #1
str x17, [x16, :lo12:Lcount193]
stp xzr, xzr, [sp, #80]
adrp x16, Lcount193
ldr x17, [x16, :lo12:Lcount193]
add x17, x17, #1
str x17, [x16, :lo12:Lcount193]
stp xzr, xzr, [sp, #96]
adrp x16, Lcount196
ldr x17, [x16, :lo12:Lcount196]
add x17, x17, #1
str x17, [x16, :lo12:Lcount196]
str xzr, [sp, #112]
adrp x16, Lcount193
ldr x17, [x16, :lo12:Lcount193]
add x17, x17, #1
str x17, [x16, :lo12:Lcount193]
stp x8, x9, [sp, #48]
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x19, x10
adrp x16, Lcount197
ldr x17, [x16, :lo12:Lcount197]
add x17, x17, #1
str x17, [x16, :lo12:Lcount197]
add x0, sp, #16
adrp x16, Lcount197
ldr x17, [x16, :lo12:Lcount197]
add x17, x17, #1
str x17, [x16, :lo12:Lcount197]
add x1, sp, #48
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x2, #9
adrp x16, Lcount198
ldr x17, [x16, :lo12:Lcount198]
add x17, x17, #1
str x17, [x16, :lo12:Lcount198]
bl fen_enter
Lfn7loop:
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x0, [sp, #56]
adrp x16, Lcount192
ldr x17, [x16, :lo12:Lcount192]
add x17, x17, #1
str x17, [x16, :lo12:Lcount192]
ldr x0, [x0]
adrp x16, Lcount196
ldr x17, [x16, :lo12:Lcount196]
add x17, x17, #1
str x17, [x16, :lo12:Lcount196]
str x0, [sp, #120]
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x0, x19
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x2, [sp, #120]
adrp x16, Lcount200
ldr x17, [x16, :lo12:Lcount200]
add x17, x17, #1
str x17, [x16, :lo12:Lcount200]
cmp x0, x2
adrp x16, Lcount201
ldr x17, [x16, :lo12:Lcount201]
add x17, x17, #1
str x17, [x16, :lo12:Lcount201]
b.ne Lfn7if974else
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x0, [sp, #48]
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7if974done
Lfn7if974else:
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x0, [sp, #48]
adrp x16, Lcount192
ldr x17, [x16, :lo12:Lcount192]
add x17, x17, #1
str x17, [x16, :lo12:Lcount192]
ldr w0, [x0, #72]
adrp x16, Lcount200
ldr x17, [x16, :lo12:Lcount200]
add x17, x17, #1
str x17, [x16, :lo12:Lcount200]
cmp w0, #17
adrp x16, Lcount203
ldr x17, [x16, :lo12:Lcount203]
add x17, x17, #1
str x17, [x16, :lo12:Lcount203]
b.eq Lfn7match980arm17
adrp x16, Lcount200
ldr x17, [x16, :lo12:Lcount200]
add x17, x17, #1
str x17, [x16, :lo12:Lcount200]
cmp w0, #13
adrp x16, Lcount203
ldr x17, [x16, :lo12:Lcount203]
add x17, x17, #1
str x17, [x16, :lo12:Lcount203]
b.eq Lfn7match980arm13
adrp x16, Lcount200
ldr x17, [x16, :lo12:Lcount200]
add x17, x17, #1
str x17, [x16, :lo12:Lcount200]
cmp w0, #14
adrp x16, Lcount203
ldr x17, [x16, :lo12:Lcount203]
add x17, x17, #1
str x17, [x16, :lo12:Lcount203]
b.eq Lfn7match980arm14
adrp x16, Lcount200
ldr x17, [x16, :lo12:Lcount200]
add x17, x17, #1
str x17, [x16, :lo12:Lcount200]
cmp w0, #15
adrp x16, Lcount203
ldr x17, [x16, :lo12:Lcount203]
add x17, x17, #1
str x17, [x16, :lo12:Lcount203]
b.eq Lfn7match980arm15
adrp x16, Lcount200
ldr x17, [x16, :lo12:Lcount200]
add x17, x17, #1
str x17, [x16, :lo12:Lcount200]
cmp w0, #16
adrp x16, Lcount203
ldr x17, [x16, :lo12:Lcount203]
add x17, x17, #1
str x17, [x16, :lo12:Lcount203]
b.eq Lfn7match980arm16
adrp x16, Lcount204
ldr x17, [x16, :lo12:Lcount204]
add x17, x17, #1
str x17, [x16, :lo12:Lcount204]
brk #0
Lfn7match980arm17:
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x0, [sp, #48]
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7match980end
Lfn7match980arm13:
adrp x16, Lcount205
ldr x17, [x16, :lo12:Lcount205]
add x17, x17, #1
str x17, [x16, :lo12:Lcount205]
bl fen_leave_result
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x8, [sp, #48]
adrp x16, Lcount192
ldr x17, [x16, :lo12:Lcount192]
add x17, x17, #1
str x17, [x16, :lo12:Lcount192]
ldr x8, [x8, #0]
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x9, [sp, #48]
adrp x16, Lcount192
ldr x17, [x16, :lo12:Lcount192]
add x17, x17, #1
str x17, [x16, :lo12:Lcount192]
ldr x9, [x9, #8]
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x10, [sp, #56]
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x11, x19
adrp x16, Lcount191
ldr x17, [x16, :lo12:Lcount191]
add x17, x17, #1
str x17, [x16, :lo12:Lcount191]
ldp x19, x20, [x29, #-16]
adrp x16, Lcount191
ldr x17, [x16, :lo12:Lcount191]
add x17, x17, #1
str x17, [x16, :lo12:Lcount191]
ldp x21, x22, [x29, #-32]
adrp x16, Lcount191
ldr x17, [x16, :lo12:Lcount191]
add x17, x17, #1
str x17, [x16, :lo12:Lcount191]
ldp x23, xzr, [x29, #-48]
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov sp, x29
adrp x16, Lcount206
ldr x17, [x16, :lo12:Lcount206]
add x17, x17, #1
str x17, [x16, :lo12:Lcount206]
ldp x29, x30, [sp], #16
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn6fields
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7match980end
Lfn7match980arm14:
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x0, [sp, #56]
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x2, x19
adrp x16, Lcount192
ldr x17, [x16, :lo12:Lcount192]
add x17, x17, #1
str x17, [x16, :lo12:Lcount192]
ldr x3, [x0]
adrp x16, Lcount200
ldr x17, [x16, :lo12:Lcount200]
add x17, x17, #1
str x17, [x16, :lo12:Lcount200]
cmp x2, x3
adrp x16, Lcount207
ldr x17, [x16, :lo12:Lcount207]
add x17, x17, #1
str x17, [x16, :lo12:Lcount207]
b.hs Lfn7fail999_4
adrp x16, Lcount192
ldr x17, [x16, :lo12:Lcount192]
add x17, x17, #1
str x17, [x16, :lo12:Lcount192]
ldr w3, [x0, #72]
adrp x16, Lcount208
ldr x17, [x16, :lo12:Lcount208]
add x17, x17, #1
str x17, [x16, :lo12:Lcount208]
cmn w3, #1
adrp x16, Lcount201
ldr x17, [x16, :lo12:Lcount201]
add x17, x17, #1
str x17, [x16, :lo12:Lcount201]
b.ne 1f
adrp x16, Lcount197
ldr x17, [x16, :lo12:Lcount197]
add x17, x17, #1
str x17, [x16, :lo12:Lcount197]
add x0, x0, #80
adrp x16, Lcount209
ldr x17, [x16, :lo12:Lcount209]
add x17, x17, #1
str x17, [x16, :lo12:Lcount209]
ldrb w0, [x0, x2]
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b 2f
1:
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x1, x2
adrp x16, Lcount210
ldr x17, [x16, :lo12:Lcount210]
add x17, x17, #1
str x17, [x16, :lo12:Lcount210]
bl fen_bytes_index
2:
adrp x16, Lcount196
ldr x17, [x16, :lo12:Lcount196]
add x17, x17, #1
str x17, [x16, :lo12:Lcount196]
str x0, [sp, #128]
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x0, [sp, #48]
adrp x16, Lcount192
ldr x17, [x16, :lo12:Lcount192]
add x17, x17, #1
str x17, [x16, :lo12:Lcount192]
ldr x0, [x0, #8]
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x2, [sp, #128]
adrp x16, Lcount211
ldr x17, [x16, :lo12:Lcount211]
add x17, x17, #1
str x17, [x16, :lo12:Lcount211]
adds x0, x0, x2
adrp x16, Lcount212
ldr x17, [x16, :lo12:Lcount212]
add x17, x17, #1
str x17, [x16, :lo12:Lcount212]
b.vs Lfn7fail997_1
adrp x16, Lcount196
ldr x17, [x16, :lo12:Lcount196]
add x17, x17, #1
str x17, [x16, :lo12:Lcount196]
str x0, [sp, #136]
adrp x16, Lcount200
ldr x17, [x16, :lo12:Lcount200]
add x17, x17, #1
str x17, [x16, :lo12:Lcount200]
cmp x0, #0
adrp x16, Lcount201
ldr x17, [x16, :lo12:Lcount201]
add x17, x17, #1
str x17, [x16, :lo12:Lcount201]
b.ne Lfn7if1002else
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x0, [sp, #48]
adrp x16, Lcount192
ldr x17, [x16, :lo12:Lcount192]
add x17, x17, #1
str x17, [x16, :lo12:Lcount192]
ldr x0, [x0, #0]
adrp x16, Lcount213
ldr x17, [x16, :lo12:Lcount213]
add x17, x17, #1
str x17, [x16, :lo12:Lcount213]
subs x0, x0, #1
adrp x16, Lcount212
ldr x17, [x16, :lo12:Lcount212]
add x17, x17, #1
str x17, [x16, :lo12:Lcount212]
b.vs Lfn7fail1007_1
adrp x16, Lcount196
ldr x17, [x16, :lo12:Lcount196]
add x17, x17, #1
str x17, [x16, :lo12:Lcount196]
str x0, [sp, #144]
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x0, #0
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x1, #17
adrp x16, Lcount214
ldr x17, [x16, :lo12:Lcount214]
add x17, x17, #1
str x17, [x16, :lo12:Lcount214]
bl fen_allocate
adrp x16, Lcount215
ldr x17, [x16, :lo12:Lcount215]
add x17, x17, #1
str x17, [x16, :lo12:Lcount215]
cbz x0, Lfn7fail1006_3
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x2, [sp, #144]
adrp x16, Lcount216
ldr x17, [x16, :lo12:Lcount216]
add x17, x17, #1
str x17, [x16, :lo12:Lcount216]
str x2, [x0, #0]
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7if1002done
Lfn7if1002else:
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x0, [sp, #48]
adrp x16, Lcount192
ldr x17, [x16, :lo12:Lcount192]
add x17, x17, #1
str x17, [x16, :lo12:Lcount192]
ldr x0, [x0, #0]
adrp x16, Lcount211
ldr x17, [x16, :lo12:Lcount211]
add x17, x17, #1
str x17, [x16, :lo12:Lcount211]
adds x0, x0, #1
adrp x16, Lcount212
ldr x17, [x16, :lo12:Lcount212]
add x17, x17, #1
str x17, [x16, :lo12:Lcount212]
b.vs Lfn7fail1013_1
adrp x16, Lcount196
ldr x17, [x16, :lo12:Lcount196]
add x17, x17, #1
str x17, [x16, :lo12:Lcount196]
str x0, [sp, #152]
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x0, #4
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x1, #15
adrp x16, Lcount214
ldr x17, [x16, :lo12:Lcount214]
add x17, x17, #1
str x17, [x16, :lo12:Lcount214]
bl fen_allocate
adrp x16, Lcount215
ldr x17, [x16, :lo12:Lcount215]
add x17, x17, #1
str x17, [x16, :lo12:Lcount215]
cbz x0, Lfn7fail1012_3
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x2, [sp, #152]
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x3, [sp, #136]
adrp x16, Lcount217
ldr x17, [x16, :lo12:Lcount217]
add x17, x17, #1
str x17, [x16, :lo12:Lcount217]
stp x2, x3, [x0, #0]
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x2, [sp, #48]
adrp x16, Lcount192
ldr x17, [x16, :lo12:Lcount192]
add x17, x17, #1
str x17, [x16, :lo12:Lcount192]
ldr x2, [x2, #16]
adrp x16, Lcount216
ldr x17, [x16, :lo12:Lcount216]
add x17, x17, #1
str x17, [x16, :lo12:Lcount216]
str x2, [x0, #16]
adrp x16, Lcount196
ldr x17, [x16, :lo12:Lcount196]
add x17, x17, #1
str x17, [x16, :lo12:Lcount196]
str x0, [sp, #64]
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x0, x19
adrp x16, Lcount211
ldr x17, [x16, :lo12:Lcount211]
add x17, x17, #1
str x17, [x16, :lo12:Lcount211]
adds x0, x0, #1
adrp x16, Lcount212
ldr x17, [x16, :lo12:Lcount212]
add x17, x17, #1
str x17, [x16, :lo12:Lcount212]
b.vs Lfn7fail1019_1
adrp x16, Lcount196
ldr x17, [x16, :lo12:Lcount196]
add x17, x17, #1
str x17, [x16, :lo12:Lcount196]
str x0, [sp, #160]
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x8, [sp, #64]
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x9, [sp, #160]
adrp x16, Lcount196
ldr x17, [x16, :lo12:Lcount196]
add x17, x17, #1
str x17, [x16, :lo12:Lcount196]
str x8, [sp, #48]
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x19, x9
adrp x16, Lcount193
ldr x17, [x16, :lo12:Lcount193]
add x17, x17, #1
str x17, [x16, :lo12:Lcount193]
stp xzr, xzr, [sp, #64]
adrp x16, Lcount193
ldr x17, [x16, :lo12:Lcount193]
add x17, x17, #1
str x17, [x16, :lo12:Lcount193]
stp xzr, xzr, [sp, #80]
adrp x16, Lcount193
ldr x17, [x16, :lo12:Lcount193]
add x17, x17, #1
str x17, [x16, :lo12:Lcount193]
stp xzr, xzr, [sp, #96]
adrp x16, Lcount196
ldr x17, [x16, :lo12:Lcount196]
add x17, x17, #1
str x17, [x16, :lo12:Lcount196]
str xzr, [sp, #112]
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7loop
Lfn7if1002done:
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7match980end
Lfn7match980arm15:
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x0, [sp, #56]
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x2, x19
adrp x16, Lcount192
ldr x17, [x16, :lo12:Lcount192]
add x17, x17, #1
str x17, [x16, :lo12:Lcount192]
ldr x3, [x0]
adrp x16, Lcount200
ldr x17, [x16, :lo12:Lcount200]
add x17, x17, #1
str x17, [x16, :lo12:Lcount200]
cmp x2, x3
adrp x16, Lcount207
ldr x17, [x16, :lo12:Lcount207]
add x17, x17, #1
str x17, [x16, :lo12:Lcount207]
b.hs Lfn7fail1027_4
adrp x16, Lcount192
ldr x17, [x16, :lo12:Lcount192]
add x17, x17, #1
str x17, [x16, :lo12:Lcount192]
ldr w3, [x0, #72]
adrp x16, Lcount208
ldr x17, [x16, :lo12:Lcount208]
add x17, x17, #1
str x17, [x16, :lo12:Lcount208]
cmn w3, #1
adrp x16, Lcount201
ldr x17, [x16, :lo12:Lcount201]
add x17, x17, #1
str x17, [x16, :lo12:Lcount201]
b.ne 1f
adrp x16, Lcount197
ldr x17, [x16, :lo12:Lcount197]
add x17, x17, #1
str x17, [x16, :lo12:Lcount197]
add x0, x0, #80
adrp x16, Lcount209
ldr x17, [x16, :lo12:Lcount209]
add x17, x17, #1
str x17, [x16, :lo12:Lcount209]
ldrb w0, [x0, x2]
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b 2f
1:
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x1, x2
adrp x16, Lcount210
ldr x17, [x16, :lo12:Lcount210]
add x17, x17, #1
str x17, [x16, :lo12:Lcount210]
bl fen_bytes_index
2:
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x21, x0
adrp x16, Lcount218
ldr x17, [x16, :lo12:Lcount218]
add x17, x17, #1
str x17, [x16, :lo12:Lcount218]
movz x0, #63, lsl #0
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x2, x21
adrp x16, Lcount200
ldr x17, [x16, :lo12:Lcount200]
add x17, x17, #1
str x17, [x16, :lo12:Lcount200]
cmp x0, x2
adrp x16, Lcount219
ldr x17, [x16, :lo12:Lcount219]
add x17, x17, #1
str x17, [x16, :lo12:Lcount219]
b.ge Lfn7if1030else
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x0, #0
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x1, #17
adrp x16, Lcount214
ldr x17, [x16, :lo12:Lcount214]
add x17, x17, #1
str x17, [x16, :lo12:Lcount214]
bl fen_allocate
adrp x16, Lcount215
ldr x17, [x16, :lo12:Lcount215]
add x17, x17, #1
str x17, [x16, :lo12:Lcount215]
cbz x0, Lfn7fail1034_3
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x2, [sp, #48]
adrp x16, Lcount192
ldr x17, [x16, :lo12:Lcount192]
add x17, x17, #1
str x17, [x16, :lo12:Lcount192]
ldr x2, [x2, #0]
adrp x16, Lcount216
ldr x17, [x16, :lo12:Lcount216]
add x17, x17, #1
str x17, [x16, :lo12:Lcount216]
str x2, [x0, #0]
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7if1030done
Lfn7if1030else:
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x0, [sp, #48]
adrp x16, Lcount192
ldr x17, [x16, :lo12:Lcount192]
add x17, x17, #1
str x17, [x16, :lo12:Lcount192]
ldr x0, [x0, #8]
adrp x16, Lcount200
ldr x17, [x16, :lo12:Lcount200]
add x17, x17, #1
str x17, [x16, :lo12:Lcount200]
cmp x0, #1
adrp x16, Lcount201
ldr x17, [x16, :lo12:Lcount201]
add x17, x17, #1
str x17, [x16, :lo12:Lcount201]
b.ne Lfn7if1038else
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x0, [sp, #48]
adrp x16, Lcount192
ldr x17, [x16, :lo12:Lcount192]
add x17, x17, #1
str x17, [x16, :lo12:Lcount192]
ldr x0, [x0, #0]
adrp x16, Lcount211
ldr x17, [x16, :lo12:Lcount211]
add x17, x17, #1
str x17, [x16, :lo12:Lcount211]
adds x0, x0, #1
adrp x16, Lcount212
ldr x17, [x16, :lo12:Lcount212]
add x17, x17, #1
str x17, [x16, :lo12:Lcount212]
b.vs Lfn7fail1043_1
adrp x16, Lcount196
ldr x17, [x16, :lo12:Lcount196]
add x17, x17, #1
str x17, [x16, :lo12:Lcount196]
str x0, [sp, #168]
adrp x16, Lcount218
ldr x17, [x16, :lo12:Lcount218]
add x17, x17, #1
str x17, [x16, :lo12:Lcount218]
movz x0, #0, lsl #0
adrp x16, Lcount196
ldr x17, [x16, :lo12:Lcount196]
add x17, x17, #1
str x17, [x16, :lo12:Lcount196]
str x0, [sp, #176]
adrp x16, Lcount218
ldr x17, [x16, :lo12:Lcount218]
add x17, x17, #1
str x17, [x16, :lo12:Lcount218]
movz x0, #0, lsl #0
adrp x16, Lcount196
ldr x17, [x16, :lo12:Lcount196]
add x17, x17, #1
str x17, [x16, :lo12:Lcount196]
str x0, [sp, #184]
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x8, [sp, #48]
adrp x16, Lcount192
ldr x17, [x16, :lo12:Lcount192]
add x17, x17, #1
str x17, [x16, :lo12:Lcount192]
ldr x8, [x8, #16]
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x9, x21
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x10, [sp, #176]
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x11, [sp, #184]
adrp x16, Lcount220
ldr x17, [x16, :lo12:Lcount220]
add x17, x17, #1
str x17, [x16, :lo12:Lcount220]
bl Lfn2fields
adrp x16, Lcount221
ldr x17, [x16, :lo12:Lcount221]
add x17, x17, #1
str x17, [x16, :lo12:Lcount221]
cbnz x1, Lfn7end
adrp x16, Lcount196
ldr x17, [x16, :lo12:Lcount196]
add x17, x17, #1
str x17, [x16, :lo12:Lcount196]
str x0, [sp, #72]
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x0, #2
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x1, #13
adrp x16, Lcount214
ldr x17, [x16, :lo12:Lcount214]
add x17, x17, #1
str x17, [x16, :lo12:Lcount214]
bl fen_allocate
adrp x16, Lcount215
ldr x17, [x16, :lo12:Lcount215]
add x17, x17, #1
str x17, [x16, :lo12:Lcount215]
cbz x0, Lfn7fail1042_3
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x2, [sp, #168]
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x3, [sp, #72]
adrp x16, Lcount217
ldr x17, [x16, :lo12:Lcount217]
add x17, x17, #1
str x17, [x16, :lo12:Lcount217]
stp x2, x3, [x0, #0]
adrp x16, Lcount196
ldr x17, [x16, :lo12:Lcount196]
add x17, x17, #1
str x17, [x16, :lo12:Lcount196]
str x0, [sp, #80]
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7if1038done
Lfn7if1038else:
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x0, [sp, #48]
adrp x16, Lcount192
ldr x17, [x16, :lo12:Lcount192]
add x17, x17, #1
str x17, [x16, :lo12:Lcount192]
ldr x0, [x0, #0]
adrp x16, Lcount211
ldr x17, [x16, :lo12:Lcount211]
add x17, x17, #1
str x17, [x16, :lo12:Lcount211]
adds x0, x0, #1
adrp x16, Lcount212
ldr x17, [x16, :lo12:Lcount212]
add x17, x17, #1
str x17, [x16, :lo12:Lcount212]
b.vs Lfn7fail1053_1
adrp x16, Lcount196
ldr x17, [x16, :lo12:Lcount196]
add x17, x17, #1
str x17, [x16, :lo12:Lcount196]
str x0, [sp, #192]
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x0, [sp, #48]
adrp x16, Lcount192
ldr x17, [x16, :lo12:Lcount192]
add x17, x17, #1
str x17, [x16, :lo12:Lcount192]
ldr x0, [x0, #8]
adrp x16, Lcount213
ldr x17, [x16, :lo12:Lcount213]
add x17, x17, #1
str x17, [x16, :lo12:Lcount213]
subs x0, x0, #1
adrp x16, Lcount212
ldr x17, [x16, :lo12:Lcount212]
add x17, x17, #1
str x17, [x16, :lo12:Lcount212]
b.vs Lfn7fail1057_1
adrp x16, Lcount196
ldr x17, [x16, :lo12:Lcount196]
add x17, x17, #1
str x17, [x16, :lo12:Lcount196]
str x0, [sp, #200]
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x0, [sp, #48]
adrp x16, Lcount192
ldr x17, [x16, :lo12:Lcount192]
add x17, x17, #1
str x17, [x16, :lo12:Lcount192]
ldr x0, [x0, #8]
adrp x16, Lcount213
ldr x17, [x16, :lo12:Lcount213]
add x17, x17, #1
str x17, [x16, :lo12:Lcount213]
subs x0, x0, #1
adrp x16, Lcount212
ldr x17, [x16, :lo12:Lcount212]
add x17, x17, #1
str x17, [x16, :lo12:Lcount212]
b.vs Lfn7fail1060_1
adrp x16, Lcount196
ldr x17, [x16, :lo12:Lcount196]
add x17, x17, #1
str x17, [x16, :lo12:Lcount196]
str x0, [sp, #208]
adrp x16, Lcount218
ldr x17, [x16, :lo12:Lcount218]
add x17, x17, #1
str x17, [x16, :lo12:Lcount218]
movz x0, #0, lsl #0
adrp x16, Lcount196
ldr x17, [x16, :lo12:Lcount196]
add x17, x17, #1
str x17, [x16, :lo12:Lcount196]
str x0, [sp, #216]
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x0, #32
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x1, #16
adrp x16, Lcount214
ldr x17, [x16, :lo12:Lcount214]
add x17, x17, #1
str x17, [x16, :lo12:Lcount214]
bl fen_allocate
adrp x16, Lcount215
ldr x17, [x16, :lo12:Lcount215]
add x17, x17, #1
str x17, [x16, :lo12:Lcount215]
cbz x0, Lfn7fail1052_3
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x2, [sp, #192]
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x3, x21
adrp x16, Lcount217
ldr x17, [x16, :lo12:Lcount217]
add x17, x17, #1
str x17, [x16, :lo12:Lcount217]
stp x2, x3, [x0, #0]
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x2, [sp, #200]
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x3, [sp, #208]
adrp x16, Lcount217
ldr x17, [x16, :lo12:Lcount217]
add x17, x17, #1
str x17, [x16, :lo12:Lcount217]
stp x2, x3, [x0, #16]
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x2, [sp, #216]
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x3, [sp, #48]
adrp x16, Lcount192
ldr x17, [x16, :lo12:Lcount192]
add x17, x17, #1
str x17, [x16, :lo12:Lcount192]
ldr x3, [x3, #16]
adrp x16, Lcount217
ldr x17, [x16, :lo12:Lcount217]
add x17, x17, #1
str x17, [x16, :lo12:Lcount217]
stp x2, x3, [x0, #32]
adrp x16, Lcount196
ldr x17, [x16, :lo12:Lcount196]
add x17, x17, #1
str x17, [x16, :lo12:Lcount196]
str x0, [sp, #88]
Lfn7if1038done:
adrp x16, Lcount196
ldr x17, [x16, :lo12:Lcount196]
add x17, x17, #1
str x17, [x16, :lo12:Lcount196]
str x0, [sp, #96]
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x0, x19
adrp x16, Lcount211
ldr x17, [x16, :lo12:Lcount211]
add x17, x17, #1
str x17, [x16, :lo12:Lcount211]
adds x0, x0, #1
adrp x16, Lcount212
ldr x17, [x16, :lo12:Lcount212]
add x17, x17, #1
str x17, [x16, :lo12:Lcount212]
b.vs Lfn7fail1066_1
adrp x16, Lcount196
ldr x17, [x16, :lo12:Lcount196]
add x17, x17, #1
str x17, [x16, :lo12:Lcount196]
str x0, [sp, #224]
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x8, [sp, #96]
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x9, [sp, #224]
adrp x16, Lcount196
ldr x17, [x16, :lo12:Lcount196]
add x17, x17, #1
str x17, [x16, :lo12:Lcount196]
str x8, [sp, #48]
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x19, x9
adrp x16, Lcount193
ldr x17, [x16, :lo12:Lcount193]
add x17, x17, #1
str x17, [x16, :lo12:Lcount193]
stp xzr, xzr, [sp, #64]
adrp x16, Lcount193
ldr x17, [x16, :lo12:Lcount193]
add x17, x17, #1
str x17, [x16, :lo12:Lcount193]
stp xzr, xzr, [sp, #80]
adrp x16, Lcount193
ldr x17, [x16, :lo12:Lcount193]
add x17, x17, #1
str x17, [x16, :lo12:Lcount193]
stp xzr, xzr, [sp, #96]
adrp x16, Lcount196
ldr x17, [x16, :lo12:Lcount196]
add x17, x17, #1
str x17, [x16, :lo12:Lcount196]
str xzr, [sp, #112]
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7loop
Lfn7if1030done:
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7match980end
Lfn7match980arm16:
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x0, [sp, #56]
adrp x16, Lcount192
ldr x17, [x16, :lo12:Lcount192]
add x17, x17, #1
str x17, [x16, :lo12:Lcount192]
ldr x0, [x0]
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x2, x19
adrp x16, Lcount213
ldr x17, [x16, :lo12:Lcount213]
add x17, x17, #1
str x17, [x16, :lo12:Lcount213]
subs x0, x0, x2
adrp x16, Lcount212
ldr x17, [x16, :lo12:Lcount212]
add x17, x17, #1
str x17, [x16, :lo12:Lcount212]
b.vs Lfn7fail1077_1
adrp x16, Lcount196
ldr x17, [x16, :lo12:Lcount196]
add x17, x17, #1
str x17, [x16, :lo12:Lcount196]
str x0, [sp, #232]
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x2, [sp, #48]
adrp x16, Lcount192
ldr x17, [x16, :lo12:Lcount192]
add x17, x17, #1
str x17, [x16, :lo12:Lcount192]
ldr x2, [x2, #24]
adrp x16, Lcount200
ldr x17, [x16, :lo12:Lcount200]
add x17, x17, #1
str x17, [x16, :lo12:Lcount200]
cmp x0, x2
adrp x16, Lcount219
ldr x17, [x16, :lo12:Lcount219]
add x17, x17, #1
str x17, [x16, :lo12:Lcount219]
b.ge Lfn7if1083else
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x0, [sp, #232]
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7if1083done
Lfn7if1083else:
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x0, [sp, #48]
adrp x16, Lcount192
ldr x17, [x16, :lo12:Lcount192]
add x17, x17, #1
str x17, [x16, :lo12:Lcount192]
ldr x0, [x0, #24]
Lfn7if1083done:
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x20, x0
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x0, x19
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x2, x20
adrp x16, Lcount211
ldr x17, [x16, :lo12:Lcount211]
add x17, x17, #1
str x17, [x16, :lo12:Lcount211]
adds x0, x0, x2
adrp x16, Lcount212
ldr x17, [x16, :lo12:Lcount212]
add x17, x17, #1
str x17, [x16, :lo12:Lcount212]
b.vs Lfn7fail1091_1
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x22, x0
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x8, [sp, #56]
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x9, x19
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x10, x22
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x11, [sp, #48]
adrp x16, Lcount192
ldr x17, [x16, :lo12:Lcount192]
add x17, x17, #1
str x17, [x16, :lo12:Lcount192]
ldr x11, [x11, #32]
adrp x16, Lcount222
ldr x17, [x16, :lo12:Lcount222]
add x17, x17, #1
str x17, [x16, :lo12:Lcount222]
bl Lfn4fields
adrp x16, Lcount221
ldr x17, [x16, :lo12:Lcount221]
add x17, x17, #1
str x17, [x16, :lo12:Lcount221]
cbnz x1, Lfn7end
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x23, x0
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x0, x20
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x2, [sp, #48]
adrp x16, Lcount192
ldr x17, [x16, :lo12:Lcount192]
add x17, x17, #1
str x17, [x16, :lo12:Lcount192]
ldr x2, [x2, #24]
adrp x16, Lcount200
ldr x17, [x16, :lo12:Lcount200]
add x17, x17, #1
str x17, [x16, :lo12:Lcount200]
cmp x0, x2
adrp x16, Lcount201
ldr x17, [x16, :lo12:Lcount201]
add x17, x17, #1
str x17, [x16, :lo12:Lcount201]
b.ne Lfn7if1102else
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x0, [sp, #48]
adrp x16, Lcount192
ldr x17, [x16, :lo12:Lcount192]
add x17, x17, #1
str x17, [x16, :lo12:Lcount192]
ldr x0, [x0, #0]
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x2, x20
adrp x16, Lcount211
ldr x17, [x16, :lo12:Lcount211]
add x17, x17, #1
str x17, [x16, :lo12:Lcount211]
adds x0, x0, x2
adrp x16, Lcount212
ldr x17, [x16, :lo12:Lcount212]
add x17, x17, #1
str x17, [x16, :lo12:Lcount212]
b.vs Lfn7fail1109_1
adrp x16, Lcount196
ldr x17, [x16, :lo12:Lcount196]
add x17, x17, #1
str x17, [x16, :lo12:Lcount196]
str x0, [sp, #240]
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x8, [sp, #48]
adrp x16, Lcount192
ldr x17, [x16, :lo12:Lcount192]
add x17, x17, #1
str x17, [x16, :lo12:Lcount192]
ldr x8, [x8, #40]
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x9, [sp, #48]
adrp x16, Lcount192
ldr x17, [x16, :lo12:Lcount192]
add x17, x17, #1
str x17, [x16, :lo12:Lcount192]
ldr x9, [x9, #8]
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x10, [sp, #48]
adrp x16, Lcount192
ldr x17, [x16, :lo12:Lcount192]
add x17, x17, #1
str x17, [x16, :lo12:Lcount192]
ldr x10, [x10, #16]
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x11, x23
adrp x16, Lcount220
ldr x17, [x16, :lo12:Lcount220]
add x17, x17, #1
str x17, [x16, :lo12:Lcount220]
bl Lfn2fields
adrp x16, Lcount221
ldr x17, [x16, :lo12:Lcount221]
add x17, x17, #1
str x17, [x16, :lo12:Lcount221]
cbnz x1, Lfn7end
adrp x16, Lcount196
ldr x17, [x16, :lo12:Lcount196]
add x17, x17, #1
str x17, [x16, :lo12:Lcount196]
str x0, [sp, #104]
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x0, #2
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x1, #13
adrp x16, Lcount214
ldr x17, [x16, :lo12:Lcount214]
add x17, x17, #1
str x17, [x16, :lo12:Lcount214]
bl fen_allocate
adrp x16, Lcount215
ldr x17, [x16, :lo12:Lcount215]
add x17, x17, #1
str x17, [x16, :lo12:Lcount215]
cbz x0, Lfn7fail1108_3
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x2, [sp, #240]
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x3, [sp, #104]
adrp x16, Lcount217
ldr x17, [x16, :lo12:Lcount217]
add x17, x17, #1
str x17, [x16, :lo12:Lcount217]
stp x2, x3, [x0, #0]
adrp x16, Lcount196
ldr x17, [x16, :lo12:Lcount196]
add x17, x17, #1
str x17, [x16, :lo12:Lcount196]
str x0, [sp, #112]
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x8, [sp, #112]
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x9, x22
adrp x16, Lcount196
ldr x17, [x16, :lo12:Lcount196]
add x17, x17, #1
str x17, [x16, :lo12:Lcount196]
str x8, [sp, #48]
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x19, x9
adrp x16, Lcount193
ldr x17, [x16, :lo12:Lcount193]
add x17, x17, #1
str x17, [x16, :lo12:Lcount193]
stp xzr, xzr, [sp, #64]
adrp x16, Lcount193
ldr x17, [x16, :lo12:Lcount193]
add x17, x17, #1
str x17, [x16, :lo12:Lcount193]
stp xzr, xzr, [sp, #80]
adrp x16, Lcount193
ldr x17, [x16, :lo12:Lcount193]
add x17, x17, #1
str x17, [x16, :lo12:Lcount193]
stp xzr, xzr, [sp, #96]
adrp x16, Lcount196
ldr x17, [x16, :lo12:Lcount196]
add x17, x17, #1
str x17, [x16, :lo12:Lcount196]
str xzr, [sp, #112]
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7loop
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7if1102done
Lfn7if1102else:
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x0, [sp, #48]
adrp x16, Lcount192
ldr x17, [x16, :lo12:Lcount192]
add x17, x17, #1
str x17, [x16, :lo12:Lcount192]
ldr x0, [x0, #0]
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x2, x20
adrp x16, Lcount211
ldr x17, [x16, :lo12:Lcount211]
add x17, x17, #1
str x17, [x16, :lo12:Lcount211]
adds x0, x0, x2
adrp x16, Lcount212
ldr x17, [x16, :lo12:Lcount212]
add x17, x17, #1
str x17, [x16, :lo12:Lcount212]
b.vs Lfn7fail1121_1
adrp x16, Lcount196
ldr x17, [x16, :lo12:Lcount196]
add x17, x17, #1
str x17, [x16, :lo12:Lcount196]
str x0, [sp, #248]
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x0, [sp, #48]
adrp x16, Lcount192
ldr x17, [x16, :lo12:Lcount192]
add x17, x17, #1
str x17, [x16, :lo12:Lcount192]
ldr x0, [x0, #24]
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x2, x20
adrp x16, Lcount213
ldr x17, [x16, :lo12:Lcount213]
add x17, x17, #1
str x17, [x16, :lo12:Lcount213]
subs x0, x0, x2
adrp x16, Lcount212
ldr x17, [x16, :lo12:Lcount212]
add x17, x17, #1
str x17, [x16, :lo12:Lcount212]
b.vs Lfn7fail1126_1
adrp x16, Lcount196
ldr x17, [x16, :lo12:Lcount196]
add x17, x17, #1
str x17, [x16, :lo12:Lcount196]
str x0, [sp, #256]
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x0, #32
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x1, #16
adrp x16, Lcount214
ldr x17, [x16, :lo12:Lcount214]
add x17, x17, #1
str x17, [x16, :lo12:Lcount214]
bl fen_allocate
adrp x16, Lcount215
ldr x17, [x16, :lo12:Lcount215]
add x17, x17, #1
str x17, [x16, :lo12:Lcount215]
cbz x0, Lfn7fail1120_3
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x2, [sp, #248]
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x3, [sp, #48]
adrp x16, Lcount192
ldr x17, [x16, :lo12:Lcount192]
add x17, x17, #1
str x17, [x16, :lo12:Lcount192]
ldr x3, [x3, #8]
adrp x16, Lcount217
ldr x17, [x16, :lo12:Lcount217]
add x17, x17, #1
str x17, [x16, :lo12:Lcount217]
stp x2, x3, [x0, #0]
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x2, [sp, #48]
adrp x16, Lcount192
ldr x17, [x16, :lo12:Lcount192]
add x17, x17, #1
str x17, [x16, :lo12:Lcount192]
ldr x2, [x2, #16]
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x3, [sp, #256]
adrp x16, Lcount217
ldr x17, [x16, :lo12:Lcount217]
add x17, x17, #1
str x17, [x16, :lo12:Lcount217]
stp x2, x3, [x0, #16]
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x2, x23
adrp x16, Lcount199
ldr x17, [x16, :lo12:Lcount199]
add x17, x17, #1
str x17, [x16, :lo12:Lcount199]
ldr x3, [sp, #48]
adrp x16, Lcount192
ldr x17, [x16, :lo12:Lcount192]
add x17, x17, #1
str x17, [x16, :lo12:Lcount192]
ldr x3, [x3, #40]
adrp x16, Lcount217
ldr x17, [x16, :lo12:Lcount217]
add x17, x17, #1
str x17, [x16, :lo12:Lcount217]
stp x2, x3, [x0, #32]
Lfn7if1102done:
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7match980end
Lfn7match980end:
Lfn7if974done:
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x1, #0
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7end
Lfn7fail999_4:
adrp x16, Lcount223
ldr x17, [x16, :lo12:Lcount223]
add x17, x17, #1
str x17, [x16, :lo12:Lcount223]
adrp x0, Lfn7fail999_4location
adrp x16, Lcount197
ldr x17, [x16, :lo12:Lcount197]
add x17, x17, #1
str x17, [x16, :lo12:Lcount197]
add x0, x0, :lo12:Lfn7fail999_4location
adrp x16, Lcount224
ldr x17, [x16, :lo12:Lcount224]
add x17, x17, #1
str x17, [x16, :lo12:Lcount224]
bl fen_set_location
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x1, #4
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7end
Lfn7fail997_1:
adrp x16, Lcount223
ldr x17, [x16, :lo12:Lcount223]
add x17, x17, #1
str x17, [x16, :lo12:Lcount223]
adrp x0, Lfn7fail997_1location
adrp x16, Lcount197
ldr x17, [x16, :lo12:Lcount197]
add x17, x17, #1
str x17, [x16, :lo12:Lcount197]
add x0, x0, :lo12:Lfn7fail997_1location
adrp x16, Lcount224
ldr x17, [x16, :lo12:Lcount224]
add x17, x17, #1
str x17, [x16, :lo12:Lcount224]
bl fen_set_location
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x1, #1
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7end
Lfn7fail1007_1:
adrp x16, Lcount223
ldr x17, [x16, :lo12:Lcount223]
add x17, x17, #1
str x17, [x16, :lo12:Lcount223]
adrp x0, Lfn7fail1007_1location
adrp x16, Lcount197
ldr x17, [x16, :lo12:Lcount197]
add x17, x17, #1
str x17, [x16, :lo12:Lcount197]
add x0, x0, :lo12:Lfn7fail1007_1location
adrp x16, Lcount224
ldr x17, [x16, :lo12:Lcount224]
add x17, x17, #1
str x17, [x16, :lo12:Lcount224]
bl fen_set_location
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x1, #1
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7end
Lfn7fail1006_3:
adrp x16, Lcount223
ldr x17, [x16, :lo12:Lcount223]
add x17, x17, #1
str x17, [x16, :lo12:Lcount223]
adrp x0, Lfn7fail1006_3location
adrp x16, Lcount197
ldr x17, [x16, :lo12:Lcount197]
add x17, x17, #1
str x17, [x16, :lo12:Lcount197]
add x0, x0, :lo12:Lfn7fail1006_3location
adrp x16, Lcount224
ldr x17, [x16, :lo12:Lcount224]
add x17, x17, #1
str x17, [x16, :lo12:Lcount224]
bl fen_set_location
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x1, #3
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7end
Lfn7fail1013_1:
adrp x16, Lcount223
ldr x17, [x16, :lo12:Lcount223]
add x17, x17, #1
str x17, [x16, :lo12:Lcount223]
adrp x0, Lfn7fail1013_1location
adrp x16, Lcount197
ldr x17, [x16, :lo12:Lcount197]
add x17, x17, #1
str x17, [x16, :lo12:Lcount197]
add x0, x0, :lo12:Lfn7fail1013_1location
adrp x16, Lcount224
ldr x17, [x16, :lo12:Lcount224]
add x17, x17, #1
str x17, [x16, :lo12:Lcount224]
bl fen_set_location
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x1, #1
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7end
Lfn7fail1012_3:
adrp x16, Lcount223
ldr x17, [x16, :lo12:Lcount223]
add x17, x17, #1
str x17, [x16, :lo12:Lcount223]
adrp x0, Lfn7fail1012_3location
adrp x16, Lcount197
ldr x17, [x16, :lo12:Lcount197]
add x17, x17, #1
str x17, [x16, :lo12:Lcount197]
add x0, x0, :lo12:Lfn7fail1012_3location
adrp x16, Lcount224
ldr x17, [x16, :lo12:Lcount224]
add x17, x17, #1
str x17, [x16, :lo12:Lcount224]
bl fen_set_location
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x1, #3
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7end
Lfn7fail1019_1:
adrp x16, Lcount223
ldr x17, [x16, :lo12:Lcount223]
add x17, x17, #1
str x17, [x16, :lo12:Lcount223]
adrp x0, Lfn7fail1019_1location
adrp x16, Lcount197
ldr x17, [x16, :lo12:Lcount197]
add x17, x17, #1
str x17, [x16, :lo12:Lcount197]
add x0, x0, :lo12:Lfn7fail1019_1location
adrp x16, Lcount224
ldr x17, [x16, :lo12:Lcount224]
add x17, x17, #1
str x17, [x16, :lo12:Lcount224]
bl fen_set_location
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x1, #1
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7end
Lfn7fail1027_4:
adrp x16, Lcount223
ldr x17, [x16, :lo12:Lcount223]
add x17, x17, #1
str x17, [x16, :lo12:Lcount223]
adrp x0, Lfn7fail1027_4location
adrp x16, Lcount197
ldr x17, [x16, :lo12:Lcount197]
add x17, x17, #1
str x17, [x16, :lo12:Lcount197]
add x0, x0, :lo12:Lfn7fail1027_4location
adrp x16, Lcount224
ldr x17, [x16, :lo12:Lcount224]
add x17, x17, #1
str x17, [x16, :lo12:Lcount224]
bl fen_set_location
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x1, #4
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7end
Lfn7fail1034_3:
adrp x16, Lcount223
ldr x17, [x16, :lo12:Lcount223]
add x17, x17, #1
str x17, [x16, :lo12:Lcount223]
adrp x0, Lfn7fail1034_3location
adrp x16, Lcount197
ldr x17, [x16, :lo12:Lcount197]
add x17, x17, #1
str x17, [x16, :lo12:Lcount197]
add x0, x0, :lo12:Lfn7fail1034_3location
adrp x16, Lcount224
ldr x17, [x16, :lo12:Lcount224]
add x17, x17, #1
str x17, [x16, :lo12:Lcount224]
bl fen_set_location
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x1, #3
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7end
Lfn7fail1043_1:
adrp x16, Lcount223
ldr x17, [x16, :lo12:Lcount223]
add x17, x17, #1
str x17, [x16, :lo12:Lcount223]
adrp x0, Lfn7fail1043_1location
adrp x16, Lcount197
ldr x17, [x16, :lo12:Lcount197]
add x17, x17, #1
str x17, [x16, :lo12:Lcount197]
add x0, x0, :lo12:Lfn7fail1043_1location
adrp x16, Lcount224
ldr x17, [x16, :lo12:Lcount224]
add x17, x17, #1
str x17, [x16, :lo12:Lcount224]
bl fen_set_location
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x1, #1
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7end
Lfn7fail1042_3:
adrp x16, Lcount223
ldr x17, [x16, :lo12:Lcount223]
add x17, x17, #1
str x17, [x16, :lo12:Lcount223]
adrp x0, Lfn7fail1042_3location
adrp x16, Lcount197
ldr x17, [x16, :lo12:Lcount197]
add x17, x17, #1
str x17, [x16, :lo12:Lcount197]
add x0, x0, :lo12:Lfn7fail1042_3location
adrp x16, Lcount224
ldr x17, [x16, :lo12:Lcount224]
add x17, x17, #1
str x17, [x16, :lo12:Lcount224]
bl fen_set_location
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x1, #3
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7end
Lfn7fail1053_1:
adrp x16, Lcount223
ldr x17, [x16, :lo12:Lcount223]
add x17, x17, #1
str x17, [x16, :lo12:Lcount223]
adrp x0, Lfn7fail1053_1location
adrp x16, Lcount197
ldr x17, [x16, :lo12:Lcount197]
add x17, x17, #1
str x17, [x16, :lo12:Lcount197]
add x0, x0, :lo12:Lfn7fail1053_1location
adrp x16, Lcount224
ldr x17, [x16, :lo12:Lcount224]
add x17, x17, #1
str x17, [x16, :lo12:Lcount224]
bl fen_set_location
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x1, #1
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7end
Lfn7fail1057_1:
adrp x16, Lcount223
ldr x17, [x16, :lo12:Lcount223]
add x17, x17, #1
str x17, [x16, :lo12:Lcount223]
adrp x0, Lfn7fail1057_1location
adrp x16, Lcount197
ldr x17, [x16, :lo12:Lcount197]
add x17, x17, #1
str x17, [x16, :lo12:Lcount197]
add x0, x0, :lo12:Lfn7fail1057_1location
adrp x16, Lcount224
ldr x17, [x16, :lo12:Lcount224]
add x17, x17, #1
str x17, [x16, :lo12:Lcount224]
bl fen_set_location
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x1, #1
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7end
Lfn7fail1060_1:
adrp x16, Lcount223
ldr x17, [x16, :lo12:Lcount223]
add x17, x17, #1
str x17, [x16, :lo12:Lcount223]
adrp x0, Lfn7fail1060_1location
adrp x16, Lcount197
ldr x17, [x16, :lo12:Lcount197]
add x17, x17, #1
str x17, [x16, :lo12:Lcount197]
add x0, x0, :lo12:Lfn7fail1060_1location
adrp x16, Lcount224
ldr x17, [x16, :lo12:Lcount224]
add x17, x17, #1
str x17, [x16, :lo12:Lcount224]
bl fen_set_location
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x1, #1
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7end
Lfn7fail1052_3:
adrp x16, Lcount223
ldr x17, [x16, :lo12:Lcount223]
add x17, x17, #1
str x17, [x16, :lo12:Lcount223]
adrp x0, Lfn7fail1052_3location
adrp x16, Lcount197
ldr x17, [x16, :lo12:Lcount197]
add x17, x17, #1
str x17, [x16, :lo12:Lcount197]
add x0, x0, :lo12:Lfn7fail1052_3location
adrp x16, Lcount224
ldr x17, [x16, :lo12:Lcount224]
add x17, x17, #1
str x17, [x16, :lo12:Lcount224]
bl fen_set_location
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x1, #3
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7end
Lfn7fail1066_1:
adrp x16, Lcount223
ldr x17, [x16, :lo12:Lcount223]
add x17, x17, #1
str x17, [x16, :lo12:Lcount223]
adrp x0, Lfn7fail1066_1location
adrp x16, Lcount197
ldr x17, [x16, :lo12:Lcount197]
add x17, x17, #1
str x17, [x16, :lo12:Lcount197]
add x0, x0, :lo12:Lfn7fail1066_1location
adrp x16, Lcount224
ldr x17, [x16, :lo12:Lcount224]
add x17, x17, #1
str x17, [x16, :lo12:Lcount224]
bl fen_set_location
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x1, #1
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7end
Lfn7fail1077_1:
adrp x16, Lcount223
ldr x17, [x16, :lo12:Lcount223]
add x17, x17, #1
str x17, [x16, :lo12:Lcount223]
adrp x0, Lfn7fail1077_1location
adrp x16, Lcount197
ldr x17, [x16, :lo12:Lcount197]
add x17, x17, #1
str x17, [x16, :lo12:Lcount197]
add x0, x0, :lo12:Lfn7fail1077_1location
adrp x16, Lcount224
ldr x17, [x16, :lo12:Lcount224]
add x17, x17, #1
str x17, [x16, :lo12:Lcount224]
bl fen_set_location
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x1, #1
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7end
Lfn7fail1091_1:
adrp x16, Lcount223
ldr x17, [x16, :lo12:Lcount223]
add x17, x17, #1
str x17, [x16, :lo12:Lcount223]
adrp x0, Lfn7fail1091_1location
adrp x16, Lcount197
ldr x17, [x16, :lo12:Lcount197]
add x17, x17, #1
str x17, [x16, :lo12:Lcount197]
add x0, x0, :lo12:Lfn7fail1091_1location
adrp x16, Lcount224
ldr x17, [x16, :lo12:Lcount224]
add x17, x17, #1
str x17, [x16, :lo12:Lcount224]
bl fen_set_location
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x1, #1
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7end
Lfn7fail1109_1:
adrp x16, Lcount223
ldr x17, [x16, :lo12:Lcount223]
add x17, x17, #1
str x17, [x16, :lo12:Lcount223]
adrp x0, Lfn7fail1109_1location
adrp x16, Lcount197
ldr x17, [x16, :lo12:Lcount197]
add x17, x17, #1
str x17, [x16, :lo12:Lcount197]
add x0, x0, :lo12:Lfn7fail1109_1location
adrp x16, Lcount224
ldr x17, [x16, :lo12:Lcount224]
add x17, x17, #1
str x17, [x16, :lo12:Lcount224]
bl fen_set_location
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x1, #1
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7end
Lfn7fail1108_3:
adrp x16, Lcount223
ldr x17, [x16, :lo12:Lcount223]
add x17, x17, #1
str x17, [x16, :lo12:Lcount223]
adrp x0, Lfn7fail1108_3location
adrp x16, Lcount197
ldr x17, [x16, :lo12:Lcount197]
add x17, x17, #1
str x17, [x16, :lo12:Lcount197]
add x0, x0, :lo12:Lfn7fail1108_3location
adrp x16, Lcount224
ldr x17, [x16, :lo12:Lcount224]
add x17, x17, #1
str x17, [x16, :lo12:Lcount224]
bl fen_set_location
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x1, #3
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7end
Lfn7fail1121_1:
adrp x16, Lcount223
ldr x17, [x16, :lo12:Lcount223]
add x17, x17, #1
str x17, [x16, :lo12:Lcount223]
adrp x0, Lfn7fail1121_1location
adrp x16, Lcount197
ldr x17, [x16, :lo12:Lcount197]
add x17, x17, #1
str x17, [x16, :lo12:Lcount197]
add x0, x0, :lo12:Lfn7fail1121_1location
adrp x16, Lcount224
ldr x17, [x16, :lo12:Lcount224]
add x17, x17, #1
str x17, [x16, :lo12:Lcount224]
bl fen_set_location
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x1, #1
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7end
Lfn7fail1126_1:
adrp x16, Lcount223
ldr x17, [x16, :lo12:Lcount223]
add x17, x17, #1
str x17, [x16, :lo12:Lcount223]
adrp x0, Lfn7fail1126_1location
adrp x16, Lcount197
ldr x17, [x16, :lo12:Lcount197]
add x17, x17, #1
str x17, [x16, :lo12:Lcount197]
add x0, x0, :lo12:Lfn7fail1126_1location
adrp x16, Lcount224
ldr x17, [x16, :lo12:Lcount224]
add x17, x17, #1
str x17, [x16, :lo12:Lcount224]
bl fen_set_location
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x1, #1
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7end
Lfn7fail1120_3:
adrp x16, Lcount223
ldr x17, [x16, :lo12:Lcount223]
add x17, x17, #1
str x17, [x16, :lo12:Lcount223]
adrp x0, Lfn7fail1120_3location
adrp x16, Lcount197
ldr x17, [x16, :lo12:Lcount197]
add x17, x17, #1
str x17, [x16, :lo12:Lcount197]
add x0, x0, :lo12:Lfn7fail1120_3location
adrp x16, Lcount224
ldr x17, [x16, :lo12:Lcount224]
add x17, x17, #1
str x17, [x16, :lo12:Lcount224]
bl fen_set_location
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov x1, #3
adrp x16, Lcount202
ldr x17, [x16, :lo12:Lcount202]
add x17, x17, #1
str x17, [x16, :lo12:Lcount202]
b Lfn7end
Lfn7end:
adrp x16, Lcount205
ldr x17, [x16, :lo12:Lcount205]
add x17, x17, #1
str x17, [x16, :lo12:Lcount205]
bl fen_leave_result
adrp x16, Lcount191
ldr x17, [x16, :lo12:Lcount191]
add x17, x17, #1
str x17, [x16, :lo12:Lcount191]
ldp x19, x20, [x29, #-16]
adrp x16, Lcount191
ldr x17, [x16, :lo12:Lcount191]
add x17, x17, #1
str x17, [x16, :lo12:Lcount191]
ldp x21, x22, [x29, #-32]
adrp x16, Lcount191
ldr x17, [x16, :lo12:Lcount191]
add x17, x17, #1
str x17, [x16, :lo12:Lcount191]
ldp x23, xzr, [x29, #-48]
adrp x16, Lcount194
ldr x17, [x16, :lo12:Lcount194]
add x17, x17, #1
str x17, [x16, :lo12:Lcount194]
mov sp, x29
adrp x16, Lcount206
ldr x17, [x16, :lo12:Lcount206]
add x17, x17, #1
str x17, [x16, :lo12:Lcount206]
ldp x29, x30, [sp], #16
adrp x16, Lcount225
ldr x17, [x16, :lo12:Lcount225]
add x17, x17, #1
str x17, [x16, :lo12:Lcount225]
ret
.globl stream_feed
stream_feed:
Lfn8:
adrp x16, Lcount226
ldr x17, [x16, :lo12:Lcount226]
add x17, x17, #1
str x17, [x16, :lo12:Lcount226]
ldp x8, x9, [x0, #0]
Lfn8fields:
adrp x16, Lcount227
ldr x17, [x16, :lo12:Lcount227]
add x17, x17, #1
str x17, [x16, :lo12:Lcount227]
stp x29, x30, [sp, #-16]!
adrp x16, Lcount228
ldr x17, [x16, :lo12:Lcount228]
add x17, x17, #1
str x17, [x16, :lo12:Lcount228]
mov x29, sp
adrp x16, Lcount229
ldr x17, [x16, :lo12:Lcount229]
add x17, x17, #1
str x17, [x16, :lo12:Lcount229]
sub sp, sp, #80
adrp x16, Lcount227
ldr x17, [x16, :lo12:Lcount227]
add x17, x17, #1
str x17, [x16, :lo12:Lcount227]
stp x8, x9, [sp, #48]
Lfn8loop:
adrp x16, Lcount230
ldr x17, [x16, :lo12:Lcount230]
add x17, x17, #1
str x17, [x16, :lo12:Lcount230]
movz x0, #0, lsl #0
adrp x16, Lcount231
ldr x17, [x16, :lo12:Lcount231]
add x17, x17, #1
str x17, [x16, :lo12:Lcount231]
str x0, [sp, #64]
adrp x16, Lcount232
ldr x17, [x16, :lo12:Lcount232]
add x17, x17, #1
str x17, [x16, :lo12:Lcount232]
ldr x8, [sp, #48]
adrp x16, Lcount232
ldr x17, [x16, :lo12:Lcount232]
add x17, x17, #1
str x17, [x16, :lo12:Lcount232]
ldr x9, [sp, #56]
adrp x16, Lcount232
ldr x17, [x16, :lo12:Lcount232]
add x17, x17, #1
str x17, [x16, :lo12:Lcount232]
ldr x10, [sp, #64]
adrp x16, Lcount228
ldr x17, [x16, :lo12:Lcount228]
add x17, x17, #1
str x17, [x16, :lo12:Lcount228]
mov sp, x29
adrp x16, Lcount233
ldr x17, [x16, :lo12:Lcount233]
add x17, x17, #1
str x17, [x16, :lo12:Lcount233]
ldp x29, x30, [sp], #16
adrp x16, Lcount234
ldr x17, [x16, :lo12:Lcount234]
add x17, x17, #1
str x17, [x16, :lo12:Lcount234]
b Lfn7fields
adrp x16, Lcount228
ldr x17, [x16, :lo12:Lcount228]
add x17, x17, #1
str x17, [x16, :lo12:Lcount228]
mov x1, #0
adrp x16, Lcount234
ldr x17, [x16, :lo12:Lcount234]
add x17, x17, #1
str x17, [x16, :lo12:Lcount234]
b Lfn8end
Lfn8end:
adrp x16, Lcount228
ldr x17, [x16, :lo12:Lcount228]
add x17, x17, #1
str x17, [x16, :lo12:Lcount228]
mov sp, x29
adrp x16, Lcount233
ldr x17, [x16, :lo12:Lcount233]
add x17, x17, #1
str x17, [x16, :lo12:Lcount233]
ldp x29, x30, [sp], #16
adrp x16, Lcount235
ldr x17, [x16, :lo12:Lcount235]
add x17, x17, #1
str x17, [x16, :lo12:Lcount235]
ret
.globl stream_finish
stream_finish:
Lfn9:
adrp x16, Lcount236
ldr x17, [x16, :lo12:Lcount236]
add x17, x17, #1
str x17, [x16, :lo12:Lcount236]
stp x29, x30, [sp, #-16]!
adrp x16, Lcount237
ldr x17, [x16, :lo12:Lcount237]
add x17, x17, #1
str x17, [x16, :lo12:Lcount237]
mov x29, sp
adrp x16, Lcount238
ldr x17, [x16, :lo12:Lcount238]
add x17, x17, #1
str x17, [x16, :lo12:Lcount238]
sub sp, sp, #64
adrp x16, Lcount239
ldr x17, [x16, :lo12:Lcount239]
add x17, x17, #1
str x17, [x16, :lo12:Lcount239]
str xzr, [sp, #56]
adrp x16, Lcount239
ldr x17, [x16, :lo12:Lcount239]
add x17, x17, #1
str x17, [x16, :lo12:Lcount239]
str x0, [sp, #48]
adrp x16, Lcount240
ldr x17, [x16, :lo12:Lcount240]
add x17, x17, #1
str x17, [x16, :lo12:Lcount240]
add x0, sp, #16
adrp x16, Lcount240
ldr x17, [x16, :lo12:Lcount240]
add x17, x17, #1
str x17, [x16, :lo12:Lcount240]
add x1, sp, #48
adrp x16, Lcount237
ldr x17, [x16, :lo12:Lcount237]
add x17, x17, #1
str x17, [x16, :lo12:Lcount237]
mov x2, #2
adrp x16, Lcount241
ldr x17, [x16, :lo12:Lcount241]
add x17, x17, #1
str x17, [x16, :lo12:Lcount241]
bl fen_enter
adrp x16, Lcount242
ldr x17, [x16, :lo12:Lcount242]
add x17, x17, #1
str x17, [x16, :lo12:Lcount242]
ldr x0, [sp, #48]
adrp x16, Lcount243
ldr x17, [x16, :lo12:Lcount243]
add x17, x17, #1
str x17, [x16, :lo12:Lcount243]
ldr w0, [x0, #72]
adrp x16, Lcount244
ldr x17, [x16, :lo12:Lcount244]
add x17, x17, #1
str x17, [x16, :lo12:Lcount244]
cmp w0, #13
adrp x16, Lcount245
ldr x17, [x16, :lo12:Lcount245]
add x17, x17, #1
str x17, [x16, :lo12:Lcount245]
b.eq Lfn9match1148arm13
adrp x16, Lcount244
ldr x17, [x16, :lo12:Lcount244]
add x17, x17, #1
str x17, [x16, :lo12:Lcount244]
cmp w0, #14
adrp x16, Lcount245
ldr x17, [x16, :lo12:Lcount245]
add x17, x17, #1
str x17, [x16, :lo12:Lcount245]
b.eq Lfn9match1148arm14
adrp x16, Lcount244
ldr x17, [x16, :lo12:Lcount244]
add x17, x17, #1
str x17, [x16, :lo12:Lcount244]
cmp w0, #15
adrp x16, Lcount245
ldr x17, [x16, :lo12:Lcount245]
add x17, x17, #1
str x17, [x16, :lo12:Lcount245]
b.eq Lfn9match1148arm15
adrp x16, Lcount244
ldr x17, [x16, :lo12:Lcount244]
add x17, x17, #1
str x17, [x16, :lo12:Lcount244]
cmp w0, #16
adrp x16, Lcount245
ldr x17, [x16, :lo12:Lcount245]
add x17, x17, #1
str x17, [x16, :lo12:Lcount245]
b.eq Lfn9match1148arm16
adrp x16, Lcount244
ldr x17, [x16, :lo12:Lcount244]
add x17, x17, #1
str x17, [x16, :lo12:Lcount244]
cmp w0, #17
adrp x16, Lcount245
ldr x17, [x16, :lo12:Lcount245]
add x17, x17, #1
str x17, [x16, :lo12:Lcount245]
b.eq Lfn9match1148arm17
adrp x16, Lcount246
ldr x17, [x16, :lo12:Lcount246]
add x17, x17, #1
str x17, [x16, :lo12:Lcount246]
brk #0
Lfn9match1148arm13:
adrp x16, Lcount242
ldr x17, [x16, :lo12:Lcount242]
add x17, x17, #1
str x17, [x16, :lo12:Lcount242]
ldr x8, [sp, #48]
adrp x16, Lcount243
ldr x17, [x16, :lo12:Lcount243]
add x17, x17, #1
str x17, [x16, :lo12:Lcount243]
ldr x8, [x8, #8]
adrp x16, Lcount247
ldr x17, [x16, :lo12:Lcount247]
add x17, x17, #1
str x17, [x16, :lo12:Lcount247]
adrp x9, Lconstant2
adrp x16, Lcount240
ldr x17, [x16, :lo12:Lcount240]
add x17, x17, #1
str x17, [x16, :lo12:Lcount240]
add x9, x9, :lo12:Lconstant2
adrp x16, Lcount248
ldr x17, [x16, :lo12:Lcount248]
add x17, x17, #1
str x17, [x16, :lo12:Lcount248]
bl Lfn3fields
adrp x16, Lcount249
ldr x17, [x16, :lo12:Lcount249]
add x17, x17, #1
str x17, [x16, :lo12:Lcount249]
cbnz x1, Lfn9end
adrp x16, Lcount239
ldr x17, [x16, :lo12:Lcount239]
add x17, x17, #1
str x17, [x16, :lo12:Lcount239]
str x0, [sp, #56]
adrp x16, Lcount237
ldr x17, [x16, :lo12:Lcount237]
add x17, x17, #1
str x17, [x16, :lo12:Lcount237]
mov x0, #1
adrp x16, Lcount237
ldr x17, [x16, :lo12:Lcount237]
add x17, x17, #1
str x17, [x16, :lo12:Lcount237]
mov x1, #18
adrp x16, Lcount250
ldr x17, [x16, :lo12:Lcount250]
add x17, x17, #1
str x17, [x16, :lo12:Lcount250]
bl fen_allocate
adrp x16, Lcount251
ldr x17, [x16, :lo12:Lcount251]
add x17, x17, #1
str x17, [x16, :lo12:Lcount251]
cbz x0, Lfn9fail1152_3
adrp x16, Lcount242
ldr x17, [x16, :lo12:Lcount242]
add x17, x17, #1
str x17, [x16, :lo12:Lcount242]
ldr x2, [sp, #56]
adrp x16, Lcount252
ldr x17, [x16, :lo12:Lcount252]
add x17, x17, #1
str x17, [x16, :lo12:Lcount252]
str x2, [x0, #0]
adrp x16, Lcount253
ldr x17, [x16, :lo12:Lcount253]
add x17, x17, #1
str x17, [x16, :lo12:Lcount253]
b Lfn9match1148end
Lfn9match1148arm14:
adrp x16, Lcount237
ldr x17, [x16, :lo12:Lcount237]
add x17, x17, #1
str x17, [x16, :lo12:Lcount237]
mov x0, #0
adrp x16, Lcount237
ldr x17, [x16, :lo12:Lcount237]
add x17, x17, #1
str x17, [x16, :lo12:Lcount237]
mov x1, #19
adrp x16, Lcount250
ldr x17, [x16, :lo12:Lcount250]
add x17, x17, #1
str x17, [x16, :lo12:Lcount250]
bl fen_allocate
adrp x16, Lcount251
ldr x17, [x16, :lo12:Lcount251]
add x17, x17, #1
str x17, [x16, :lo12:Lcount251]
cbz x0, Lfn9fail1160_3
adrp x16, Lcount242
ldr x17, [x16, :lo12:Lcount242]
add x17, x17, #1
str x17, [x16, :lo12:Lcount242]
ldr x2, [sp, #48]
adrp x16, Lcount243
ldr x17, [x16, :lo12:Lcount243]
add x17, x17, #1
str x17, [x16, :lo12:Lcount243]
ldr x2, [x2, #0]
adrp x16, Lcount252
ldr x17, [x16, :lo12:Lcount252]
add x17, x17, #1
str x17, [x16, :lo12:Lcount252]
str x2, [x0, #0]
adrp x16, Lcount253
ldr x17, [x16, :lo12:Lcount253]
add x17, x17, #1
str x17, [x16, :lo12:Lcount253]
b Lfn9match1148end
Lfn9match1148arm15:
adrp x16, Lcount237
ldr x17, [x16, :lo12:Lcount237]
add x17, x17, #1
str x17, [x16, :lo12:Lcount237]
mov x0, #0
adrp x16, Lcount237
ldr x17, [x16, :lo12:Lcount237]
add x17, x17, #1
str x17, [x16, :lo12:Lcount237]
mov x1, #19
adrp x16, Lcount250
ldr x17, [x16, :lo12:Lcount250]
add x17, x17, #1
str x17, [x16, :lo12:Lcount250]
bl fen_allocate
adrp x16, Lcount251
ldr x17, [x16, :lo12:Lcount251]
add x17, x17, #1
str x17, [x16, :lo12:Lcount251]
cbz x0, Lfn9fail1165_3
adrp x16, Lcount242
ldr x17, [x16, :lo12:Lcount242]
add x17, x17, #1
str x17, [x16, :lo12:Lcount242]
ldr x2, [sp, #48]
adrp x16, Lcount243
ldr x17, [x16, :lo12:Lcount243]
add x17, x17, #1
str x17, [x16, :lo12:Lcount243]
ldr x2, [x2, #0]
adrp x16, Lcount252
ldr x17, [x16, :lo12:Lcount252]
add x17, x17, #1
str x17, [x16, :lo12:Lcount252]
str x2, [x0, #0]
adrp x16, Lcount253
ldr x17, [x16, :lo12:Lcount253]
add x17, x17, #1
str x17, [x16, :lo12:Lcount253]
b Lfn9match1148end
Lfn9match1148arm16:
adrp x16, Lcount237
ldr x17, [x16, :lo12:Lcount237]
add x17, x17, #1
str x17, [x16, :lo12:Lcount237]
mov x0, #0
adrp x16, Lcount237
ldr x17, [x16, :lo12:Lcount237]
add x17, x17, #1
str x17, [x16, :lo12:Lcount237]
mov x1, #19
adrp x16, Lcount250
ldr x17, [x16, :lo12:Lcount250]
add x17, x17, #1
str x17, [x16, :lo12:Lcount250]
bl fen_allocate
adrp x16, Lcount251
ldr x17, [x16, :lo12:Lcount251]
add x17, x17, #1
str x17, [x16, :lo12:Lcount251]
cbz x0, Lfn9fail1173_3
adrp x16, Lcount242
ldr x17, [x16, :lo12:Lcount242]
add x17, x17, #1
str x17, [x16, :lo12:Lcount242]
ldr x2, [sp, #48]
adrp x16, Lcount243
ldr x17, [x16, :lo12:Lcount243]
add x17, x17, #1
str x17, [x16, :lo12:Lcount243]
ldr x2, [x2, #0]
adrp x16, Lcount252
ldr x17, [x16, :lo12:Lcount252]
add x17, x17, #1
str x17, [x16, :lo12:Lcount252]
str x2, [x0, #0]
adrp x16, Lcount253
ldr x17, [x16, :lo12:Lcount253]
add x17, x17, #1
str x17, [x16, :lo12:Lcount253]
b Lfn9match1148end
Lfn9match1148arm17:
adrp x16, Lcount237
ldr x17, [x16, :lo12:Lcount237]
add x17, x17, #1
str x17, [x16, :lo12:Lcount237]
mov x0, #0
adrp x16, Lcount237
ldr x17, [x16, :lo12:Lcount237]
add x17, x17, #1
str x17, [x16, :lo12:Lcount237]
mov x1, #19
adrp x16, Lcount250
ldr x17, [x16, :lo12:Lcount250]
add x17, x17, #1
str x17, [x16, :lo12:Lcount250]
bl fen_allocate
adrp x16, Lcount251
ldr x17, [x16, :lo12:Lcount251]
add x17, x17, #1
str x17, [x16, :lo12:Lcount251]
cbz x0, Lfn9fail1176_3
adrp x16, Lcount242
ldr x17, [x16, :lo12:Lcount242]
add x17, x17, #1
str x17, [x16, :lo12:Lcount242]
ldr x2, [sp, #48]
adrp x16, Lcount243
ldr x17, [x16, :lo12:Lcount243]
add x17, x17, #1
str x17, [x16, :lo12:Lcount243]
ldr x2, [x2, #0]
adrp x16, Lcount252
ldr x17, [x16, :lo12:Lcount252]
add x17, x17, #1
str x17, [x16, :lo12:Lcount252]
str x2, [x0, #0]
adrp x16, Lcount253
ldr x17, [x16, :lo12:Lcount253]
add x17, x17, #1
str x17, [x16, :lo12:Lcount253]
b Lfn9match1148end
Lfn9match1148end:
adrp x16, Lcount237
ldr x17, [x16, :lo12:Lcount237]
add x17, x17, #1
str x17, [x16, :lo12:Lcount237]
mov x1, #0
adrp x16, Lcount253
ldr x17, [x16, :lo12:Lcount253]
add x17, x17, #1
str x17, [x16, :lo12:Lcount253]
b Lfn9end
Lfn9fail1152_3:
adrp x16, Lcount247
ldr x17, [x16, :lo12:Lcount247]
add x17, x17, #1
str x17, [x16, :lo12:Lcount247]
adrp x0, Lfn9fail1152_3location
adrp x16, Lcount240
ldr x17, [x16, :lo12:Lcount240]
add x17, x17, #1
str x17, [x16, :lo12:Lcount240]
add x0, x0, :lo12:Lfn9fail1152_3location
adrp x16, Lcount254
ldr x17, [x16, :lo12:Lcount254]
add x17, x17, #1
str x17, [x16, :lo12:Lcount254]
bl fen_set_location
adrp x16, Lcount237
ldr x17, [x16, :lo12:Lcount237]
add x17, x17, #1
str x17, [x16, :lo12:Lcount237]
mov x1, #3
adrp x16, Lcount253
ldr x17, [x16, :lo12:Lcount253]
add x17, x17, #1
str x17, [x16, :lo12:Lcount253]
b Lfn9end
Lfn9fail1160_3:
adrp x16, Lcount247
ldr x17, [x16, :lo12:Lcount247]
add x17, x17, #1
str x17, [x16, :lo12:Lcount247]
adrp x0, Lfn9fail1160_3location
adrp x16, Lcount240
ldr x17, [x16, :lo12:Lcount240]
add x17, x17, #1
str x17, [x16, :lo12:Lcount240]
add x0, x0, :lo12:Lfn9fail1160_3location
adrp x16, Lcount254
ldr x17, [x16, :lo12:Lcount254]
add x17, x17, #1
str x17, [x16, :lo12:Lcount254]
bl fen_set_location
adrp x16, Lcount237
ldr x17, [x16, :lo12:Lcount237]
add x17, x17, #1
str x17, [x16, :lo12:Lcount237]
mov x1, #3
adrp x16, Lcount253
ldr x17, [x16, :lo12:Lcount253]
add x17, x17, #1
str x17, [x16, :lo12:Lcount253]
b Lfn9end
Lfn9fail1165_3:
adrp x16, Lcount247
ldr x17, [x16, :lo12:Lcount247]
add x17, x17, #1
str x17, [x16, :lo12:Lcount247]
adrp x0, Lfn9fail1165_3location
adrp x16, Lcount240
ldr x17, [x16, :lo12:Lcount240]
add x17, x17, #1
str x17, [x16, :lo12:Lcount240]
add x0, x0, :lo12:Lfn9fail1165_3location
adrp x16, Lcount254
ldr x17, [x16, :lo12:Lcount254]
add x17, x17, #1
str x17, [x16, :lo12:Lcount254]
bl fen_set_location
adrp x16, Lcount237
ldr x17, [x16, :lo12:Lcount237]
add x17, x17, #1
str x17, [x16, :lo12:Lcount237]
mov x1, #3
adrp x16, Lcount253
ldr x17, [x16, :lo12:Lcount253]
add x17, x17, #1
str x17, [x16, :lo12:Lcount253]
b Lfn9end
Lfn9fail1173_3:
adrp x16, Lcount247
ldr x17, [x16, :lo12:Lcount247]
add x17, x17, #1
str x17, [x16, :lo12:Lcount247]
adrp x0, Lfn9fail1173_3location
adrp x16, Lcount240
ldr x17, [x16, :lo12:Lcount240]
add x17, x17, #1
str x17, [x16, :lo12:Lcount240]
add x0, x0, :lo12:Lfn9fail1173_3location
adrp x16, Lcount254
ldr x17, [x16, :lo12:Lcount254]
add x17, x17, #1
str x17, [x16, :lo12:Lcount254]
bl fen_set_location
adrp x16, Lcount237
ldr x17, [x16, :lo12:Lcount237]
add x17, x17, #1
str x17, [x16, :lo12:Lcount237]
mov x1, #3
adrp x16, Lcount253
ldr x17, [x16, :lo12:Lcount253]
add x17, x17, #1
str x17, [x16, :lo12:Lcount253]
b Lfn9end
Lfn9fail1176_3:
adrp x16, Lcount247
ldr x17, [x16, :lo12:Lcount247]
add x17, x17, #1
str x17, [x16, :lo12:Lcount247]
adrp x0, Lfn9fail1176_3location
adrp x16, Lcount240
ldr x17, [x16, :lo12:Lcount240]
add x17, x17, #1
str x17, [x16, :lo12:Lcount240]
add x0, x0, :lo12:Lfn9fail1176_3location
adrp x16, Lcount254
ldr x17, [x16, :lo12:Lcount254]
add x17, x17, #1
str x17, [x16, :lo12:Lcount254]
bl fen_set_location
adrp x16, Lcount237
ldr x17, [x16, :lo12:Lcount237]
add x17, x17, #1
str x17, [x16, :lo12:Lcount237]
mov x1, #3
adrp x16, Lcount253
ldr x17, [x16, :lo12:Lcount253]
add x17, x17, #1
str x17, [x16, :lo12:Lcount253]
b Lfn9end
Lfn9end:
adrp x16, Lcount255
ldr x17, [x16, :lo12:Lcount255]
add x17, x17, #1
str x17, [x16, :lo12:Lcount255]
bl fen_leave_result
adrp x16, Lcount237
ldr x17, [x16, :lo12:Lcount237]
add x17, x17, #1
str x17, [x16, :lo12:Lcount237]
mov sp, x29
adrp x16, Lcount256
ldr x17, [x16, :lo12:Lcount256]
add x17, x17, #1
str x17, [x16, :lo12:Lcount256]
ldp x29, x30, [sp], #16
adrp x16, Lcount257
ldr x17, [x16, :lo12:Lcount257]
add x17, x17, #1
str x17, [x16, :lo12:Lcount257]
ret
Lfn10:
adrp x16, Lcount258
ldr x17, [x16, :lo12:Lcount258]
add x17, x17, #1
str x17, [x16, :lo12:Lcount258]
stp x29, x30, [sp, #-16]!
adrp x16, Lcount259
ldr x17, [x16, :lo12:Lcount259]
add x17, x17, #1
str x17, [x16, :lo12:Lcount259]
mov x29, sp
adrp x16, Lcount260
ldr x17, [x16, :lo12:Lcount260]
add x17, x17, #1
str x17, [x16, :lo12:Lcount260]
sub sp, sp, #64
adrp x16, Lcount261
ldr x17, [x16, :lo12:Lcount261]
add x17, x17, #1
str x17, [x16, :lo12:Lcount261]
str x0, [sp, #48]
adrp x16, Lcount262
ldr x17, [x16, :lo12:Lcount262]
add x17, x17, #1
str x17, [x16, :lo12:Lcount262]
ldr x0, [sp, #48]
adrp x16, Lcount263
ldr x17, [x16, :lo12:Lcount263]
add x17, x17, #1
str x17, [x16, :lo12:Lcount263]
cmp x0, #5
adrp x16, Lcount264
ldr x17, [x16, :lo12:Lcount264]
add x17, x17, #1
str x17, [x16, :lo12:Lcount264]
b.ge Lfn10if1180else
adrp x16, Lcount262
ldr x17, [x16, :lo12:Lcount262]
add x17, x17, #1
str x17, [x16, :lo12:Lcount262]
ldr x0, [sp, #48]
adrp x16, Lcount263
ldr x17, [x16, :lo12:Lcount263]
add x17, x17, #1
str x17, [x16, :lo12:Lcount263]
cmp x0, #2
adrp x16, Lcount264
ldr x17, [x16, :lo12:Lcount264]
add x17, x17, #1
str x17, [x16, :lo12:Lcount264]
b.ge Lfn10if1184else
adrp x16, Lcount262
ldr x17, [x16, :lo12:Lcount262]
add x17, x17, #1
str x17, [x16, :lo12:Lcount262]
ldr x0, [sp, #48]
adrp x16, Lcount263
ldr x17, [x16, :lo12:Lcount263]
add x17, x17, #1
str x17, [x16, :lo12:Lcount263]
cmp x0, #0
adrp x16, Lcount265
ldr x17, [x16, :lo12:Lcount265]
add x17, x17, #1
str x17, [x16, :lo12:Lcount265]
b.ne Lfn10if1188else
adrp x16, Lcount266
ldr x17, [x16, :lo12:Lcount266]
add x17, x17, #1
str x17, [x16, :lo12:Lcount266]
adrp x0, Lconstant3
adrp x16, Lcount267
ldr x17, [x16, :lo12:Lcount267]
add x17, x17, #1
str x17, [x16, :lo12:Lcount267]
add x0, x0, :lo12:Lconstant3
adrp x16, Lcount268
ldr x17, [x16, :lo12:Lcount268]
add x17, x17, #1
str x17, [x16, :lo12:Lcount268]
b Lfn10if1188done
Lfn10if1188else:
adrp x16, Lcount266
ldr x17, [x16, :lo12:Lcount266]
add x17, x17, #1
str x17, [x16, :lo12:Lcount266]
adrp x0, Lconstant4
adrp x16, Lcount267
ldr x17, [x16, :lo12:Lcount267]
add x17, x17, #1
str x17, [x16, :lo12:Lcount267]
add x0, x0, :lo12:Lconstant4
Lfn10if1188done:
adrp x16, Lcount268
ldr x17, [x16, :lo12:Lcount268]
add x17, x17, #1
str x17, [x16, :lo12:Lcount268]
b Lfn10if1184done
Lfn10if1184else:
adrp x16, Lcount262
ldr x17, [x16, :lo12:Lcount262]
add x17, x17, #1
str x17, [x16, :lo12:Lcount262]
ldr x0, [sp, #48]
adrp x16, Lcount263
ldr x17, [x16, :lo12:Lcount263]
add x17, x17, #1
str x17, [x16, :lo12:Lcount263]
cmp x0, #2
adrp x16, Lcount265
ldr x17, [x16, :lo12:Lcount265]
add x17, x17, #1
str x17, [x16, :lo12:Lcount265]
b.ne Lfn10if1194else
adrp x16, Lcount266
ldr x17, [x16, :lo12:Lcount266]
add x17, x17, #1
str x17, [x16, :lo12:Lcount266]
adrp x0, Lconstant5
adrp x16, Lcount267
ldr x17, [x16, :lo12:Lcount267]
add x17, x17, #1
str x17, [x16, :lo12:Lcount267]
add x0, x0, :lo12:Lconstant5
adrp x16, Lcount268
ldr x17, [x16, :lo12:Lcount268]
add x17, x17, #1
str x17, [x16, :lo12:Lcount268]
b Lfn10if1194done
Lfn10if1194else:
adrp x16, Lcount262
ldr x17, [x16, :lo12:Lcount262]
add x17, x17, #1
str x17, [x16, :lo12:Lcount262]
ldr x0, [sp, #48]
adrp x16, Lcount263
ldr x17, [x16, :lo12:Lcount263]
add x17, x17, #1
str x17, [x16, :lo12:Lcount263]
cmp x0, #3
adrp x16, Lcount265
ldr x17, [x16, :lo12:Lcount265]
add x17, x17, #1
str x17, [x16, :lo12:Lcount265]
b.ne Lfn10if1199else
adrp x16, Lcount266
ldr x17, [x16, :lo12:Lcount266]
add x17, x17, #1
str x17, [x16, :lo12:Lcount266]
adrp x0, Lconstant6
adrp x16, Lcount267
ldr x17, [x16, :lo12:Lcount267]
add x17, x17, #1
str x17, [x16, :lo12:Lcount267]
add x0, x0, :lo12:Lconstant6
adrp x16, Lcount268
ldr x17, [x16, :lo12:Lcount268]
add x17, x17, #1
str x17, [x16, :lo12:Lcount268]
b Lfn10if1199done
Lfn10if1199else:
adrp x16, Lcount266
ldr x17, [x16, :lo12:Lcount266]
add x17, x17, #1
str x17, [x16, :lo12:Lcount266]
adrp x0, Lconstant7
adrp x16, Lcount267
ldr x17, [x16, :lo12:Lcount267]
add x17, x17, #1
str x17, [x16, :lo12:Lcount267]
add x0, x0, :lo12:Lconstant7
Lfn10if1199done:
Lfn10if1194done:
Lfn10if1184done:
adrp x16, Lcount268
ldr x17, [x16, :lo12:Lcount268]
add x17, x17, #1
str x17, [x16, :lo12:Lcount268]
b Lfn10if1180done
Lfn10if1180else:
adrp x16, Lcount262
ldr x17, [x16, :lo12:Lcount262]
add x17, x17, #1
str x17, [x16, :lo12:Lcount262]
ldr x0, [sp, #48]
adrp x16, Lcount263
ldr x17, [x16, :lo12:Lcount263]
add x17, x17, #1
str x17, [x16, :lo12:Lcount263]
cmp x0, #7
adrp x16, Lcount264
ldr x17, [x16, :lo12:Lcount264]
add x17, x17, #1
str x17, [x16, :lo12:Lcount264]
b.ge Lfn10if1205else
adrp x16, Lcount262
ldr x17, [x16, :lo12:Lcount262]
add x17, x17, #1
str x17, [x16, :lo12:Lcount262]
ldr x0, [sp, #48]
adrp x16, Lcount263
ldr x17, [x16, :lo12:Lcount263]
add x17, x17, #1
str x17, [x16, :lo12:Lcount263]
cmp x0, #5
adrp x16, Lcount265
ldr x17, [x16, :lo12:Lcount265]
add x17, x17, #1
str x17, [x16, :lo12:Lcount265]
b.ne Lfn10if1209else
adrp x16, Lcount266
ldr x17, [x16, :lo12:Lcount266]
add x17, x17, #1
str x17, [x16, :lo12:Lcount266]
adrp x0, Lconstant8
adrp x16, Lcount267
ldr x17, [x16, :lo12:Lcount267]
add x17, x17, #1
str x17, [x16, :lo12:Lcount267]
add x0, x0, :lo12:Lconstant8
adrp x16, Lcount268
ldr x17, [x16, :lo12:Lcount268]
add x17, x17, #1
str x17, [x16, :lo12:Lcount268]
b Lfn10if1209done
Lfn10if1209else:
adrp x16, Lcount266
ldr x17, [x16, :lo12:Lcount266]
add x17, x17, #1
str x17, [x16, :lo12:Lcount266]
adrp x0, Lconstant9
adrp x16, Lcount267
ldr x17, [x16, :lo12:Lcount267]
add x17, x17, #1
str x17, [x16, :lo12:Lcount267]
add x0, x0, :lo12:Lconstant9
Lfn10if1209done:
adrp x16, Lcount268
ldr x17, [x16, :lo12:Lcount268]
add x17, x17, #1
str x17, [x16, :lo12:Lcount268]
b Lfn10if1205done
Lfn10if1205else:
adrp x16, Lcount262
ldr x17, [x16, :lo12:Lcount262]
add x17, x17, #1
str x17, [x16, :lo12:Lcount262]
ldr x0, [sp, #48]
adrp x16, Lcount263
ldr x17, [x16, :lo12:Lcount263]
add x17, x17, #1
str x17, [x16, :lo12:Lcount263]
cmp x0, #7
adrp x16, Lcount265
ldr x17, [x16, :lo12:Lcount265]
add x17, x17, #1
str x17, [x16, :lo12:Lcount265]
b.ne Lfn10if1215else
adrp x16, Lcount266
ldr x17, [x16, :lo12:Lcount266]
add x17, x17, #1
str x17, [x16, :lo12:Lcount266]
adrp x0, Lconstant10
adrp x16, Lcount267
ldr x17, [x16, :lo12:Lcount267]
add x17, x17, #1
str x17, [x16, :lo12:Lcount267]
add x0, x0, :lo12:Lconstant10
adrp x16, Lcount268
ldr x17, [x16, :lo12:Lcount268]
add x17, x17, #1
str x17, [x16, :lo12:Lcount268]
b Lfn10if1215done
Lfn10if1215else:
adrp x16, Lcount262
ldr x17, [x16, :lo12:Lcount262]
add x17, x17, #1
str x17, [x16, :lo12:Lcount262]
ldr x0, [sp, #48]
adrp x16, Lcount263
ldr x17, [x16, :lo12:Lcount263]
add x17, x17, #1
str x17, [x16, :lo12:Lcount263]
cmp x0, #8
adrp x16, Lcount265
ldr x17, [x16, :lo12:Lcount265]
add x17, x17, #1
str x17, [x16, :lo12:Lcount265]
b.ne Lfn10if1220else
adrp x16, Lcount266
ldr x17, [x16, :lo12:Lcount266]
add x17, x17, #1
str x17, [x16, :lo12:Lcount266]
adrp x0, Lconstant11
adrp x16, Lcount267
ldr x17, [x16, :lo12:Lcount267]
add x17, x17, #1
str x17, [x16, :lo12:Lcount267]
add x0, x0, :lo12:Lconstant11
adrp x16, Lcount268
ldr x17, [x16, :lo12:Lcount268]
add x17, x17, #1
str x17, [x16, :lo12:Lcount268]
b Lfn10if1220done
Lfn10if1220else:
adrp x16, Lcount266
ldr x17, [x16, :lo12:Lcount266]
add x17, x17, #1
str x17, [x16, :lo12:Lcount266]
adrp x0, Lconstant12
adrp x16, Lcount267
ldr x17, [x16, :lo12:Lcount267]
add x17, x17, #1
str x17, [x16, :lo12:Lcount267]
add x0, x0, :lo12:Lconstant12
Lfn10if1220done:
Lfn10if1215done:
Lfn10if1205done:
Lfn10if1180done:
adrp x16, Lcount259
ldr x17, [x16, :lo12:Lcount259]
add x17, x17, #1
str x17, [x16, :lo12:Lcount259]
mov x1, #0
adrp x16, Lcount268
ldr x17, [x16, :lo12:Lcount268]
add x17, x17, #1
str x17, [x16, :lo12:Lcount268]
b Lfn10end
Lfn10end:
adrp x16, Lcount259
ldr x17, [x16, :lo12:Lcount259]
add x17, x17, #1
str x17, [x16, :lo12:Lcount259]
mov sp, x29
adrp x16, Lcount269
ldr x17, [x16, :lo12:Lcount269]
add x17, x17, #1
str x17, [x16, :lo12:Lcount269]
ldp x29, x30, [sp], #16
adrp x16, Lcount270
ldr x17, [x16, :lo12:Lcount270]
add x17, x17, #1
str x17, [x16, :lo12:Lcount270]
ret
Lfn11:
adrp x16, Lcount271
ldr x17, [x16, :lo12:Lcount271]
add x17, x17, #1
str x17, [x16, :lo12:Lcount271]
stp x29, x30, [sp, #-16]!
adrp x16, Lcount272
ldr x17, [x16, :lo12:Lcount272]
add x17, x17, #1
str x17, [x16, :lo12:Lcount272]
mov x29, sp
adrp x16, Lcount273
ldr x17, [x16, :lo12:Lcount273]
add x17, x17, #1
str x17, [x16, :lo12:Lcount273]
sub sp, sp, #112
adrp x16, Lcount271
ldr x17, [x16, :lo12:Lcount271]
add x17, x17, #1
str x17, [x16, :lo12:Lcount271]
stp xzr, xzr, [sp, #48]
adrp x16, Lcount274
ldr x17, [x16, :lo12:Lcount274]
add x17, x17, #1
str x17, [x16, :lo12:Lcount274]
str x0, [sp, #64]
adrp x16, Lcount275
ldr x17, [x16, :lo12:Lcount275]
add x17, x17, #1
str x17, [x16, :lo12:Lcount275]
add x0, sp, #16
adrp x16, Lcount275
ldr x17, [x16, :lo12:Lcount275]
add x17, x17, #1
str x17, [x16, :lo12:Lcount275]
add x1, sp, #48
adrp x16, Lcount272
ldr x17, [x16, :lo12:Lcount272]
add x17, x17, #1
str x17, [x16, :lo12:Lcount272]
mov x2, #2
adrp x16, Lcount276
ldr x17, [x16, :lo12:Lcount276]
add x17, x17, #1
str x17, [x16, :lo12:Lcount276]
bl fen_enter
adrp x16, Lcount277
ldr x17, [x16, :lo12:Lcount277]
add x17, x17, #1
str x17, [x16, :lo12:Lcount277]
ldr x0, [sp, #64]
adrp x16, Lcount278
ldr x17, [x16, :lo12:Lcount278]
add x17, x17, #1
str x17, [x16, :lo12:Lcount278]
cmp x0, #10
adrp x16, Lcount279
ldr x17, [x16, :lo12:Lcount279]
add x17, x17, #1
str x17, [x16, :lo12:Lcount279]
b.ge Lfn11if1228else
adrp x16, Lcount277
ldr x17, [x16, :lo12:Lcount277]
add x17, x17, #1
str x17, [x16, :lo12:Lcount277]
ldr x0, [sp, #64]
adrp x16, Lcount280
ldr x17, [x16, :lo12:Lcount280]
add x17, x17, #1
str x17, [x16, :lo12:Lcount280]
bl fen_leave_result
adrp x16, Lcount272
ldr x17, [x16, :lo12:Lcount272]
add x17, x17, #1
str x17, [x16, :lo12:Lcount272]
mov sp, x29
adrp x16, Lcount281
ldr x17, [x16, :lo12:Lcount281]
add x17, x17, #1
str x17, [x16, :lo12:Lcount281]
ldp x29, x30, [sp], #16
adrp x16, Lcount282
ldr x17, [x16, :lo12:Lcount282]
add x17, x17, #1
str x17, [x16, :lo12:Lcount282]
b Lfn10
adrp x16, Lcount282
ldr x17, [x16, :lo12:Lcount282]
add x17, x17, #1
str x17, [x16, :lo12:Lcount282]
b Lfn11if1228done
Lfn11if1228else:
adrp x16, Lcount283
ldr x17, [x16, :lo12:Lcount283]
add x17, x17, #1
str x17, [x16, :lo12:Lcount283]
movz x0, #10, lsl #0
adrp x16, Lcount274
ldr x17, [x16, :lo12:Lcount274]
add x17, x17, #1
str x17, [x16, :lo12:Lcount274]
str x0, [sp, #72]
adrp x16, Lcount277
ldr x17, [x16, :lo12:Lcount277]
add x17, x17, #1
str x17, [x16, :lo12:Lcount277]
ldr x0, [sp, #64]
adrp x16, Lcount277
ldr x17, [x16, :lo12:Lcount277]
add x17, x17, #1
str x17, [x16, :lo12:Lcount277]
ldr x2, [sp, #72]
adrp x16, Lcount284
ldr x17, [x16, :lo12:Lcount284]
add x17, x17, #1
str x17, [x16, :lo12:Lcount284]
cbz x2, Lfn11fail1236_2
adrp x16, Lcount285
ldr x17, [x16, :lo12:Lcount285]
add x17, x17, #1
str x17, [x16, :lo12:Lcount285]
cmn x2, #1
adrp x16, Lcount286
ldr x17, [x16, :lo12:Lcount286]
add x17, x17, #1
str x17, [x16, :lo12:Lcount286]
b.ne 1f
adrp x16, Lcount287
ldr x17, [x16, :lo12:Lcount287]
add x17, x17, #1
str x17, [x16, :lo12:Lcount287]
negs x3, x0
adrp x16, Lcount288
ldr x17, [x16, :lo12:Lcount288]
add x17, x17, #1
str x17, [x16, :lo12:Lcount288]
b.vs Lfn11fail1236_1
1:
adrp x16, Lcount289
ldr x17, [x16, :lo12:Lcount289]
add x17, x17, #1
str x17, [x16, :lo12:Lcount289]
sdiv x0, x0, x2
adrp x16, Lcount274
ldr x17, [x16, :lo12:Lcount274]
add x17, x17, #1
str x17, [x16, :lo12:Lcount274]
str x0, [sp, #80]
adrp x16, Lcount290
ldr x17, [x16, :lo12:Lcount290]
add x17, x17, #1
str x17, [x16, :lo12:Lcount290]
bl Lfn11
adrp x16, Lcount291
ldr x17, [x16, :lo12:Lcount291]
add x17, x17, #1
str x17, [x16, :lo12:Lcount291]
cbnz x1, Lfn11end
adrp x16, Lcount274
ldr x17, [x16, :lo12:Lcount274]
add x17, x17, #1
str x17, [x16, :lo12:Lcount274]
str x0, [sp, #48]
adrp x16, Lcount283
ldr x17, [x16, :lo12:Lcount283]
add x17, x17, #1
str x17, [x16, :lo12:Lcount283]
movz x0, #10, lsl #0
adrp x16, Lcount274
ldr x17, [x16, :lo12:Lcount274]
add x17, x17, #1
str x17, [x16, :lo12:Lcount274]
str x0, [sp, #88]
adrp x16, Lcount277
ldr x17, [x16, :lo12:Lcount277]
add x17, x17, #1
str x17, [x16, :lo12:Lcount277]
ldr x0, [sp, #80]
adrp x16, Lcount277
ldr x17, [x16, :lo12:Lcount277]
add x17, x17, #1
str x17, [x16, :lo12:Lcount277]
ldr x2, [sp, #88]
adrp x16, Lcount292
ldr x17, [x16, :lo12:Lcount292]
add x17, x17, #1
str x17, [x16, :lo12:Lcount292]
smulh x3, x0, x2
adrp x16, Lcount293
ldr x17, [x16, :lo12:Lcount293]
add x17, x17, #1
str x17, [x16, :lo12:Lcount293]
mul x0, x0, x2
adrp x16, Lcount278
ldr x17, [x16, :lo12:Lcount278]
add x17, x17, #1
str x17, [x16, :lo12:Lcount278]
cmp x3, x0, asr #63
adrp x16, Lcount286
ldr x17, [x16, :lo12:Lcount286]
add x17, x17, #1
str x17, [x16, :lo12:Lcount286]
b.ne Lfn11fail1245_1
adrp x16, Lcount274
ldr x17, [x16, :lo12:Lcount274]
add x17, x17, #1
str x17, [x16, :lo12:Lcount274]
str x0, [sp, #96]
adrp x16, Lcount277
ldr x17, [x16, :lo12:Lcount277]
add x17, x17, #1
str x17, [x16, :lo12:Lcount277]
ldr x0, [sp, #64]
adrp x16, Lcount277
ldr x17, [x16, :lo12:Lcount277]
add x17, x17, #1
str x17, [x16, :lo12:Lcount277]
ldr x2, [sp, #96]
adrp x16, Lcount294
ldr x17, [x16, :lo12:Lcount294]
add x17, x17, #1
str x17, [x16, :lo12:Lcount294]
subs x0, x0, x2
adrp x16, Lcount288
ldr x17, [x16, :lo12:Lcount288]
add x17, x17, #1
str x17, [x16, :lo12:Lcount288]
b.vs Lfn11fail1243_1
adrp x16, Lcount295
ldr x17, [x16, :lo12:Lcount295]
add x17, x17, #1
str x17, [x16, :lo12:Lcount295]
bl Lfn10
adrp x16, Lcount291
ldr x17, [x16, :lo12:Lcount291]
add x17, x17, #1
str x17, [x16, :lo12:Lcount291]
cbnz x1, Lfn11end
adrp x16, Lcount274
ldr x17, [x16, :lo12:Lcount274]
add x17, x17, #1
str x17, [x16, :lo12:Lcount274]
str x0, [sp, #56]
adrp x16, Lcount277
ldr x17, [x16, :lo12:Lcount277]
add x17, x17, #1
str x17, [x16, :lo12:Lcount277]
ldr x0, [sp, #48]
adrp x16, Lcount277
ldr x17, [x16, :lo12:Lcount277]
add x17, x17, #1
str x17, [x16, :lo12:Lcount277]
ldr x2, [sp, #56]
adrp x16, Lcount272
ldr x17, [x16, :lo12:Lcount272]
add x17, x17, #1
str x17, [x16, :lo12:Lcount272]
mov x1, x2
adrp x16, Lcount296
ldr x17, [x16, :lo12:Lcount296]
add x17, x17, #1
str x17, [x16, :lo12:Lcount296]
bl fen_bytes_concat
adrp x16, Lcount284
ldr x17, [x16, :lo12:Lcount284]
add x17, x17, #1
str x17, [x16, :lo12:Lcount284]
cbz x0, Lfn11fail1239_3
Lfn11if1228done:
adrp x16, Lcount272
ldr x17, [x16, :lo12:Lcount272]
add x17, x17, #1
str x17, [x16, :lo12:Lcount272]
mov x1, #0
adrp x16, Lcount282
ldr x17, [x16, :lo12:Lcount282]
add x17, x17, #1
str x17, [x16, :lo12:Lcount282]
b Lfn11end
Lfn11fail1236_2:
adrp x16, Lcount297
ldr x17, [x16, :lo12:Lcount297]
add x17, x17, #1
str x17, [x16, :lo12:Lcount297]
adrp x0, Lfn11fail1236_2location
adrp x16, Lcount275
ldr x17, [x16, :lo12:Lcount275]
add x17, x17, #1
str x17, [x16, :lo12:Lcount275]
add x0, x0, :lo12:Lfn11fail1236_2location
adrp x16, Lcount298
ldr x17, [x16, :lo12:Lcount298]
add x17, x17, #1
str x17, [x16, :lo12:Lcount298]
bl fen_set_location
adrp x16, Lcount272
ldr x17, [x16, :lo12:Lcount272]
add x17, x17, #1
str x17, [x16, :lo12:Lcount272]
mov x1, #2
adrp x16, Lcount282
ldr x17, [x16, :lo12:Lcount282]
add x17, x17, #1
str x17, [x16, :lo12:Lcount282]
b Lfn11end
Lfn11fail1236_1:
adrp x16, Lcount297
ldr x17, [x16, :lo12:Lcount297]
add x17, x17, #1
str x17, [x16, :lo12:Lcount297]
adrp x0, Lfn11fail1236_1location
adrp x16, Lcount275
ldr x17, [x16, :lo12:Lcount275]
add x17, x17, #1
str x17, [x16, :lo12:Lcount275]
add x0, x0, :lo12:Lfn11fail1236_1location
adrp x16, Lcount298
ldr x17, [x16, :lo12:Lcount298]
add x17, x17, #1
str x17, [x16, :lo12:Lcount298]
bl fen_set_location
adrp x16, Lcount272
ldr x17, [x16, :lo12:Lcount272]
add x17, x17, #1
str x17, [x16, :lo12:Lcount272]
mov x1, #1
adrp x16, Lcount282
ldr x17, [x16, :lo12:Lcount282]
add x17, x17, #1
str x17, [x16, :lo12:Lcount282]
b Lfn11end
Lfn11fail1245_1:
adrp x16, Lcount297
ldr x17, [x16, :lo12:Lcount297]
add x17, x17, #1
str x17, [x16, :lo12:Lcount297]
adrp x0, Lfn11fail1245_1location
adrp x16, Lcount275
ldr x17, [x16, :lo12:Lcount275]
add x17, x17, #1
str x17, [x16, :lo12:Lcount275]
add x0, x0, :lo12:Lfn11fail1245_1location
adrp x16, Lcount298
ldr x17, [x16, :lo12:Lcount298]
add x17, x17, #1
str x17, [x16, :lo12:Lcount298]
bl fen_set_location
adrp x16, Lcount272
ldr x17, [x16, :lo12:Lcount272]
add x17, x17, #1
str x17, [x16, :lo12:Lcount272]
mov x1, #1
adrp x16, Lcount282
ldr x17, [x16, :lo12:Lcount282]
add x17, x17, #1
str x17, [x16, :lo12:Lcount282]
b Lfn11end
Lfn11fail1243_1:
adrp x16, Lcount297
ldr x17, [x16, :lo12:Lcount297]
add x17, x17, #1
str x17, [x16, :lo12:Lcount297]
adrp x0, Lfn11fail1243_1location
adrp x16, Lcount275
ldr x17, [x16, :lo12:Lcount275]
add x17, x17, #1
str x17, [x16, :lo12:Lcount275]
add x0, x0, :lo12:Lfn11fail1243_1location
adrp x16, Lcount298
ldr x17, [x16, :lo12:Lcount298]
add x17, x17, #1
str x17, [x16, :lo12:Lcount298]
bl fen_set_location
adrp x16, Lcount272
ldr x17, [x16, :lo12:Lcount272]
add x17, x17, #1
str x17, [x16, :lo12:Lcount272]
mov x1, #1
adrp x16, Lcount282
ldr x17, [x16, :lo12:Lcount282]
add x17, x17, #1
str x17, [x16, :lo12:Lcount282]
b Lfn11end
Lfn11fail1239_3:
adrp x16, Lcount297
ldr x17, [x16, :lo12:Lcount297]
add x17, x17, #1
str x17, [x16, :lo12:Lcount297]
adrp x0, Lfn11fail1239_3location
adrp x16, Lcount275
ldr x17, [x16, :lo12:Lcount275]
add x17, x17, #1
str x17, [x16, :lo12:Lcount275]
add x0, x0, :lo12:Lfn11fail1239_3location
adrp x16, Lcount298
ldr x17, [x16, :lo12:Lcount298]
add x17, x17, #1
str x17, [x16, :lo12:Lcount298]
bl fen_set_location
adrp x16, Lcount272
ldr x17, [x16, :lo12:Lcount272]
add x17, x17, #1
str x17, [x16, :lo12:Lcount272]
mov x1, #3
adrp x16, Lcount282
ldr x17, [x16, :lo12:Lcount282]
add x17, x17, #1
str x17, [x16, :lo12:Lcount282]
b Lfn11end
Lfn11end:
adrp x16, Lcount280
ldr x17, [x16, :lo12:Lcount280]
add x17, x17, #1
str x17, [x16, :lo12:Lcount280]
bl fen_leave_result
adrp x16, Lcount272
ldr x17, [x16, :lo12:Lcount272]
add x17, x17, #1
str x17, [x16, :lo12:Lcount272]
mov sp, x29
adrp x16, Lcount281
ldr x17, [x16, :lo12:Lcount281]
add x17, x17, #1
str x17, [x16, :lo12:Lcount281]
ldp x29, x30, [sp], #16
adrp x16, Lcount299
ldr x17, [x16, :lo12:Lcount299]
add x17, x17, #1
str x17, [x16, :lo12:Lcount299]
ret
Lfn12:
adrp x16, Lcount300
ldr x17, [x16, :lo12:Lcount300]
add x17, x17, #1
str x17, [x16, :lo12:Lcount300]
ldp x8, x9, [x0, #0]
adrp x16, Lcount300
ldr x17, [x16, :lo12:Lcount300]
add x17, x17, #1
str x17, [x16, :lo12:Lcount300]
ldp x10, x11, [x0, #16]
Lfn12fields:
adrp x16, Lcount301
ldr x17, [x16, :lo12:Lcount301]
add x17, x17, #1
str x17, [x16, :lo12:Lcount301]
stp x29, x30, [sp, #-16]!
adrp x16, Lcount302
ldr x17, [x16, :lo12:Lcount302]
add x17, x17, #1
str x17, [x16, :lo12:Lcount302]
mov x29, sp
adrp x16, Lcount303
ldr x17, [x16, :lo12:Lcount303]
add x17, x17, #1
str x17, [x16, :lo12:Lcount303]
sub sp, sp, #160
adrp x16, Lcount301
ldr x17, [x16, :lo12:Lcount301]
add x17, x17, #1
str x17, [x16, :lo12:Lcount301]
stp xzr, xzr, [sp, #48]
adrp x16, Lcount301
ldr x17, [x16, :lo12:Lcount301]
add x17, x17, #1
str x17, [x16, :lo12:Lcount301]
stp xzr, xzr, [sp, #64]
adrp x16, Lcount301
ldr x17, [x16, :lo12:Lcount301]
add x17, x17, #1
str x17, [x16, :lo12:Lcount301]
stp xzr, xzr, [sp, #80]
adrp x16, Lcount301
ldr x17, [x16, :lo12:Lcount301]
add x17, x17, #1
str x17, [x16, :lo12:Lcount301]
stp xzr, xzr, [sp, #96]
adrp x16, Lcount301
ldr x17, [x16, :lo12:Lcount301]
add x17, x17, #1
str x17, [x16, :lo12:Lcount301]
stp xzr, xzr, [sp, #112]
adrp x16, Lcount301
ldr x17, [x16, :lo12:Lcount301]
add x17, x17, #1
str x17, [x16, :lo12:Lcount301]
stp x8, x9, [sp, #128]
adrp x16, Lcount301
ldr x17, [x16, :lo12:Lcount301]
add x17, x17, #1
str x17, [x16, :lo12:Lcount301]
stp x10, x11, [sp, #144]
adrp x16, Lcount304
ldr x17, [x16, :lo12:Lcount304]
add x17, x17, #1
str x17, [x16, :lo12:Lcount304]
add x0, sp, #16
adrp x16, Lcount304
ldr x17, [x16, :lo12:Lcount304]
add x17, x17, #1
str x17, [x16, :lo12:Lcount304]
add x1, sp, #48
adrp x16, Lcount302
ldr x17, [x16, :lo12:Lcount302]
add x17, x17, #1
str x17, [x16, :lo12:Lcount302]
mov x2, #10
adrp x16, Lcount305
ldr x17, [x16, :lo12:Lcount305]
add x17, x17, #1
str x17, [x16, :lo12:Lcount305]
bl fen_enter
Lfn12loop:
adrp x16, Lcount306
ldr x17, [x16, :lo12:Lcount306]
add x17, x17, #1
str x17, [x16, :lo12:Lcount306]
ldr x0, [sp, #128]
adrp x16, Lcount307
ldr x17, [x16, :lo12:Lcount307]
add x17, x17, #1
str x17, [x16, :lo12:Lcount307]
bl Lfn11
adrp x16, Lcount308
ldr x17, [x16, :lo12:Lcount308]
add x17, x17, #1
str x17, [x16, :lo12:Lcount308]
cbnz x1, Lfn12end
adrp x16, Lcount309
ldr x17, [x16, :lo12:Lcount309]
add x17, x17, #1
str x17, [x16, :lo12:Lcount309]
str x0, [sp, #48]
adrp x16, Lcount306
ldr x17, [x16, :lo12:Lcount306]
add x17, x17, #1
str x17, [x16, :lo12:Lcount306]
ldr x0, [sp, #136]
adrp x16, Lcount307
ldr x17, [x16, :lo12:Lcount307]
add x17, x17, #1
str x17, [x16, :lo12:Lcount307]
bl Lfn11
adrp x16, Lcount308
ldr x17, [x16, :lo12:Lcount308]
add x17, x17, #1
str x17, [x16, :lo12:Lcount308]
cbnz x1, Lfn12end
adrp x16, Lcount309
ldr x17, [x16, :lo12:Lcount309]
add x17, x17, #1
str x17, [x16, :lo12:Lcount309]
str x0, [sp, #56]
adrp x16, Lcount310
ldr x17, [x16, :lo12:Lcount310]
add x17, x17, #1
str x17, [x16, :lo12:Lcount310]
adrp x0, Lconstant13
adrp x16, Lcount304
ldr x17, [x16, :lo12:Lcount304]
add x17, x17, #1
str x17, [x16, :lo12:Lcount304]
add x0, x0, :lo12:Lconstant13
adrp x16, Lcount306
ldr x17, [x16, :lo12:Lcount306]
add x17, x17, #1
str x17, [x16, :lo12:Lcount306]
ldr x2, [sp, #56]
adrp x16, Lcount302
ldr x17, [x16, :lo12:Lcount302]
add x17, x17, #1
str x17, [x16, :lo12:Lcount302]
mov x1, x2
adrp x16, Lcount311
ldr x17, [x16, :lo12:Lcount311]
add x17, x17, #1
str x17, [x16, :lo12:Lcount311]
bl fen_bytes_concat
adrp x16, Lcount312
ldr x17, [x16, :lo12:Lcount312]
add x17, x17, #1
str x17, [x16, :lo12:Lcount312]
cbz x0, Lfn12fail1270_3
adrp x16, Lcount309
ldr x17, [x16, :lo12:Lcount309]
add x17, x17, #1
str x17, [x16, :lo12:Lcount309]
str x0, [sp, #64]
adrp x16, Lcount306
ldr x17, [x16, :lo12:Lcount306]
add x17, x17, #1
str x17, [x16, :lo12:Lcount306]
ldr x0, [sp, #48]
adrp x16, Lcount306
ldr x17, [x16, :lo12:Lcount306]
add x17, x17, #1
str x17, [x16, :lo12:Lcount306]
ldr x2, [sp, #64]
adrp x16, Lcount302
ldr x17, [x16, :lo12:Lcount302]
add x17, x17, #1
str x17, [x16, :lo12:Lcount302]
mov x1, x2
adrp x16, Lcount311
ldr x17, [x16, :lo12:Lcount311]
add x17, x17, #1
str x17, [x16, :lo12:Lcount311]
bl fen_bytes_concat
adrp x16, Lcount312
ldr x17, [x16, :lo12:Lcount312]
add x17, x17, #1
str x17, [x16, :lo12:Lcount312]
cbz x0, Lfn12fail1267_3
adrp x16, Lcount309
ldr x17, [x16, :lo12:Lcount309]
add x17, x17, #1
str x17, [x16, :lo12:Lcount309]
str x0, [sp, #72]
adrp x16, Lcount306
ldr x17, [x16, :lo12:Lcount306]
add x17, x17, #1
str x17, [x16, :lo12:Lcount306]
ldr x0, [sp, #144]
adrp x16, Lcount307
ldr x17, [x16, :lo12:Lcount307]
add x17, x17, #1
str x17, [x16, :lo12:Lcount307]
bl Lfn11
adrp x16, Lcount308
ldr x17, [x16, :lo12:Lcount308]
add x17, x17, #1
str x17, [x16, :lo12:Lcount308]
cbnz x1, Lfn12end
adrp x16, Lcount309
ldr x17, [x16, :lo12:Lcount309]
add x17, x17, #1
str x17, [x16, :lo12:Lcount309]
str x0, [sp, #80]
adrp x16, Lcount310
ldr x17, [x16, :lo12:Lcount310]
add x17, x17, #1
str x17, [x16, :lo12:Lcount310]
adrp x0, Lconstant13
adrp x16, Lcount304
ldr x17, [x16, :lo12:Lcount304]
add x17, x17, #1
str x17, [x16, :lo12:Lcount304]
add x0, x0, :lo12:Lconstant13
adrp x16, Lcount306
ldr x17, [x16, :lo12:Lcount306]
add x17, x17, #1
str x17, [x16, :lo12:Lcount306]
ldr x2, [sp, #80]
adrp x16, Lcount302
ldr x17, [x16, :lo12:Lcount302]
add x17, x17, #1
str x17, [x16, :lo12:Lcount302]
mov x1, x2
adrp x16, Lcount311
ldr x17, [x16, :lo12:Lcount311]
add x17, x17, #1
str x17, [x16, :lo12:Lcount311]
bl fen_bytes_concat
adrp x16, Lcount312
ldr x17, [x16, :lo12:Lcount312]
add x17, x17, #1
str x17, [x16, :lo12:Lcount312]
cbz x0, Lfn12fail1275_3
adrp x16, Lcount309
ldr x17, [x16, :lo12:Lcount309]
add x17, x17, #1
str x17, [x16, :lo12:Lcount309]
str x0, [sp, #88]
adrp x16, Lcount306
ldr x17, [x16, :lo12:Lcount306]
add x17, x17, #1
str x17, [x16, :lo12:Lcount306]
ldr x0, [sp, #152]
adrp x16, Lcount307
ldr x17, [x16, :lo12:Lcount307]
add x17, x17, #1
str x17, [x16, :lo12:Lcount307]
bl Lfn11
adrp x16, Lcount308
ldr x17, [x16, :lo12:Lcount308]
add x17, x17, #1
str x17, [x16, :lo12:Lcount308]
cbnz x1, Lfn12end
adrp x16, Lcount309
ldr x17, [x16, :lo12:Lcount309]
add x17, x17, #1
str x17, [x16, :lo12:Lcount309]
str x0, [sp, #96]
adrp x16, Lcount310
ldr x17, [x16, :lo12:Lcount310]
add x17, x17, #1
str x17, [x16, :lo12:Lcount310]
adrp x2, Lconstant14
adrp x16, Lcount304
ldr x17, [x16, :lo12:Lcount304]
add x17, x17, #1
str x17, [x16, :lo12:Lcount304]
add x2, x2, :lo12:Lconstant14
adrp x16, Lcount302
ldr x17, [x16, :lo12:Lcount302]
add x17, x17, #1
str x17, [x16, :lo12:Lcount302]
mov x1, x2
adrp x16, Lcount311
ldr x17, [x16, :lo12:Lcount311]
add x17, x17, #1
str x17, [x16, :lo12:Lcount311]
bl fen_bytes_concat
adrp x16, Lcount312
ldr x17, [x16, :lo12:Lcount312]
add x17, x17, #1
str x17, [x16, :lo12:Lcount312]
cbz x0, Lfn12fail1281_3
adrp x16, Lcount309
ldr x17, [x16, :lo12:Lcount309]
add x17, x17, #1
str x17, [x16, :lo12:Lcount309]
str x0, [sp, #104]
adrp x16, Lcount310
ldr x17, [x16, :lo12:Lcount310]
add x17, x17, #1
str x17, [x16, :lo12:Lcount310]
adrp x0, Lconstant13
adrp x16, Lcount304
ldr x17, [x16, :lo12:Lcount304]
add x17, x17, #1
str x17, [x16, :lo12:Lcount304]
add x0, x0, :lo12:Lconstant13
adrp x16, Lcount306
ldr x17, [x16, :lo12:Lcount306]
add x17, x17, #1
str x17, [x16, :lo12:Lcount306]
ldr x2, [sp, #104]
adrp x16, Lcount302
ldr x17, [x16, :lo12:Lcount302]
add x17, x17, #1
str x17, [x16, :lo12:Lcount302]
mov x1, x2
adrp x16, Lcount311
ldr x17, [x16, :lo12:Lcount311]
add x17, x17, #1
str x17, [x16, :lo12:Lcount311]
bl fen_bytes_concat
adrp x16, Lcount312
ldr x17, [x16, :lo12:Lcount312]
add x17, x17, #1
str x17, [x16, :lo12:Lcount312]
cbz x0, Lfn12fail1279_3
adrp x16, Lcount309
ldr x17, [x16, :lo12:Lcount309]
add x17, x17, #1
str x17, [x16, :lo12:Lcount309]
str x0, [sp, #112]
adrp x16, Lcount306
ldr x17, [x16, :lo12:Lcount306]
add x17, x17, #1
str x17, [x16, :lo12:Lcount306]
ldr x0, [sp, #88]
adrp x16, Lcount306
ldr x17, [x16, :lo12:Lcount306]
add x17, x17, #1
str x17, [x16, :lo12:Lcount306]
ldr x2, [sp, #112]
adrp x16, Lcount302
ldr x17, [x16, :lo12:Lcount302]
add x17, x17, #1
str x17, [x16, :lo12:Lcount302]
mov x1, x2
adrp x16, Lcount311
ldr x17, [x16, :lo12:Lcount311]
add x17, x17, #1
str x17, [x16, :lo12:Lcount311]
bl fen_bytes_concat
adrp x16, Lcount312
ldr x17, [x16, :lo12:Lcount312]
add x17, x17, #1
str x17, [x16, :lo12:Lcount312]
cbz x0, Lfn12fail1274_3
adrp x16, Lcount309
ldr x17, [x16, :lo12:Lcount309]
add x17, x17, #1
str x17, [x16, :lo12:Lcount309]
str x0, [sp, #120]
adrp x16, Lcount306
ldr x17, [x16, :lo12:Lcount306]
add x17, x17, #1
str x17, [x16, :lo12:Lcount306]
ldr x0, [sp, #72]
adrp x16, Lcount306
ldr x17, [x16, :lo12:Lcount306]
add x17, x17, #1
str x17, [x16, :lo12:Lcount306]
ldr x2, [sp, #120]
adrp x16, Lcount302
ldr x17, [x16, :lo12:Lcount302]
add x17, x17, #1
str x17, [x16, :lo12:Lcount302]
mov x1, x2
adrp x16, Lcount311
ldr x17, [x16, :lo12:Lcount311]
add x17, x17, #1
str x17, [x16, :lo12:Lcount311]
bl fen_bytes_concat
adrp x16, Lcount312
ldr x17, [x16, :lo12:Lcount312]
add x17, x17, #1
str x17, [x16, :lo12:Lcount312]
cbz x0, Lfn12fail1266_3
adrp x16, Lcount302
ldr x17, [x16, :lo12:Lcount302]
add x17, x17, #1
str x17, [x16, :lo12:Lcount302]
mov x1, #0
adrp x16, Lcount313
ldr x17, [x16, :lo12:Lcount313]
add x17, x17, #1
str x17, [x16, :lo12:Lcount313]
b Lfn12end
Lfn12fail1270_3:
adrp x16, Lcount310
ldr x17, [x16, :lo12:Lcount310]
add x17, x17, #1
str x17, [x16, :lo12:Lcount310]
adrp x0, Lfn12fail1270_3location
adrp x16, Lcount304
ldr x17, [x16, :lo12:Lcount304]
add x17, x17, #1
str x17, [x16, :lo12:Lcount304]
add x0, x0, :lo12:Lfn12fail1270_3location
adrp x16, Lcount314
ldr x17, [x16, :lo12:Lcount314]
add x17, x17, #1
str x17, [x16, :lo12:Lcount314]
bl fen_set_location
adrp x16, Lcount302
ldr x17, [x16, :lo12:Lcount302]
add x17, x17, #1
str x17, [x16, :lo12:Lcount302]
mov x1, #3
adrp x16, Lcount313
ldr x17, [x16, :lo12:Lcount313]
add x17, x17, #1
str x17, [x16, :lo12:Lcount313]
b Lfn12end
Lfn12fail1267_3:
adrp x16, Lcount310
ldr x17, [x16, :lo12:Lcount310]
add x17, x17, #1
str x17, [x16, :lo12:Lcount310]
adrp x0, Lfn12fail1267_3location
adrp x16, Lcount304
ldr x17, [x16, :lo12:Lcount304]
add x17, x17, #1
str x17, [x16, :lo12:Lcount304]
add x0, x0, :lo12:Lfn12fail1267_3location
adrp x16, Lcount314
ldr x17, [x16, :lo12:Lcount314]
add x17, x17, #1
str x17, [x16, :lo12:Lcount314]
bl fen_set_location
adrp x16, Lcount302
ldr x17, [x16, :lo12:Lcount302]
add x17, x17, #1
str x17, [x16, :lo12:Lcount302]
mov x1, #3
adrp x16, Lcount313
ldr x17, [x16, :lo12:Lcount313]
add x17, x17, #1
str x17, [x16, :lo12:Lcount313]
b Lfn12end
Lfn12fail1275_3:
adrp x16, Lcount310
ldr x17, [x16, :lo12:Lcount310]
add x17, x17, #1
str x17, [x16, :lo12:Lcount310]
adrp x0, Lfn12fail1275_3location
adrp x16, Lcount304
ldr x17, [x16, :lo12:Lcount304]
add x17, x17, #1
str x17, [x16, :lo12:Lcount304]
add x0, x0, :lo12:Lfn12fail1275_3location
adrp x16, Lcount314
ldr x17, [x16, :lo12:Lcount314]
add x17, x17, #1
str x17, [x16, :lo12:Lcount314]
bl fen_set_location
adrp x16, Lcount302
ldr x17, [x16, :lo12:Lcount302]
add x17, x17, #1
str x17, [x16, :lo12:Lcount302]
mov x1, #3
adrp x16, Lcount313
ldr x17, [x16, :lo12:Lcount313]
add x17, x17, #1
str x17, [x16, :lo12:Lcount313]
b Lfn12end
Lfn12fail1281_3:
adrp x16, Lcount310
ldr x17, [x16, :lo12:Lcount310]
add x17, x17, #1
str x17, [x16, :lo12:Lcount310]
adrp x0, Lfn12fail1281_3location
adrp x16, Lcount304
ldr x17, [x16, :lo12:Lcount304]
add x17, x17, #1
str x17, [x16, :lo12:Lcount304]
add x0, x0, :lo12:Lfn12fail1281_3location
adrp x16, Lcount314
ldr x17, [x16, :lo12:Lcount314]
add x17, x17, #1
str x17, [x16, :lo12:Lcount314]
bl fen_set_location
adrp x16, Lcount302
ldr x17, [x16, :lo12:Lcount302]
add x17, x17, #1
str x17, [x16, :lo12:Lcount302]
mov x1, #3
adrp x16, Lcount313
ldr x17, [x16, :lo12:Lcount313]
add x17, x17, #1
str x17, [x16, :lo12:Lcount313]
b Lfn12end
Lfn12fail1279_3:
adrp x16, Lcount310
ldr x17, [x16, :lo12:Lcount310]
add x17, x17, #1
str x17, [x16, :lo12:Lcount310]
adrp x0, Lfn12fail1279_3location
adrp x16, Lcount304
ldr x17, [x16, :lo12:Lcount304]
add x17, x17, #1
str x17, [x16, :lo12:Lcount304]
add x0, x0, :lo12:Lfn12fail1279_3location
adrp x16, Lcount314
ldr x17, [x16, :lo12:Lcount314]
add x17, x17, #1
str x17, [x16, :lo12:Lcount314]
bl fen_set_location
adrp x16, Lcount302
ldr x17, [x16, :lo12:Lcount302]
add x17, x17, #1
str x17, [x16, :lo12:Lcount302]
mov x1, #3
adrp x16, Lcount313
ldr x17, [x16, :lo12:Lcount313]
add x17, x17, #1
str x17, [x16, :lo12:Lcount313]
b Lfn12end
Lfn12fail1274_3:
adrp x16, Lcount310
ldr x17, [x16, :lo12:Lcount310]
add x17, x17, #1
str x17, [x16, :lo12:Lcount310]
adrp x0, Lfn12fail1274_3location
adrp x16, Lcount304
ldr x17, [x16, :lo12:Lcount304]
add x17, x17, #1
str x17, [x16, :lo12:Lcount304]
add x0, x0, :lo12:Lfn12fail1274_3location
adrp x16, Lcount314
ldr x17, [x16, :lo12:Lcount314]
add x17, x17, #1
str x17, [x16, :lo12:Lcount314]
bl fen_set_location
adrp x16, Lcount302
ldr x17, [x16, :lo12:Lcount302]
add x17, x17, #1
str x17, [x16, :lo12:Lcount302]
mov x1, #3
adrp x16, Lcount313
ldr x17, [x16, :lo12:Lcount313]
add x17, x17, #1
str x17, [x16, :lo12:Lcount313]
b Lfn12end
Lfn12fail1266_3:
adrp x16, Lcount310
ldr x17, [x16, :lo12:Lcount310]
add x17, x17, #1
str x17, [x16, :lo12:Lcount310]
adrp x0, Lfn12fail1266_3location
adrp x16, Lcount304
ldr x17, [x16, :lo12:Lcount304]
add x17, x17, #1
str x17, [x16, :lo12:Lcount304]
add x0, x0, :lo12:Lfn12fail1266_3location
adrp x16, Lcount314
ldr x17, [x16, :lo12:Lcount314]
add x17, x17, #1
str x17, [x16, :lo12:Lcount314]
bl fen_set_location
adrp x16, Lcount302
ldr x17, [x16, :lo12:Lcount302]
add x17, x17, #1
str x17, [x16, :lo12:Lcount302]
mov x1, #3
adrp x16, Lcount313
ldr x17, [x16, :lo12:Lcount313]
add x17, x17, #1
str x17, [x16, :lo12:Lcount313]
b Lfn12end
Lfn12end:
adrp x16, Lcount315
ldr x17, [x16, :lo12:Lcount315]
add x17, x17, #1
str x17, [x16, :lo12:Lcount315]
bl fen_leave_result
adrp x16, Lcount302
ldr x17, [x16, :lo12:Lcount302]
add x17, x17, #1
str x17, [x16, :lo12:Lcount302]
mov sp, x29
adrp x16, Lcount316
ldr x17, [x16, :lo12:Lcount316]
add x17, x17, #1
str x17, [x16, :lo12:Lcount316]
ldp x29, x30, [sp], #16
adrp x16, Lcount317
ldr x17, [x16, :lo12:Lcount317]
add x17, x17, #1
str x17, [x16, :lo12:Lcount317]
ret
.globl stream_rejection_line
stream_rejection_line:
Lfn13:
adrp x16, Lcount318
ldr x17, [x16, :lo12:Lcount318]
add x17, x17, #1
str x17, [x16, :lo12:Lcount318]
stp x29, x30, [sp, #-16]!
adrp x16, Lcount319
ldr x17, [x16, :lo12:Lcount319]
add x17, x17, #1
str x17, [x16, :lo12:Lcount319]
mov x29, sp
adrp x16, Lcount320
ldr x17, [x16, :lo12:Lcount320]
add x17, x17, #1
str x17, [x16, :lo12:Lcount320]
sub sp, sp, #80
adrp x16, Lcount318
ldr x17, [x16, :lo12:Lcount318]
add x17, x17, #1
str x17, [x16, :lo12:Lcount318]
stp xzr, xzr, [sp, #48]
adrp x16, Lcount321
ldr x17, [x16, :lo12:Lcount321]
add x17, x17, #1
str x17, [x16, :lo12:Lcount321]
str x0, [sp, #64]
adrp x16, Lcount322
ldr x17, [x16, :lo12:Lcount322]
add x17, x17, #1
str x17, [x16, :lo12:Lcount322]
add x0, sp, #16
adrp x16, Lcount322
ldr x17, [x16, :lo12:Lcount322]
add x17, x17, #1
str x17, [x16, :lo12:Lcount322]
add x1, sp, #48
adrp x16, Lcount319
ldr x17, [x16, :lo12:Lcount319]
add x17, x17, #1
str x17, [x16, :lo12:Lcount319]
mov x2, #2
adrp x16, Lcount323
ldr x17, [x16, :lo12:Lcount323]
add x17, x17, #1
str x17, [x16, :lo12:Lcount323]
bl fen_enter
adrp x16, Lcount324
ldr x17, [x16, :lo12:Lcount324]
add x17, x17, #1
str x17, [x16, :lo12:Lcount324]
ldr x0, [sp, #64]
adrp x16, Lcount325
ldr x17, [x16, :lo12:Lcount325]
add x17, x17, #1
str x17, [x16, :lo12:Lcount325]
bl Lfn11
adrp x16, Lcount326
ldr x17, [x16, :lo12:Lcount326]
add x17, x17, #1
str x17, [x16, :lo12:Lcount326]
cbnz x1, Lfn13end
adrp x16, Lcount321
ldr x17, [x16, :lo12:Lcount321]
add x17, x17, #1
str x17, [x16, :lo12:Lcount321]
str x0, [sp, #48]
adrp x16, Lcount327
ldr x17, [x16, :lo12:Lcount327]
add x17, x17, #1
str x17, [x16, :lo12:Lcount327]
adrp x2, Lconstant14
adrp x16, Lcount322
ldr x17, [x16, :lo12:Lcount322]
add x17, x17, #1
str x17, [x16, :lo12:Lcount322]
add x2, x2, :lo12:Lconstant14
adrp x16, Lcount319
ldr x17, [x16, :lo12:Lcount319]
add x17, x17, #1
str x17, [x16, :lo12:Lcount319]
mov x1, x2
adrp x16, Lcount328
ldr x17, [x16, :lo12:Lcount328]
add x17, x17, #1
str x17, [x16, :lo12:Lcount328]
bl fen_bytes_concat
adrp x16, Lcount329
ldr x17, [x16, :lo12:Lcount329]
add x17, x17, #1
str x17, [x16, :lo12:Lcount329]
cbz x0, Lfn13fail1289_3
adrp x16, Lcount321
ldr x17, [x16, :lo12:Lcount321]
add x17, x17, #1
str x17, [x16, :lo12:Lcount321]
str x0, [sp, #56]
adrp x16, Lcount327
ldr x17, [x16, :lo12:Lcount327]
add x17, x17, #1
str x17, [x16, :lo12:Lcount327]
adrp x0, Lconstant15
adrp x16, Lcount322
ldr x17, [x16, :lo12:Lcount322]
add x17, x17, #1
str x17, [x16, :lo12:Lcount322]
add x0, x0, :lo12:Lconstant15
adrp x16, Lcount324
ldr x17, [x16, :lo12:Lcount324]
add x17, x17, #1
str x17, [x16, :lo12:Lcount324]
ldr x2, [sp, #56]
adrp x16, Lcount319
ldr x17, [x16, :lo12:Lcount319]
add x17, x17, #1
str x17, [x16, :lo12:Lcount319]
mov x1, x2
adrp x16, Lcount328
ldr x17, [x16, :lo12:Lcount328]
add x17, x17, #1
str x17, [x16, :lo12:Lcount328]
bl fen_bytes_concat
adrp x16, Lcount329
ldr x17, [x16, :lo12:Lcount329]
add x17, x17, #1
str x17, [x16, :lo12:Lcount329]
cbz x0, Lfn13fail1287_3
adrp x16, Lcount319
ldr x17, [x16, :lo12:Lcount319]
add x17, x17, #1
str x17, [x16, :lo12:Lcount319]
mov x1, #0
adrp x16, Lcount330
ldr x17, [x16, :lo12:Lcount330]
add x17, x17, #1
str x17, [x16, :lo12:Lcount330]
b Lfn13end
Lfn13fail1289_3:
adrp x16, Lcount327
ldr x17, [x16, :lo12:Lcount327]
add x17, x17, #1
str x17, [x16, :lo12:Lcount327]
adrp x0, Lfn13fail1289_3location
adrp x16, Lcount322
ldr x17, [x16, :lo12:Lcount322]
add x17, x17, #1
str x17, [x16, :lo12:Lcount322]
add x0, x0, :lo12:Lfn13fail1289_3location
adrp x16, Lcount331
ldr x17, [x16, :lo12:Lcount331]
add x17, x17, #1
str x17, [x16, :lo12:Lcount331]
bl fen_set_location
adrp x16, Lcount319
ldr x17, [x16, :lo12:Lcount319]
add x17, x17, #1
str x17, [x16, :lo12:Lcount319]
mov x1, #3
adrp x16, Lcount330
ldr x17, [x16, :lo12:Lcount330]
add x17, x17, #1
str x17, [x16, :lo12:Lcount330]
b Lfn13end
Lfn13fail1287_3:
adrp x16, Lcount327
ldr x17, [x16, :lo12:Lcount327]
add x17, x17, #1
str x17, [x16, :lo12:Lcount327]
adrp x0, Lfn13fail1287_3location
adrp x16, Lcount322
ldr x17, [x16, :lo12:Lcount322]
add x17, x17, #1
str x17, [x16, :lo12:Lcount322]
add x0, x0, :lo12:Lfn13fail1287_3location
adrp x16, Lcount331
ldr x17, [x16, :lo12:Lcount331]
add x17, x17, #1
str x17, [x16, :lo12:Lcount331]
bl fen_set_location
adrp x16, Lcount319
ldr x17, [x16, :lo12:Lcount319]
add x17, x17, #1
str x17, [x16, :lo12:Lcount319]
mov x1, #3
adrp x16, Lcount330
ldr x17, [x16, :lo12:Lcount330]
add x17, x17, #1
str x17, [x16, :lo12:Lcount330]
b Lfn13end
Lfn13end:
adrp x16, Lcount332
ldr x17, [x16, :lo12:Lcount332]
add x17, x17, #1
str x17, [x16, :lo12:Lcount332]
bl fen_leave_result
adrp x16, Lcount319
ldr x17, [x16, :lo12:Lcount319]
add x17, x17, #1
str x17, [x16, :lo12:Lcount319]
mov sp, x29
adrp x16, Lcount333
ldr x17, [x16, :lo12:Lcount333]
add x17, x17, #1
str x17, [x16, :lo12:Lcount333]
ldp x29, x30, [sp], #16
adrp x16, Lcount334
ldr x17, [x16, :lo12:Lcount334]
add x17, x17, #1
str x17, [x16, :lo12:Lcount334]
ret
.globl stream_next_line
stream_next_line:
Lfn14:
adrp x16, Lcount335
ldr x17, [x16, :lo12:Lcount335]
add x17, x17, #1
str x17, [x16, :lo12:Lcount335]
stp x29, x30, [sp, #-16]!
adrp x16, Lcount336
ldr x17, [x16, :lo12:Lcount336]
add x17, x17, #1
str x17, [x16, :lo12:Lcount336]
mov x29, sp
adrp x16, Lcount337
ldr x17, [x16, :lo12:Lcount337]
add x17, x17, #1
str x17, [x16, :lo12:Lcount337]
sub sp, sp, #64
adrp x16, Lcount338
ldr x17, [x16, :lo12:Lcount338]
add x17, x17, #1
str x17, [x16, :lo12:Lcount338]
str xzr, [sp, #56]
adrp x16, Lcount338
ldr x17, [x16, :lo12:Lcount338]
add x17, x17, #1
str x17, [x16, :lo12:Lcount338]
str x0, [sp, #48]
adrp x16, Lcount339
ldr x17, [x16, :lo12:Lcount339]
add x17, x17, #1
str x17, [x16, :lo12:Lcount339]
add x0, sp, #16
adrp x16, Lcount339
ldr x17, [x16, :lo12:Lcount339]
add x17, x17, #1
str x17, [x16, :lo12:Lcount339]
add x1, sp, #48
adrp x16, Lcount336
ldr x17, [x16, :lo12:Lcount336]
add x17, x17, #1
str x17, [x16, :lo12:Lcount336]
mov x2, #2
adrp x16, Lcount340
ldr x17, [x16, :lo12:Lcount340]
add x17, x17, #1
str x17, [x16, :lo12:Lcount340]
bl fen_enter
adrp x16, Lcount341
ldr x17, [x16, :lo12:Lcount341]
add x17, x17, #1
str x17, [x16, :lo12:Lcount341]
ldr x0, [sp, #48]
adrp x16, Lcount342
ldr x17, [x16, :lo12:Lcount342]
add x17, x17, #1
str x17, [x16, :lo12:Lcount342]
ldr w0, [x0, #72]
adrp x16, Lcount343
ldr x17, [x16, :lo12:Lcount343]
add x17, x17, #1
str x17, [x16, :lo12:Lcount343]
cmp w0, #7
adrp x16, Lcount344
ldr x17, [x16, :lo12:Lcount344]
add x17, x17, #1
str x17, [x16, :lo12:Lcount344]
b.eq Lfn14match1295arm7
adrp x16, Lcount343
ldr x17, [x16, :lo12:Lcount343]
add x17, x17, #1
str x17, [x16, :lo12:Lcount343]
cmp w0, #8
adrp x16, Lcount344
ldr x17, [x16, :lo12:Lcount344]
add x17, x17, #1
str x17, [x16, :lo12:Lcount344]
b.eq Lfn14match1295arm8
adrp x16, Lcount345
ldr x17, [x16, :lo12:Lcount345]
add x17, x17, #1
str x17, [x16, :lo12:Lcount345]
brk #0
Lfn14match1295arm7:
adrp x16, Lcount346
ldr x17, [x16, :lo12:Lcount346]
add x17, x17, #1
str x17, [x16, :lo12:Lcount346]
adrp x0, Lconstant16
adrp x16, Lcount339
ldr x17, [x16, :lo12:Lcount339]
add x17, x17, #1
str x17, [x16, :lo12:Lcount339]
add x0, x0, :lo12:Lconstant16
adrp x16, Lcount347
ldr x17, [x16, :lo12:Lcount347]
add x17, x17, #1
str x17, [x16, :lo12:Lcount347]
b Lfn14match1295end
Lfn14match1295arm8:
adrp x16, Lcount341
ldr x17, [x16, :lo12:Lcount341]
add x17, x17, #1
str x17, [x16, :lo12:Lcount341]
ldr x8, [sp, #48]
adrp x16, Lcount342
ldr x17, [x16, :lo12:Lcount342]
add x17, x17, #1
str x17, [x16, :lo12:Lcount342]
ldr x8, [x8, #0]
adrp x16, Lcount341
ldr x17, [x16, :lo12:Lcount341]
add x17, x17, #1
str x17, [x16, :lo12:Lcount341]
ldr x9, [sp, #48]
adrp x16, Lcount342
ldr x17, [x16, :lo12:Lcount342]
add x17, x17, #1
str x17, [x16, :lo12:Lcount342]
ldr x9, [x9, #8]
adrp x16, Lcount341
ldr x17, [x16, :lo12:Lcount341]
add x17, x17, #1
str x17, [x16, :lo12:Lcount341]
ldr x10, [sp, #48]
adrp x16, Lcount342
ldr x17, [x16, :lo12:Lcount342]
add x17, x17, #1
str x17, [x16, :lo12:Lcount342]
ldr x10, [x10, #16]
adrp x16, Lcount341
ldr x17, [x16, :lo12:Lcount341]
add x17, x17, #1
str x17, [x16, :lo12:Lcount341]
ldr x11, [sp, #48]
adrp x16, Lcount342
ldr x17, [x16, :lo12:Lcount342]
add x17, x17, #1
str x17, [x16, :lo12:Lcount342]
ldr x11, [x11, #24]
adrp x16, Lcount348
ldr x17, [x16, :lo12:Lcount348]
add x17, x17, #1
str x17, [x16, :lo12:Lcount348]
bl Lfn12fields
adrp x16, Lcount349
ldr x17, [x16, :lo12:Lcount349]
add x17, x17, #1
str x17, [x16, :lo12:Lcount349]
cbnz x1, Lfn14end
adrp x16, Lcount338
ldr x17, [x16, :lo12:Lcount338]
add x17, x17, #1
str x17, [x16, :lo12:Lcount338]
str x0, [sp, #56]
adrp x16, Lcount336
ldr x17, [x16, :lo12:Lcount336]
add x17, x17, #1
str x17, [x16, :lo12:Lcount336]
mov x0, #3
adrp x16, Lcount336
ldr x17, [x16, :lo12:Lcount336]
add x17, x17, #1
str x17, [x16, :lo12:Lcount336]
mov x1, #21
adrp x16, Lcount350
ldr x17, [x16, :lo12:Lcount350]
add x17, x17, #1
str x17, [x16, :lo12:Lcount350]
bl fen_allocate
adrp x16, Lcount351
ldr x17, [x16, :lo12:Lcount351]
add x17, x17, #1
str x17, [x16, :lo12:Lcount351]
cbz x0, Lfn14fail1303_3
adrp x16, Lcount341
ldr x17, [x16, :lo12:Lcount341]
add x17, x17, #1
str x17, [x16, :lo12:Lcount341]
ldr x2, [sp, #56]
adrp x16, Lcount341
ldr x17, [x16, :lo12:Lcount341]
add x17, x17, #1
str x17, [x16, :lo12:Lcount341]
ldr x3, [sp, #48]
adrp x16, Lcount342
ldr x17, [x16, :lo12:Lcount342]
add x17, x17, #1
str x17, [x16, :lo12:Lcount342]
ldr x3, [x3, #32]
adrp x16, Lcount352
ldr x17, [x16, :lo12:Lcount352]
add x17, x17, #1
str x17, [x16, :lo12:Lcount352]
stp x2, x3, [x0, #0]
adrp x16, Lcount347
ldr x17, [x16, :lo12:Lcount347]
add x17, x17, #1
str x17, [x16, :lo12:Lcount347]
b Lfn14match1295end
Lfn14match1295end:
adrp x16, Lcount336
ldr x17, [x16, :lo12:Lcount336]
add x17, x17, #1
str x17, [x16, :lo12:Lcount336]
mov x1, #0
adrp x16, Lcount347
ldr x17, [x16, :lo12:Lcount347]
add x17, x17, #1
str x17, [x16, :lo12:Lcount347]
b Lfn14end
Lfn14fail1303_3:
adrp x16, Lcount346
ldr x17, [x16, :lo12:Lcount346]
add x17, x17, #1
str x17, [x16, :lo12:Lcount346]
adrp x0, Lfn14fail1303_3location
adrp x16, Lcount339
ldr x17, [x16, :lo12:Lcount339]
add x17, x17, #1
str x17, [x16, :lo12:Lcount339]
add x0, x0, :lo12:Lfn14fail1303_3location
adrp x16, Lcount353
ldr x17, [x16, :lo12:Lcount353]
add x17, x17, #1
str x17, [x16, :lo12:Lcount353]
bl fen_set_location
adrp x16, Lcount336
ldr x17, [x16, :lo12:Lcount336]
add x17, x17, #1
str x17, [x16, :lo12:Lcount336]
mov x1, #3
adrp x16, Lcount347
ldr x17, [x16, :lo12:Lcount347]
add x17, x17, #1
str x17, [x16, :lo12:Lcount347]
b Lfn14end
Lfn14end:
adrp x16, Lcount354
ldr x17, [x16, :lo12:Lcount354]
add x17, x17, #1
str x17, [x16, :lo12:Lcount354]
bl fen_leave_result
adrp x16, Lcount336
ldr x17, [x16, :lo12:Lcount336]
add x17, x17, #1
str x17, [x16, :lo12:Lcount336]
mov sp, x29
adrp x16, Lcount355
ldr x17, [x16, :lo12:Lcount355]
add x17, x17, #1
str x17, [x16, :lo12:Lcount355]
ldp x29, x30, [sp], #16
adrp x16, Lcount356
ldr x17, [x16, :lo12:Lcount356]
add x17, x17, #1
str x17, [x16, :lo12:Lcount356]
ret
.globl fenrir_entry
fenrir_entry:
Lfn15:
adrp x16, Lcount357
ldr x17, [x16, :lo12:Lcount357]
add x17, x17, #1
str x17, [x16, :lo12:Lcount357]
stp x29, x30, [sp, #-16]!
adrp x16, Lcount358
ldr x17, [x16, :lo12:Lcount358]
add x17, x17, #1
str x17, [x16, :lo12:Lcount358]
mov x29, sp
adrp x16, Lcount359
ldr x17, [x16, :lo12:Lcount359]
add x17, x17, #1
str x17, [x16, :lo12:Lcount359]
sub sp, sp, #64
adrp x16, Lcount360
ldr x17, [x16, :lo12:Lcount360]
add x17, x17, #1
str x17, [x16, :lo12:Lcount360]
str x0, [sp, #48]
adrp x16, Lcount361
ldr x17, [x16, :lo12:Lcount361]
add x17, x17, #1
str x17, [x16, :lo12:Lcount361]
adrp x0, Lconstant17
adrp x16, Lcount362
ldr x17, [x16, :lo12:Lcount362]
add x17, x17, #1
str x17, [x16, :lo12:Lcount362]
add x0, x0, :lo12:Lconstant17
adrp x16, Lcount358
ldr x17, [x16, :lo12:Lcount358]
add x17, x17, #1
str x17, [x16, :lo12:Lcount358]
mov x1, #0
adrp x16, Lcount363
ldr x17, [x16, :lo12:Lcount363]
add x17, x17, #1
str x17, [x16, :lo12:Lcount363]
b Lfn15end
Lfn15end:
adrp x16, Lcount358
ldr x17, [x16, :lo12:Lcount358]
add x17, x17, #1
str x17, [x16, :lo12:Lcount358]
mov sp, x29
adrp x16, Lcount364
ldr x17, [x16, :lo12:Lcount364]
add x17, x17, #1
str x17, [x16, :lo12:Lcount364]
ldp x29, x30, [sp], #16
adrp x16, Lcount365
ldr x17, [x16, :lo12:Lcount365]
add x17, x17, #1
str x17, [x16, :lo12:Lcount365]
ret
.globl stream_invalid_offset
stream_invalid_offset:
Lfn16:
adrp x16, Lcount366
ldr x17, [x16, :lo12:Lcount366]
add x17, x17, #1
str x17, [x16, :lo12:Lcount366]
stp x29, x30, [sp, #-16]!
adrp x16, Lcount367
ldr x17, [x16, :lo12:Lcount367]
add x17, x17, #1
str x17, [x16, :lo12:Lcount367]
mov x29, sp
adrp x16, Lcount368
ldr x17, [x16, :lo12:Lcount368]
add x17, x17, #1
str x17, [x16, :lo12:Lcount368]
sub sp, sp, #64
adrp x16, Lcount369
ldr x17, [x16, :lo12:Lcount369]
add x17, x17, #1
str x17, [x16, :lo12:Lcount369]
str x0, [sp, #48]
adrp x16, Lcount370
ldr x17, [x16, :lo12:Lcount370]
add x17, x17, #1
str x17, [x16, :lo12:Lcount370]
ldr x0, [sp, #48]
adrp x16, Lcount371
ldr x17, [x16, :lo12:Lcount371]
add x17, x17, #1
str x17, [x16, :lo12:Lcount371]
ldr w0, [x0, #72]
adrp x16, Lcount372
ldr x17, [x16, :lo12:Lcount372]
add x17, x17, #1
str x17, [x16, :lo12:Lcount372]
cmp w0, #13
adrp x16, Lcount373
ldr x17, [x16, :lo12:Lcount373]
add x17, x17, #1
str x17, [x16, :lo12:Lcount373]
b.eq Lfn16match1318arm13
adrp x16, Lcount372
ldr x17, [x16, :lo12:Lcount372]
add x17, x17, #1
str x17, [x16, :lo12:Lcount372]
cmp w0, #14
adrp x16, Lcount373
ldr x17, [x16, :lo12:Lcount373]
add x17, x17, #1
str x17, [x16, :lo12:Lcount373]
b.eq Lfn16match1318arm14
adrp x16, Lcount372
ldr x17, [x16, :lo12:Lcount372]
add x17, x17, #1
str x17, [x16, :lo12:Lcount372]
cmp w0, #15
adrp x16, Lcount373
ldr x17, [x16, :lo12:Lcount373]
add x17, x17, #1
str x17, [x16, :lo12:Lcount373]
b.eq Lfn16match1318arm15
adrp x16, Lcount372
ldr x17, [x16, :lo12:Lcount372]
add x17, x17, #1
str x17, [x16, :lo12:Lcount372]
cmp w0, #16
adrp x16, Lcount373
ldr x17, [x16, :lo12:Lcount373]
add x17, x17, #1
str x17, [x16, :lo12:Lcount373]
b.eq Lfn16match1318arm16
adrp x16, Lcount372
ldr x17, [x16, :lo12:Lcount372]
add x17, x17, #1
str x17, [x16, :lo12:Lcount372]
cmp w0, #17
adrp x16, Lcount373
ldr x17, [x16, :lo12:Lcount373]
add x17, x17, #1
str x17, [x16, :lo12:Lcount373]
b.eq Lfn16match1318arm17
adrp x16, Lcount374
ldr x17, [x16, :lo12:Lcount374]
add x17, x17, #1
str x17, [x16, :lo12:Lcount374]
brk #0
Lfn16match1318arm13:
adrp x16, Lcount375
ldr x17, [x16, :lo12:Lcount375]
add x17, x17, #1
str x17, [x16, :lo12:Lcount375]
movn x0, #0, lsl #0
adrp x16, Lcount376
ldr x17, [x16, :lo12:Lcount376]
add x17, x17, #1
str x17, [x16, :lo12:Lcount376]
b Lfn16match1318end
Lfn16match1318arm14:
adrp x16, Lcount375
ldr x17, [x16, :lo12:Lcount375]
add x17, x17, #1
str x17, [x16, :lo12:Lcount375]
movn x0, #0, lsl #0
adrp x16, Lcount376
ldr x17, [x16, :lo12:Lcount376]
add x17, x17, #1
str x17, [x16, :lo12:Lcount376]
b Lfn16match1318end
Lfn16match1318arm15:
adrp x16, Lcount375
ldr x17, [x16, :lo12:Lcount375]
add x17, x17, #1
str x17, [x16, :lo12:Lcount375]
movn x0, #0, lsl #0
adrp x16, Lcount376
ldr x17, [x16, :lo12:Lcount376]
add x17, x17, #1
str x17, [x16, :lo12:Lcount376]
b Lfn16match1318end
Lfn16match1318arm16:
adrp x16, Lcount375
ldr x17, [x16, :lo12:Lcount375]
add x17, x17, #1
str x17, [x16, :lo12:Lcount375]
movn x0, #0, lsl #0
adrp x16, Lcount376
ldr x17, [x16, :lo12:Lcount376]
add x17, x17, #1
str x17, [x16, :lo12:Lcount376]
b Lfn16match1318end
Lfn16match1318arm17:
adrp x16, Lcount370
ldr x17, [x16, :lo12:Lcount370]
add x17, x17, #1
str x17, [x16, :lo12:Lcount370]
ldr x0, [sp, #48]
adrp x16, Lcount371
ldr x17, [x16, :lo12:Lcount371]
add x17, x17, #1
str x17, [x16, :lo12:Lcount371]
ldr x0, [x0, #0]
adrp x16, Lcount376
ldr x17, [x16, :lo12:Lcount376]
add x17, x17, #1
str x17, [x16, :lo12:Lcount376]
b Lfn16match1318end
Lfn16match1318end:
adrp x16, Lcount367
ldr x17, [x16, :lo12:Lcount367]
add x17, x17, #1
str x17, [x16, :lo12:Lcount367]
mov x1, #0
adrp x16, Lcount376
ldr x17, [x16, :lo12:Lcount376]
add x17, x17, #1
str x17, [x16, :lo12:Lcount376]
b Lfn16end
Lfn16end:
adrp x16, Lcount367
ldr x17, [x16, :lo12:Lcount367]
add x17, x17, #1
str x17, [x16, :lo12:Lcount367]
mov sp, x29
adrp x16, Lcount377
ldr x17, [x16, :lo12:Lcount377]
add x17, x17, #1
str x17, [x16, :lo12:Lcount377]
ldp x29, x30, [sp], #16
adrp x16, Lcount378
ldr x17, [x16, :lo12:Lcount378]
add x17, x17, #1
str x17, [x16, :lo12:Lcount378]
ret
.globl stream_final_offset
stream_final_offset:
Lfn17:
adrp x16, Lcount379
ldr x17, [x16, :lo12:Lcount379]
add x17, x17, #1
str x17, [x16, :lo12:Lcount379]
stp x29, x30, [sp, #-16]!
adrp x16, Lcount380
ldr x17, [x16, :lo12:Lcount380]
add x17, x17, #1
str x17, [x16, :lo12:Lcount380]
mov x29, sp
adrp x16, Lcount381
ldr x17, [x16, :lo12:Lcount381]
add x17, x17, #1
str x17, [x16, :lo12:Lcount381]
sub sp, sp, #64
adrp x16, Lcount382
ldr x17, [x16, :lo12:Lcount382]
add x17, x17, #1
str x17, [x16, :lo12:Lcount382]
str x0, [sp, #48]
adrp x16, Lcount383
ldr x17, [x16, :lo12:Lcount383]
add x17, x17, #1
str x17, [x16, :lo12:Lcount383]
ldr x0, [sp, #48]
adrp x16, Lcount384
ldr x17, [x16, :lo12:Lcount384]
add x17, x17, #1
str x17, [x16, :lo12:Lcount384]
ldr w0, [x0, #72]
adrp x16, Lcount385
ldr x17, [x16, :lo12:Lcount385]
add x17, x17, #1
str x17, [x16, :lo12:Lcount385]
cmp w0, #18
adrp x16, Lcount386
ldr x17, [x16, :lo12:Lcount386]
add x17, x17, #1
str x17, [x16, :lo12:Lcount386]
b.eq Lfn17match1342arm18
adrp x16, Lcount385
ldr x17, [x16, :lo12:Lcount385]
add x17, x17, #1
str x17, [x16, :lo12:Lcount385]
cmp w0, #19
adrp x16, Lcount386
ldr x17, [x16, :lo12:Lcount386]
add x17, x17, #1
str x17, [x16, :lo12:Lcount386]
b.eq Lfn17match1342arm19
adrp x16, Lcount387
ldr x17, [x16, :lo12:Lcount387]
add x17, x17, #1
str x17, [x16, :lo12:Lcount387]
brk #0
Lfn17match1342arm18:
adrp x16, Lcount388
ldr x17, [x16, :lo12:Lcount388]
add x17, x17, #1
str x17, [x16, :lo12:Lcount388]
movn x0, #0, lsl #0
adrp x16, Lcount389
ldr x17, [x16, :lo12:Lcount389]
add x17, x17, #1
str x17, [x16, :lo12:Lcount389]
b Lfn17match1342end
Lfn17match1342arm19:
adrp x16, Lcount383
ldr x17, [x16, :lo12:Lcount383]
add x17, x17, #1
str x17, [x16, :lo12:Lcount383]
ldr x0, [sp, #48]
adrp x16, Lcount384
ldr x17, [x16, :lo12:Lcount384]
add x17, x17, #1
str x17, [x16, :lo12:Lcount384]
ldr x0, [x0, #0]
adrp x16, Lcount389
ldr x17, [x16, :lo12:Lcount389]
add x17, x17, #1
str x17, [x16, :lo12:Lcount389]
b Lfn17match1342end
Lfn17match1342end:
adrp x16, Lcount380
ldr x17, [x16, :lo12:Lcount380]
add x17, x17, #1
str x17, [x16, :lo12:Lcount380]
mov x1, #0
adrp x16, Lcount389
ldr x17, [x16, :lo12:Lcount389]
add x17, x17, #1
str x17, [x16, :lo12:Lcount389]
b Lfn17end
Lfn17end:
adrp x16, Lcount380
ldr x17, [x16, :lo12:Lcount380]
add x17, x17, #1
str x17, [x16, :lo12:Lcount380]
mov sp, x29
adrp x16, Lcount390
ldr x17, [x16, :lo12:Lcount390]
add x17, x17, #1
str x17, [x16, :lo12:Lcount390]
ldp x29, x30, [sp], #16
adrp x16, Lcount391
ldr x17, [x16, :lo12:Lcount391]
add x17, x17, #1
str x17, [x16, :lo12:Lcount391]
ret
.globl stream_summary_keys
stream_summary_keys:
Lfn18:
adrp x16, Lcount392
ldr x17, [x16, :lo12:Lcount392]
add x17, x17, #1
str x17, [x16, :lo12:Lcount392]
stp x29, x30, [sp, #-16]!
adrp x16, Lcount393
ldr x17, [x16, :lo12:Lcount393]
add x17, x17, #1
str x17, [x16, :lo12:Lcount393]
mov x29, sp
adrp x16, Lcount394
ldr x17, [x16, :lo12:Lcount394]
add x17, x17, #1
str x17, [x16, :lo12:Lcount394]
sub sp, sp, #64
adrp x16, Lcount395
ldr x17, [x16, :lo12:Lcount395]
add x17, x17, #1
str x17, [x16, :lo12:Lcount395]
str x0, [sp, #48]
adrp x16, Lcount396
ldr x17, [x16, :lo12:Lcount396]
add x17, x17, #1
str x17, [x16, :lo12:Lcount396]
ldr x0, [sp, #48]
adrp x16, Lcount397
ldr x17, [x16, :lo12:Lcount397]
add x17, x17, #1
str x17, [x16, :lo12:Lcount397]
ldr w0, [x0, #72]
adrp x16, Lcount398
ldr x17, [x16, :lo12:Lcount398]
add x17, x17, #1
str x17, [x16, :lo12:Lcount398]
cmp w0, #18
adrp x16, Lcount399
ldr x17, [x16, :lo12:Lcount399]
add x17, x17, #1
str x17, [x16, :lo12:Lcount399]
b.eq Lfn18match1350arm18
adrp x16, Lcount398
ldr x17, [x16, :lo12:Lcount398]
add x17, x17, #1
str x17, [x16, :lo12:Lcount398]
cmp w0, #19
adrp x16, Lcount399
ldr x17, [x16, :lo12:Lcount399]
add x17, x17, #1
str x17, [x16, :lo12:Lcount399]
b.eq Lfn18match1350arm19
adrp x16, Lcount400
ldr x17, [x16, :lo12:Lcount400]
add x17, x17, #1
str x17, [x16, :lo12:Lcount400]
brk #0
Lfn18match1350arm18:
adrp x16, Lcount396
ldr x17, [x16, :lo12:Lcount396]
add x17, x17, #1
str x17, [x16, :lo12:Lcount396]
ldr x0, [sp, #48]
adrp x16, Lcount397
ldr x17, [x16, :lo12:Lcount397]
add x17, x17, #1
str x17, [x16, :lo12:Lcount397]
ldr x0, [x0, #0]
adrp x16, Lcount401
ldr x17, [x16, :lo12:Lcount401]
add x17, x17, #1
str x17, [x16, :lo12:Lcount401]
b Lfn18match1350end
Lfn18match1350arm19:
adrp x16, Lcount402
ldr x17, [x16, :lo12:Lcount402]
add x17, x17, #1
str x17, [x16, :lo12:Lcount402]
adrp x0, Lconstant2
adrp x16, Lcount403
ldr x17, [x16, :lo12:Lcount403]
add x17, x17, #1
str x17, [x16, :lo12:Lcount403]
add x0, x0, :lo12:Lconstant2
adrp x16, Lcount401
ldr x17, [x16, :lo12:Lcount401]
add x17, x17, #1
str x17, [x16, :lo12:Lcount401]
b Lfn18match1350end
Lfn18match1350end:
adrp x16, Lcount393
ldr x17, [x16, :lo12:Lcount393]
add x17, x17, #1
str x17, [x16, :lo12:Lcount393]
mov x1, #0
adrp x16, Lcount401
ldr x17, [x16, :lo12:Lcount401]
add x17, x17, #1
str x17, [x16, :lo12:Lcount401]
b Lfn18end
Lfn18end:
adrp x16, Lcount393
ldr x17, [x16, :lo12:Lcount393]
add x17, x17, #1
str x17, [x16, :lo12:Lcount393]
mov sp, x29
adrp x16, Lcount404
ldr x17, [x16, :lo12:Lcount404]
add x17, x17, #1
str x17, [x16, :lo12:Lcount404]
ldp x29, x30, [sp], #16
adrp x16, Lcount405
ldr x17, [x16, :lo12:Lcount405]
add x17, x17, #1
str x17, [x16, :lo12:Lcount405]
ret
.globl stream_line_bytes
stream_line_bytes:
Lfn19:
adrp x16, Lcount406
ldr x17, [x16, :lo12:Lcount406]
add x17, x17, #1
str x17, [x16, :lo12:Lcount406]
stp x29, x30, [sp, #-16]!
adrp x16, Lcount407
ldr x17, [x16, :lo12:Lcount407]
add x17, x17, #1
str x17, [x16, :lo12:Lcount407]
mov x29, sp
adrp x16, Lcount408
ldr x17, [x16, :lo12:Lcount408]
add x17, x17, #1
str x17, [x16, :lo12:Lcount408]
sub sp, sp, #64
adrp x16, Lcount409
ldr x17, [x16, :lo12:Lcount409]
add x17, x17, #1
str x17, [x16, :lo12:Lcount409]
str x0, [sp, #48]
adrp x16, Lcount410
ldr x17, [x16, :lo12:Lcount410]
add x17, x17, #1
str x17, [x16, :lo12:Lcount410]
ldr x0, [sp, #48]
adrp x16, Lcount411
ldr x17, [x16, :lo12:Lcount411]
add x17, x17, #1
str x17, [x16, :lo12:Lcount411]
ldr w0, [x0, #72]
adrp x16, Lcount412
ldr x17, [x16, :lo12:Lcount412]
add x17, x17, #1
str x17, [x16, :lo12:Lcount412]
cmp w0, #20
adrp x16, Lcount413
ldr x17, [x16, :lo12:Lcount413]
add x17, x17, #1
str x17, [x16, :lo12:Lcount413]
b.eq Lfn19match1358arm20
adrp x16, Lcount412
ldr x17, [x16, :lo12:Lcount412]
add x17, x17, #1
str x17, [x16, :lo12:Lcount412]
cmp w0, #21
adrp x16, Lcount413
ldr x17, [x16, :lo12:Lcount413]
add x17, x17, #1
str x17, [x16, :lo12:Lcount413]
b.eq Lfn19match1358arm21
adrp x16, Lcount414
ldr x17, [x16, :lo12:Lcount414]
add x17, x17, #1
str x17, [x16, :lo12:Lcount414]
brk #0
Lfn19match1358arm20:
adrp x16, Lcount415
ldr x17, [x16, :lo12:Lcount415]
add x17, x17, #1
str x17, [x16, :lo12:Lcount415]
adrp x0, Lconstant18
adrp x16, Lcount416
ldr x17, [x16, :lo12:Lcount416]
add x17, x17, #1
str x17, [x16, :lo12:Lcount416]
add x0, x0, :lo12:Lconstant18
adrp x16, Lcount417
ldr x17, [x16, :lo12:Lcount417]
add x17, x17, #1
str x17, [x16, :lo12:Lcount417]
b Lfn19match1358end
Lfn19match1358arm21:
adrp x16, Lcount410
ldr x17, [x16, :lo12:Lcount410]
add x17, x17, #1
str x17, [x16, :lo12:Lcount410]
ldr x0, [sp, #48]
adrp x16, Lcount411
ldr x17, [x16, :lo12:Lcount411]
add x17, x17, #1
str x17, [x16, :lo12:Lcount411]
ldr x0, [x0, #0]
adrp x16, Lcount417
ldr x17, [x16, :lo12:Lcount417]
add x17, x17, #1
str x17, [x16, :lo12:Lcount417]
b Lfn19match1358end
Lfn19match1358end:
adrp x16, Lcount407
ldr x17, [x16, :lo12:Lcount407]
add x17, x17, #1
str x17, [x16, :lo12:Lcount407]
mov x1, #0
adrp x16, Lcount417
ldr x17, [x16, :lo12:Lcount417]
add x17, x17, #1
str x17, [x16, :lo12:Lcount417]
b Lfn19end
Lfn19end:
adrp x16, Lcount407
ldr x17, [x16, :lo12:Lcount407]
add x17, x17, #1
str x17, [x16, :lo12:Lcount407]
mov sp, x29
adrp x16, Lcount418
ldr x17, [x16, :lo12:Lcount418]
add x17, x17, #1
str x17, [x16, :lo12:Lcount418]
ldp x29, x30, [sp], #16
adrp x16, Lcount419
ldr x17, [x16, :lo12:Lcount419]
add x17, x17, #1
str x17, [x16, :lo12:Lcount419]
ret
.globl stream_remaining_keys
stream_remaining_keys:
Lfn20:
adrp x16, Lcount420
ldr x17, [x16, :lo12:Lcount420]
add x17, x17, #1
str x17, [x16, :lo12:Lcount420]
stp x29, x30, [sp, #-16]!
adrp x16, Lcount421
ldr x17, [x16, :lo12:Lcount421]
add x17, x17, #1
str x17, [x16, :lo12:Lcount421]
mov x29, sp
adrp x16, Lcount422
ldr x17, [x16, :lo12:Lcount422]
add x17, x17, #1
str x17, [x16, :lo12:Lcount422]
sub sp, sp, #64
adrp x16, Lcount423
ldr x17, [x16, :lo12:Lcount423]
add x17, x17, #1
str x17, [x16, :lo12:Lcount423]
str x0, [sp, #48]
adrp x16, Lcount424
ldr x17, [x16, :lo12:Lcount424]
add x17, x17, #1
str x17, [x16, :lo12:Lcount424]
ldr x0, [sp, #48]
adrp x16, Lcount425
ldr x17, [x16, :lo12:Lcount425]
add x17, x17, #1
str x17, [x16, :lo12:Lcount425]
ldr w0, [x0, #72]
adrp x16, Lcount426
ldr x17, [x16, :lo12:Lcount426]
add x17, x17, #1
str x17, [x16, :lo12:Lcount426]
cmp w0, #20
adrp x16, Lcount427
ldr x17, [x16, :lo12:Lcount427]
add x17, x17, #1
str x17, [x16, :lo12:Lcount427]
b.eq Lfn20match1366arm20
adrp x16, Lcount426
ldr x17, [x16, :lo12:Lcount426]
add x17, x17, #1
str x17, [x16, :lo12:Lcount426]
cmp w0, #21
adrp x16, Lcount427
ldr x17, [x16, :lo12:Lcount427]
add x17, x17, #1
str x17, [x16, :lo12:Lcount427]
b.eq Lfn20match1366arm21
adrp x16, Lcount428
ldr x17, [x16, :lo12:Lcount428]
add x17, x17, #1
str x17, [x16, :lo12:Lcount428]
brk #0
Lfn20match1366arm20:
adrp x16, Lcount429
ldr x17, [x16, :lo12:Lcount429]
add x17, x17, #1
str x17, [x16, :lo12:Lcount429]
adrp x0, Lconstant2
adrp x16, Lcount430
ldr x17, [x16, :lo12:Lcount430]
add x17, x17, #1
str x17, [x16, :lo12:Lcount430]
add x0, x0, :lo12:Lconstant2
adrp x16, Lcount431
ldr x17, [x16, :lo12:Lcount431]
add x17, x17, #1
str x17, [x16, :lo12:Lcount431]
b Lfn20match1366end
Lfn20match1366arm21:
adrp x16, Lcount424
ldr x17, [x16, :lo12:Lcount424]
add x17, x17, #1
str x17, [x16, :lo12:Lcount424]
ldr x0, [sp, #48]
adrp x16, Lcount425
ldr x17, [x16, :lo12:Lcount425]
add x17, x17, #1
str x17, [x16, :lo12:Lcount425]
ldr x0, [x0, #8]
adrp x16, Lcount431
ldr x17, [x16, :lo12:Lcount431]
add x17, x17, #1
str x17, [x16, :lo12:Lcount431]
b Lfn20match1366end
Lfn20match1366end:
adrp x16, Lcount421
ldr x17, [x16, :lo12:Lcount421]
add x17, x17, #1
str x17, [x16, :lo12:Lcount421]
mov x1, #0
adrp x16, Lcount431
ldr x17, [x16, :lo12:Lcount431]
add x17, x17, #1
str x17, [x16, :lo12:Lcount431]
b Lfn20end
Lfn20end:
adrp x16, Lcount421
ldr x17, [x16, :lo12:Lcount421]
add x17, x17, #1
str x17, [x16, :lo12:Lcount421]
mov sp, x29
adrp x16, Lcount432
ldr x17, [x16, :lo12:Lcount432]
add x17, x17, #1
str x17, [x16, :lo12:Lcount432]
ldp x29, x30, [sp], #16
adrp x16, Lcount433
ldr x17, [x16, :lo12:Lcount433]
add x17, x17, #1
str x17, [x16, :lo12:Lcount433]
ret
.text
.globl fen_print_result
fen_print_result:
b Lprint0
Lprint0:
stp x19, x30, [sp, #-16]!
mov x19, x0
bl fen_tag
mov x1, #13
cmp x0, x1
b.eq Lprint0v13
mov x1, #14
cmp x0, x1
b.eq Lprint0v14
mov x1, #15
cmp x0, x1
b.eq Lprint0v15
mov x1, #16
cmp x0, x1
b.eq Lprint0v16
mov x1, #17
cmp x0, x1
b.eq Lprint0v17
brk #0
Lprint0v13:
adrp x0, Lstr0
add x0, x0, :lo12:Lstr0
mov x1, #9
bl fen_write
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #0]
bl Lprint1
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #8]
bl Lprint2
adrp x0, Lstr2
add x0, x0, :lo12:Lstr2
mov x1, #1
bl fen_write
b Lprint0done
Lprint0v14:
adrp x0, Lstr3
add x0, x0, :lo12:Lstr3
mov x1, #9
bl fen_write
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #0]
bl Lprint1
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #8]
bl Lprint1
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #16]
bl Lprint2
adrp x0, Lstr2
add x0, x0, :lo12:Lstr2
mov x1, #1
bl fen_write
b Lprint0done
Lprint0v15:
adrp x0, Lstr4
add x0, x0, :lo12:Lstr4
mov x1, #8
bl fen_write
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #0]
bl Lprint1
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #8]
bl Lprint1
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #16]
bl Lprint2
adrp x0, Lstr2
add x0, x0, :lo12:Lstr2
mov x1, #1
bl fen_write
b Lprint0done
Lprint0v16:
adrp x0, Lstr5
add x0, x0, :lo12:Lstr5
mov x1, #8
bl fen_write
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #0]
bl Lprint1
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #8]
bl Lprint1
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #16]
bl Lprint1
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #24]
bl Lprint1
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #32]
bl Lprint1
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #40]
bl Lprint2
adrp x0, Lstr2
add x0, x0, :lo12:Lstr2
mov x1, #1
bl fen_write
b Lprint0done
Lprint0v17:
adrp x0, Lstr6
add x0, x0, :lo12:Lstr6
mov x1, #8
bl fen_write
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #0]
bl Lprint1
adrp x0, Lstr2
add x0, x0, :lo12:Lstr2
mov x1, #1
bl fen_write
b Lprint0done
Lprint0done:
ldp x19, x30, [sp], #16
ret
Lprint1:
b fen_write_i64
Lprint2:
stp x19, x30, [sp, #-16]!
mov x19, x0
bl fen_tag
mov x1, #9
cmp x0, x1
b.eq Lprint2v9
mov x1, #10
cmp x0, x1
b.eq Lprint2v10
mov x1, #11
cmp x0, x1
b.eq Lprint2v11
mov x1, #12
cmp x0, x1
b.eq Lprint2v12
brk #0
Lprint2v9:
adrp x0, Lstr7
add x0, x0, :lo12:Lstr7
mov x1, #6
bl fen_write
b Lprint2done
Lprint2v10:
adrp x0, Lstr8
add x0, x0, :lo12:Lstr8
mov x1, #5
bl fen_write
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #0]
bl Lprint1
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #8]
bl Lprint1
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #16]
bl Lprint1
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #24]
bl Lprint1
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #32]
bl Lprint1
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #40]
bl Lprint1
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #48]
bl Lprint1
adrp x0, Lstr2
add x0, x0, :lo12:Lstr2
mov x1, #1
bl fen_write
b Lprint2done
Lprint2v11:
adrp x0, Lstr9
add x0, x0, :lo12:Lstr9
mov x1, #6
bl fen_write
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #0]
bl Lprint2
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #8]
bl Lprint2
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #16]
bl Lprint2
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #24]
bl Lprint2
adrp x0, Lstr2
add x0, x0, :lo12:Lstr2
mov x1, #1
bl fen_write
b Lprint2done
Lprint2v12:
adrp x0, Lstr10
add x0, x0, :lo12:Lstr10
mov x1, #7
bl fen_write
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #0]
bl Lprint2
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #8]
bl Lprint2
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #16]
bl Lprint2
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #24]
bl Lprint2
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #32]
bl Lprint2
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #40]
bl Lprint2
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #48]
bl Lprint2
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #56]
bl Lprint2
adrp x0, Lstr2
add x0, x0, :lo12:Lstr2
mov x1, #1
bl fen_write
b Lprint2done
Lprint2done:
ldp x19, x30, [sp], #16
ret
Lstr0:
.byte 40,76,101,110,103,116,104,72,105
Lstr1:
.byte 32
Lstr2:
.byte 41
Lstr3:
.byte 40,76,101,110,103,116,104,76,111
Lstr4:
.byte 40,82,101,97,100,75,101,121
Lstr5:
.byte 40,80,97,121,108,111,97,100
Lstr6:
.byte 40,73,110,118,97,108,105,100
Lstr7:
.byte 86,97,99,97,110,116
Lstr8:
.byte 40,80,97,105,114
Lstr9:
.byte 40,71,114,111,117,112
Lstr10:
.byte 40,66,114,97,110,99,104
Lfn0fail20_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,51,58,51,52,10,0
Lfn0fail31_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,53,58,51,53,10,0
Lfn0fail39_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,53,58,54,52,10,0
Lfn0fail60_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,55,58,49,55,10,0
Lfn0fail63_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,55,58,50,53,10,0
Lfn0fail66_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,55,58,51,54,10,0
Lfn0fail58_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,55,58,57,10,0
Lfn0fail77_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,56,58,50,51,10,0
Lfn0fail80_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,56,58,51,49,10,0
Lfn0fail83_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,56,58,52,50,10,0
Lfn0fail72_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,56,58,57,10,0
.p2align 3
Lconstant0:
.zero 72
.long 9
.byte 0,2,0,0
Lfn1fail136_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,50,54,58,49,54,10,0
Lfn1fail172_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,51,50,58,49,57,10,0
Lfn1fail181_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,51,51,58,49,57,10,0
Lfn1fail194_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,51,53,58,49,57,10,0
Lfn1fail203_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,51,54,58,49,57,10,0
Lfn1fail220_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,51,57,58,49,57,10,0
Lfn1fail229_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,52,48,58,49,57,10,0
Lfn1fail242_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,52,50,58,49,57,10,0
Lfn1fail251_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,52,51,58,49,57,10,0
Lfn1fail299_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,53,48,58,49,53,10,0
Lfn1fail313_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,53,49,58,49,53,10,0
Lfn1fail331_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,53,51,58,49,53,10,0
Lfn1fail345_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,53,52,58,49,53,10,0
Lfn1fail367_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,53,55,58,49,53,10,0
Lfn1fail381_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,53,56,58,49,53,10,0
Lfn1fail399_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,54,48,58,49,53,10,0
Lfn1fail413_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,54,49,58,49,53,10,0
.section .rodata
.p2align 3
Lconstant1:
.quad Lconstant0
.quad Lconstant0
.quad Lconstant0
.quad Lconstant0
.zero 40
.long 11
.byte 15,2,0,0
.text
Lfn2fail491_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,55,50,58,49,51,10,0
Lfn2fail501_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,55,52,58,49,51,10,0
Lfn2fail515_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,55,55,58,49,51,10,0
Lfn2fail525_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,55,57,58,49,51,10,0
Lfn3fail563_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,56,53,58,54,50,10,0
Lfn3fail562_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,56,53,58,53,55,10,0
Lfn3fail575_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,56,54,58,50,52,10,0
Lfn4fail657_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,57,51,58,50,50,10,0
Lfn4fail663_4location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,57,51,58,52,49,10,0
Lfn4fail661_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,57,51,58,51,52,10,0
Lfn5fail703_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,57,55,58,54,57,10,0
Lfn5fail701_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,57,55,58,53,54,10,0
Lfn5fail711_4location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,57,56,58,49,54,10,0
Lfn5fail710_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,57,56,58,49,51,10,0
Lfn5fail717_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,57,57,58,49,56,10,0
Lfn5fail725_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,48,48,58,51,52,10,0
Lfn5fail729_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,48,48,58,52,54,10,0
Lfn5fail724_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,48,48,58,50,52,10,0
Lfn5fail735_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,48,48,58,54,57,10,0
Lfn5fail744_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,48,49,58,52,56,10,0
Lfn5fail742_4location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,48,49,58,50,57,10,0
Lfn5fail740_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,48,49,58,50,51,10,0
Lfn5fail751_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,48,50,58,51,48,10,0
Lfn5fail757_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,48,51,58,52,53,10,0
Lfn5fail755_4location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,48,51,58,50,54,10,0
Lfn5fail765_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,48,52,58,52,51,10,0
Lfn5fail764_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,48,52,58,51,52,10,0
Lfn5fail770_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,48,53,58,51,50,10,0
Lfn5fail775_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,48,54,58,51,48,10,0
Lfn5fail781_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,48,55,58,51,53,10,0
Lfn5fail787_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,48,56,58,51,54,10,0
Lfn5fail809_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,49,50,58,52,52,10,0
Lfn5fail808_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,49,50,58,52,49,10,0
Lfn5fail827_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,49,52,58,52,52,10,0
Lfn5fail826_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,49,52,58,52,49,10,0
Lfn5fail849_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,49,55,58,52,52,10,0
Lfn5fail848_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,49,55,58,52,49,10,0
Lfn5fail867_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,49,57,58,52,52,10,0
Lfn5fail866_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,49,57,58,52,49,10,0
Lfn5fail885_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,50,49,58,52,55,10,0
Lfn5fail892_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,50,49,58,54,54,10,0
Lfn5fail884_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,50,49,58,51,56,10,0
Lfn6fail949_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,50,55,58,51,52,10,0
Lfn6fail958_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,50,56,58,51,48,10,0
Lfn7fail999_4location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,51,54,58,50,53,10,0
Lfn7fail997_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,51,54,58,49,57,10,0
Lfn7fail1007_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,51,55,58,51,53,10,0
Lfn7fail1006_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,51,55,58,50,54,10,0
Lfn7fail1013_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,51,56,58,51,51,10,0
Lfn7fail1012_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,51,56,58,50,52,10,0
Lfn7fail1019_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,51,56,58,54,49,10,0
Lfn7fail1027_4location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,52,48,58,49,56,10,0
Lfn7fail1034_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,52,49,58,50,54,10,0
Lfn7fail1043_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,52,50,58,52,57,10,0
Lfn7fail1042_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,52,50,58,51,57,10,0
Lfn7fail1053_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,52,51,58,51,53,10,0
Lfn7fail1057_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,52,51,58,52,56,10,0
Lfn7fail1060_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,52,51,58,53,57,10,0
Lfn7fail1052_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,52,51,58,50,54,10,0
Lfn7fail1066_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,52,52,58,51,48,10,0
Lfn7fail1077_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,52,54,58,50,52,10,0
Lfn7fail1091_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,52,56,58,50,50,10,0
Lfn7fail1109_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,53,49,58,52,48,10,0
Lfn7fail1108_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,53,49,58,51,48,10,0
Lfn7fail1121_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,53,50,58,50,56,10,0
Lfn7fail1126_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,53,50,58,52,57,10,0
Lfn7fail1120_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,53,50,58,49,57,10,0
.p2align 3
Lconstant2:
.zero 72
.long 7
.byte 0,2,0,0
Lfn9fail1152_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,53,57,58,51,48,10,0
Lfn9fail1160_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,54,48,58,51,51,10,0
Lfn9fail1165_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,54,49,58,51,52,10,0
Lfn9fail1173_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,54,50,58,52,55,10,0
Lfn9fail1176_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,54,51,58,50,50,10,0
.p2align 3
Lconstant3:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 48
.p2align 3
Lconstant4:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 49
.p2align 3
Lconstant5:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 50
.p2align 3
Lconstant6:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 51
.p2align 3
Lconstant7:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 52
.p2align 3
Lconstant8:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 53
.p2align 3
Lconstant9:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 54
.p2align 3
Lconstant10:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 55
.p2align 3
Lconstant11:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 56
.p2align 3
Lconstant12:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 57
Lfn11fail1236_2location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,55,52,58,49,53,10,0
Lfn11fail1236_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,55,52,58,49,53,10,0
Lfn11fail1245_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,55,53,58,52,56,10,0
Lfn11fail1243_1location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,55,53,58,52,51,10,0
Lfn11fail1239_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,55,53,58,55,10,0
.p2align 3
Lconstant13:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 32
.p2align 3
Lconstant14:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 10
Lfn12fail1270_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,55,57,58,52,55,10,0
Lfn12fail1267_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,55,57,58,49,57,10,0
Lfn12fail1275_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,56,48,58,50,49,10,0
Lfn12fail1281_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,56,49,58,50,55,10,0
Lfn12fail1279_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,56,49,58,57,10,0
Lfn12fail1274_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,56,48,58,55,10,0
Lfn12fail1266_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,55,57,58,53,10,0
.p2align 3
Lconstant15:
.quad 7
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 114,101,106,101,99,116,32
Lfn13fail1289_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,56,52,58,51,55,10,0
Lfn13fail1287_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,56,52,58,49,51,10,0
.p2align 3
Lconstant16:
.zero 72
.long 20
.byte 0,2,0,0
Lfn14fail1303_3location:
.byte 116,114,97,112,32,97,116,58,32,112,114,111,99,101,115,115,111,114,46,102,101,110,58,49,57,50,58,55,10,0
.section .rodata
.p2align 3
Lconstant17:
.quad 0
.quad Lconstant0
.zero 56
.long 13
.byte 2,2,0,0
.text
.p2align 3
Lconstant18:
.quad 0
.zero 64
.long 4294967295
.byte 0,2,0,0
.data
.p2align 3
.globl counts
counts:
Lcount0:
.quad 0
Lcount1:
.quad 0
Lcount2:
.quad 0
Lcount3:
.quad 0
Lcount4:
.quad 0
Lcount5:
.quad 0
Lcount6:
.quad 0
Lcount7:
.quad 0
Lcount8:
.quad 0
Lcount9:
.quad 0
Lcount10:
.quad 0
Lcount11:
.quad 0
Lcount12:
.quad 0
Lcount13:
.quad 0
Lcount14:
.quad 0
Lcount15:
.quad 0
Lcount16:
.quad 0
Lcount17:
.quad 0
Lcount18:
.quad 0
Lcount19:
.quad 0
Lcount20:
.quad 0
Lcount21:
.quad 0
Lcount22:
.quad 0
Lcount23:
.quad 0
Lcount24:
.quad 0
Lcount25:
.quad 0
Lcount26:
.quad 0
Lcount27:
.quad 0
Lcount28:
.quad 0
Lcount29:
.quad 0
Lcount30:
.quad 0
Lcount31:
.quad 0
Lcount32:
.quad 0
Lcount33:
.quad 0
Lcount34:
.quad 0
Lcount35:
.quad 0
Lcount36:
.quad 0
Lcount37:
.quad 0
Lcount38:
.quad 0
Lcount39:
.quad 0
Lcount40:
.quad 0
Lcount41:
.quad 0
Lcount42:
.quad 0
Lcount43:
.quad 0
Lcount44:
.quad 0
Lcount45:
.quad 0
Lcount46:
.quad 0
Lcount47:
.quad 0
Lcount48:
.quad 0
Lcount49:
.quad 0
Lcount50:
.quad 0
Lcount51:
.quad 0
Lcount52:
.quad 0
Lcount53:
.quad 0
Lcount54:
.quad 0
Lcount55:
.quad 0
Lcount56:
.quad 0
Lcount57:
.quad 0
Lcount58:
.quad 0
Lcount59:
.quad 0
Lcount60:
.quad 0
Lcount61:
.quad 0
Lcount62:
.quad 0
Lcount63:
.quad 0
Lcount64:
.quad 0
Lcount65:
.quad 0
Lcount66:
.quad 0
Lcount67:
.quad 0
Lcount68:
.quad 0
Lcount69:
.quad 0
Lcount70:
.quad 0
Lcount71:
.quad 0
Lcount72:
.quad 0
Lcount73:
.quad 0
Lcount74:
.quad 0
Lcount75:
.quad 0
Lcount76:
.quad 0
Lcount77:
.quad 0
Lcount78:
.quad 0
Lcount79:
.quad 0
Lcount80:
.quad 0
Lcount81:
.quad 0
Lcount82:
.quad 0
Lcount83:
.quad 0
Lcount84:
.quad 0
Lcount85:
.quad 0
Lcount86:
.quad 0
Lcount87:
.quad 0
Lcount88:
.quad 0
Lcount89:
.quad 0
Lcount90:
.quad 0
Lcount91:
.quad 0
Lcount92:
.quad 0
Lcount93:
.quad 0
Lcount94:
.quad 0
Lcount95:
.quad 0
Lcount96:
.quad 0
Lcount97:
.quad 0
Lcount98:
.quad 0
Lcount99:
.quad 0
Lcount100:
.quad 0
Lcount101:
.quad 0
Lcount102:
.quad 0
Lcount103:
.quad 0
Lcount104:
.quad 0
Lcount105:
.quad 0
Lcount106:
.quad 0
Lcount107:
.quad 0
Lcount108:
.quad 0
Lcount109:
.quad 0
Lcount110:
.quad 0
Lcount111:
.quad 0
Lcount112:
.quad 0
Lcount113:
.quad 0
Lcount114:
.quad 0
Lcount115:
.quad 0
Lcount116:
.quad 0
Lcount117:
.quad 0
Lcount118:
.quad 0
Lcount119:
.quad 0
Lcount120:
.quad 0
Lcount121:
.quad 0
Lcount122:
.quad 0
Lcount123:
.quad 0
Lcount124:
.quad 0
Lcount125:
.quad 0
Lcount126:
.quad 0
Lcount127:
.quad 0
Lcount128:
.quad 0
Lcount129:
.quad 0
Lcount130:
.quad 0
Lcount131:
.quad 0
Lcount132:
.quad 0
Lcount133:
.quad 0
Lcount134:
.quad 0
Lcount135:
.quad 0
Lcount136:
.quad 0
Lcount137:
.quad 0
Lcount138:
.quad 0
Lcount139:
.quad 0
Lcount140:
.quad 0
Lcount141:
.quad 0
Lcount142:
.quad 0
Lcount143:
.quad 0
Lcount144:
.quad 0
Lcount145:
.quad 0
Lcount146:
.quad 0
Lcount147:
.quad 0
Lcount148:
.quad 0
Lcount149:
.quad 0
Lcount150:
.quad 0
Lcount151:
.quad 0
Lcount152:
.quad 0
Lcount153:
.quad 0
Lcount154:
.quad 0
Lcount155:
.quad 0
Lcount156:
.quad 0
Lcount157:
.quad 0
Lcount158:
.quad 0
Lcount159:
.quad 0
Lcount160:
.quad 0
Lcount161:
.quad 0
Lcount162:
.quad 0
Lcount163:
.quad 0
Lcount164:
.quad 0
Lcount165:
.quad 0
Lcount166:
.quad 0
Lcount167:
.quad 0
Lcount168:
.quad 0
Lcount169:
.quad 0
Lcount170:
.quad 0
Lcount171:
.quad 0
Lcount172:
.quad 0
Lcount173:
.quad 0
Lcount174:
.quad 0
Lcount175:
.quad 0
Lcount176:
.quad 0
Lcount177:
.quad 0
Lcount178:
.quad 0
Lcount179:
.quad 0
Lcount180:
.quad 0
Lcount181:
.quad 0
Lcount182:
.quad 0
Lcount183:
.quad 0
Lcount184:
.quad 0
Lcount185:
.quad 0
Lcount186:
.quad 0
Lcount187:
.quad 0
Lcount188:
.quad 0
Lcount189:
.quad 0
Lcount190:
.quad 0
Lcount191:
.quad 0
Lcount192:
.quad 0
Lcount193:
.quad 0
Lcount194:
.quad 0
Lcount195:
.quad 0
Lcount196:
.quad 0
Lcount197:
.quad 0
Lcount198:
.quad 0
Lcount199:
.quad 0
Lcount200:
.quad 0
Lcount201:
.quad 0
Lcount202:
.quad 0
Lcount203:
.quad 0
Lcount204:
.quad 0
Lcount205:
.quad 0
Lcount206:
.quad 0
Lcount207:
.quad 0
Lcount208:
.quad 0
Lcount209:
.quad 0
Lcount210:
.quad 0
Lcount211:
.quad 0
Lcount212:
.quad 0
Lcount213:
.quad 0
Lcount214:
.quad 0
Lcount215:
.quad 0
Lcount216:
.quad 0
Lcount217:
.quad 0
Lcount218:
.quad 0
Lcount219:
.quad 0
Lcount220:
.quad 0
Lcount221:
.quad 0
Lcount222:
.quad 0
Lcount223:
.quad 0
Lcount224:
.quad 0
Lcount225:
.quad 0
Lcount226:
.quad 0
Lcount227:
.quad 0
Lcount228:
.quad 0
Lcount229:
.quad 0
Lcount230:
.quad 0
Lcount231:
.quad 0
Lcount232:
.quad 0
Lcount233:
.quad 0
Lcount234:
.quad 0
Lcount235:
.quad 0
Lcount236:
.quad 0
Lcount237:
.quad 0
Lcount238:
.quad 0
Lcount239:
.quad 0
Lcount240:
.quad 0
Lcount241:
.quad 0
Lcount242:
.quad 0
Lcount243:
.quad 0
Lcount244:
.quad 0
Lcount245:
.quad 0
Lcount246:
.quad 0
Lcount247:
.quad 0
Lcount248:
.quad 0
Lcount249:
.quad 0
Lcount250:
.quad 0
Lcount251:
.quad 0
Lcount252:
.quad 0
Lcount253:
.quad 0
Lcount254:
.quad 0
Lcount255:
.quad 0
Lcount256:
.quad 0
Lcount257:
.quad 0
Lcount258:
.quad 0
Lcount259:
.quad 0
Lcount260:
.quad 0
Lcount261:
.quad 0
Lcount262:
.quad 0
Lcount263:
.quad 0
Lcount264:
.quad 0
Lcount265:
.quad 0
Lcount266:
.quad 0
Lcount267:
.quad 0
Lcount268:
.quad 0
Lcount269:
.quad 0
Lcount270:
.quad 0
Lcount271:
.quad 0
Lcount272:
.quad 0
Lcount273:
.quad 0
Lcount274:
.quad 0
Lcount275:
.quad 0
Lcount276:
.quad 0
Lcount277:
.quad 0
Lcount278:
.quad 0
Lcount279:
.quad 0
Lcount280:
.quad 0
Lcount281:
.quad 0
Lcount282:
.quad 0
Lcount283:
.quad 0
Lcount284:
.quad 0
Lcount285:
.quad 0
Lcount286:
.quad 0
Lcount287:
.quad 0
Lcount288:
.quad 0
Lcount289:
.quad 0
Lcount290:
.quad 0
Lcount291:
.quad 0
Lcount292:
.quad 0
Lcount293:
.quad 0
Lcount294:
.quad 0
Lcount295:
.quad 0
Lcount296:
.quad 0
Lcount297:
.quad 0
Lcount298:
.quad 0
Lcount299:
.quad 0
Lcount300:
.quad 0
Lcount301:
.quad 0
Lcount302:
.quad 0
Lcount303:
.quad 0
Lcount304:
.quad 0
Lcount305:
.quad 0
Lcount306:
.quad 0
Lcount307:
.quad 0
Lcount308:
.quad 0
Lcount309:
.quad 0
Lcount310:
.quad 0
Lcount311:
.quad 0
Lcount312:
.quad 0
Lcount313:
.quad 0
Lcount314:
.quad 0
Lcount315:
.quad 0
Lcount316:
.quad 0
Lcount317:
.quad 0
Lcount318:
.quad 0
Lcount319:
.quad 0
Lcount320:
.quad 0
Lcount321:
.quad 0
Lcount322:
.quad 0
Lcount323:
.quad 0
Lcount324:
.quad 0
Lcount325:
.quad 0
Lcount326:
.quad 0
Lcount327:
.quad 0
Lcount328:
.quad 0
Lcount329:
.quad 0
Lcount330:
.quad 0
Lcount331:
.quad 0
Lcount332:
.quad 0
Lcount333:
.quad 0
Lcount334:
.quad 0
Lcount335:
.quad 0
Lcount336:
.quad 0
Lcount337:
.quad 0
Lcount338:
.quad 0
Lcount339:
.quad 0
Lcount340:
.quad 0
Lcount341:
.quad 0
Lcount342:
.quad 0
Lcount343:
.quad 0
Lcount344:
.quad 0
Lcount345:
.quad 0
Lcount346:
.quad 0
Lcount347:
.quad 0
Lcount348:
.quad 0
Lcount349:
.quad 0
Lcount350:
.quad 0
Lcount351:
.quad 0
Lcount352:
.quad 0
Lcount353:
.quad 0
Lcount354:
.quad 0
Lcount355:
.quad 0
Lcount356:
.quad 0
Lcount357:
.quad 0
Lcount358:
.quad 0
Lcount359:
.quad 0
Lcount360:
.quad 0
Lcount361:
.quad 0
Lcount362:
.quad 0
Lcount363:
.quad 0
Lcount364:
.quad 0
Lcount365:
.quad 0
Lcount366:
.quad 0
Lcount367:
.quad 0
Lcount368:
.quad 0
Lcount369:
.quad 0
Lcount370:
.quad 0
Lcount371:
.quad 0
Lcount372:
.quad 0
Lcount373:
.quad 0
Lcount374:
.quad 0
Lcount375:
.quad 0
Lcount376:
.quad 0
Lcount377:
.quad 0
Lcount378:
.quad 0
Lcount379:
.quad 0
Lcount380:
.quad 0
Lcount381:
.quad 0
Lcount382:
.quad 0
Lcount383:
.quad 0
Lcount384:
.quad 0
Lcount385:
.quad 0
Lcount386:
.quad 0
Lcount387:
.quad 0
Lcount388:
.quad 0
Lcount389:
.quad 0
Lcount390:
.quad 0
Lcount391:
.quad 0
Lcount392:
.quad 0
Lcount393:
.quad 0
Lcount394:
.quad 0
Lcount395:
.quad 0
Lcount396:
.quad 0
Lcount397:
.quad 0
Lcount398:
.quad 0
Lcount399:
.quad 0
Lcount400:
.quad 0
Lcount401:
.quad 0
Lcount402:
.quad 0
Lcount403:
.quad 0
Lcount404:
.quad 0
Lcount405:
.quad 0
Lcount406:
.quad 0
Lcount407:
.quad 0
Lcount408:
.quad 0
Lcount409:
.quad 0
Lcount410:
.quad 0
Lcount411:
.quad 0
Lcount412:
.quad 0
Lcount413:
.quad 0
Lcount414:
.quad 0
Lcount415:
.quad 0
Lcount416:
.quad 0
Lcount417:
.quad 0
Lcount418:
.quad 0
Lcount419:
.quad 0
Lcount420:
.quad 0
Lcount421:
.quad 0
Lcount422:
.quad 0
Lcount423:
.quad 0
Lcount424:
.quad 0
Lcount425:
.quad 0
Lcount426:
.quad 0
Lcount427:
.quad 0
Lcount428:
.quad 0
Lcount429:
.quad 0
Lcount430:
.quad 0
Lcount431:
.quad 0
Lcount432:
.quad 0
Lcount433:
.quad 0
