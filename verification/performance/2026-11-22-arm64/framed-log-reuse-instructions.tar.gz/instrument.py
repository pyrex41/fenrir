import json,re
from pathlib import Path
p=Path(__file__).resolve().parent
names=[f['name'] for f in json.loads((p/'artifact').read_bytes())['functions']]
groups={};lines=[];owner=None
for line in (p/'original.s').read_text().splitlines():
 m=re.fullmatch(r'Lfn(\d+):',line)
 if m: owner=names[int(m[1])]
 if line=='.globl fen_print_result': owner=None
 if owner and line and not line.startswith('.') and not line.endswith(':'):
  assert not re.search(r'\b[wx](16|17)\b',line)
  op=line.split()[0];kind=line if op=='bl' else ('stack '+op if '[sp' in line else op)
  i=groups.setdefault((owner,kind),len(groups))
  label=f'Lcount{i}'
  lines.extend([f'adrp x16, {label}',f'ldr x17, [x16, :lo12:{label}]','add x17, x17, #1',f'str x17, [x16, :lo12:{label}]'])
 lines.append(line)
lines+=['.data','.p2align 3','.globl counts','counts:']
for i in range(len(groups)):lines.extend([f'Lcount{i}:','.quad 0'])
(p/'program.s').write_text('\n'.join(lines)+'\n')
(p/'groups.json').write_text(json.dumps(list(groups)))
f=p/'stream-spt.c';s=f.read_text().replace('        if (profile_io) {',f'''        extern uint64_t counts[];
        for(unsigned i=0;i<{len(groups)};i++) {{fen_write("count ",6);fen_write_i64(counts[i]);fen_write("\\n",1);}}
        if (profile_io) {{''')
f.write_text(s)
