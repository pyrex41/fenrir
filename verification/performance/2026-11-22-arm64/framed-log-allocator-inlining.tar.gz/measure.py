import json, subprocess, statistics, random, hashlib
from pathlib import Path
p=Path(__file__).resolve().parent
r=json.loads((p/'report.json').read_bytes())
order=['fenrir','candidate','candidate','fenrir']*13
raw=subprocess.check_output(['docker','run','--rm','--network','none','--platform','linux/arm64','--cpuset-cpus','1','-v',f'{p}:/work:ro','-w','/work','--entrypoint','sh',r['container'],'-ec','cp corpus /tmp/input; for n do /opt/solo5-install/bin/solo5-spt --block:input=/tmp/input "$n.spt" --solo5:quiet t1048576; done','sh',*order],text=True,timeout=180)
(p/'raw.txt').write_text(raw)
lines=iter(raw.splitlines()); times=[]
for name in order:
    output=''.join(next(lines)+'\n' for _ in range(64))
    assert hashlib.sha256(output.encode()).hexdigest()==r['expected_output_sha256']
    tag,n=next(lines).split()
    assert tag=='elapsed_ns' and int(n)>0
    times.append(int(n))
assert next(lines,None) is None
pairs=[dict(zip(order[i:i+2],times[i:i+2])) for i in range(0,len(order),2)]
ratios=[b['candidate']/b['fenrir'] for b in pairs[2:]]
rng=random.Random(1147);boot=sorted(statistics.median(rng.choices(ratios,k=len(ratios))) for _ in range(10000))
s=dict(warmup_pairs=2,order=order,times=times,median=statistics.median(ratios),interval=[boot[249],boot[9749]])
(p/'comparison.json').write_text(json.dumps(s,indent=2)+'\n')
print(s['median'],s['interval'])
