import hashlib,json,subprocess,time
from pathlib import Path
out=Path(__file__).resolve().parent
package=Path('/nix/store/0ypaq18rgi3pxxvxf67d1hadzc2y6mh1-fenrir-0.1-dev')
base=package/'libexec/fenrir/benchmarks/prover'
corpus=out/'queue-width-branches-v1.txt'
cases=[line.split() for line in corpus.read_text().splitlines()]
targets=('macos-arm64','solo5-arm64-spt')
with (out/'samples.jsonl').open('x') as log:
 for block in range(10):
  for index,target in enumerate(targets[::1 if block%2==0 else -1]):
   cli=[package/'bin/fenrir-toolchain','python3',base/'run-fenrir.py',target]
   obs={}
   for mode in (('batch','single') if (block+targets.index(target))%2==0 else ('single','batch')):
    start=time.monotonic_ns()
    if mode=='batch':
     rows=subprocess.check_output([*cli,'--corpus',corpus],timeout=360)
    else:
     lines=[]
     for name,_,budget,*formula in cases:
      row=subprocess.check_output([*cli,'--formula',' '.join(formula),'--budget',budget],timeout=180)
      assert row.startswith(b'goal ')
      lines.append(name.encode()+row[4:])
     rows=b''.join(lines)
    elapsed=time.monotonic_ns()-start
    assert len(rows.splitlines())==len(cases)
    obs[mode]=rows
    print(json.dumps(dict(block=block,target=target,mode=mode,elapsed_ns=elapsed,rows_sha256=hashlib.sha256(rows).hexdigest())),file=log,flush=True)
   assert obs['batch']==obs['single']
