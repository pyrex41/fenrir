"""Check externally supplied certificates and three mutations per proof."""
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
from fenrir_driver import compiled, literal
from verify import formula

here = Path(__file__).resolve().parent
proofs = dict(line.split() for line in (here / "certificates-v1.txt").read_text().splitlines())
cases = []
for row in (here / "corpus-v1.txt").read_text().splitlines():
    name, kind, _, *tokens = row.split()
    if kind == "proof":
        goal = literal(formula(iter(tokens)))
        cases.append((goal, proofs.pop(name)))
if proofs:
    raise ValueError("unknown proof names")
body = "false"
for i in reversed(range(len(cases))):
    goal, witness = cases[i]
    tape = (f'(if (= mode 0) "{witness}" (if (= mode 1) "{witness[:-1]}" '
            f'(if (= mode 2) "{witness}x" "{witness[:-1]}?")))')
    body = f"(if (= row {i}) (verify-proof {goal} {tape}) {body})"
program = (here / "formula.fen").read_text() + (here / "certificate.fen").read_text()
program += f"\n(define main {{I64 --> Bool}} i -> (let row (/ i 4) mode (- i (* row 4)) {body}))\n"
with compiled(here.parents[1], sys.argv[1], program) as command:
    for i in range(4 * len(cases)):
        result = subprocess.check_output([*command, str(i)], text=True, timeout=30)
        if result != ("1\n" if i % 4 == 0 else "0\n"):
            raise ValueError((i, result))
print(f"{len(cases)} certificates accepted, {3 * len(cases)} mutations rejected")
