"""Regression cases at the sustainable-rate evidence boundary."""
from copy import deepcopy
from pathlib import Path
from runpy import run_path
import unittest

assess = run_path(str(Path(__file__).with_name("assess-rate.py")))["assess"]


def valid_row():
    return dict(Seconds=600, Rate=10, Connections=2, Scheduled=6000, Valid=6000,
                Invalid=0, Errors=0, Missed=0, ElapsedNs=600_000_010_000,
                P50ns=100, P99ns=200, MaxNs=400,
                Timeline=[dict(Second=i, Scheduled=min(6000, i*10+1),
                               Completed=i*10, Backlog=int(i<600), ObservedNs=i*10**9)
                          for i in range(1, 601)])


class Assessment(unittest.TestCase):
    def test_release_requires_replicated_capacity_and_latency(self):
        gate = run_path(str(Path(__file__).with_name("paired-latency.py")))["service_gate"]
        meets = "meets-threshold"
        self.assertEqual(gate(1, meets, True, meets), "undetermined")
        self.assertEqual(gate(10, meets, False, meets), "undetermined")
        self.assertEqual(gate(10, "undetermined", True, meets), "undetermined")
        self.assertEqual(gate(10, meets, True, meets), "passed")
        self.assertEqual(gate(10, "below-threshold", False, "undetermined"), "failed")
        self.assertEqual(gate(10, meets, True, "above-threshold"), "failed")

    def test_sample_origin(self):
        verify = run_path(str(Path(__file__).with_name("assess-rate.py")))["verify_sample_origin"]
        env = dict(target="mac", sample_origin_version=1)
        origin = dict(worker="nim", position=0, environment_sha256="digest")
        verify({"Origin": origin}, env, "nim", 1, 1, "digest")
        for change in (dict(worker="rust"), dict(position=1), dict(environment_sha256="other")):
            with self.assertRaises(ValueError):
                verify({"Origin": {**origin, **change}}, env, "nim", 1, 1, "digest")
        with self.assertRaises(ValueError):
            verify({}, env, "nim", 1, 1, "digest")

    def test_complete(self):
        self.assertEqual(assess(valid_row())["verdict"], "sustained-at-offered-rate")

    def test_errors(self):
        row = valid_row()
        row.update(Valid=5994, Errors=6)
        self.assertEqual(assess(row)["verdict"], "failed-response-criteria")
        row.update(Valid=5995, Errors=5)
        self.assertEqual(assess(row)["verdict"], "sustained-at-offered-rate")
        row.update(Errors=4, Invalid=1)
        self.assertEqual(assess(row)["verdict"], "invalid-response")
        bounds = run_path(str(Path(__file__).with_name("capacity.py")))["bounds"]
        self.assertEqual(bounds({10: ["invalid-response"]}), {"sustained": None, "failed": None})

    def test_transport_error_census(self):
        row = valid_row()
        row.update(Errors=1, Valid=5999, ErrorKinds={"timeout": 1})
        for sample in row["Timeline"]:
            sample["Errors"] = int(sample["Second"] >= 30)
        self.assertEqual(assess(row)["error_kinds"], {"timeout": 1})
        with self.assertRaises(ValueError):
            assess(dict(row, ErrorKinds={}))
        row["Timeline"][31]["Errors"] = 0
        with self.assertRaises(ValueError):
            assess(row)

    def test_missing_and_corrupt(self):
        row = valid_row()
        for key, value in [("Timeline", row["Timeline"][:-1]), ("Valid", 5999),
                           ("ElapsedNs", 500_000_000_000), ("P99ns", 401)]:
            with self.subTest(key=key), self.assertRaises(ValueError):
                assess(dict(row, **{key:value}))
        for key, value in [("Scheduled", 0), ("Completed", 6000), ("ObservedNs", 1)]:
            broken = deepcopy(row)
            broken["Timeline"][25][key] = value
            with self.subTest(key=key), self.assertRaises(ValueError):
                assess(broken)

    def test_census_requires_whole_requests(self):
        row = valid_row()
        for invalid in [dict(row, Valid=5999.5, Errors=0.5), dict(row, Errors=False)]:
            with self.assertRaises(ValueError):
                assess(invalid)
        row["Timeline"][0].update(Completed=10.5, Backlog=0.5)
        with self.assertRaises(ValueError):
            assess(row)

    def test_phase_histograms(self):
        row = valid_row()
        bins = [5940, 60] + [0] * 62
        row["ValidRequestPhases"] = dict.fromkeys(("PreviousRequest", "Dispatch", "Fetch"), bins)
        self.assertEqual(assess(row)["phase_p99_upper_ms"]["Dispatch"], 0)
        bins[:2] = [5939, 61]
        self.assertEqual(assess(row)["phase_p99_upper_ms"]["Dispatch"], 0.000001)
        bins[0] -= 1
        with self.assertRaises(ValueError):
            assess(row)

    def test_backlog(self):
        row = valid_row()
        for s in row["Timeline"][-60:]:
            s["Completed"] -= 4
            s["Backlog"] += 4
        self.assertEqual(assess(row)["verdict"], "backlog-clearance-unconfirmed")

    def test_late_sample_does_not_prove_sustained_rate(self):
        row = valid_row()
        delayed = row["Timeline"][99]
        delayed.update(ObservedNs=101 * 10**9, Scheduled=1011, Backlog=11)
        result = assess(row)
        self.assertEqual(result["verdict"], "sampling-cadence-unconfirmed")
        self.assertEqual(result["late_sample_seconds"], [100])
        self.assertEqual(result["max_observed_sample_delay_ns"], 10**9)
        delayed["ObservedNs"] += 1
        with self.assertRaisesRegex(ValueError, "sampling clock"):
            assess(row)

    def test_legacy(self):
        row = valid_row()
        for s in row["Timeline"]:
            del s["ObservedNs"]
        self.assertEqual(assess(row)["verdict"], "sustained-at-offered-rate")
        row["ElapsedNs"] += 2_000_000_000
        self.assertEqual(assess(row)["verdict"], "sampling-cadence-unconfirmed")


if __name__ == "__main__":
    unittest.main()
