#!/bin/sh
# Build from the working sources, including files awaiting their first commit.
set -eu
[ "$#" -le 1 ] || { echo 'usage: package-mac.sh [NEW_SOURCE_ARCHIVE.tar.gz]' >&2; exit 2; }
archive=
if [ "$#" = 1 ]; then
    case "$1" in /*) archive=$1 ;; *) archive=$PWD/$1 ;; esac
    [ ! -e "$archive" ] && [ ! -L "$archive" ] || { echo 'source archive already exists' >&2; exit 2; }
fi
root=$(cd "$(dirname "$0")/../.." && pwd)
stage=$(mktemp -d)
temporary=
trap 'rm -rf "$stage"; if [ -n "$temporary" ]; then rm -f "$temporary"; fi' EXIT
cd "$root"
cp -R README.md WORK_FILE.md flake.nix flake.lock bin frontend harness models typing tools runtime package.json benchmarks examples fixtures "$stage/"
mkdir -p "$stage/verification" "$stage/host" "$stage/backends" "$stage/tests/solo5" "$stage/tests/host" "$stage/tests/frontend"
cp -R spec "$stage/"
cp -R verification/aarch64 "$stage/verification/"
cp -R tests/native "$stage/tests/"
cp -R tests/frontend/roundtrip "$stage/tests/frontend/"
cp -R tests/host/histories "$stage/tests/host/"
cp tests/solo5/durable-hand-cases.mjs "$stage/tests/solo5/"
cp -R backends/solo5 "$stage/backends/"
cp -R host/service "$stage/host/"
package=$(nix build --no-link --print-out-paths "path:$stage#fenrir")
if [ -n "$archive" ]; then
    temporary=$(mktemp "$(dirname "$archive")/.fenrir-source.XXXXXXXX")
    COPYFILE_DISABLE=1 tar -czf "$temporary" -C "$stage" .
    ln "$temporary" "$archive"
    shasum -a 256 "$archive" >&2
fi
printf '%s\n' "$package"
