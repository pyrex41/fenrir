#include <stdio.h>
#define REPRESENTATION_DIAGNOSTICS
#include "representation.c"
void representation_observe(unsigned i, unsigned result, unsigned steps, unsigned cells, unsigned copies) {
    printf("case %u outcome %u steps %u cells %u accumulated_copies %u\n", i,result,steps,cells,copies);
}
int main(void) {
    struct outcome_value result=fenrir_entry(1);
    printf("accepted %lld allocations %llu copied %llu\n",(long long)result.value,
           (unsigned long long)representation_queue_allocations,(unsigned long long)representation_queue_cells_copied);
    return result.status || result.value != sizeof prepared / sizeof *prepared;
}
