import hashlib
import json
import statistics
import subprocess
from pathlib import Path

directory = Path(__file__).resolve().parent
jit = directory.parents[1] / "build/toolchain/shen-jit-0.7/bin/shen-jit"
samples = []
ratios = {"check": [], "search": []}
for block in range(8):
    for lane, cases in ([("search", 10), ("check", 6)][::1 if block % 4 < 2 else -1]):
        times = {}
        commands = {"fenrir": [directory / f"warm-{lane}"],
                    "shen": [jit, "script", directory / f"long-{lane}.shen"]}
        for name in list(commands)[::1 if block % 2 == 0 else -1]:
            command = commands[name]
            warm, total, cpu = subprocess.check_output(command, text=True, timeout=60).split()
            assert (int(warm), int(total)) == (100 * cases, 500000 * cases) and float(cpu) > 0
            samples.append(dict(block=block, lane=lane, language=name, warm=int(warm),
                                result=int(total), cpu_seconds=float(cpu), binary_sha256=
                                hashlib.sha256(command[0].read_bytes()).hexdigest()))
            times[name] = float(cpu)
        ratios[lane].append(times["fenrir"] / times["shen"])
(directory / "paired.json").write_text(json.dumps(dict(samples=samples, ratios=ratios), indent=2))
for lane, values in ratios.items():
    print(lane, statistics.median(values), min(values), max(values))
