#include <errno.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

struct outcome { int64_t value; uint64_t status; };
extern struct outcome fenrir_entry(int64_t argument);

extern const char *fen_trap_location;
extern const char *fen_schedule_request;
extern void fen_print_result(uintptr_t value);
void fen_write(const char *s, size_t n) { fwrite(s, 1, n, stdout); }
void fen_write_i64(int64_t n) { printf("%" PRId64, n); }

extern uint64_t (*fen_host_clock)(void);
extern void (*fen_host_wait)(uint64_t);
static uint64_t monotonic_ns(void) { return clock_gettime_nsec_np(CLOCK_MONOTONIC); }
static void wait_ns(uint64_t ns) {
    struct timespec delay = {ns / 1000000000, ns % 1000000000};
    nanosleep(&delay, NULL);
}

int main(void) {
    struct outcome warm = fenrir_entry(100);
    clock_t start = clock();
    struct outcome measured = fenrir_entry(500000);
    clock_t end = clock();
    if (warm.status || measured.status || end <= start) return 1;
    printf("%lld %lld %.9f\n", (long long)warm.value, (long long)measured.value,
           (double)(end - start) / CLOCKS_PER_SEC);
    return 0;
}
