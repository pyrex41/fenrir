(define pv.bit
  0 -> 1
  N -> (* 2 (pv.bit (- N 1))))

(define pv.mask
  [] -> 0
  [N | Ns] -> (+ (pv.bit N) (pv.mask Ns)))

(define pv.prefix
  C [proof W Fuel] -> [proof (cn C W) Fuel]
  _ Result -> Result)

(define pv.fork
  [proof W Fuel] Queue Pos Neg ->
    (pv.prefix (cn "b" W) (pv.search Queue Pos Neg Fuel))
  Failure _ _ _ -> Failure)

(define pv.search
  _ _ _ 0 -> [exhausted "-" 0]
  [] Pos _ Fuel -> [model (str (pv.mask Pos)) (- Fuel 1)]
  [[Sign Atom] | Rest] Pos Neg Fuel ->
    (if (element? Atom (if Sign Neg Pos))
        [proof "x" (- Fuel 1)]
        (let P (if (and Sign (not (element? Atom Pos))) [Atom | Pos] Pos)
             N (if (and (not Sign) (not (element? Atom Neg))) [Atom | Neg] Neg)
          (pv.prefix "s" (pv.search Rest P N (- Fuel 1)))))
    where (number? Atom)
  [[Sign [neg A]] | Rest] Pos Neg Fuel ->
    (pv.prefix "s" (pv.search (append Rest [[(not Sign) A]]) Pos Neg (- Fuel 1)))
  [[Sign [Op A B]] | Rest] Pos Neg Fuel ->
    (let First [(if (= Op imp) (not Sign) Sign) A]
         Second [Sign B]
      (if (= (= Op conj) Sign)
          (pv.prefix "s" (pv.search (append Rest [First Second]) Pos Neg (- Fuel 1)))
          (pv.fork (pv.search (append Rest [First]) Pos Neg (- Fuel 1))
                   (append Rest [Second]) Pos Neg))))

(define pv.format
  Name Budget [Status Witness Remaining] ->
    (make-string "~A ~A ~A ~A~%" Name Status (- Budget Remaining) Witness))

(define pv.row
  Name Budget Goal -> (pv.format Name Budget (pv.search [[false Goal]] [] [] Budget)))

(define pv.check-step
  _ _ _ invalid -> invalid
  [] _ _ _ -> invalid
  _ _ _ [] -> invalid
  [[Sign Atom] | Rest] Pos Neg [Rule | Tape] ->
    (if (element? Atom (if Sign Neg Pos))
        (if (= Rule "x") Tape invalid)
        (if (= Rule "s")
            (pv.check-step Rest
              (if (and Sign (not (element? Atom Pos))) [Atom | Pos] Pos)
              (if (and (not Sign) (not (element? Atom Neg))) [Atom | Neg] Neg)
              Tape)
            invalid))
    where (number? Atom)
  [[Sign [neg A]] | Rest] Pos Neg ["s" | Tape] ->
    (pv.check-step (append Rest [[(not Sign) A]]) Pos Neg Tape)
  [[Sign [Op A B]] | Rest] Pos Neg [Rule | Tape] ->
    (let First [(if (= Op imp) (not Sign) Sign) A]
         Second [Sign B]
      (if (= (= Op conj) Sign)
          (if (= Rule "s") (pv.check-step (append Rest [First Second]) Pos Neg Tape) invalid)
          (if (= Rule "b")
              (pv.check-step (append Rest [Second]) Pos Neg
                (pv.check-step (append Rest [First]) Pos Neg Tape))
              invalid)))
  _ _ _ _ -> invalid)

(define pv.verify
  Goal Witness -> (= [] (pv.check-step [[false Goal]] [] [] (explode Witness))))

(set *pv-input-1* [imp 0 0])
(set *pv-input-2* [disj 0 [neg 0]])
(set *pv-input-3* [imp [conj 0 [imp 0 1]] 1])
(set *pv-input-4* [imp [conj 0 [disj 1 2]] [disj [conj 0 1] [conj 0 2]]])
(set *pv-input-5* [imp [conj [imp 0 1] [imp 1 2]] [imp 0 2]])
(set *pv-input-6* [imp [imp [imp 0 1] 0] 0])
(set *pv-input-7* [conj 0 1])
(set *pv-input-8* [imp [imp 0 1] [imp 1 0]])
(set *pv-input-9* [imp [conj 0 [disj 1 2]] [disj [conj 0 1] [conj 0 2]]])
(set *pv-input-10* 0)
(define pv.round Unit -> (+ (+ (+ (+ (+ (+ (+ (+ (+ (+ 0 (if (= (pv.search [[false (value *pv-input-1*)]] [] [] 100) [proof "ssx" 97]) 1 0)) (if (= (pv.search [[false (value *pv-input-2*)]] [] [] 100) [proof "sssx" 96]) 1 0)) (if (= (pv.search [[false (value *pv-input-3*)]] [] [] 100) [proof "ssssbxx" 93]) 1 0)) (if (= (pv.search [[false (value *pv-input-4*)]] [] [] 100) [proof "ssssbbbsxsxbsxsxbbsxsxbssxssx" 71]) 1 0)) (if (= (pv.search [[false (value *pv-input-5*)]] [] [] 200) [proof "sssbbssxssxbsssxsssx" 180]) 1 0)) (if (= (pv.search [[false (value *pv-input-6*)]] [] [] 200) [proof "sbssxsx" 193]) 1 0)) (if (= (pv.search [[false (value *pv-input-7*)]] [] [] 100) [model "0" 97]) 1 0)) (if (= (pv.search [[false (value *pv-input-8*)]] [] [] 100) [model "2" 93]) 1 0)) (if (= (pv.search [[false (value *pv-input-9*)]] [] [] 3) [exhausted "-" 0]) 1 0)) (if (= (pv.search [[false (value *pv-input-10*)]] [] [] 0) [exhausted "-" 0]) 1 0)))
(define pv.repeat 0 Acc -> Acc N Acc -> (pv.repeat (- N 1) (+ Acc (pv.round 0))))
(let Warm (pv.repeat 100 0) Start (get-time run) Result (pv.repeat 500000 0) End (get-time run) (output "~A ~A ~A~%" Warm Result (- End Start)))
