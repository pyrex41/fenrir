"""Exercise the pipelined host binary with a guest that controls reply timing."""
import os
from pathlib import Path
import select
import socket
import struct
import subprocess
import sys
import time

ingress = Path(sys.argv[1])
def exact(fd, size):
    deadline = time.monotonic() + 5
    data = b''
    while len(data) < size:
        if not select.select([fd], [], [], max(0, deadline-time.monotonic()))[0]:
            raise TimeoutError('ingress withheld a request frame')
        chunk = os.read(fd, size-len(data))
        if not chunk:
            raise EOFError('incomplete request frame')
        data += chunk
    return data

def receive_header(worker, expected):
    length, complete = struct.unpack('<II', exact(worker.stdout.fileno(), 8))
    assert complete == 1 and length == len(expected)
    assert exact(worker.stdout.fileno(), length) == expected

def send_request(addr, path):
    head = b'GET '+path+b' HTTP/1.1\r\nHost:x\r\nConnection: close\r\n\r\n'
    conn = socket.create_connection(addr, timeout=5)
    conn.sendall(head)
    return conn,head

def run(reset_index):
    with subprocess.Popen([ingress,'0'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE) as worker:
        connections = []
        try:
            host,port=worker.stderr.readline().strip().split(b':')
            addr=(host.decode(),int(port))
            for i in range(16):
                digits=str(i).encode().rjust(i+1,b'0')
                conn,head=send_request(addr,b'/items/'+digits)
                connections.append((conn,head,digits))
                receive_header(worker,head)
            connections[reset_index][0].setsockopt(socket.SOL_SOCKET,socket.SO_LINGER,struct.pack('ii',1,0))
            connections[reset_index][0].close()
            for _,head,digits in connections[:1] + connections[2:3] + connections[1:2] + connections[3:]:
                start=head.index(b'/items/')+len(b'/items/')
                worker.stdin.write(struct.pack('<QQQQ',200,1,start,len(digits)))
            worker.stdin.flush()
            for i,(conn,_,digits) in enumerate(connections):
                if i == reset_index:continue
                with conn.makefile('rb') as reader:
                    response=reader.read()
                assert response.startswith(b'HTTP/1.1 200 OK\r\n') and response.split(b'\r\n\r\n')[1]==digits
            conn,head=send_request(addr,b'/')
            connections.append((conn,head,b''))
            receive_header(worker,head)
            worker.stdin.write(struct.pack('<QQQQ',200,1,0,0));worker.stdin.flush()
            with conn.makefile('rb') as reader:assert reader.read().endswith(b'\r\n\r\nfenrir\n')
        finally:
            for conn,_,_ in connections:conn.close()
            worker.terminate()
            worker.wait(timeout=5)

for i in range(16):run(i)
print('Passed 16 reset positions with 16 outstanding requests and a subsequent healthy request.')
