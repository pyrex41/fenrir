import json
from pathlib import Path
from runpy import run_path
import select
import subprocess
import sys

root=Path(__file__).resolve().parent
suite=root/'benchmarks/http'
queue=select.kqueue()
try:
    queue.control([select.kevent(int(sys.argv[1]), filter=select.KQ_FILTER_PROC,
                                 flags=select.KQ_EV_ADD, fflags=select.KQ_NOTE_EXIT)],1,14400)
except ProcessLookupError:
    pass
folders=[root/'sweep',root/'extension']
if (root/'upper-100000').is_dir():
    folders.append(root/'upper-100000')
result=run_path(str(suite/'capacity.py'))['summarize'](*folders)
if json.loads(json.dumps(result)) != json.loads((root/'upper-capacity.json').read_bytes()):
    sys.exit('capacity replay differs')
rate=result['paired_latency_rate']
if not rate:
    sys.exit('capacity lacks the bounds required to select a rate')
output=root/'linked-latency'
subprocess.run([sys.executable,suite/'sweep.py',sys.argv[2],output,'--target','mac','--driver-from',folders[0],
                '--seconds','600','--blocks','10','--rates',str(rate)],check=True,timeout=21600)
report=subprocess.check_output([sys.executable,sys.argv[3],output,'--capacity',*folders],timeout=120)
(root/'linked-verdict.json').write_bytes(report)
