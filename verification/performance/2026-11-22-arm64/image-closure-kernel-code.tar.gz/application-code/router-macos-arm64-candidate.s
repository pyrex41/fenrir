.text
.p2align 2
Lfn0:
ldp x8, x9, [x0, #0]
ldr x10, [x0, #16]
Lfn0fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #80
stp x8, x9, [sp, #48]
str x10, [sp, #64]
Lfn0loop:
ldr x0, [sp, #48]
ldr x2, [sp, #56]
cmp x0, x2
b.ge Lfn0if14else
movz x0, #0, lsl #0
b Lfn0if14done
Lfn0if14else:
ldr x0, [sp, #48]
ldr x2, [sp, #64]
cmp x0, x2
cset x0, le
Lfn0if14done:
mov x1, #0
b Lfn0end
Lfn0end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn1:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #80
str x0, [sp, #48]
movz x0, #65, lsl #0
str x0, [sp, #56]
movz x0, #90, lsl #0
str x0, [sp, #64]
ldr x8, [sp, #48]
ldr x9, [sp, #56]
ldr x10, [sp, #64]
bl Lfn0fields
cbnz x1, Lfn1end
cbz x0, Lfn1if24else
ldr x0, [sp, #48]
adds x0, x0, #32
b.vs Lfn1fail30_1
b Lfn1if24done
Lfn1if24else:
ldr x0, [sp, #48]
Lfn1if24done:
mov x1, #0
b Lfn1end
Lfn1fail30_1:
adrp x0, Lfn1fail30_1location@PAGE
add x0, x0, Lfn1fail30_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn1end
Lfn1end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn2:
ldp x8, x9, [x0, #0]
ldp x10, x11, [x0, #16]
ldr x12, [x0, #32]
Lfn2fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #144
str x8, [sp, #48]
str x9, [sp, #64]
str x10, [sp, #56]
stp x11, x12, [sp, #72]
Lfn2loop:
ldr x0, [sp, #56]
ldr x0, [x0]
str x0, [sp, #88]
ldr x0, [sp, #72]
ldr x2, [sp, #88]
cmp x0, x2
b.ne Lfn2if56else
movz x0, #1, lsl #0
b Lfn2if56done
Lfn2if56else:
ldr x0, [sp, #48]
ldr x0, [x0]
str x0, [sp, #96]
ldr x0, [sp, #64]
ldr x2, [sp, #96]
cmp x0, x2
b.lt Lfn2if62else
movz x0, #0, lsl #0
b Lfn2if62done
Lfn2if62else:
ldr x0, [sp, #48]
ldr x2, [sp, #64]
ldr x3, [x0]
cmp x2, x3
b.hs Lfn2fail70_4
ldr w3, [x0, #72]
cmn w3, #1
b.ne 1f
add x0, x0, #80
ldrb w0, [x0, x2]
b 2f
1:
mov x1, x2
bl _fen_bytes_index
2:
str x0, [sp, #104]
ldr x0, [sp, #80]
cbz x0, Lfn2if75else
ldr x0, [sp, #104]
bl Lfn1
cbnz x1, Lfn2end
b Lfn2if75done
Lfn2if75else:
ldr x0, [sp, #104]
Lfn2if75done:
str x0, [sp, #112]
ldr x0, [sp, #56]
ldr x2, [sp, #72]
ldr x3, [x0]
cmp x2, x3
b.hs Lfn2fail80_4
ldr w3, [x0, #72]
cmn w3, #1
b.ne 1f
add x0, x0, #80
ldrb w0, [x0, x2]
b 2f
1:
mov x1, x2
bl _fen_bytes_index
2:
str x0, [sp, #120]
ldr x0, [sp, #112]
ldr x2, [sp, #120]
cmp x0, x2
b.ne Lfn2if73else
ldr x0, [sp, #64]
adds x0, x0, #1
b.vs Lfn2fail86_1
str x0, [sp, #128]
ldr x0, [sp, #72]
adds x0, x0, #1
b.vs Lfn2fail90_1
str x0, [sp, #136]
ldr x8, [sp, #128]
ldr x9, [sp, #136]
str x8, [sp, #64]
str x9, [sp, #72]
b Lfn2loop
b Lfn2if73done
Lfn2if73else:
movz x0, #0, lsl #0
Lfn2if73done:
Lfn2if62done:
Lfn2if56done:
mov x1, #0
b Lfn2end
Lfn2fail70_4:
adrp x0, Lfn2fail70_4location@PAGE
add x0, x0, Lfn2fail70_4location@PAGEOFF
bl _fen_set_location
mov x1, #4
b Lfn2end
Lfn2fail80_4:
adrp x0, Lfn2fail80_4location@PAGE
add x0, x0, Lfn2fail80_4location@PAGEOFF
bl _fen_set_location
mov x1, #4
b Lfn2end
Lfn2fail86_1:
adrp x0, Lfn2fail86_1location@PAGE
add x0, x0, Lfn2fail86_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn2end
Lfn2fail90_1:
adrp x0, Lfn2fail90_1location@PAGE
add x0, x0, Lfn2fail90_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn2end
Lfn2end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn3:
ldp x8, x9, [x0, #0]
ldp x10, x11, [x0, #16]
Lfn3fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #112
str x8, [sp, #48]
stp x9, x10, [sp, #64]
str x11, [sp, #56]
Lfn3loop:
ldr x0, [sp, #72]
ldr x2, [sp, #64]
subs x0, x0, x2
b.vs Lfn3fail115_1
str x0, [sp, #80]
ldr x0, [sp, #56]
ldr x0, [x0]
str x0, [sp, #88]
ldr x0, [sp, #80]
ldr x2, [sp, #88]
cmp x0, x2
b.ne Lfn3if113else
movz x0, #0, lsl #0
str x0, [sp, #96]
movz x0, #1, lsl #0
str x0, [sp, #104]
ldr x8, [sp, #48]
ldr x9, [sp, #64]
ldr x10, [sp, #56]
ldr x11, [sp, #96]
ldr x12, [sp, #104]
mov sp, x29
ldp x29, x30, [sp], #16
b Lfn2fields
b Lfn3if113done
Lfn3if113else:
movz x0, #0, lsl #0
Lfn3if113done:
mov x1, #0
b Lfn3end
Lfn3fail115_1:
adrp x0, Lfn3fail115_1location@PAGE
add x0, x0, Lfn3fail115_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn3end
Lfn3end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn4:
ldp x8, x9, [x0, #0]
Lfn4fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #112
stp x8, x9, [sp, #48]
ldr x2, [sp, #48]
ldr x3, [sp, #56]
ldr w4, [x2, #72]
cmn w4, #1
b.ne Lfn4loop
ldr x4, [x2]
cmp x3, x4
b.hi Lfn4loop
add x2, x2, #80
adrp x0, Lfn4scantable@PAGE
add x0, x0, Lfn4scantable@PAGEOFF
movi v1.16b, #33
movi v2.16b, #126
Lfn4scan:
sub x6, x4, x3
cmp x6, #16
b.lo Lfn4scanbyte
ldr q0, [x2, x3]
cmhs v3.16b, v0.16b, v1.16b
cmhs v4.16b, v2.16b, v0.16b
and v3.16b, v3.16b, v4.16b
uminv b3, v3.16b
umov w5, v3.b[0]
cbz w5, Lfn4scanbyte
add x3, x3, #16
b Lfn4scan
Lfn4scanbyte:
cmp x3, x4
b.eq Lfn4scanbad
ldrb w5, [x2, x3]
ldrb w5, [x0, x5]
cbz w5, Lfn4scanbad
cmp w5, #1
b.eq Lfn4scanfound
add x3, x3, #1
b Lfn4scan
Lfn4scanbad:
mov x3, #-1
Lfn4scanfound:
mov x0, x3
mov x1, #0
b Lfn4end
Lfn4loop:
ldr x0, [sp, #48]
ldr x0, [x0]
str x0, [sp, #64]
ldr x0, [sp, #56]
ldr x2, [sp, #64]
cmp x0, x2
b.ne Lfn4if138else
movn x0, #0, lsl #0
b Lfn4if138done
Lfn4if138else:
ldr x0, [sp, #48]
ldr x2, [sp, #56]
ldr x3, [x0]
cmp x2, x3
b.hs Lfn4fail146_4
ldr w3, [x0, #72]
cmn w3, #1
b.ne 1f
add x0, x0, #80
ldrb w0, [x0, x2]
b 2f
1:
mov x1, x2
bl _fen_bytes_index
2:
str x0, [sp, #72]
cmp x0, #32
b.ne Lfn4if149else
ldr x0, [sp, #56]
b Lfn4if149done
Lfn4if149else:
movz x0, #33, lsl #0
str x0, [sp, #80]
movz x0, #126, lsl #0
str x0, [sp, #88]
ldr x8, [sp, #72]
ldr x9, [sp, #80]
ldr x10, [sp, #88]
bl Lfn0fields
cbnz x1, Lfn4end
cbz x0, Lfn4if154else
ldr x0, [sp, #56]
adds x0, x0, #1
b.vs Lfn4fail163_1
str x0, [sp, #96]
ldr x8, [sp, #96]
str x8, [sp, #56]
b Lfn4loop
b Lfn4if154done
Lfn4if154else:
movn x0, #0, lsl #0
Lfn4if154done:
Lfn4if149done:
Lfn4if138done:
mov x1, #0
b Lfn4end
Lfn4fail146_4:
adrp x0, Lfn4fail146_4location@PAGE
add x0, x0, Lfn4fail146_4location@PAGEOFF
bl _fen_set_location
mov x1, #4
b Lfn4end
Lfn4fail163_1:
adrp x0, Lfn4fail163_1location@PAGE
add x0, x0, Lfn4fail163_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn4end
Lfn4end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn5:
ldp x8, x9, [x0, #0]
ldr x10, [x0, #16]
Lfn5fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #112
stp x8, x9, [sp, #48]
str x10, [sp, #64]
Lfn5loop:
ldr x0, [sp, #56]
ldr x2, [sp, #64]
cmp x0, x2
b.ne Lfn5if181else
movz x0, #1, lsl #0
b Lfn5if181done
Lfn5if181else:
ldr x0, [sp, #48]
ldr x2, [sp, #56]
ldr x3, [x0]
cmp x2, x3
b.hs Lfn5fail189_4
ldr w3, [x0, #72]
cmn w3, #1
b.ne 1f
add x0, x0, #80
ldrb w0, [x0, x2]
b 2f
1:
mov x1, x2
bl _fen_bytes_index
2:
str x0, [sp, #72]
movz x0, #48, lsl #0
str x0, [sp, #80]
movz x0, #57, lsl #0
str x0, [sp, #88]
ldr x8, [sp, #72]
ldr x9, [sp, #80]
ldr x10, [sp, #88]
bl Lfn0fields
cbnz x1, Lfn5end
cbz x0, Lfn5if186else
ldr x0, [sp, #56]
adds x0, x0, #1
b.vs Lfn5fail197_1
str x0, [sp, #96]
ldr x8, [sp, #96]
str x8, [sp, #56]
b Lfn5loop
b Lfn5if186done
Lfn5if186else:
movz x0, #0, lsl #0
Lfn5if186done:
Lfn5if181done:
mov x1, #0
b Lfn5end
Lfn5fail189_4:
adrp x0, Lfn5fail189_4location@PAGE
add x0, x0, Lfn5fail189_4location@PAGEOFF
bl _fen_set_location
mov x1, #4
b Lfn5end
Lfn5fail197_1:
adrp x0, Lfn5fail197_1location@PAGE
add x0, x0, Lfn5fail197_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn5end
Lfn5end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn6:
ldp x8, x9, [x0, #0]
Lfn6fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #144
stp x8, x9, [sp, #48]
add x0, sp, #16
add x1, sp, #48
mov x2, #1
bl _fen_enter
Lfn6loop:
ldr x0, [sp, #56]
cmp x0, #5
b.ne Lfn6if212else
adrp x0, Lconstant0@PAGE
add x0, x0, Lconstant0@PAGEOFF
b Lfn6if212done
Lfn6if212else:
ldr x0, [sp, #56]
cmp x0, #11
b.ne Lfn6if218else
movz x0, #4, lsl #0
str x0, [sp, #64]
movz x0, #0, lsl #0
str x0, [sp, #72]
movz x0, #0, lsl #0
str x0, [sp, #80]
ldr x8, [sp, #48]
ldr x9, [sp, #64]
adrp x10, Lconstant1@PAGE
add x10, x10, Lconstant1@PAGEOFF
ldr x11, [sp, #72]
ldr x12, [sp, #80]
bl Lfn2fields
cbnz x1, Lfn6end
b Lfn6if218done
Lfn6if218else:
movz x0, #0, lsl #0
Lfn6if218done:
cbz x0, Lfn6if217else
adrp x0, Lconstant2@PAGE
add x0, x0, Lconstant2@PAGEOFF
b Lfn6if217done
Lfn6if217else:
ldr x0, [sp, #56]
cmp x0, #11
b.le Lfn6if232else
movz x0, #4, lsl #0
str x0, [sp, #88]
movz x0, #0, lsl #0
str x0, [sp, #96]
movz x0, #0, lsl #0
str x0, [sp, #104]
ldr x8, [sp, #48]
ldr x9, [sp, #88]
adrp x10, Lconstant3@PAGE
add x10, x10, Lconstant3@PAGEOFF
ldr x11, [sp, #96]
ldr x12, [sp, #104]
bl Lfn2fields
cbnz x1, Lfn6end
b Lfn6if232done
Lfn6if232else:
movz x0, #0, lsl #0
Lfn6if232done:
cbz x0, Lfn6if231else
movz x0, #11, lsl #0
str x0, [sp, #112]
ldr x8, [sp, #48]
ldr x9, [sp, #112]
ldr x10, [sp, #56]
bl Lfn5fields
cbnz x1, Lfn6end
cbz x0, Lfn6if244else
movz x0, #11, lsl #0
str x0, [sp, #120]
ldr x0, [sp, #56]
subs x0, x0, #11
b.vs Lfn6fail252_1
str x0, [sp, #128]
mov x0, #0
mov x1, #9
bl _fen_allocate
cbz x0, Lfn6fail250_3
ldr x2, [sp, #120]
ldr x3, [sp, #128]
stp x2, x3, [x0, #0]
b Lfn6if244done
Lfn6if244else:
adrp x0, Lconstant4@PAGE
add x0, x0, Lconstant4@PAGEOFF
Lfn6if244done:
b Lfn6if231done
Lfn6if231else:
adrp x0, Lconstant4@PAGE
add x0, x0, Lconstant4@PAGEOFF
Lfn6if231done:
Lfn6if217done:
Lfn6if212done:
mov x1, #0
b Lfn6end
Lfn6fail252_1:
adrp x0, Lfn6fail252_1location@PAGE
add x0, x0, Lfn6fail252_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn6end
Lfn6fail250_3:
adrp x0, Lfn6fail250_3location@PAGE
add x0, x0, Lfn6fail250_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn6end
Lfn6end:
bl _fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn7:
ldp x8, x9, [x0, #0]
ldr x10, [x0, #16]
Lfn7fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #96
stp x8, x9, [sp, #48]
str x10, [sp, #64]
Lfn7loop:
ldr x0, [sp, #48]
ldr x0, [x0]
str x0, [sp, #72]
ldr x0, [sp, #64]
ldr x2, [sp, #72]
cmp x0, x2
b.ne Lfn7if271else
movz x0, #0, lsl #0
b Lfn7if271done
Lfn7if271else:
ldr x0, [sp, #48]
ldr x2, [sp, #64]
ldr x3, [x0]
cmp x2, x3
b.hs Lfn7fail280_4
ldr w3, [x0, #72]
cmn w3, #1
b.ne 1f
add x0, x0, #80
ldrb w0, [x0, x2]
b 2f
1:
mov x1, x2
bl _fen_bytes_index
2:
str x0, [sp, #80]
ldr x0, [sp, #56]
ldr x2, [sp, #80]
cmp x0, x2
b.ne Lfn7if277else
movz x0, #1, lsl #0
b Lfn7if277done
Lfn7if277else:
ldr x0, [sp, #64]
adds x0, x0, #1
b.vs Lfn7fail288_1
str x0, [sp, #88]
ldr x8, [sp, #88]
str x8, [sp, #64]
b Lfn7loop
Lfn7if277done:
Lfn7if271done:
mov x1, #0
b Lfn7end
Lfn7fail280_4:
adrp x0, Lfn7fail280_4location@PAGE
add x0, x0, Lfn7fail280_4location@PAGEOFF
bl _fen_set_location
mov x1, #4
b Lfn7end
Lfn7fail288_1:
adrp x0, Lfn7fail288_1location@PAGE
add x0, x0, Lfn7fail288_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn7end
Lfn7end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn8:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #112
str x0, [sp, #48]
movz x0, #48, lsl #0
str x0, [sp, #56]
movz x0, #57, lsl #0
str x0, [sp, #64]
ldr x8, [sp, #48]
ldr x9, [sp, #56]
ldr x10, [sp, #64]
bl Lfn0fields
cbnz x1, Lfn8end
cbz x0, Lfn8if293else
movz x0, #1, lsl #0
b Lfn8if293done
Lfn8if293else:
ldr x0, [sp, #48]
bl Lfn1
cbnz x1, Lfn8end
str x0, [sp, #72]
movz x0, #97, lsl #0
str x0, [sp, #80]
movz x0, #122, lsl #0
str x0, [sp, #88]
ldr x8, [sp, #72]
ldr x9, [sp, #80]
ldr x10, [sp, #88]
bl Lfn0fields
cbnz x1, Lfn8end
cbz x0, Lfn8if300else
movz x0, #1, lsl #0
b Lfn8if300done
Lfn8if300else:
movz x0, #0, lsl #0
str x0, [sp, #96]
adrp x8, Lconstant5@PAGE
add x8, x8, Lconstant5@PAGEOFF
ldr x9, [sp, #48]
ldr x10, [sp, #96]
mov sp, x29
ldp x29, x30, [sp], #16
b Lfn7fields
Lfn8if300done:
Lfn8if293done:
mov x1, #0
b Lfn8end
Lfn8end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn9:
ldp x8, x9, [x0, #0]
Lfn9fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #96
stp x8, x9, [sp, #48]
Lfn9loop:
ldr x0, [sp, #48]
ldr x0, [x0]
str x0, [sp, #64]
ldr x0, [sp, #56]
ldr x2, [sp, #64]
cmp x0, x2
b.ne Lfn9if323else
movn x0, #0, lsl #0
b Lfn9if323done
Lfn9if323else:
ldr x0, [sp, #48]
ldr x2, [sp, #56]
ldr x3, [x0]
cmp x2, x3
b.hs Lfn9fail331_4
ldr w3, [x0, #72]
cmn w3, #1
b.ne 1f
add x0, x0, #80
ldrb w0, [x0, x2]
b 2f
1:
mov x1, x2
bl _fen_bytes_index
2:
str x0, [sp, #72]
cmp x0, #58
b.ne Lfn9if334else
ldr x0, [sp, #56]
b Lfn9if334done
Lfn9if334else:
ldr x0, [sp, #72]
bl Lfn8
cbnz x1, Lfn9end
cbz x0, Lfn9if339else
ldr x0, [sp, #56]
adds x0, x0, #1
b.vs Lfn9fail345_1
str x0, [sp, #80]
ldr x8, [sp, #80]
str x8, [sp, #56]
b Lfn9loop
b Lfn9if339done
Lfn9if339else:
movn x0, #0, lsl #0
Lfn9if339done:
Lfn9if334done:
Lfn9if323done:
mov x1, #0
b Lfn9end
Lfn9fail331_4:
adrp x0, Lfn9fail331_4location@PAGE
add x0, x0, Lfn9fail331_4location@PAGEOFF
bl _fen_set_location
mov x1, #4
b Lfn9end
Lfn9fail345_1:
adrp x0, Lfn9fail345_1location@PAGE
add x0, x0, Lfn9fail345_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn9end
Lfn9end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn10:
ldp x8, x9, [x0, #0]
Lfn10fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #112
stp x8, x9, [sp, #48]
ldr x2, [sp, #48]
ldr x3, [sp, #56]
ldr w4, [x2, #72]
cmn w4, #1
b.ne Lfn10loop
ldr x4, [x2]
cmp x3, x4
b.hi Lfn10loop
add x2, x2, #80
adrp x0, Lfn10scantable@PAGE
add x0, x0, Lfn10scantable@PAGEOFF
movi v1.16b, #32
movi v2.16b, #126
Lfn10scan:
sub x6, x4, x3
cmp x6, #16
b.lo Lfn10scanbyte
ldr q0, [x2, x3]
cmhs v3.16b, v0.16b, v1.16b
cmhs v4.16b, v2.16b, v0.16b
and v3.16b, v3.16b, v4.16b
uminv b3, v3.16b
umov w5, v3.b[0]
cbz w5, Lfn10scanbyte
add x3, x3, #16
b Lfn10scan
Lfn10scanbyte:
cmp x3, x4
b.eq Lfn10scanbad
ldrb w5, [x2, x3]
ldrb w5, [x0, x5]
cbz w5, Lfn10scanbad
cmp w5, #1
b.eq Lfn10scanfound
add x3, x3, #1
b Lfn10scan
Lfn10scanbad:
mov x3, #-1
Lfn10scanfound:
mov x0, x3
mov x1, #0
b Lfn10end
Lfn10loop:
ldr x0, [sp, #48]
ldr x0, [x0]
str x0, [sp, #64]
ldr x0, [sp, #56]
ldr x2, [sp, #64]
cmp x0, x2
b.ne Lfn10if359else
movn x0, #0, lsl #0
b Lfn10if359done
Lfn10if359else:
ldr x0, [sp, #48]
ldr x2, [sp, #56]
ldr x3, [x0]
cmp x2, x3
b.hs Lfn10fail367_4
ldr w3, [x0, #72]
cmn w3, #1
b.ne 1f
add x0, x0, #80
ldrb w0, [x0, x2]
b 2f
1:
mov x1, x2
bl _fen_bytes_index
2:
str x0, [sp, #72]
cmp x0, #13
b.ne Lfn10if370else
ldr x0, [sp, #56]
b Lfn10if370done
Lfn10if370else:
ldr x0, [sp, #72]
cmp x0, #9
b.ne Lfn10if376else
movz x0, #1, lsl #0
b Lfn10if376done
Lfn10if376else:
movz x0, #32, lsl #0
str x0, [sp, #80]
movz x0, #126, lsl #0
str x0, [sp, #88]
ldr x8, [sp, #72]
ldr x9, [sp, #80]
ldr x10, [sp, #88]
bl Lfn0fields
cbnz x1, Lfn10end
Lfn10if376done:
cbz x0, Lfn10if375else
ldr x0, [sp, #56]
adds x0, x0, #1
b.vs Lfn10fail389_1
str x0, [sp, #96]
ldr x8, [sp, #96]
str x8, [sp, #56]
b Lfn10loop
b Lfn10if375done
Lfn10if375else:
movn x0, #0, lsl #0
Lfn10if375done:
Lfn10if370done:
Lfn10if359done:
mov x1, #0
b Lfn10end
Lfn10fail367_4:
adrp x0, Lfn10fail367_4location@PAGE
add x0, x0, Lfn10fail367_4location@PAGEOFF
bl _fen_set_location
mov x1, #4
b Lfn10end
Lfn10fail389_1:
adrp x0, Lfn10fail389_1location@PAGE
add x0, x0, Lfn10fail389_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn10end
Lfn10end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn11:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
str x0, [sp, #48]
ldr x0, [sp, #48]
cmp x0, #32
b.ne Lfn11if395else
movz x0, #1, lsl #0
b Lfn11if395done
Lfn11if395else:
ldr x0, [sp, #48]
cmp x0, #9
cset x0, eq
Lfn11if395done:
mov x1, #0
b Lfn11end
Lfn11end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn12:
ldp x8, x9, [x0, #0]
ldr x10, [x0, #16]
Lfn12fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #80
stp x8, x9, [sp, #48]
str x10, [sp, #64]
Lfn12loop:
ldr x0, [sp, #56]
ldr x2, [sp, #64]
cmp x0, x2
b.ne Lfn12if417else
ldr x0, [sp, #64]
b Lfn12if417done
Lfn12if417else:
ldr x0, [sp, #48]
ldr x2, [sp, #56]
ldr x3, [x0]
cmp x2, x3
b.hs Lfn12fail424_4
ldr w3, [x0, #72]
cmn w3, #1
b.ne 1f
add x0, x0, #80
ldrb w0, [x0, x2]
b 2f
1:
mov x1, x2
bl _fen_bytes_index
2:
bl Lfn11
cbnz x1, Lfn12end
cbz x0, Lfn12if422else
ldr x0, [sp, #56]
adds x0, x0, #1
b.vs Lfn12fail430_1
str x0, [sp, #72]
ldr x8, [sp, #72]
str x8, [sp, #56]
b Lfn12loop
b Lfn12if422done
Lfn12if422else:
ldr x0, [sp, #56]
Lfn12if422done:
Lfn12if417done:
mov x1, #0
b Lfn12end
Lfn12fail424_4:
adrp x0, Lfn12fail424_4location@PAGE
add x0, x0, Lfn12fail424_4location@PAGEOFF
bl _fen_set_location
mov x1, #4
b Lfn12end
Lfn12fail430_1:
adrp x0, Lfn12fail430_1location@PAGE
add x0, x0, Lfn12fail430_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn12end
Lfn12end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn13:
ldp x8, x9, [x0, #0]
ldr x10, [x0, #16]
Lfn13fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #96
stp x8, x9, [sp, #48]
str x10, [sp, #64]
Lfn13loop:
ldr x0, [sp, #56]
ldr x2, [sp, #64]
cmp x0, x2
b.ne Lfn13if449else
ldr x0, [sp, #64]
b Lfn13if449done
Lfn13if449else:
ldr x0, [sp, #64]
subs x0, x0, #1
b.vs Lfn13fail458_1
str x0, [sp, #72]
ldr x0, [sp, #48]
ldr x2, [sp, #72]
ldr x3, [x0]
cmp x2, x3
b.hs Lfn13fail456_4
ldr w3, [x0, #72]
cmn w3, #1
b.ne 1f
add x0, x0, #80
ldrb w0, [x0, x2]
b 2f
1:
mov x1, x2
bl _fen_bytes_index
2:
bl Lfn11
cbnz x1, Lfn13end
cbz x0, Lfn13if454else
ldr x0, [sp, #64]
subs x0, x0, #1
b.vs Lfn13fail465_1
str x0, [sp, #80]
ldr x8, [sp, #80]
str x8, [sp, #64]
b Lfn13loop
b Lfn13if454done
Lfn13if454else:
ldr x0, [sp, #64]
Lfn13if454done:
Lfn13if449done:
mov x1, #0
b Lfn13end
Lfn13fail458_1:
adrp x0, Lfn13fail458_1location@PAGE
add x0, x0, Lfn13fail458_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn13end
Lfn13fail456_4:
adrp x0, Lfn13fail456_4location@PAGE
add x0, x0, Lfn13fail456_4location@PAGEOFF
bl _fen_set_location
mov x1, #4
b Lfn13end
Lfn13fail465_1:
adrp x0, Lfn13fail465_1location@PAGE
add x0, x0, Lfn13fail465_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn13end
Lfn13end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn14:
ldp x8, x9, [x0, #0]
ldr x10, [x0, #16]
Lfn14fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #80
stp x8, x9, [sp, #48]
str x10, [sp, #64]
Lfn14loop:
ldr x0, [sp, #56]
ldr x2, [sp, #64]
cmp x0, x2
b.ne Lfn14if483else
ldr x0, [sp, #64]
b Lfn14if483done
Lfn14if483else:
ldr x0, [sp, #48]
ldr x2, [sp, #56]
ldr x3, [x0]
cmp x2, x3
b.hs Lfn14fail490_4
ldr w3, [x0, #72]
cmn w3, #1
b.ne 1f
add x0, x0, #80
ldrb w0, [x0, x2]
b 2f
1:
mov x1, x2
bl _fen_bytes_index
2:
cmp x0, #44
b.ne Lfn14if488else
ldr x0, [sp, #56]
b Lfn14if488done
Lfn14if488else:
ldr x0, [sp, #56]
adds x0, x0, #1
b.vs Lfn14fail498_1
str x0, [sp, #72]
ldr x8, [sp, #72]
str x8, [sp, #56]
b Lfn14loop
Lfn14if488done:
Lfn14if483done:
mov x1, #0
b Lfn14end
Lfn14fail490_4:
adrp x0, Lfn14fail490_4location@PAGE
add x0, x0, Lfn14fail490_4location@PAGEOFF
bl _fen_set_location
mov x1, #4
b Lfn14end
Lfn14fail498_1:
adrp x0, Lfn14fail498_1location@PAGE
add x0, x0, Lfn14fail498_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn14end
Lfn14end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn15:
ldp x8, x9, [x0, #0]
ldr x10, [x0, #16]
Lfn15fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #112
stp x8, x9, [sp, #48]
str x10, [sp, #64]
Lfn15loop:
ldr x8, [sp, #48]
ldr x9, [sp, #56]
ldr x10, [sp, #64]
bl Lfn14fields
cbnz x1, Lfn15end
str x0, [sp, #72]
ldr x8, [sp, #48]
ldr x9, [sp, #56]
ldr x10, [sp, #72]
bl Lfn12fields
cbnz x1, Lfn15end
str x0, [sp, #80]
ldr x8, [sp, #48]
ldr x9, [sp, #80]
ldr x10, [sp, #72]
bl Lfn13fields
cbnz x1, Lfn15end
str x0, [sp, #88]
ldr x8, [sp, #48]
ldr x9, [sp, #80]
ldr x10, [sp, #88]
adrp x11, Lconstant6@PAGE
add x11, x11, Lconstant6@PAGEOFF
bl Lfn3fields
cbnz x1, Lfn15end
cbz x0, Lfn15if530else
movz x0, #1, lsl #0
b Lfn15if530done
Lfn15if530else:
ldr x0, [sp, #72]
ldr x2, [sp, #64]
cmp x0, x2
b.ne Lfn15if542else
movz x0, #0, lsl #0
b Lfn15if542done
Lfn15if542else:
ldr x0, [sp, #72]
adds x0, x0, #1
b.vs Lfn15fail550_1
str x0, [sp, #96]
ldr x8, [sp, #96]
str x8, [sp, #56]
b Lfn15loop
Lfn15if542done:
Lfn15if530done:
mov x1, #0
b Lfn15end
Lfn15fail550_1:
adrp x0, Lfn15fail550_1location@PAGE
add x0, x0, Lfn15fail550_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn15end
Lfn15end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn16:
ldp x8, x9, [x0, #0]
ldp x10, x11, [x0, #16]
ldr x12, [x0, #32]
Lfn16fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
stp x19, x20, [sp, #-16]!
stp x21, x22, [sp, #-16]!
stp x23, x24, [sp, #-16]!
sub sp, sp, #144
str x8, [sp, #48]
mov x19, x9
str x10, [sp, #56]
mov x23, x11
mov x24, x12
add x0, sp, #16
add x1, sp, #48
mov x2, #2
bl _fen_enter
Lfn16loop:
movz x0, #0, lsl #0
str x0, [sp, #64]
movz x0, #0, lsl #0
str x0, [sp, #72]
ldr x8, [sp, #48]
mov x9, x19
adrp x10, Lconstant7@PAGE
add x10, x10, Lconstant7@PAGEOFF
ldr x11, [sp, #64]
ldr x12, [sp, #72]
bl Lfn2fields
cbnz x1, Lfn16end
cbz x0, Lfn16if576else
mov x0, x23
cbz x0, Lfn16if585else
mov x0, x19
adds x0, x0, #2
b.vs Lfn16fail588_1
str x0, [sp, #80]
ldr x0, [sp, #48]
ldr x0, [x0]
str x0, [sp, #88]
ldr x0, [sp, #80]
ldr x2, [sp, #88]
cmp x0, x2
cset x0, eq
b Lfn16if585done
Lfn16if585else:
movz x0, #0, lsl #0
Lfn16if585done:
cbz x0, Lfn16if584else
mov x0, #1
mov x1, #13
bl _fen_allocate
cbz x0, Lfn16fail594_3
ldr x2, [sp, #56]
mov x3, x24
stp x2, x3, [x0, #0]
b Lfn16if584done
Lfn16if584else:
adrp x0, Lconstant8@PAGE
add x0, x0, Lconstant8@PAGEOFF
Lfn16if584done:
b Lfn16if576done
Lfn16if576else:
ldr x8, [sp, #48]
mov x9, x19
bl Lfn9fields
cbnz x1, Lfn16end
mov x21, x0
mov x2, x19
cmp x0, x2
b.gt Lfn16if604else
adrp x0, Lconstant8@PAGE
add x0, x0, Lconstant8@PAGEOFF
b Lfn16if604done
Lfn16if604else:
mov x0, x21
adds x0, x0, #1
b.vs Lfn16fail611_1
mov x22, x0
ldr x8, [sp, #48]
mov x9, x22
bl Lfn10fields
cbnz x1, Lfn16end
mov x20, x0
cmp x0, #0
b.ge Lfn16if620else
adrp x0, Lconstant8@PAGE
add x0, x0, Lconstant8@PAGEOFF
b Lfn16if620done
Lfn16if620else:
movz x0, #0, lsl #0
str x0, [sp, #96]
movz x0, #0, lsl #0
str x0, [sp, #104]
ldr x8, [sp, #48]
mov x9, x20
adrp x10, Lconstant7@PAGE
add x10, x10, Lconstant7@PAGEOFF
ldr x11, [sp, #96]
ldr x12, [sp, #104]
bl Lfn2fields
cbnz x1, Lfn16end
cbz x0, Lfn16if625else
ldr x8, [sp, #48]
mov x9, x19
mov x10, x21
adrp x11, Lconstant9@PAGE
add x11, x11, Lconstant9@PAGEOFF
bl Lfn3fields
cbnz x1, Lfn16end
cbz x0, Lfn16if633else
mov x0, x23
cbz x0, Lfn16if641else
movz x0, #1, lsl #0
b Lfn16if641done
Lfn16if641else:
ldr x8, [sp, #48]
mov x9, x22
mov x10, x20
bl Lfn12fields
cbnz x1, Lfn16end
mov x2, x20
cmp x0, x2
cset x0, eq
Lfn16if641done:
cbz x0, Lfn16if640else
adrp x0, Lconstant8@PAGE
add x0, x0, Lconstant8@PAGEOFF
b Lfn16if640done
Lfn16if640else:
mov x0, x20
adds x0, x0, #2
b.vs Lfn16fail655_1
str x0, [sp, #112]
movz x0, #1, lsl #0
str x0, [sp, #120]
ldr x8, [sp, #112]
ldr x9, [sp, #120]
mov x19, x8
mov x23, x9
b Lfn16loop
Lfn16if640done:
b Lfn16if633done
Lfn16if633else:
ldr x8, [sp, #48]
mov x9, x19
mov x10, x21
adrp x11, Lconstant10@PAGE
add x11, x11, Lconstant10@PAGEOFF
bl Lfn3fields
cbnz x1, Lfn16end
cbz x0, Lfn16if662else
movz x0, #1, lsl #0
b Lfn16if662done
Lfn16if662else:
ldr x8, [sp, #48]
mov x9, x19
mov x10, x21
adrp x11, Lconstant11@PAGE
add x11, x11, Lconstant11@PAGEOFF
bl Lfn3fields
cbnz x1, Lfn16end
Lfn16if662done:
cbz x0, Lfn16if661else
adrp x0, Lconstant8@PAGE
add x0, x0, Lconstant8@PAGEOFF
b Lfn16if661done
Lfn16if661else:
mov x0, x20
adds x0, x0, #2
b.vs Lfn16fail680_1
str x0, [sp, #128]
mov x0, x24
cbz x0, Lfn16if685else
movz x0, #1, lsl #0
b Lfn16if685done
Lfn16if685else:
ldr x8, [sp, #48]
mov x9, x19
mov x10, x21
adrp x11, Lconstant12@PAGE
add x11, x11, Lconstant12@PAGEOFF
bl Lfn3fields
cbnz x1, Lfn16end
cbz x0, Lfn16if688else
ldr x8, [sp, #48]
mov x9, x22
mov x10, x20
bl Lfn15fields
cbnz x1, Lfn16end
b Lfn16if688done
Lfn16if688else:
movz x0, #0, lsl #0
Lfn16if688done:
Lfn16if685done:
str x0, [sp, #136]
ldr x8, [sp, #128]
ldr x9, [sp, #136]
mov x19, x8
mov x24, x9
b Lfn16loop
Lfn16if661done:
Lfn16if633done:
b Lfn16if625done
Lfn16if625else:
adrp x0, Lconstant8@PAGE
add x0, x0, Lconstant8@PAGEOFF
Lfn16if625done:
Lfn16if620done:
Lfn16if604done:
Lfn16if576done:
mov x1, #0
b Lfn16end
Lfn16fail588_1:
adrp x0, Lfn16fail588_1location@PAGE
add x0, x0, Lfn16fail588_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn16end
Lfn16fail594_3:
adrp x0, Lfn16fail594_3location@PAGE
add x0, x0, Lfn16fail594_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn16end
Lfn16fail611_1:
adrp x0, Lfn16fail611_1location@PAGE
add x0, x0, Lfn16fail611_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn16end
Lfn16fail655_1:
adrp x0, Lfn16fail655_1location@PAGE
add x0, x0, Lfn16fail655_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn16end
Lfn16fail680_1:
adrp x0, Lfn16fail680_1location@PAGE
add x0, x0, Lfn16fail680_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn16end
Lfn16end:
bl _fen_leave_result
ldp x19, x20, [x29, #-16]
ldp x21, x22, [x29, #-32]
ldp x23, x24, [x29, #-48]
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn17:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #160
str xzr, [sp, #56]
str x0, [sp, #48]
add x0, sp, #16
add x1, sp, #48
mov x2, #2
bl _fen_enter
ldr x0, [sp, #48]
ldr x0, [x0]
str x0, [sp, #64]
movz x0, #8192, lsl #0
str x0, [sp, #72]
ldr x0, [sp, #64]
ldr x2, [sp, #72]
cmp x0, x2
b.le Lfn17if704else
adrp x0, Lconstant13@PAGE
add x0, x0, Lconstant13@PAGEOFF
b Lfn17if704done
Lfn17if704else:
movz x0, #0, lsl #0
str x0, [sp, #80]
movz x0, #0, lsl #0
str x0, [sp, #88]
movz x0, #0, lsl #0
str x0, [sp, #96]
ldr x8, [sp, #48]
ldr x9, [sp, #80]
adrp x10, Lconstant14@PAGE
add x10, x10, Lconstant14@PAGEOFF
ldr x11, [sp, #88]
ldr x12, [sp, #96]
bl Lfn2fields
cbnz x1, Lfn17end
cbz x0, Lfn17if710else
movz x0, #4, lsl #0
str x0, [sp, #104]
ldr x8, [sp, #48]
ldr x9, [sp, #104]
bl Lfn4fields
cbnz x1, Lfn17end
str x0, [sp, #112]
cmp x0, #0
b.ge Lfn17if724else
adrp x0, Lconstant8@PAGE
add x0, x0, Lconstant8@PAGEOFF
b Lfn17if724done
Lfn17if724else:
movz x0, #0, lsl #0
str x0, [sp, #120]
movz x0, #0, lsl #0
str x0, [sp, #128]
ldr x8, [sp, #48]
ldr x9, [sp, #112]
adrp x10, Lconstant15@PAGE
add x10, x10, Lconstant15@PAGEOFF
ldr x11, [sp, #120]
ldr x12, [sp, #128]
bl Lfn2fields
cbnz x1, Lfn17end
cbz x0, Lfn17if729else
ldr x0, [sp, #112]
adds x0, x0, #11
b.vs Lfn17fail740_1
str x0, [sp, #136]
ldr x8, [sp, #48]
ldr x9, [sp, #112]
bl Lfn6fields
cbnz x1, Lfn17end
str x0, [sp, #56]
movz x0, #0, lsl #0
str x0, [sp, #144]
movz x0, #0, lsl #0
str x0, [sp, #152]
bl _fen_leave_result
ldr x8, [sp, #48]
ldr x9, [sp, #136]
ldr x10, [sp, #56]
ldr x11, [sp, #144]
ldr x12, [sp, #152]
mov sp, x29
ldp x29, x30, [sp], #16
b Lfn16fields
b Lfn17if729done
Lfn17if729else:
adrp x0, Lconstant8@PAGE
add x0, x0, Lconstant8@PAGEOFF
Lfn17if729done:
Lfn17if724done:
b Lfn17if710done
Lfn17if710else:
adrp x0, Lconstant8@PAGE
add x0, x0, Lconstant8@PAGEOFF
Lfn17if710done:
Lfn17if704done:
mov x1, #0
b Lfn17end
Lfn17fail740_1:
adrp x0, Lfn17fail740_1location@PAGE
add x0, x0, Lfn17fail740_1location@PAGEOFF
bl _fen_set_location
mov x1, #1
b Lfn17end
Lfn17end:
bl _fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
.globl _http_response
_http_response:
Lfn18:
ldp x8, x9, [x0, #0]
Lfn18fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #160
str xzr, [sp, #56]
str x8, [sp, #48]
str x9, [sp, #64]
add x0, sp, #16
add x1, sp, #48
mov x2, #2
bl _fen_enter
Lfn18loop:
ldr x0, [sp, #64]
cbz x0, Lfn18if761else
ldr x0, [sp, #48]
bl Lfn17
cbnz x1, Lfn18end
str x0, [sp, #56]
ldr w0, [x0, #72]
cmp w0, #11
b.eq Lfn18match763arm11
cmp w0, #12
b.eq Lfn18match763arm12
cmp w0, #13
b.eq Lfn18match763arm13
brk #0
Lfn18match763arm11:
adrp x0, Lconstant16@PAGE
add x0, x0, Lconstant16@PAGEOFF
b Lfn18match763end
Lfn18match763arm12:
adrp x0, Lconstant17@PAGE
add x0, x0, Lconstant17@PAGEOFF
b Lfn18match763end
Lfn18match763arm13:
ldr x0, [sp, #56]
ldr x0, [x0, #0]
ldr w0, [x0, #72]
cmp w0, #7
b.eq Lfn18match778arm7
cmp w0, #8
b.eq Lfn18match778arm8
cmp w0, #9
b.eq Lfn18match778arm9
cmp w0, #10
b.eq Lfn18match778arm10
brk #0
Lfn18match778arm7:
movz x0, #200, lsl #0
str x0, [sp, #72]
movz x0, #0, lsl #0
str x0, [sp, #80]
movz x0, #0, lsl #0
str x0, [sp, #88]
mov x0, #0
mov x1, #0
bl _fen_allocate
cbz x0, Lfn18fail780_3
ldr x2, [sp, #72]
ldr x3, [sp, #56]
ldr x3, [x3, #8]
stp x2, x3, [x0, #0]
ldr x2, [sp, #80]
ldr x3, [sp, #88]
stp x2, x3, [x0, #16]
b Lfn18match778end
Lfn18match778arm8:
movz x0, #200, lsl #0
str x0, [sp, #96]
movn x0, #0, lsl #0
str x0, [sp, #104]
movz x0, #0, lsl #0
str x0, [sp, #112]
mov x0, #0
mov x1, #0
bl _fen_allocate
cbz x0, Lfn18fail785_3
ldr x2, [sp, #96]
ldr x3, [sp, #56]
ldr x3, [x3, #8]
stp x2, x3, [x0, #0]
ldr x2, [sp, #104]
ldr x3, [sp, #112]
stp x2, x3, [x0, #16]
b Lfn18match778end
Lfn18match778arm9:
movz x0, #200, lsl #0
str x0, [sp, #120]
mov x0, #0
mov x1, #0
bl _fen_allocate
cbz x0, Lfn18fail792_3
ldr x2, [sp, #120]
ldr x3, [sp, #56]
ldr x3, [x3, #8]
stp x2, x3, [x0, #0]
ldr x4, [sp, #56]
ldr x4, [x4, #0]
ldp x2, x3, [x4, #0]
stp x2, x3, [x0, #16]
b Lfn18match778end
Lfn18match778arm10:
movz x0, #404, lsl #0
str x0, [sp, #128]
movz x0, #0, lsl #0
str x0, [sp, #136]
movz x0, #0, lsl #0
str x0, [sp, #144]
mov x0, #0
mov x1, #0
bl _fen_allocate
cbz x0, Lfn18fail797_3
ldr x2, [sp, #128]
ldr x3, [sp, #56]
ldr x3, [x3, #8]
stp x2, x3, [x0, #0]
ldr x2, [sp, #136]
ldr x3, [sp, #144]
stp x2, x3, [x0, #16]
b Lfn18match778end
Lfn18match778end:
b Lfn18match763end
Lfn18match763end:
b Lfn18if761done
Lfn18if761else:
adrp x0, Lconstant17@PAGE
add x0, x0, Lconstant17@PAGEOFF
Lfn18if761done:
mov x1, #0
b Lfn18end
Lfn18fail780_3:
adrp x0, Lfn18fail780_3location@PAGE
add x0, x0, Lfn18fail780_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn18end
Lfn18fail785_3:
adrp x0, Lfn18fail785_3location@PAGE
add x0, x0, Lfn18fail785_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn18end
Lfn18fail792_3:
adrp x0, Lfn18fail792_3location@PAGE
add x0, x0, Lfn18fail792_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn18end
Lfn18fail797_3:
adrp x0, Lfn18fail797_3location@PAGE
add x0, x0, Lfn18fail797_3location@PAGEOFF
bl _fen_set_location
mov x1, #3
b Lfn18end
Lfn18end:
bl _fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
.globl _fenrir_entry
_fenrir_entry:
Lfn19:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
str x0, [sp, #48]
ldr x0, [sp, #48]
mov x1, #0
b Lfn19end
Lfn19end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
.text
.globl _fen_print_result
_fen_print_result:
b Lprint0
Lprint0:
b _fen_write_i64
Lfn1fail30_1location:
.byte 116,114,97,112,32,97,116,58,32,114,111,117,116,101,114,46,102,101,110,58,56,58,51,48,10,0
Lfn2fail70_4location:
.byte 116,114,97,112,32,97,116,58,32,114,111,117,116,101,114,46,102,101,110,58,49,52,58,49,54,10,0
Lfn2fail80_4location:
.byte 116,114,97,112,32,97,116,58,32,114,111,117,116,101,114,46,102,101,110,58,49,53,58,52,48,10,0
Lfn2fail86_1location:
.byte 116,114,97,112,32,97,116,58,32,114,111,117,116,101,114,46,102,101,110,58,49,54,58,50,54,10,0
Lfn2fail90_1location:
.byte 116,114,97,112,32,97,116,58,32,114,111,117,116,101,114,46,102,101,110,58,49,54,58,52,49,10,0
Lfn3fail115_1location:
.byte 116,114,97,112,32,97,116,58,32,114,111,117,116,101,114,46,102,101,110,58,49,57,58,51,50,10,0
Lfn4scantable:
.byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
Lfn4fail146_4location:
.byte 116,114,97,112,32,97,116,58,32,114,111,117,116,101,114,46,102,101,110,58,50,52,58,49,50,10,0
Lfn4fail163_1location:
.byte 116,114,97,112,32,97,116,58,32,114,111,117,116,101,114,46,102,101,110,58,50,53,58,53,57,10,0
Lfn5fail189_4location:
.byte 116,114,97,112,32,97,116,58,32,114,111,117,116,101,114,46,102,101,110,58,50,57,58,49,56,10,0
Lfn5fail197_1location:
.byte 116,114,97,112,32,97,116,58,32,114,111,117,116,101,114,46,102,101,110,58,50,57,58,53,55,10,0
.p2align 3
Lconstant0:
.zero 72
.long 7
.byte 0,2,0,0
.p2align 3
Lconstant1:
.quad 7
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 47,115,116,97,116,117,115
.p2align 3
Lconstant2:
.zero 72
.long 8
.byte 0,2,0,0
.p2align 3
Lconstant3:
.quad 7
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 47,105,116,101,109,115,47
.p2align 3
Lconstant4:
.zero 72
.long 10
.byte 0,2,0,0
Lfn6fail252_1location:
.byte 116,114,97,112,32,97,116,58,32,114,111,117,116,101,114,46,102,101,110,58,51,53,58,52,50,10,0
Lfn6fail250_3location:
.byte 116,114,97,112,32,97,116,58,32,114,111,117,116,101,114,46,102,101,110,58,51,53,58,51,51,10,0
Lfn7fail280_4location:
.byte 116,114,97,112,32,97,116,58,32,114,111,117,116,101,114,46,102,101,110,58,51,57,58,49,52,10,0
Lfn7fail288_1location:
.byte 116,114,97,112,32,97,116,58,32,114,111,117,116,101,114,46,102,101,110,58,51,57,58,54,49,10,0
.p2align 3
Lconstant5:
.quad 15
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 33,35,36,37,38,39,42,43,45,46,94,95,96,124,126
Lfn9fail331_4location:
.byte 116,114,97,112,32,97,116,58,32,114,111,117,116,101,114,46,102,101,110,58,52,55,58,49,50,10,0
Lfn9fail345_1location:
.byte 116,114,97,112,32,97,116,58,32,114,111,117,116,101,114,46,102,101,110,58,52,56,58,52,48,10,0
Lfn10scantable:
.byte 0,0,0,0,0,0,0,0,0,2,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
Lfn10fail367_4location:
.byte 116,114,97,112,32,97,116,58,32,114,111,117,116,101,114,46,102,101,110,58,53,50,58,49,50,10,0
Lfn10fail389_1location:
.byte 116,114,97,112,32,97,116,58,32,114,111,117,116,101,114,46,102,101,110,58,53,51,58,54,51,10,0
Lfn12fail424_4location:
.byte 116,114,97,112,32,97,116,58,32,114,111,117,116,101,114,46,102,101,110,58,53,57,58,49,54,10,0
Lfn12fail430_1location:
.byte 116,114,97,112,32,97,116,58,32,114,111,117,116,101,114,46,102,101,110,58,53,57,58,53,51,10,0
Lfn13fail458_1location:
.byte 116,114,97,112,32,97,116,58,32,114,111,117,116,101,114,46,102,101,110,58,54,51,58,51,51,10,0
Lfn13fail456_4location:
.byte 116,114,97,112,32,97,116,58,32,114,111,117,116,101,114,46,102,101,110,58,54,51,58,49,54,10,0
Lfn13fail465_1location:
.byte 116,114,97,112,32,97,116,58,32,114,111,117,116,101,114,46,102,101,110,58,54,51,58,54,53,10,0
Lfn14fail490_4location:
.byte 116,114,97,112,32,97,116,58,32,114,111,117,116,101,114,46,102,101,110,58,54,55,58,49,50,10,0
Lfn14fail498_1location:
.byte 116,114,97,112,32,97,116,58,32,114,111,117,116,101,114,46,102,101,110,58,54,55,58,53,50,10,0
.p2align 3
Lconstant6:
.quad 5
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 99,108,111,115,101
Lfn15fail550_1location:
.byte 116,114,97,112,32,97,116,58,32,114,111,117,116,101,114,46,102,101,110,58,55,51,58,53,48,10,0
.p2align 3
Lconstant7:
.quad 2
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 13,10
.p2align 3
Lconstant8:
.zero 72
.long 11
.byte 0,2,0,0
.p2align 3
Lconstant9:
.quad 4
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 104,111,115,116
.p2align 3
Lconstant10:
.quad 14
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 99,111,110,116,101,110,116,45,108,101,110,103,116,104
.p2align 3
Lconstant11:
.quad 17
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 116,114,97,110,115,102,101,114,45,101,110,99,111,100,105,110,103
.p2align 3
Lconstant12:
.quad 10
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 99,111,110,110,101,99,116,105,111,110
Lfn16fail588_1location:
.byte 116,114,97,112,32,97,116,58,32,114,111,117,116,101,114,46,102,101,110,58,55,56,58,50,51,10,0
Lfn16fail594_3location:
.byte 116,114,97,112,32,97,116,58,32,114,111,117,116,101,114,46,102,101,110,58,55,56,58,53,56,10,0
Lfn16fail611_1location:
.byte 116,114,97,112,32,97,116,58,32,114,111,117,116,101,114,46,102,101,110,58,56,49,58,50,50,10,0
Lfn16fail655_1location:
.byte 116,114,97,112,32,97,116,58,32,114,111,117,116,101,114,46,102,101,110,58,56,55,58,51,54,10,0
Lfn16fail680_1location:
.byte 116,114,97,112,32,97,116,58,32,114,111,117,116,101,114,46,102,101,110,58,57,48,58,51,54,10,0
.p2align 3
Lconstant13:
.zero 72
.long 12
.byte 0,2,0,0
.p2align 3
Lconstant14:
.quad 5
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 71,69,84,32,47
.p2align 3
Lconstant15:
.quad 11
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 32,72,84,84,80,47,49,46,49,13,10
Lfn17fail740_1location:
.byte 116,114,97,112,32,97,116,58,32,114,111,117,116,101,114,46,102,101,110,58,49,48,48,58,50,54,10,0
.p2align 3
Lconstant16:
.quad 400
.quad 1
.quad 0
.quad 0
.zero 40
.long 0
.byte 0,2,0,0
.p2align 3
Lconstant17:
.quad 431
.quad 1
.quad 0
.quad 0
.zero 40
.long 0
.byte 0,2,0,0
Lfn18fail780_3location:
.byte 116,114,97,112,32,97,116,58,32,115,101,114,118,105,99,101,46,102,101,110,58,57,58,49,56,10,0
Lfn18fail785_3location:
.byte 116,114,97,112,32,97,116,58,32,115,101,114,118,105,99,101,46,102,101,110,58,49,48,58,50,48,10,0
Lfn18fail792_3location:
.byte 116,114,97,112,32,97,116,58,32,115,101,114,118,105,99,101,46,102,101,110,58,49,49,58,50,56,10,0
Lfn18fail797_3location:
.byte 116,114,97,112,32,97,116,58,32,115,101,114,118,105,99,101,46,102,101,110,58,49,50,58,50,49,10,0
