.text
.p2align 2
Lfn0:
ldp x8, x9, [x0, #0]
Lfn0fields:
ldr w2, [x8, #72]
cmp w2, #10
b.ne Lfn0frame
mov x0, x9
mov x1, #0
ret
Lfn0frame:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #80
stp xzr, xzr, [sp, #64]
stp x8, x9, [sp, #48]
add x0, sp, #16
add x1, sp, #48
mov x2, #4
bl fen_enter
Lfn0loop:
ldr x0, [sp, #48]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn0match10arm10
cmp w0, #11
b.eq Lfn0match10arm11
brk #0
Lfn0match10arm10:
ldr x0, [sp, #56]
b Lfn0match10end
Lfn0match10arm11:
ldr x0, [sp, #48]
ldr x0, [x0, #16]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn0match16arm10
cmp w0, #11
b.eq Lfn0match16arm11
brk #0
Lfn0match16arm10:
mov x0, #6
mov x1, #11
bl fen_allocate
cbz x0, Lfn0fail18_3
ldr x4, [sp, #48]
ldp x2, x3, [x4, #0]
stp x2, x3, [x0, #0]
ldr x2, [sp, #56]
str x2, [x0, #16]
b Lfn0match16end
Lfn0match16arm11:
ldr x8, [sp, #48]
ldr x8, [x8, #16]
ldr x8, [x8, #16]
ldr x9, [sp, #56]
bl Lfn0fields
cbnz x1, Lfn0end
str x0, [sp, #64]
mov x0, #6
mov x1, #11
bl fen_allocate
cbz x0, Lfn0fail28_3
ldr x4, [sp, #48]
ldr x4, [x4, #16]
ldp x2, x3, [x4, #0]
stp x2, x3, [x0, #0]
ldr x2, [sp, #64]
str x2, [x0, #16]
str x0, [sp, #72]
mov x0, #6
mov x1, #11
bl fen_allocate
cbz x0, Lfn0fail25_3
ldr x4, [sp, #48]
ldp x2, x3, [x4, #0]
stp x2, x3, [x0, #0]
ldr x2, [sp, #72]
str x2, [x0, #16]
b Lfn0match16end
Lfn0match16end:
b Lfn0match10end
Lfn0match10end:
mov x1, #0
b Lfn0end
Lfn0fail18_3:
adrp x0, Lfn0fail18_3location
add x0, x0, :lo12:Lfn0fail18_3location
bl fen_set_location
mov x1, #3
b Lfn0end
Lfn0fail28_3:
adrp x0, Lfn0fail28_3location
add x0, x0, :lo12:Lfn0fail28_3location
bl fen_set_location
mov x1, #3
b Lfn0end
Lfn0fail25_3:
adrp x0, Lfn0fail25_3location
add x0, x0, :lo12:Lfn0fail25_3location
bl fen_set_location
mov x1, #3
b Lfn0end
Lfn0end:
bl fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn1:
ldp x8, x9, [x0, #0]
ldr x10, [x0, #16]
Lfn1fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #80
str xzr, [sp, #64]
str x8, [sp, #48]
str x9, [sp, #72]
str x10, [sp, #56]
add x0, sp, #16
add x1, sp, #48
mov x2, #3
bl fen_enter
Lfn1loop:
mov x0, #6
mov x1, #11
bl fen_allocate
cbz x0, Lfn1fail52_3
ldr x2, [sp, #72]
ldr x3, [sp, #56]
stp x2, x3, [x0, #0]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
str x2, [x0, #16]
str x0, [sp, #64]
bl fen_leave_result
ldr x8, [sp, #48]
ldr x9, [sp, #64]
mov sp, x29
ldp x29, x30, [sp], #16
b Lfn0fields
mov x1, #0
b Lfn1end
Lfn1fail52_3:
adrp x0, Lfn1fail52_3location
add x0, x0, :lo12:Lfn1fail52_3location
bl fen_set_location
mov x1, #3
b Lfn1end
Lfn1end:
bl fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn2:
ldp x8, x9, [x0, #0]
Lfn2fields:
tbnz x8, #63, Lfn2arithmetic
cmp x9, #0
b.le Lfn2arithmetic
sub x2, x9, #1
tst x2, x9
b.ne Lfn2arithmetic
tst x8, x9
cset x0, ne
mov x1, #0
ret
Lfn2arithmetic:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
stp x8, x9, [sp, #48]
Lfn2loop:
ldr x0, [sp, #48]
ldr x2, [sp, #56]
cmp x0, x2
b.ge Lfn2if66else
movz x0, #0, lsl #0
b Lfn2if66done
Lfn2if66else:
ldr x0, [sp, #48]
ldr x2, [sp, #56]
cbz x2, Lfn2fail73_2
cmn x2, #1
b.ne 1f
negs x3, x0
b.vs Lfn2fail73_1
1:
sdiv x0, x0, x2
cmp x0, #0
neg x2, x0
and x2, x2, #1
and x0, x0, #1
csneg x0, x0, x2, ge
cmp x0, #1
cset x0, eq
Lfn2if66done:
mov x1, #0
b Lfn2end
Lfn2fail73_2:
adrp x0, Lfn2fail73_2location
add x0, x0, :lo12:Lfn2fail73_2location
bl fen_set_location
mov x1, #2
b Lfn2end
Lfn2fail73_1:
adrp x0, Lfn2fail73_1location
add x0, x0, :lo12:Lfn2fail73_1location
bl fen_set_location
mov x1, #1
b Lfn2end
Lfn2end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn3:
ldp x8, x9, [x0, #0]
Lfn3fields:
tbnz x8, #63, Lfn3arithmetic
cmp x9, #0
b.le Lfn3arithmetic
sub x2, x9, #1
tst x2, x9
b.ne Lfn3arithmetic
orr x0, x8, x9
mov x1, #0
ret
Lfn3arithmetic:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
stp x8, x9, [sp, #48]
Lfn3loop:
ldr x0, [sp, #48]
ldr x2, [sp, #56]
cmp x0, x2
b.ge Lfn3if95else
ldr x0, [sp, #48]
ldr x2, [sp, #56]
adds x0, x0, x2
b.vs Lfn3fail99_1
b Lfn3if95done
Lfn3if95else:
ldr x8, [sp, #48]
ldr x9, [sp, #56]
bl Lfn2fields
cbnz x1, Lfn3end
cbz x0, Lfn3if102else
ldr x0, [sp, #48]
b Lfn3if102done
Lfn3if102else:
ldr x0, [sp, #48]
ldr x2, [sp, #56]
adds x0, x0, x2
b.vs Lfn3fail108_1
Lfn3if102done:
Lfn3if95done:
mov x1, #0
b Lfn3end
Lfn3fail99_1:
adrp x0, Lfn3fail99_1location
add x0, x0, :lo12:Lfn3fail99_1location
bl fen_set_location
mov x1, #1
b Lfn3end
Lfn3fail108_1:
adrp x0, Lfn3fail108_1location
add x0, x0, :lo12:Lfn3fail108_1location
bl fen_set_location
mov x1, #1
b Lfn3end
Lfn3end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn4:
ldp x8, x9, [x0, #0]
Lfn4fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
stp x19, xzr, [sp, #-16]!
sub sp, sp, #128
str xzr, [sp, #56]
mov x19, x8
str x9, [sp, #48]
add x0, sp, #16
add x1, sp, #48
mov x2, #2
bl fen_enter
Lfn4loop:
mov x0, x19
cmp x0, #8
b.lt Lfn4if121else
mov x0, x19
subs x0, x0, #8
b.vs Lfn4fail127_1
str x0, [sp, #64]
adrp x0, Lconstant1
add x0, x0, :lo12:Lconstant1
ldr x2, [sp, #48]
mov x1, x2
bl fen_bytes_concat
cbz x0, Lfn4fail130_3
str x0, [sp, #56]
ldr x8, [sp, #64]
ldr x9, [sp, #56]
mov x19, x8
str x9, [sp, #48]
str xzr, [sp, #56]
b Lfn4loop
b Lfn4if121done
Lfn4if121else:
mov x0, x19
cmp x0, #0
b.ne Lfn4if133else
ldr x0, [sp, #48]
b Lfn4if133done
Lfn4if133else:
mov x0, x19
cmp x0, #4
b.ge Lfn4if139else
mov x0, x19
cmp x0, #2
b.ge Lfn4if143else
adrp x0, Lconstant2
add x0, x0, :lo12:Lconstant2
b Lfn4if143done
Lfn4if143else:
mov x0, x19
cmp x0, #2
b.ne Lfn4if148else
adrp x0, Lconstant3
add x0, x0, :lo12:Lconstant3
b Lfn4if148done
Lfn4if148else:
adrp x0, Lconstant4
add x0, x0, :lo12:Lconstant4
Lfn4if148done:
str x0, [sp, #72]
Lfn4if143done:
str x0, [sp, #80]
b Lfn4if139done
Lfn4if139else:
mov x0, x19
cmp x0, #6
b.ge Lfn4if154else
mov x0, x19
cmp x0, #4
b.ne Lfn4if158else
adrp x0, Lconstant5
add x0, x0, :lo12:Lconstant5
b Lfn4if158done
Lfn4if158else:
adrp x0, Lconstant6
add x0, x0, :lo12:Lconstant6
Lfn4if158done:
str x0, [sp, #88]
b Lfn4if154done
Lfn4if154else:
mov x0, x19
cmp x0, #6
b.ne Lfn4if164else
adrp x0, Lconstant7
add x0, x0, :lo12:Lconstant7
b Lfn4if164done
Lfn4if164else:
adrp x0, Lconstant8
add x0, x0, :lo12:Lconstant8
Lfn4if164done:
str x0, [sp, #96]
Lfn4if154done:
str x0, [sp, #104]
Lfn4if139done:
str x0, [sp, #112]
ldr x2, [sp, #48]
mov x1, x2
bl fen_bytes_concat
cbz x0, Lfn4fail138_3
Lfn4if133done:
Lfn4if121done:
mov x1, #0
b Lfn4end
Lfn4fail127_1:
adrp x0, Lfn4fail127_1location
add x0, x0, :lo12:Lfn4fail127_1location
bl fen_set_location
mov x1, #1
b Lfn4end
Lfn4fail130_3:
adrp x0, Lfn4fail130_3location
add x0, x0, :lo12:Lfn4fail130_3location
bl fen_set_location
mov x1, #3
b Lfn4end
Lfn4fail138_3:
adrp x0, Lfn4fail138_3location
add x0, x0, :lo12:Lfn4fail138_3location
bl fen_set_location
mov x1, #3
b Lfn4end
Lfn4end:
bl fen_leave_result
ldp x19, xzr, [x29, #-16]
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn5:
ldp x8, x9, [x0, #0]
ldp x10, x11, [x0, #16]
ldp x12, x13, [x0, #32]
Lfn5fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
stp x19, x20, [sp, #-16]!
stp x21, x22, [sp, #-16]!
stp x23, x24, [sp, #-16]!
sub sp, sp, #256
stp xzr, xzr, [sp, #64]
stp xzr, xzr, [sp, #80]
stp xzr, xzr, [sp, #96]
stp xzr, xzr, [sp, #112]
str xzr, [sp, #128]
stp x8, x9, [sp, #48]
mov x21, x10
mov x22, x11
mov x23, x12
mov x19, x13
add x0, sp, #16
add x1, sp, #48
mov x2, #11
bl fen_enter
Lfn5loop:
mov x0, x23
cmp x0, #0
b.ne Lfn5if197else
adrp x0, Lconstant9
add x0, x0, :lo12:Lconstant9
b Lfn5if197done
Lfn5if197else:
mov x0, x23
subs x0, x0, #1
b.vs Lfn5fail204_1
mov x20, x0
ldr x0, [sp, #48]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn5match207arm10
cmp w0, #11
b.eq Lfn5match207arm11
brk #0
Lfn5match207arm10:
ldr x0, [sp, #56]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn5match209arm10
cmp w0, #11
b.eq Lfn5match209arm11
brk #0
Lfn5match209arm10:
mov x0, #0
mov x1, #13
bl fen_allocate
cbz x0, Lfn5fail211_3
mov x2, x21
mov x3, x20
stp x2, x3, [x0, #0]
b Lfn5match209end
Lfn5match209arm11:
ldr x8, [sp, #56]
adrp x9, Lconstant0
add x9, x9, :lo12:Lconstant0
str x8, [sp, #48]
str x9, [sp, #56]
stp xzr, xzr, [sp, #64]
stp xzr, xzr, [sp, #80]
stp xzr, xzr, [sp, #96]
stp xzr, xzr, [sp, #112]
str xzr, [sp, #128]
b Lfn5loop
b Lfn5match209end
Lfn5match209end:
b Lfn5match207end
Lfn5match207arm11:
ldr x0, [sp, #48]
ldr x0, [x0, #8]
ldr w0, [x0, #72]
cmp w0, #7
b.eq Lfn5match228arm7
cmp w0, #8
b.eq Lfn5match228arm8
cmp w0, #9
b.eq Lfn5match228arm9
brk #0
Lfn5match228arm7:
ldr x0, [sp, #48]
ldr x0, [x0, #0]
cbz x0, Lfn5if234else
mov x0, x22
b Lfn5if234done
Lfn5if234else:
mov x0, x21
Lfn5if234done:
str x0, [sp, #136]
ldr x8, [sp, #136]
ldr x9, [sp, #48]
ldr x9, [x9, #8]
ldr x9, [x9, #0]
bl Lfn2fields
cbnz x1, Lfn5end
cbz x0, Lfn5if231else
mov x8, x19
adrp x9, Lconstant10
add x9, x9, :lo12:Lconstant10
bl Lfn4fields
cbnz x1, Lfn5end
str x0, [sp, #64]
mov x0, #1
mov x1, #12
bl fen_allocate
cbz x0, Lfn5fail239_3
ldr x2, [sp, #64]
mov x3, x20
stp x2, x3, [x0, #0]
b Lfn5if231done
Lfn5if231else:
ldr x0, [sp, #48]
ldr x0, [x0, #0]
cbz x0, Lfn5if249else
mov x8, x21
ldr x9, [sp, #48]
ldr x9, [x9, #8]
ldr x9, [x9, #0]
bl Lfn3fields
cbnz x1, Lfn5end
b Lfn5if249done
Lfn5if249else:
mov x0, x21
Lfn5if249done:
str x0, [sp, #144]
ldr x0, [sp, #48]
ldr x0, [x0, #0]
cbz x0, Lfn5if256else
mov x0, x22
b Lfn5if256done
Lfn5if256else:
mov x8, x22
ldr x9, [sp, #48]
ldr x9, [x9, #8]
ldr x9, [x9, #0]
bl Lfn3fields
cbnz x1, Lfn5end
Lfn5if256done:
str x0, [sp, #152]
mov x0, x19
adds x0, x0, #1
b.vs Lfn5fail264_1
str x0, [sp, #160]
ldr x8, [sp, #48]
ldr x8, [x8, #16]
ldr x9, [sp, #144]
ldr x10, [sp, #152]
mov x11, x20
ldr x12, [sp, #160]
str x8, [sp, #48]
mov x21, x9
mov x22, x10
mov x23, x11
mov x19, x12
stp xzr, xzr, [sp, #64]
stp xzr, xzr, [sp, #80]
stp xzr, xzr, [sp, #96]
stp xzr, xzr, [sp, #112]
str xzr, [sp, #128]
b Lfn5loop
Lfn5if231done:
b Lfn5match228end
Lfn5match228arm8:
ldr x0, [sp, #48]
ldr x0, [x0, #16]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn5match268arm10
cmp w0, #11
b.eq Lfn5match268arm11
brk #0
Lfn5match268arm10:
ldr x0, [sp, #48]
ldr x0, [x0, #0]
eor x0, x0, #1
str x0, [sp, #168]
mov x0, #6
mov x1, #11
bl fen_allocate
cbz x0, Lfn5fail273_3
ldr x2, [sp, #168]
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #0]
stp x2, x3, [x0, #0]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
str x2, [x0, #16]
str x0, [sp, #64]
mov x0, x19
adds x0, x0, #1
b.vs Lfn5fail281_1
str x0, [sp, #176]
ldr x8, [sp, #56]
ldr x9, [sp, #64]
mov x10, x20
ldr x11, [sp, #176]
str x8, [sp, #48]
str x9, [sp, #56]
mov x23, x10
mov x19, x11
stp xzr, xzr, [sp, #64]
stp xzr, xzr, [sp, #80]
stp xzr, xzr, [sp, #96]
stp xzr, xzr, [sp, #112]
str xzr, [sp, #128]
b Lfn5loop
b Lfn5match268end
Lfn5match268arm11:
ldr x0, [sp, #48]
ldr x0, [x0, #0]
eor x0, x0, #1
str x0, [sp, #184]
ldr x8, [sp, #56]
ldr x9, [sp, #184]
ldr x10, [sp, #48]
ldr x10, [x10, #8]
ldr x10, [x10, #0]
bl Lfn1fields
cbnz x1, Lfn5end
str x0, [sp, #64]
mov x0, x19
adds x0, x0, #1
b.vs Lfn5fail299_1
str x0, [sp, #192]
ldr x8, [sp, #48]
ldr x8, [x8, #16]
ldr x9, [sp, #64]
mov x10, x20
ldr x11, [sp, #192]
str x8, [sp, #48]
str x9, [sp, #56]
mov x23, x10
mov x19, x11
stp xzr, xzr, [sp, #64]
stp xzr, xzr, [sp, #80]
stp xzr, xzr, [sp, #96]
stp xzr, xzr, [sp, #112]
str xzr, [sp, #128]
b Lfn5loop
b Lfn5match268end
Lfn5match268end:
b Lfn5match228end
Lfn5match228arm9:
ldr x0, [sp, #48]
ldr x0, [x0, #8]
ldr x0, [x0, #0]
cmp x0, #2
b.ne Lfn5if307else
ldr x0, [sp, #48]
ldr x0, [x0, #0]
eor x0, x0, #1
b Lfn5if307done
Lfn5if307else:
ldr x0, [sp, #48]
ldr x0, [x0, #0]
Lfn5if307done:
mov x24, x0
ldr x0, [sp, #48]
ldr x0, [x0, #8]
ldr x0, [x0, #0]
cmp x0, #0
cset x0, eq
ldr x2, [sp, #48]
ldr x2, [x2, #0]
cmp x0, x2
b.ne Lfn5if314else
ldr x0, [sp, #48]
ldr x0, [x0, #16]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn5match320arm10
cmp w0, #11
b.eq Lfn5match320arm11
brk #0
Lfn5match320arm10:
mov x0, #6
mov x1, #11
bl fen_allocate
cbz x0, Lfn5fail328_3
ldr x2, [sp, #48]
ldr x2, [x2, #0]
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #16]
stp x2, x3, [x0, #0]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
str x2, [x0, #16]
str x0, [sp, #64]
mov x0, #6
mov x1, #11
bl fen_allocate
cbz x0, Lfn5fail325_3
mov x2, x24
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #8]
stp x2, x3, [x0, #0]
ldr x2, [sp, #64]
str x2, [x0, #16]
str x0, [sp, #72]
mov x0, x19
adds x0, x0, #1
b.vs Lfn5fail335_1
str x0, [sp, #200]
ldr x8, [sp, #56]
ldr x9, [sp, #72]
mov x10, x20
ldr x11, [sp, #200]
str x8, [sp, #48]
str x9, [sp, #56]
mov x23, x10
mov x19, x11
stp xzr, xzr, [sp, #64]
stp xzr, xzr, [sp, #80]
stp xzr, xzr, [sp, #96]
stp xzr, xzr, [sp, #112]
str xzr, [sp, #128]
b Lfn5loop
b Lfn5match320end
Lfn5match320arm11:
mov x0, #6
mov x1, #11
bl fen_allocate
cbz x0, Lfn5fail350_3
ldr x2, [sp, #48]
ldr x2, [x2, #0]
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #16]
stp x2, x3, [x0, #0]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
str x2, [x0, #16]
str x0, [sp, #64]
mov x0, #6
mov x1, #11
bl fen_allocate
cbz x0, Lfn5fail347_3
mov x2, x24
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #8]
stp x2, x3, [x0, #0]
ldr x2, [sp, #64]
str x2, [x0, #16]
str x0, [sp, #72]
ldr x8, [sp, #56]
ldr x9, [sp, #72]
bl Lfn0fields
cbnz x1, Lfn5end
str x0, [sp, #80]
mov x0, x19
adds x0, x0, #1
b.vs Lfn5fail357_1
str x0, [sp, #208]
ldr x8, [sp, #48]
ldr x8, [x8, #16]
ldr x9, [sp, #80]
mov x10, x20
ldr x11, [sp, #208]
str x8, [sp, #48]
str x9, [sp, #56]
mov x23, x10
mov x19, x11
stp xzr, xzr, [sp, #64]
stp xzr, xzr, [sp, #80]
stp xzr, xzr, [sp, #96]
stp xzr, xzr, [sp, #112]
str xzr, [sp, #128]
b Lfn5loop
b Lfn5match320end
Lfn5match320end:
b Lfn5if314done
Lfn5if314else:
ldr x0, [sp, #48]
ldr x0, [x0, #16]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn5match362arm10
cmp w0, #11
b.eq Lfn5match362arm11
brk #0
Lfn5match362arm10:
mov x0, #6
mov x1, #11
bl fen_allocate
cbz x0, Lfn5fail367_3
mov x2, x24
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #8]
stp x2, x3, [x0, #0]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
str x2, [x0, #16]
str x0, [sp, #64]
movz x0, #0, lsl #0
str x0, [sp, #216]
ldr x8, [sp, #56]
ldr x9, [sp, #64]
mov x10, x21
mov x11, x22
mov x12, x20
ldr x13, [sp, #216]
bl Lfn5fields
cbnz x1, Lfn5end
str x0, [sp, #72]
b Lfn5match362end
Lfn5match362arm11:
ldr x8, [sp, #56]
mov x9, x24
ldr x10, [sp, #48]
ldr x10, [x10, #8]
ldr x10, [x10, #8]
bl Lfn1fields
cbnz x1, Lfn5end
str x0, [sp, #64]
movz x0, #0, lsl #0
str x0, [sp, #224]
ldr x8, [sp, #48]
ldr x8, [x8, #16]
ldr x9, [sp, #64]
mov x10, x21
mov x11, x22
mov x12, x20
ldr x13, [sp, #224]
bl Lfn5fields
cbnz x1, Lfn5end
str x0, [sp, #72]
b Lfn5match362end
Lfn5match362end:
str x0, [sp, #80]
ldr w0, [x0, #72]
cmp w0, #12
b.eq Lfn5match390arm12
cmp w0, #13
b.eq Lfn5match390arm13
cmp w0, #14
b.eq Lfn5match390arm14
brk #0
Lfn5match390arm12:
ldr x0, [sp, #48]
ldr x0, [x0, #16]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn5match396arm10
cmp w0, #11
b.eq Lfn5match396arm11
brk #0
Lfn5match396arm10:
mov x0, #6
mov x1, #11
bl fen_allocate
cbz x0, Lfn5fail401_3
ldr x2, [sp, #48]
ldr x2, [x2, #0]
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #16]
stp x2, x3, [x0, #0]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
str x2, [x0, #16]
str x0, [sp, #88]
movz x0, #0, lsl #0
str x0, [sp, #232]
ldr x8, [sp, #56]
ldr x9, [sp, #88]
mov x10, x21
mov x11, x22
ldr x12, [sp, #80]
ldr x12, [x12, #8]
ldr x13, [sp, #232]
bl Lfn5fields
cbnz x1, Lfn5end
str x0, [sp, #96]
b Lfn5match396end
Lfn5match396arm11:
ldr x8, [sp, #56]
ldr x9, [sp, #48]
ldr x9, [x9, #0]
ldr x10, [sp, #48]
ldr x10, [x10, #8]
ldr x10, [x10, #16]
bl Lfn1fields
cbnz x1, Lfn5end
str x0, [sp, #88]
movz x0, #0, lsl #0
str x0, [sp, #240]
ldr x8, [sp, #48]
ldr x8, [x8, #16]
ldr x9, [sp, #88]
mov x10, x21
mov x11, x22
ldr x12, [sp, #80]
ldr x12, [x12, #8]
ldr x13, [sp, #240]
bl Lfn5fields
cbnz x1, Lfn5end
str x0, [sp, #96]
b Lfn5match396end
Lfn5match396end:
str x0, [sp, #104]
ldr w0, [x0, #72]
cmp w0, #12
b.eq Lfn5match424arm12
cmp w0, #13
b.eq Lfn5match424arm13
cmp w0, #14
b.eq Lfn5match424arm14
brk #0
Lfn5match424arm12:
ldr x0, [sp, #80]
ldr x0, [x0, #0]
ldr x2, [sp, #104]
ldr x2, [x2, #0]
mov x1, x2
bl fen_bytes_concat
cbz x0, Lfn5fail434_3
str x0, [sp, #112]
adrp x0, Lconstant11
add x0, x0, :lo12:Lconstant11
ldr x2, [sp, #112]
mov x1, x2
bl fen_bytes_concat
cbz x0, Lfn5fail432_3
str x0, [sp, #120]
mov x8, x19
ldr x9, [sp, #120]
bl Lfn4fields
cbnz x1, Lfn5end
str x0, [sp, #128]
mov x0, #1
mov x1, #12
bl fen_allocate
cbz x0, Lfn5fail428_3
ldr x2, [sp, #128]
ldr x3, [sp, #104]
ldr x3, [x3, #8]
stp x2, x3, [x0, #0]
b Lfn5match424end
Lfn5match424arm13:
ldr x0, [sp, #104]
b Lfn5match424end
Lfn5match424arm14:
ldr x0, [sp, #104]
b Lfn5match424end
Lfn5match424end:
b Lfn5match390end
Lfn5match390arm13:
ldr x0, [sp, #80]
b Lfn5match390end
Lfn5match390arm14:
ldr x0, [sp, #80]
b Lfn5match390end
Lfn5match390end:
Lfn5if314done:
b Lfn5match228end
Lfn5match228end:
b Lfn5match207end
Lfn5match207end:
Lfn5if197done:
mov x1, #0
b Lfn5end
Lfn5fail204_1:
adrp x0, Lfn5fail204_1location
add x0, x0, :lo12:Lfn5fail204_1location
bl fen_set_location
mov x1, #1
b Lfn5end
Lfn5fail211_3:
adrp x0, Lfn5fail211_3location
add x0, x0, :lo12:Lfn5fail211_3location
bl fen_set_location
mov x1, #3
b Lfn5end
Lfn5fail239_3:
adrp x0, Lfn5fail239_3location
add x0, x0, :lo12:Lfn5fail239_3location
bl fen_set_location
mov x1, #3
b Lfn5end
Lfn5fail264_1:
adrp x0, Lfn5fail264_1location
add x0, x0, :lo12:Lfn5fail264_1location
bl fen_set_location
mov x1, #1
b Lfn5end
Lfn5fail273_3:
adrp x0, Lfn5fail273_3location
add x0, x0, :lo12:Lfn5fail273_3location
bl fen_set_location
mov x1, #3
b Lfn5end
Lfn5fail281_1:
adrp x0, Lfn5fail281_1location
add x0, x0, :lo12:Lfn5fail281_1location
bl fen_set_location
mov x1, #1
b Lfn5end
Lfn5fail299_1:
adrp x0, Lfn5fail299_1location
add x0, x0, :lo12:Lfn5fail299_1location
bl fen_set_location
mov x1, #1
b Lfn5end
Lfn5fail328_3:
adrp x0, Lfn5fail328_3location
add x0, x0, :lo12:Lfn5fail328_3location
bl fen_set_location
mov x1, #3
b Lfn5end
Lfn5fail325_3:
adrp x0, Lfn5fail325_3location
add x0, x0, :lo12:Lfn5fail325_3location
bl fen_set_location
mov x1, #3
b Lfn5end
Lfn5fail335_1:
adrp x0, Lfn5fail335_1location
add x0, x0, :lo12:Lfn5fail335_1location
bl fen_set_location
mov x1, #1
b Lfn5end
Lfn5fail350_3:
adrp x0, Lfn5fail350_3location
add x0, x0, :lo12:Lfn5fail350_3location
bl fen_set_location
mov x1, #3
b Lfn5end
Lfn5fail347_3:
adrp x0, Lfn5fail347_3location
add x0, x0, :lo12:Lfn5fail347_3location
bl fen_set_location
mov x1, #3
b Lfn5end
Lfn5fail357_1:
adrp x0, Lfn5fail357_1location
add x0, x0, :lo12:Lfn5fail357_1location
bl fen_set_location
mov x1, #1
b Lfn5end
Lfn5fail367_3:
adrp x0, Lfn5fail367_3location
add x0, x0, :lo12:Lfn5fail367_3location
bl fen_set_location
mov x1, #3
b Lfn5end
Lfn5fail401_3:
adrp x0, Lfn5fail401_3location
add x0, x0, :lo12:Lfn5fail401_3location
bl fen_set_location
mov x1, #3
b Lfn5end
Lfn5fail434_3:
adrp x0, Lfn5fail434_3location
add x0, x0, :lo12:Lfn5fail434_3location
bl fen_set_location
mov x1, #3
b Lfn5end
Lfn5fail432_3:
adrp x0, Lfn5fail432_3location
add x0, x0, :lo12:Lfn5fail432_3location
bl fen_set_location
mov x1, #3
b Lfn5end
Lfn5fail428_3:
adrp x0, Lfn5fail428_3location
add x0, x0, :lo12:Lfn5fail428_3location
bl fen_set_location
mov x1, #3
b Lfn5end
Lfn5end:
bl fen_leave_result
ldp x19, x20, [x29, #-16]
ldp x21, x22, [x29, #-32]
ldp x23, x24, [x29, #-48]
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn6:
ldp x8, x9, [x0, #0]
ldp x10, x11, [x0, #16]
Lfn6fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #96
stp x8, x9, [sp, #48]
stp x10, x11, [sp, #64]
Lfn6loop:
movz x0, #0, lsl #0
str x0, [sp, #80]
ldr x8, [sp, #48]
adrp x9, Lconstant0
add x9, x9, :lo12:Lconstant0
ldr x10, [sp, #56]
ldr x11, [sp, #64]
ldr x12, [sp, #72]
ldr x13, [sp, #80]
mov sp, x29
ldp x29, x30, [sp], #16
b Lfn5fields
mov x1, #0
b Lfn6end
Lfn6end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn7:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #96
str xzr, [sp, #48]
str x0, [sp, #56]
add x0, sp, #16
add x1, sp, #48
mov x2, #1
bl fen_enter
movz x0, #0, lsl #0
str x0, [sp, #64]
movz x0, #0, lsl #0
str x0, [sp, #72]
movz x0, #100, lsl #0
str x0, [sp, #80]
adrp x8, Lconstant14
add x8, x8, :lo12:Lconstant14
ldr x9, [sp, #64]
ldr x10, [sp, #72]
ldr x11, [sp, #80]
bl Lfn6fields
cbnz x1, Lfn7end
str x0, [sp, #48]
adrp x2, Lconstant16
add x2, x2, :lo12:Lconstant16
mov x1, x2
bl fen_equal
cbz x0, Lfn7if474else
movz x0, #1, lsl #0
b Lfn7if474done
Lfn7if474else:
movz x0, #0, lsl #0
Lfn7if474done:
mov x1, #0
b Lfn7end
Lfn7end:
bl fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn8:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #96
str xzr, [sp, #48]
str x0, [sp, #56]
add x0, sp, #16
add x1, sp, #48
mov x2, #1
bl fen_enter
movz x0, #0, lsl #0
str x0, [sp, #64]
movz x0, #0, lsl #0
str x0, [sp, #72]
movz x0, #100, lsl #0
str x0, [sp, #80]
adrp x8, Lconstant19
add x8, x8, :lo12:Lconstant19
ldr x9, [sp, #64]
ldr x10, [sp, #72]
ldr x11, [sp, #80]
bl Lfn6fields
cbnz x1, Lfn8end
str x0, [sp, #48]
adrp x2, Lconstant21
add x2, x2, :lo12:Lconstant21
mov x1, x2
bl fen_equal
cbz x0, Lfn8if497else
movz x0, #1, lsl #0
b Lfn8if497done
Lfn8if497else:
movz x0, #0, lsl #0
Lfn8if497done:
mov x1, #0
b Lfn8end
Lfn8end:
bl fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn9:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #96
str xzr, [sp, #48]
str x0, [sp, #56]
add x0, sp, #16
add x1, sp, #48
mov x2, #1
bl fen_enter
movz x0, #0, lsl #0
str x0, [sp, #64]
movz x0, #0, lsl #0
str x0, [sp, #72]
movz x0, #100, lsl #0
str x0, [sp, #80]
adrp x8, Lconstant26
add x8, x8, :lo12:Lconstant26
ldr x9, [sp, #64]
ldr x10, [sp, #72]
ldr x11, [sp, #80]
bl Lfn6fields
cbnz x1, Lfn9end
str x0, [sp, #48]
adrp x2, Lconstant28
add x2, x2, :lo12:Lconstant28
mov x1, x2
bl fen_equal
cbz x0, Lfn9if521else
movz x0, #1, lsl #0
b Lfn9if521done
Lfn9if521else:
movz x0, #0, lsl #0
Lfn9if521done:
mov x1, #0
b Lfn9end
Lfn9end:
bl fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn10:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #96
str xzr, [sp, #48]
str x0, [sp, #56]
add x0, sp, #16
add x1, sp, #48
mov x2, #1
bl fen_enter
movz x0, #0, lsl #0
str x0, [sp, #64]
movz x0, #0, lsl #0
str x0, [sp, #72]
movz x0, #100, lsl #0
str x0, [sp, #80]
adrp x8, Lconstant36
add x8, x8, :lo12:Lconstant36
ldr x9, [sp, #64]
ldr x10, [sp, #72]
ldr x11, [sp, #80]
bl Lfn6fields
cbnz x1, Lfn10end
str x0, [sp, #48]
adrp x2, Lconstant38
add x2, x2, :lo12:Lconstant38
mov x1, x2
bl fen_equal
cbz x0, Lfn10if552else
movz x0, #1, lsl #0
b Lfn10if552done
Lfn10if552else:
movz x0, #0, lsl #0
Lfn10if552done:
mov x1, #0
b Lfn10end
Lfn10end:
bl fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn11:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #96
str xzr, [sp, #48]
str x0, [sp, #56]
add x0, sp, #16
add x1, sp, #48
mov x2, #1
bl fen_enter
movz x0, #0, lsl #0
str x0, [sp, #64]
movz x0, #0, lsl #0
str x0, [sp, #72]
movz x0, #200, lsl #0
str x0, [sp, #80]
adrp x8, Lconstant43
add x8, x8, :lo12:Lconstant43
ldr x9, [sp, #64]
ldr x10, [sp, #72]
ldr x11, [sp, #80]
bl Lfn6fields
cbnz x1, Lfn11end
str x0, [sp, #48]
adrp x2, Lconstant45
add x2, x2, :lo12:Lconstant45
mov x1, x2
bl fen_equal
cbz x0, Lfn11if595else
movz x0, #1, lsl #0
b Lfn11if595done
Lfn11if595else:
movz x0, #0, lsl #0
Lfn11if595done:
mov x1, #0
b Lfn11end
Lfn11end:
bl fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn12:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #96
str xzr, [sp, #48]
str x0, [sp, #56]
add x0, sp, #16
add x1, sp, #48
mov x2, #1
bl fen_enter
movz x0, #0, lsl #0
str x0, [sp, #64]
movz x0, #0, lsl #0
str x0, [sp, #72]
movz x0, #200, lsl #0
str x0, [sp, #80]
adrp x8, Lconstant48
add x8, x8, :lo12:Lconstant48
ldr x9, [sp, #64]
ldr x10, [sp, #72]
ldr x11, [sp, #80]
bl Lfn6fields
cbnz x1, Lfn12end
str x0, [sp, #48]
adrp x2, Lconstant50
add x2, x2, :lo12:Lconstant50
mov x1, x2
bl fen_equal
cbz x0, Lfn12if634else
movz x0, #1, lsl #0
b Lfn12if634done
Lfn12if634else:
movz x0, #0, lsl #0
Lfn12if634done:
mov x1, #0
b Lfn12end
Lfn12end:
bl fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn13:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #96
str xzr, [sp, #48]
str x0, [sp, #56]
add x0, sp, #16
add x1, sp, #48
mov x2, #1
bl fen_enter
movz x0, #0, lsl #0
str x0, [sp, #64]
movz x0, #0, lsl #0
str x0, [sp, #72]
movz x0, #100, lsl #0
str x0, [sp, #80]
adrp x8, Lconstant51
add x8, x8, :lo12:Lconstant51
ldr x9, [sp, #64]
ldr x10, [sp, #72]
ldr x11, [sp, #80]
bl Lfn6fields
cbnz x1, Lfn13end
str x0, [sp, #48]
adrp x2, Lconstant52
add x2, x2, :lo12:Lconstant52
mov x1, x2
bl fen_equal
cbz x0, Lfn13if665else
movz x0, #1, lsl #0
b Lfn13if665done
Lfn13if665else:
movz x0, #0, lsl #0
Lfn13if665done:
mov x1, #0
b Lfn13end
Lfn13end:
bl fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn14:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #96
str xzr, [sp, #48]
str x0, [sp, #56]
add x0, sp, #16
add x1, sp, #48
mov x2, #1
bl fen_enter
movz x0, #0, lsl #0
str x0, [sp, #64]
movz x0, #0, lsl #0
str x0, [sp, #72]
movz x0, #100, lsl #0
str x0, [sp, #80]
adrp x8, Lconstant55
add x8, x8, :lo12:Lconstant55
ldr x9, [sp, #64]
ldr x10, [sp, #72]
ldr x11, [sp, #80]
bl Lfn6fields
cbnz x1, Lfn14end
str x0, [sp, #48]
adrp x2, Lconstant56
add x2, x2, :lo12:Lconstant56
mov x1, x2
bl fen_equal
cbz x0, Lfn14if688else
movz x0, #1, lsl #0
b Lfn14if688done
Lfn14if688else:
movz x0, #0, lsl #0
Lfn14if688done:
mov x1, #0
b Lfn14end
Lfn14end:
bl fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn15:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #96
str xzr, [sp, #48]
str x0, [sp, #56]
add x0, sp, #16
add x1, sp, #48
mov x2, #1
bl fen_enter
movz x0, #0, lsl #0
str x0, [sp, #64]
movz x0, #0, lsl #0
str x0, [sp, #72]
movz x0, #3, lsl #0
str x0, [sp, #80]
adrp x8, Lconstant36
add x8, x8, :lo12:Lconstant36
ldr x9, [sp, #64]
ldr x10, [sp, #72]
ldr x11, [sp, #80]
bl Lfn6fields
cbnz x1, Lfn15end
str x0, [sp, #48]
adrp x2, Lconstant9
add x2, x2, :lo12:Lconstant9
mov x1, x2
bl fen_equal
cbz x0, Lfn15if719else
movz x0, #1, lsl #0
b Lfn15if719done
Lfn15if719else:
movz x0, #0, lsl #0
Lfn15if719done:
mov x1, #0
b Lfn15end
Lfn15end:
bl fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn16:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #96
str xzr, [sp, #48]
str x0, [sp, #56]
add x0, sp, #16
add x1, sp, #48
mov x2, #1
bl fen_enter
movz x0, #0, lsl #0
str x0, [sp, #64]
movz x0, #0, lsl #0
str x0, [sp, #72]
movz x0, #0, lsl #0
str x0, [sp, #80]
adrp x8, Lconstant57
add x8, x8, :lo12:Lconstant57
ldr x9, [sp, #64]
ldr x10, [sp, #72]
ldr x11, [sp, #80]
bl Lfn6fields
cbnz x1, Lfn16end
str x0, [sp, #48]
adrp x2, Lconstant9
add x2, x2, :lo12:Lconstant9
mov x1, x2
bl fen_equal
cbz x0, Lfn16if760else
movz x0, #1, lsl #0
b Lfn16if760done
Lfn16if760else:
movz x0, #0, lsl #0
Lfn16if760done:
mov x1, #0
b Lfn16end
Lfn16end:
bl fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn17:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #224
str x0, [sp, #48]
movz x0, #0, lsl #0
str x0, [sp, #56]
ldr x0, [sp, #48]
bl Lfn7
cbnz x1, Lfn17end
str x0, [sp, #64]
ldr x0, [sp, #56]
ldr x2, [sp, #64]
adds x0, x0, x2
b.vs Lfn17fail786_1
str x0, [sp, #72]
ldr x0, [sp, #48]
bl Lfn8
cbnz x1, Lfn17end
str x0, [sp, #80]
ldr x0, [sp, #72]
ldr x2, [sp, #80]
adds x0, x0, x2
b.vs Lfn17fail785_1
str x0, [sp, #88]
ldr x0, [sp, #48]
bl Lfn9
cbnz x1, Lfn17end
str x0, [sp, #96]
ldr x0, [sp, #88]
ldr x2, [sp, #96]
adds x0, x0, x2
b.vs Lfn17fail784_1
str x0, [sp, #104]
ldr x0, [sp, #48]
bl Lfn10
cbnz x1, Lfn17end
str x0, [sp, #112]
ldr x0, [sp, #104]
ldr x2, [sp, #112]
adds x0, x0, x2
b.vs Lfn17fail783_1
str x0, [sp, #120]
ldr x0, [sp, #48]
bl Lfn11
cbnz x1, Lfn17end
str x0, [sp, #128]
ldr x0, [sp, #120]
ldr x2, [sp, #128]
adds x0, x0, x2
b.vs Lfn17fail782_1
str x0, [sp, #136]
ldr x0, [sp, #48]
bl Lfn12
cbnz x1, Lfn17end
str x0, [sp, #144]
ldr x0, [sp, #136]
ldr x2, [sp, #144]
adds x0, x0, x2
b.vs Lfn17fail781_1
str x0, [sp, #152]
ldr x0, [sp, #48]
bl Lfn13
cbnz x1, Lfn17end
str x0, [sp, #160]
ldr x0, [sp, #152]
ldr x2, [sp, #160]
adds x0, x0, x2
b.vs Lfn17fail780_1
str x0, [sp, #168]
ldr x0, [sp, #48]
bl Lfn14
cbnz x1, Lfn17end
str x0, [sp, #176]
ldr x0, [sp, #168]
ldr x2, [sp, #176]
adds x0, x0, x2
b.vs Lfn17fail779_1
str x0, [sp, #184]
ldr x0, [sp, #48]
bl Lfn15
cbnz x1, Lfn17end
str x0, [sp, #192]
ldr x0, [sp, #184]
ldr x2, [sp, #192]
adds x0, x0, x2
b.vs Lfn17fail778_1
str x0, [sp, #200]
ldr x0, [sp, #48]
bl Lfn16
cbnz x1, Lfn17end
str x0, [sp, #208]
ldr x0, [sp, #200]
ldr x2, [sp, #208]
adds x0, x0, x2
b.vs Lfn17fail777_1
mov x1, #0
b Lfn17end
Lfn17fail786_1:
adrp x0, Lfn17fail786_1location
add x0, x0, :lo12:Lfn17fail786_1location
bl fen_set_location
mov x1, #1
b Lfn17end
Lfn17fail785_1:
adrp x0, Lfn17fail785_1location
add x0, x0, :lo12:Lfn17fail785_1location
bl fen_set_location
mov x1, #1
b Lfn17end
Lfn17fail784_1:
adrp x0, Lfn17fail784_1location
add x0, x0, :lo12:Lfn17fail784_1location
bl fen_set_location
mov x1, #1
b Lfn17end
Lfn17fail783_1:
adrp x0, Lfn17fail783_1location
add x0, x0, :lo12:Lfn17fail783_1location
bl fen_set_location
mov x1, #1
b Lfn17end
Lfn17fail782_1:
adrp x0, Lfn17fail782_1location
add x0, x0, :lo12:Lfn17fail782_1location
bl fen_set_location
mov x1, #1
b Lfn17end
Lfn17fail781_1:
adrp x0, Lfn17fail781_1location
add x0, x0, :lo12:Lfn17fail781_1location
bl fen_set_location
mov x1, #1
b Lfn17end
Lfn17fail780_1:
adrp x0, Lfn17fail780_1location
add x0, x0, :lo12:Lfn17fail780_1location
bl fen_set_location
mov x1, #1
b Lfn17end
Lfn17fail779_1:
adrp x0, Lfn17fail779_1location
add x0, x0, :lo12:Lfn17fail779_1location
bl fen_set_location
mov x1, #1
b Lfn17end
Lfn17fail778_1:
adrp x0, Lfn17fail778_1location
add x0, x0, :lo12:Lfn17fail778_1location
bl fen_set_location
mov x1, #1
b Lfn17end
Lfn17fail777_1:
adrp x0, Lfn17fail777_1location
add x0, x0, :lo12:Lfn17fail777_1location
bl fen_set_location
mov x1, #1
b Lfn17end
Lfn17end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn18:
ldp x8, x9, [x0, #0]
Lfn18fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
stp x19, x20, [sp, #-16]!
sub sp, sp, #80
mov x19, x8
mov x20, x9
Lfn18loop:
mov x0, x19
cmp x0, #0
b.gt Lfn18if818else
mov x0, x20
b Lfn18if818done
Lfn18if818else:
mov x0, x19
subs x0, x0, #1
b.vs Lfn18fail825_1
str x0, [sp, #48]
mov x0, x19
bl Lfn17
cbnz x1, Lfn18end
str x0, [sp, #56]
mov x0, x20
ldr x2, [sp, #56]
adds x0, x0, x2
b.vs Lfn18fail828_1
str x0, [sp, #64]
ldr x8, [sp, #48]
ldr x9, [sp, #64]
mov x19, x8
mov x20, x9
b Lfn18loop
Lfn18if818done:
mov x1, #0
b Lfn18end
Lfn18fail825_1:
adrp x0, Lfn18fail825_1location
add x0, x0, :lo12:Lfn18fail825_1location
bl fen_set_location
mov x1, #1
b Lfn18end
Lfn18fail828_1:
adrp x0, Lfn18fail828_1location
add x0, x0, :lo12:Lfn18fail828_1location
bl fen_set_location
mov x1, #1
b Lfn18end
Lfn18end:
ldp x19, x20, [x29, #-16]
mov sp, x29
ldp x29, x30, [sp], #16
ret
.globl fenrir_entry
fenrir_entry:
Lfn19:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
str x0, [sp, #48]
movz x0, #0, lsl #0
str x0, [sp, #56]
ldr x8, [sp, #48]
ldr x9, [sp, #56]
mov sp, x29
ldp x29, x30, [sp], #16
b Lfn18fields
mov x1, #0
b Lfn19end
Lfn19end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
.text
.globl fen_print_result
fen_print_result:
b Lprint0
Lprint0:
b fen_write_i64
Lfn0fail18_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,56,58,49,55,10,0
Lfn0fail28_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,58,52,48,10,0
Lfn0fail25_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,58,50,55,10,0
.p2align 3
Lconstant0:
.zero 72
.long 10
.byte 0,2,0,0
Lfn1fail52_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,49,50,58,51,49,10,0
Lfn2fail73_2location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,49,54,58,51,49,10,0
Lfn2fail73_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,49,54,58,51,49,10,0
Lfn3fail99_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,50,48,58,51,50,10,0
Lfn3fail108_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,50,49,58,52,53,10,0
.p2align 3
Lconstant1:
.quad 8
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,115,115,115,115
.p2align 3
Lconstant2:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115
.p2align 3
Lconstant3:
.quad 2
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115
.p2align 3
Lconstant4:
.quad 3
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115
.p2align 3
Lconstant5:
.quad 4
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115
.p2align 3
Lconstant6:
.quad 5
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,115
.p2align 3
Lconstant7:
.quad 6
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,115,115
.p2align 3
Lconstant8:
.quad 7
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,115,115,115
Lfn4fail127_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,50,54,58,50,48,10,0
Lfn4fail130_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,50,54,58,51,50,10,0
Lfn4fail138_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,50,56,58,55,10,0
.p2align 3
Lconstant9:
.zero 72
.long 14
.byte 0,2,0,0
.p2align 3
Lconstant10:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 120
.p2align 3
Lconstant11:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 98
Lfn5fail204_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,51,55,58,49,53,10,0
Lfn5fail211_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,51,57,58,52,49,10,0
Lfn5fail239_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,52,52,58,49,57,10,0
Lfn5fail264_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,52,54,58,56,52,10,0
Lfn5fail273_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,52,56,58,53,54,10,0
Lfn5fail281_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,52,56,58,49,48,48,10,0
Lfn5fail299_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,52,57,58,49,49,50,10,0
Lfn5fail328_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,53,52,58,54,55,10,0
Lfn5fail325_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,53,52,58,53,50,10,0
Lfn5fail335_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,53,53,58,53,51,10,0
Lfn5fail350_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,53,54,58,57,54,10,0
Lfn5fail347_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,53,54,58,56,49,10,0
Lfn5fail357_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,53,55,58,53,51,10,0
Lfn5fail367_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,53,57,58,54,52,10,0
Lfn5fail401_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,54,52,58,54,57,10,0
Lfn5fail434_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,54,55,58,57,56,10,0
Lfn5fail432_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,54,55,58,56,48,10,0
Lfn5fail428_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,54,55,58,53,50,10,0
.p2align 3
Lconstant12:
.quad 1
.zero 64
.long 7
.byte 0,2,0,0
.section .rodata
.p2align 3
Lconstant13:
.quad 2
.quad Lconstant12
.quad Lconstant12
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant14:
.quad 0
.quad Lconstant13
.quad Lconstant0
.zero 48
.long 11
.byte 6,2,0,0
.text
.p2align 3
Lconstant15:
.quad 3
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,120
.section .rodata
.p2align 3
Lconstant16:
.quad Lconstant15
.quad 97
.zero 56
.long 12
.byte 1,2,0,0
.text
.section .rodata
.p2align 3
Lconstant17:
.quad Lconstant12
.zero 64
.long 8
.byte 1,2,0,0
.text
.section .rodata
.p2align 3
Lconstant18:
.quad 1
.quad Lconstant12
.quad Lconstant17
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant19:
.quad 0
.quad Lconstant18
.quad Lconstant0
.zero 48
.long 11
.byte 6,2,0,0
.text
.p2align 3
Lconstant20:
.quad 4
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,120
.section .rodata
.p2align 3
Lconstant21:
.quad Lconstant20
.quad 96
.zero 56
.long 12
.byte 1,2,0,0
.text
.p2align 3
Lconstant22:
.quad 2
.zero 64
.long 7
.byte 0,2,0,0
.section .rodata
.p2align 3
Lconstant23:
.quad 2
.quad Lconstant12
.quad Lconstant22
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant24:
.quad 0
.quad Lconstant12
.quad Lconstant23
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant25:
.quad 2
.quad Lconstant24
.quad Lconstant22
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant26:
.quad 0
.quad Lconstant25
.quad Lconstant0
.zero 48
.long 11
.byte 6,2,0,0
.text
.p2align 3
Lconstant27:
.quad 7
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,98,120,120
.section .rodata
.p2align 3
Lconstant28:
.quad Lconstant27
.quad 93
.zero 56
.long 12
.byte 1,2,0,0
.text
.p2align 3
Lconstant29:
.quad 4
.zero 64
.long 7
.byte 0,2,0,0
.section .rodata
.p2align 3
Lconstant30:
.quad 1
.quad Lconstant22
.quad Lconstant29
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant31:
.quad 0
.quad Lconstant12
.quad Lconstant30
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant32:
.quad 0
.quad Lconstant12
.quad Lconstant22
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant33:
.quad 0
.quad Lconstant12
.quad Lconstant29
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant34:
.quad 1
.quad Lconstant32
.quad Lconstant33
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant35:
.quad 2
.quad Lconstant31
.quad Lconstant34
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant36:
.quad 0
.quad Lconstant35
.quad Lconstant0
.zero 48
.long 11
.byte 6,2,0,0
.text
.p2align 3
Lconstant37:
.quad 29
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,98,98,98,115,120,115,120,98,115,120,115,120,98,98,115,120,115,120,98,115,115,120,115,115,120
.section .rodata
.p2align 3
Lconstant38:
.quad Lconstant37
.quad 71
.zero 56
.long 12
.byte 1,2,0,0
.text
.section .rodata
.p2align 3
Lconstant39:
.quad 2
.quad Lconstant22
.quad Lconstant29
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant40:
.quad 0
.quad Lconstant23
.quad Lconstant39
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant41:
.quad 2
.quad Lconstant12
.quad Lconstant29
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant42:
.quad 2
.quad Lconstant40
.quad Lconstant41
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant43:
.quad 0
.quad Lconstant42
.quad Lconstant0
.zero 48
.long 11
.byte 6,2,0,0
.text
.p2align 3
Lconstant44:
.quad 20
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,98,98,115,115,120,115,115,120,98,115,115,115,120,115,115,115,120
.section .rodata
.p2align 3
Lconstant45:
.quad Lconstant44
.quad 180
.zero 56
.long 12
.byte 1,2,0,0
.text
.section .rodata
.p2align 3
Lconstant46:
.quad 2
.quad Lconstant23
.quad Lconstant12
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant47:
.quad 2
.quad Lconstant46
.quad Lconstant12
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant48:
.quad 0
.quad Lconstant47
.quad Lconstant0
.zero 48
.long 11
.byte 6,2,0,0
.text
.p2align 3
Lconstant49:
.quad 7
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,98,115,115,120,115,120
.section .rodata
.p2align 3
Lconstant50:
.quad Lconstant49
.quad 193
.zero 56
.long 12
.byte 1,2,0,0
.text
.section .rodata
.p2align 3
Lconstant51:
.quad 0
.quad Lconstant32
.quad Lconstant0
.zero 48
.long 11
.byte 6,2,0,0
.text
.p2align 3
Lconstant52:
.quad 0
.quad 97
.zero 56
.long 13
.byte 0,2,0,0
.section .rodata
.p2align 3
Lconstant53:
.quad 2
.quad Lconstant22
.quad Lconstant12
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant54:
.quad 2
.quad Lconstant23
.quad Lconstant53
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant55:
.quad 0
.quad Lconstant54
.quad Lconstant0
.zero 48
.long 11
.byte 6,2,0,0
.text
.p2align 3
Lconstant56:
.quad 2
.quad 93
.zero 56
.long 13
.byte 0,2,0,0
.section .rodata
.p2align 3
Lconstant57:
.quad 0
.quad Lconstant12
.quad Lconstant0
.zero 48
.long 11
.byte 6,2,0,0
.text
Lfn17fail786_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,54,58,54,52,10,0
Lfn17fail785_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,54,58,54,49,10,0
Lfn17fail784_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,54,58,53,56,10,0
Lfn17fail783_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,54,58,53,53,10,0
Lfn17fail782_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,54,58,53,50,10,0
Lfn17fail781_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,54,58,52,57,10,0
Lfn17fail780_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,54,58,52,54,10,0
Lfn17fail779_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,54,58,52,51,10,0
Lfn17fail778_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,54,58,52,48,10,0
Lfn17fail777_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,54,58,51,55,10,0
Lfn18fail825_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,56,58,52,55,10,0
Lfn18fail828_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,56,58,53,53,10,0
