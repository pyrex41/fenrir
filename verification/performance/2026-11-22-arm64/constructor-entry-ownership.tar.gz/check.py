import json
from pathlib import Path
d=Path(__file__).resolve().parent
controls=json.loads((d/'controls.json').read_text())
assert [(r['caller'],r['argument'],r['constructor']) for r in controls]==[
    ('direct',0,'Box'),('single',0,'Box'),('siblings',0,'Box'),('siblings',1,'Box')]
assert len({r['allocation'] for r in controls})==4
for name in ('stream','shared'):
    rows=json.loads((d/(name+'.json')).read_text())
    assert len(rows)==4 and all(r['callee']=='feed-from' and r['argument']==0 for r in rows)
    assert {r['constructor'] for r in rows}=={'LengthLo','Payload','ReadKey','LengthHi'}
