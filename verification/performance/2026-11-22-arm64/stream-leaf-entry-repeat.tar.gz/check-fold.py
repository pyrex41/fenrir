import json, subprocess, sys
from pathlib import Path
root, candidate = map(Path, sys.argv[1:])
sys.path.insert(0, str(root / 'benchmarks/prover'))
from fenrir_driver import compiled
program = """(define sum-range {(Tuple Bytes I64 I64 I64) --> I64}
  chunk i end sum -> (if (= i end) sum
    (sum-range chunk (+ i 1) end (+ sum (bytes-index chunk i)))))
(define main {I64 --> I64} n ->
 (if (= n 0) (sum-range #x010203 0 3 9223372036854775804)
 (if (= n 1) (sum-range #x010203 0 4 0)
 (if (= n 2) (sum-range #x010203 -1 1 0)
 (if (= n 3) (sum-range #x010203 4 4 57)
 (if (= n 4) (sum-range (bytes-concat #x0102 #x0304) 1 3 -9)
 (if (= n 5) (sum-range (bytes-concat #x%s #x%s) 29 33 8)
 (sum-range #x010203 1 3 9223372036854775802))))))))
""" % ('01'*32, '02'*32)
for target in ('macos-arm64','solo5-arm64-spt'):
    rows = []
    for source in (root, candidate):
        with compiled(source,target,program) as cmd:
            results = []
            for i in range(7):
                p = subprocess.run([*cmd,str(i)],capture_output=True,text=True,timeout=30)
                results.append([p.returncode,p.stdout.strip(),p.stderr.strip()])
            rows.append(results)
    assert rows[0] == rows[1],rows
    assert [x[1] for x in rows[1][3:]] == ['57','-4','13','9223372036854775807'],rows
    assert all(x[0] or 'trap' in (x[1]+x[2]).lower() for x in rows[1][:3]),rows
    print(json.dumps([target, rows[1]]),flush=True)
