import hashlib
import json
import tarfile
from pathlib import Path
from runpy import run_path

base = Path(__file__).resolve().parent
root = base.parents[1]
tools = root / 'benchmarks/durable'
read = lambda p: json.loads(p.read_bytes())
history = run_path(str(tools / 'compare-recovery.py'))['history_summary']
check = run_path(str(tools / 'check-fresh-store.py'))['check']
assess = run_path(str(tools / 'assess-paced.py'))['check_workload']
report = read(base / 'runs/paired.json')
assert report['schedule'] == {'rate':100,'seconds':600} and report['blocks']==1
rows = {}
files = [base / 'runs/paired.json', Path(__file__).resolve()]
for name in ('fenrir-native-mac','rust','nim','erlang','elixir'):
    folder = base / 'runs/0' / name
    p = folder / '0'
    v = read(p / 'check/verdicts.jsonl')
    h = history(p / 'history.json')
    assert h['events_sha256'] == report['history_events_sha256']
    assert v['verdict']=='accepted' and Path(v['history']) == p/'history.json'
    assert v['events']==h['event_count']==60001 and h['worker_implementation']==name
    assert check(p/'jobs.db',60000)==read(p/'store-check.json')
    t=read(p/'timings.json')
    a=assess(t,60001,60000,100)
    assert a==read(p/'paced.json') and a['offered_rate_verdict']=='sustained-at-offered-rate'
    assert a['acknowledgement_p99_us']==report['samples_us'][0][name]['acknowledgement_p99_us']
    rows[name]=dict(p99_us=a['acknowledgement_p99_us'],max_backlog=max(a['outstanding_by_second']),end_backlog=a['outstanding_by_second'][-1])
    files.extend([folder/'summary.json',p/'timings.json',p/'store-check.json',p/'resources.json',p/'paced.json',p/'check/verdicts.jsonl',p/'jobs.db',*p.glob('jobs.db-wal'),*p.glob('history.json*')])
summary=base/'five-worker-check.json'
summary.write_text(json.dumps(dict(workers=rows,history_sha256=report['history_events_sha256'],host=report['host'],runtime=report['runtime'],sqlite=report['sqlite_connection']),indent=2)+'\n')
final=root/'verification/performance/2026-11-22-arm64/durable-mac-five-ten-minute.tar.gz'
with tarfile.open(final,'x:gz') as archive:
    for f in [summary,*files]:
        archive.add(f,arcname=f.relative_to(base))
print(summary,final)
