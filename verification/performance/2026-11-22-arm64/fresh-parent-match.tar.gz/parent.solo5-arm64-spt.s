.text
.p2align 2
.globl fenrir_entry
fenrir_entry:
Lfn0:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
str xzr, [sp, #48]
str x0, [sp, #56]
add x0, sp, #16
add x1, sp, #48
mov x2, #1
bl fen_enter
mov x0, #0
mov x1, #7
bl fen_allocate
cbz x0, Lfn0fail4_3
ldr x2, [sp, #56]
str x2, [x0, #0]
str x0, [sp, #48]
mov x0, #3
mov x1, #0
bl fen_allocate
cbz x0, Lfn0fail15_3
ldr x2, [sp, #48]
ldr x3, [sp, #48]
stp x2, x3, [x0, #0]
mov x1, #0
b Lfn0end
Lfn0fail4_3:
adrp x0, Lfn0fail4_3location
add x0, x0, :lo12:Lfn0fail4_3location
bl fen_set_location
mov x1, #3
b Lfn0end
Lfn0fail15_3:
adrp x0, Lfn0fail15_3location
add x0, x0, :lo12:Lfn0fail15_3location
bl fen_set_location
mov x1, #3
b Lfn0end
Lfn0end:
bl fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
.text
.globl fen_print_result
fen_print_result:
b Lprint0
Lprint0:
stp x19, x30, [sp, #-16]!
mov x19, x0
adrp x0, Lstr0
add x0, x0, :lo12:Lstr0
mov x1, #6
bl fen_write
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #0]
bl Lprint1
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #8]
bl Lprint1
adrp x0, Lstr2
add x0, x0, :lo12:Lstr2
mov x1, #1
bl fen_write
Lprint0done:
ldp x19, x30, [sp], #16
ret
Lprint1:
stp x19, x30, [sp, #-16]!
mov x19, x0
bl fen_tag
mov x1, #7
cmp x0, x1
b.eq Lprint1v7
brk #0
Lprint1v7:
adrp x0, Lstr3
add x0, x0, :lo12:Lstr3
mov x1, #5
bl fen_write
adrp x0, Lstr1
add x0, x0, :lo12:Lstr1
mov x1, #1
bl fen_write
ldr x0, [x19, #0]
bl Lprint2
adrp x0, Lstr2
add x0, x0, :lo12:Lstr2
mov x1, #1
bl fen_write
b Lprint1done
Lprint1done:
ldp x19, x30, [sp], #16
ret
Lprint2:
b fen_write_i64
Lstr0:
.byte 40,116,117,112,108,101
Lstr1:
.byte 32
Lstr2:
.byte 41
Lstr3:
.byte 40,67,101,108,108
Lfn0fail4_3location:
.byte 116,114,97,112,32,97,116,58,32,112,97,114,101,110,116,46,102,101,110,58,52,58,50,48,10,0
Lfn0fail15_3location:
.byte 116,114,97,112,32,97,116,58,32,112,97,114,101,110,116,46,102,101,110,58,53,58,52,48,10,0
