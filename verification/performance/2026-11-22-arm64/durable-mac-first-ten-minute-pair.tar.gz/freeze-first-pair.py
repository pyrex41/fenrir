import hashlib
import json
from pathlib import Path
from runpy import run_path
import tarfile

d = Path(__file__).resolve().parent
root = d.parents[1]
tools = d/'src/benchmarks/durable'
history = run_path(str(tools/'compare-recovery.py'))['history_summary']
check = run_path(str(tools/'assess-paced.py'))['check_workload']
database = run_path(str(tools/'check-fresh-store.py'))['check']
resources = run_path(str(tools/'paired-recovery.py'))['service_resources']
read = lambda p: json.loads(p.read_bytes())
evidence = []
rows = {}
shared = []
for worker in ['fenrir-native-mac','rust']:
    path = d/'runs/0'/worker/'0'
    summary = read(path.parent/'summary.json')
    timings = read(path/'timings.json')
    h = history(path/'history.json')
    v = read(path/'check/verdicts.jsonl')
    assert v['verdict']=='accepted' and v['events']==h['event_count']==60001
    assert h['worker_implementation']==summary['worker']==worker
    assert Path(v['history']).resolve()==(path/'history.json').resolve()
    pacing = check(timings,v['events'],60000,100)
    assert pacing==read(path/'paced.json')
    db=database(path/'jobs.db',60000)
    assert db==read(path/'store-check.json')
    shared.append([h['events_sha256'],db,timings['sqlite_connection'],summary['runtime'],summary['host']])
    rows[worker]=dict(acknowledgement_p99_us=pacing['acknowledgement_p99_us'],
                      peak_backlog=max(pacing['outstanding_by_second']),cutoff_backlog=pacing['outstanding_by_second'][-1],
                      drain_us=pacing['drain_past_cutoff_us'],rate_verdict=pacing['offered_rate_verdict'],
                      service_resources=resources(path))
    evidence.extend([path.parent/'summary.json',path/'check/verdicts.jsonl',path/'timings.json',path/'resources.json',
                     path/'paced.json',path/'store-check.json',path/'jobs.db',*sorted(path.glob('history.json*'))])
assert shared[0]==shared[1]
report = dict(rate=100,seconds=600,blocks=1,workers=rows,events_sha256=shared[0][0],
              database=shared[0][1],sqlite=shared[0][2],runtime=shared[0][3],host=shared[0][4])
result=d/'first-pair.json'
result.write_text(json.dumps(report,indent=2)+'\n')
dest=root/'verification/performance/2026-11-22-arm64/durable-mac-first-ten-minute-pair.tar.gz'
with tarfile.open(dest,'x:gz') as archive:
    for p in [result,*evidence,Path(__file__).resolve()]: archive.add(p,arcname=str(p.relative_to(d)))
print(dest, dest.stat().st_size)
