from pathlib import Path
import json
import hashlib

root = Path(__file__).resolve().parent
cached = root / "full-explore-cached"
canonical = root / "full-explore-canonical"

def witnesses(directory):
    result = {}
    for path in sorted(directory.glob("*.json")):
        obj = json.loads(path.read_bytes())
        assert obj.pop("replay").endswith("/" + path.name)
        result[path.name] = obj
    assert result
    return result

def report(value):
    if isinstance(value, list):
        return [report(v) for v in value]
    if isinstance(value, dict):
        return {k: Path(v).name if k == "counterexample" else report(v)
                for k, v in value.items() if k != "seconds"}
    return value

def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            h.update(block)
    return h.hexdigest()

a = witnesses(cached / "counterexamples")
assert a == witnesses(Path("spec/service/counterexamples"))
print("retained witness matches", len(a), flush=True)
assert a == witnesses(canonical / "counterexamples")
x, y = (report(json.loads((d / "report.json").read_bytes())) for d in [cached, canonical])
assert x == y and x["status"] == "development-pass"
edges = digest(cached / "js-edges.jsonl")
assert edges == digest(canonical / "js-edges.jsonl")
print(json.dumps(dict(witnesses=len(a), report_matches=True, edge_sha256=edges)))
