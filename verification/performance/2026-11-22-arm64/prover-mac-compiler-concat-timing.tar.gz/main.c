#include <stdint.h>
#include <stdio.h>
#include <time.h>
struct outcome { int64_t value; uint64_t status; };
extern struct outcome fenrir_entry(int64_t);
void fen_write(const char *s, size_t n) { fwrite(s,1,n,stdout); }
void fen_write_i64(int64_t n) { printf("%lld",(long long)n); }
int main(void) {
    uint64_t start=clock_gettime_nsec_np(CLOCK_MONOTONIC);
    struct outcome r=fenrir_entry(50000);
    uint64_t elapsed=clock_gettime_nsec_np(CLOCK_MONOTONIC)-start;
    if (r.status || r.value!=500000) return 1;
    printf("%llu\n",(unsigned long long)elapsed);
    return 0;
}
