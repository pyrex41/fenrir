.text
.p2align 2
Lfn0:
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
ldp x8, x9, [x0, #0]
Lfn0fields:
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
ldr w2, [x8, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
cmp w2, #10
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
b.ne Lfn0frame
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
mov x0, x9
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
ret
Lfn0frame:
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
stp x29, x30, [sp, #-16]!
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
mov x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
sub sp, sp, #80
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
stp x8, x9, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
add x0, sp, #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
add x1, sp, #48
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
mov x2, #4
stp x16,x17,[sp,#-16]!
adrp x16, cnt2
ldr x17,[x16,:lo12:cnt2]
add x17,x17,#1
str x17,[x16,:lo12:cnt2]
ldp x16,x17,[sp],#16
bl fen_enter
Lfn0loop:
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
ldr w0, [x0, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
cmp w0, #10
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
b.eq Lfn0match10arm10
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
cmp w0, #11
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
b.eq Lfn0match10arm11
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
brk #0
Lfn0match10arm10:
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
ldr x0, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
b Lfn0match10end
Lfn0match10arm11:
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
ldr x0, [x0, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
ldr w0, [x0, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
cmp w0, #10
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
b.eq Lfn0match16arm10
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
cmp w0, #11
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
b.eq Lfn0match16arm11
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
brk #0
Lfn0match16arm10:
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
mov x0, #6
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
mov x1, #11
stp x16,x17,[sp,#-16]!
adrp x16, cnt2
ldr x17,[x16,:lo12:cnt2]
add x17,x17,#1
str x17,[x16,:lo12:cnt2]
ldp x16,x17,[sp],#16
bl fen_allocate
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
cbz x0, Lfn0fail18_3
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
ldr x4, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
ldp x2, x3, [x4, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
stp x2, x3, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
ldr x2, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
str x2, [x0, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
b Lfn0match16end
Lfn0match16arm11:
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
ldr x8, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
ldr x8, [x8, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
ldr x8, [x8, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
ldr x9, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt2
ldr x17,[x16,:lo12:cnt2]
add x17,x17,#1
str x17,[x16,:lo12:cnt2]
ldp x16,x17,[sp],#16
bl Lfn0fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
cbnz x1, Lfn0end
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
str x0, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
mov x0, #6
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
mov x1, #11
stp x16,x17,[sp,#-16]!
adrp x16, cnt2
ldr x17,[x16,:lo12:cnt2]
add x17,x17,#1
str x17,[x16,:lo12:cnt2]
ldp x16,x17,[sp],#16
bl fen_allocate
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
cbz x0, Lfn0fail28_3
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
ldr x4, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
ldr x4, [x4, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
ldp x2, x3, [x4, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
stp x2, x3, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
ldr x2, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
str x2, [x0, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
str x0, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
mov x0, #6
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
mov x1, #11
stp x16,x17,[sp,#-16]!
adrp x16, cnt2
ldr x17,[x16,:lo12:cnt2]
add x17,x17,#1
str x17,[x16,:lo12:cnt2]
ldp x16,x17,[sp],#16
bl fen_allocate
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
cbz x0, Lfn0fail25_3
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
ldr x4, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
ldp x2, x3, [x4, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
stp x2, x3, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
ldr x2, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
str x2, [x0, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
b Lfn0match16end
Lfn0match16end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
b Lfn0match10end
Lfn0match10end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
b Lfn0end
Lfn0fail18_3:
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
adrp x0, Lfn0fail18_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn0fail18_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt2
ldr x17,[x16,:lo12:cnt2]
add x17,x17,#1
str x17,[x16,:lo12:cnt2]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
mov x1, #3
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
b Lfn0end
Lfn0fail28_3:
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
adrp x0, Lfn0fail28_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn0fail28_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt2
ldr x17,[x16,:lo12:cnt2]
add x17,x17,#1
str x17,[x16,:lo12:cnt2]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
mov x1, #3
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
b Lfn0end
Lfn0fail25_3:
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
adrp x0, Lfn0fail25_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn0fail25_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt2
ldr x17,[x16,:lo12:cnt2]
add x17,x17,#1
str x17,[x16,:lo12:cnt2]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
mov x1, #3
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
b Lfn0end
Lfn0end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt2
ldr x17,[x16,:lo12:cnt2]
add x17,x17,#1
str x17,[x16,:lo12:cnt2]
ldp x16,x17,[sp],#16
bl fen_leave_result
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
ret
Lfn1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
ldp x8, x9, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
ldr x10, [x0, #16]
Lfn1fields:
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
stp x29, x30, [sp, #-16]!
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
mov x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
sub sp, sp, #80
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
str xzr, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
str x8, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
str x9, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
str x10, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
add x0, sp, #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
add x1, sp, #48
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
mov x2, #3
stp x16,x17,[sp,#-16]!
adrp x16, cnt5
ldr x17,[x16,:lo12:cnt5]
add x17,x17,#1
str x17,[x16,:lo12:cnt5]
ldp x16,x17,[sp],#16
bl fen_enter
Lfn1loop:
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
mov x0, #6
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
mov x1, #11
stp x16,x17,[sp,#-16]!
adrp x16, cnt5
ldr x17,[x16,:lo12:cnt5]
add x17,x17,#1
str x17,[x16,:lo12:cnt5]
ldp x16,x17,[sp],#16
bl fen_allocate
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
cbz x0, Lfn1fail52_3
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
ldr x2, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
ldr x3, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
stp x2, x3, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
adrp x2, Lconstant0
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
add x2, x2, :lo12:Lconstant0
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
str x2, [x0, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
str x0, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt5
ldr x17,[x16,:lo12:cnt5]
add x17,x17,#1
str x17,[x16,:lo12:cnt5]
ldp x16,x17,[sp],#16
bl fen_leave_result
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
ldr x8, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
ldr x9, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
b Lfn0fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
b Lfn1end
Lfn1fail52_3:
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
adrp x0, Lfn1fail52_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn1fail52_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt5
ldr x17,[x16,:lo12:cnt5]
add x17,x17,#1
str x17,[x16,:lo12:cnt5]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
mov x1, #3
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
b Lfn1end
Lfn1end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt5
ldr x17,[x16,:lo12:cnt5]
add x17,x17,#1
str x17,[x16,:lo12:cnt5]
ldp x16,x17,[sp],#16
bl fen_leave_result
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
ret
Lfn2:
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
ldp x8, x9, [x0, #0]
Lfn2fields:
stp x16,x17,[sp,#-16]!
adrp x16, cnt7
ldr x17,[x16,:lo12:cnt7]
add x17,x17,#1
str x17,[x16,:lo12:cnt7]
ldp x16,x17,[sp],#16
stp x29, x30, [sp, #-16]!
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
mov x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
sub sp, sp, #64
stp x16,x17,[sp,#-16]!
adrp x16, cnt7
ldr x17,[x16,:lo12:cnt7]
add x17,x17,#1
str x17,[x16,:lo12:cnt7]
ldp x16,x17,[sp],#16
stp x8, x9, [sp, #48]
Lfn2loop:
stp x16,x17,[sp,#-16]!
adrp x16, cnt7
ldr x17,[x16,:lo12:cnt7]
add x17,x17,#1
str x17,[x16,:lo12:cnt7]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt7
ldr x17,[x16,:lo12:cnt7]
add x17,x17,#1
str x17,[x16,:lo12:cnt7]
ldp x16,x17,[sp],#16
ldr x2, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
cmp x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
b.ge Lfn2if66else
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
b Lfn2if66done
Lfn2if66else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt7
ldr x17,[x16,:lo12:cnt7]
add x17,x17,#1
str x17,[x16,:lo12:cnt7]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt7
ldr x17,[x16,:lo12:cnt7]
add x17,x17,#1
str x17,[x16,:lo12:cnt7]
ldp x16,x17,[sp],#16
ldr x2, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
cbz x2, Lfn2fail73_2
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
cmn x2, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
b.ne 1f
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
negs x3, x0
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
b.vs Lfn2fail73_1
1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
sdiv x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
cmp x0, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
neg x2, x0
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
and x2, x2, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
and x0, x0, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
csneg x0, x0, x2, ge
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
cmp x0, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
cset x0, eq
Lfn2if66done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
b Lfn2end
Lfn2fail73_2:
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
adrp x0, Lfn2fail73_2location
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn2fail73_2location
stp x16,x17,[sp,#-16]!
adrp x16, cnt8
ldr x17,[x16,:lo12:cnt8]
add x17,x17,#1
str x17,[x16,:lo12:cnt8]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
mov x1, #2
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
b Lfn2end
Lfn2fail73_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
adrp x0, Lfn2fail73_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn2fail73_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt8
ldr x17,[x16,:lo12:cnt8]
add x17,x17,#1
str x17,[x16,:lo12:cnt8]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
b Lfn2end
Lfn2end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt7
ldr x17,[x16,:lo12:cnt7]
add x17,x17,#1
str x17,[x16,:lo12:cnt7]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
ret
Lfn3:
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
ldp x8, x9, [x0, #0]
Lfn3fields:
stp x16,x17,[sp,#-16]!
adrp x16, cnt10
ldr x17,[x16,:lo12:cnt10]
add x17,x17,#1
str x17,[x16,:lo12:cnt10]
ldp x16,x17,[sp],#16
stp x29, x30, [sp, #-16]!
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
mov x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
sub sp, sp, #64
stp x16,x17,[sp,#-16]!
adrp x16, cnt10
ldr x17,[x16,:lo12:cnt10]
add x17,x17,#1
str x17,[x16,:lo12:cnt10]
ldp x16,x17,[sp],#16
stp x8, x9, [sp, #48]
Lfn3loop:
stp x16,x17,[sp,#-16]!
adrp x16, cnt10
ldr x17,[x16,:lo12:cnt10]
add x17,x17,#1
str x17,[x16,:lo12:cnt10]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt10
ldr x17,[x16,:lo12:cnt10]
add x17,x17,#1
str x17,[x16,:lo12:cnt10]
ldp x16,x17,[sp],#16
ldr x2, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
cmp x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
b.ge Lfn3if95else
stp x16,x17,[sp,#-16]!
adrp x16, cnt10
ldr x17,[x16,:lo12:cnt10]
add x17,x17,#1
str x17,[x16,:lo12:cnt10]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt10
ldr x17,[x16,:lo12:cnt10]
add x17,x17,#1
str x17,[x16,:lo12:cnt10]
ldp x16,x17,[sp],#16
ldr x2, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
b.vs Lfn3fail99_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
b Lfn3if95done
Lfn3if95else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt10
ldr x17,[x16,:lo12:cnt10]
add x17,x17,#1
str x17,[x16,:lo12:cnt10]
ldp x16,x17,[sp],#16
ldr x8, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt10
ldr x17,[x16,:lo12:cnt10]
add x17,x17,#1
str x17,[x16,:lo12:cnt10]
ldp x16,x17,[sp],#16
ldr x9, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt11
ldr x17,[x16,:lo12:cnt11]
add x17,x17,#1
str x17,[x16,:lo12:cnt11]
ldp x16,x17,[sp],#16
bl Lfn2fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
cbnz x1, Lfn3end
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
cbz x0, Lfn3if102else
stp x16,x17,[sp,#-16]!
adrp x16, cnt10
ldr x17,[x16,:lo12:cnt10]
add x17,x17,#1
str x17,[x16,:lo12:cnt10]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
b Lfn3if102done
Lfn3if102else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt10
ldr x17,[x16,:lo12:cnt10]
add x17,x17,#1
str x17,[x16,:lo12:cnt10]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt10
ldr x17,[x16,:lo12:cnt10]
add x17,x17,#1
str x17,[x16,:lo12:cnt10]
ldp x16,x17,[sp],#16
ldr x2, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
b.vs Lfn3fail108_1
Lfn3if102done:
Lfn3if95done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
b Lfn3end
Lfn3fail99_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
adrp x0, Lfn3fail99_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn3fail99_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt11
ldr x17,[x16,:lo12:cnt11]
add x17,x17,#1
str x17,[x16,:lo12:cnt11]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
b Lfn3end
Lfn3fail108_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
adrp x0, Lfn3fail108_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn3fail108_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt11
ldr x17,[x16,:lo12:cnt11]
add x17,x17,#1
str x17,[x16,:lo12:cnt11]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
b Lfn3end
Lfn3end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt10
ldr x17,[x16,:lo12:cnt10]
add x17,x17,#1
str x17,[x16,:lo12:cnt10]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
ret
Lfn4:
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldp x8, x9, [x0, #0]
Lfn4fields:
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
stp x29, x30, [sp, #-16]!
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
mov x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
sub sp, sp, #128
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #88]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str xzr, [sp, #104]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x8, [sp, #112]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x9, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
add x0, sp, #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
add x1, sp, #48
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
mov x2, #8
stp x16,x17,[sp,#-16]!
adrp x16, cnt14
ldr x17,[x16,:lo12:cnt14]
add x17,x17,#1
str x17,[x16,:lo12:cnt14]
ldp x16,x17,[sp],#16
bl fen_enter
Lfn4loop:
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #112]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cmp x0, #8
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b.lt Lfn4if121else
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #112]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
subs x0, x0, #8
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b.vs Lfn4fail127_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x0, [sp, #120]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
adrp x0, Lconstant1
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lconstant1
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x2, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
mov x1, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt14
ldr x17,[x16,:lo12:cnt14]
add x17,x17,#1
str x17,[x16,:lo12:cnt14]
ldp x16,x17,[sp],#16
bl fen_bytes_concat
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cbz x0, Lfn4fail130_3
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x0, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x8, [sp, #120]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x9, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x8, [sp, #112]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x9, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #88]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str xzr, [sp, #104]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4loop
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4if121done
Lfn4if121else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #112]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cmp x0, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b.ne Lfn4if133else
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4if133done
Lfn4if133else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #112]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cmp x0, #4
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b.ge Lfn4if139else
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #112]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cmp x0, #2
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b.ge Lfn4if143else
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
adrp x0, Lconstant2
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lconstant2
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4if143done
Lfn4if143else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #112]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cmp x0, #2
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b.ne Lfn4if148else
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
adrp x0, Lconstant3
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lconstant3
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4if148done
Lfn4if148else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
adrp x0, Lconstant4
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lconstant4
Lfn4if148done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x0, [sp, #64]
Lfn4if143done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x0, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4if139done
Lfn4if139else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #112]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cmp x0, #6
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b.ge Lfn4if154else
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #112]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cmp x0, #4
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b.ne Lfn4if158else
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
adrp x0, Lconstant5
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lconstant5
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4if158done
Lfn4if158else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
adrp x0, Lconstant6
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lconstant6
Lfn4if158done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x0, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4if154done
Lfn4if154else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #112]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cmp x0, #6
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b.ne Lfn4if164else
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
adrp x0, Lconstant7
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lconstant7
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4if164done
Lfn4if164else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
adrp x0, Lconstant8
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lconstant8
Lfn4if164done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x0, [sp, #88]
Lfn4if154done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x0, [sp, #96]
Lfn4if139done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x0, [sp, #104]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x2, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
mov x1, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt14
ldr x17,[x16,:lo12:cnt14]
add x17,x17,#1
str x17,[x16,:lo12:cnt14]
ldp x16,x17,[sp],#16
bl fen_bytes_concat
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cbz x0, Lfn4fail138_3
Lfn4if133done:
Lfn4if121done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4end
Lfn4fail127_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
adrp x0, Lfn4fail127_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn4fail127_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt14
ldr x17,[x16,:lo12:cnt14]
add x17,x17,#1
str x17,[x16,:lo12:cnt14]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4end
Lfn4fail130_3:
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
adrp x0, Lfn4fail130_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn4fail130_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt14
ldr x17,[x16,:lo12:cnt14]
add x17,x17,#1
str x17,[x16,:lo12:cnt14]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
mov x1, #3
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4end
Lfn4fail138_3:
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
adrp x0, Lfn4fail138_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn4fail138_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt14
ldr x17,[x16,:lo12:cnt14]
add x17,x17,#1
str x17,[x16,:lo12:cnt14]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
mov x1, #3
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4end
Lfn4end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt14
ldr x17,[x16,:lo12:cnt14]
add x17,x17,#1
str x17,[x16,:lo12:cnt14]
ldp x16,x17,[sp],#16
bl fen_leave_result
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ret
Lfn5:
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldp x8, x9, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldp x10, x11, [x0, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldp x12, x13, [x0, #32]
Lfn5fields:
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp x29, x30, [sp, #-16]!
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
mov x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
sub sp, sp, #288
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #96]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #112]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #128]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #144]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp x8, x9, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp x10, x11, [sp, #160]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp x12, x13, [sp, #176]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
add x0, sp, #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
add x1, sp, #48
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
mov x2, #14
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl fen_enter
Lfn5loop:
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x0, [sp, #176]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cmp x0, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b.ne Lfn5if197else
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
adrp x0, Lconstant9
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lconstant9
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5if197done
Lfn5if197else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x0, [sp, #176]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
subs x0, x0, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b.vs Lfn5fail204_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x0, [sp, #192]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr w0, [x0, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cmp w0, #10
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b.eq Lfn5match207arm10
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cmp w0, #11
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b.eq Lfn5match207arm11
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
brk #0
Lfn5match207arm10:
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x0, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr w0, [x0, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cmp w0, #10
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b.eq Lfn5match209arm10
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cmp w0, #11
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b.eq Lfn5match209arm11
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
brk #0
Lfn5match209arm10:
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
mov x0, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
mov x1, #13
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl fen_allocate
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cbz x0, Lfn5fail211_3
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x2, [sp, #160]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x3, [sp, #192]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
stp x2, x3, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5match209end
Lfn5match209arm11:
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x8, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
adrp x9, Lconstant0
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
add x9, x9, :lo12:Lconstant0
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x8, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x9, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #96]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #112]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #128]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #144]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5loop
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5match209end
Lfn5match209end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5match207end
Lfn5match207arm11:
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x0, [x0, #8]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr w0, [x0, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cmp w0, #7
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b.eq Lfn5match228arm7
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cmp w0, #8
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b.eq Lfn5match228arm8
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cmp w0, #9
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b.eq Lfn5match228arm9
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
brk #0
Lfn5match228arm7:
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x0, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cbz x0, Lfn5if234else
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x0, [sp, #168]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5if234done
Lfn5if234else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x0, [sp, #160]
Lfn5if234done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x0, [sp, #200]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x8, [sp, #200]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x9, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x9, [x9, #8]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x9, [x9, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl Lfn2fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cbnz x1, Lfn5end
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cbz x0, Lfn5if231else
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x8, [sp, #184]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
adrp x9, Lconstant10
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
add x9, x9, :lo12:Lconstant10
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl Lfn4fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cbnz x1, Lfn5end
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x0, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
mov x0, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
mov x1, #12
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl fen_allocate
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cbz x0, Lfn5fail239_3
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x2, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x3, [sp, #192]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
stp x2, x3, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5if231done
Lfn5if231else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x0, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cbz x0, Lfn5if249else
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x8, [sp, #160]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x9, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x9, [x9, #8]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x9, [x9, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl Lfn3fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cbnz x1, Lfn5end
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5if249done
Lfn5if249else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x0, [sp, #160]
Lfn5if249done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x0, [sp, #208]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x0, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cbz x0, Lfn5if256else
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x0, [sp, #168]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5if256done
Lfn5if256else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x8, [sp, #168]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x9, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x9, [x9, #8]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x9, [x9, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl Lfn3fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cbnz x1, Lfn5end
Lfn5if256done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x0, [sp, #216]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x0, [sp, #184]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
adds x0, x0, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b.vs Lfn5fail264_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x0, [sp, #224]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x8, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x8, [x8, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x9, [sp, #208]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x10, [sp, #216]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x11, [sp, #192]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x12, [sp, #224]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x8, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x9, [sp, #160]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x10, [sp, #168]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x11, [sp, #176]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x12, [sp, #184]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #96]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #112]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #128]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #144]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5loop
Lfn5if231done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5match228end
Lfn5match228arm8:
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x0, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
eor x0, x0, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x0, [sp, #232]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x8, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x9, [sp, #232]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x10, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x10, [x10, #8]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x10, [x10, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl Lfn1fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cbnz x1, Lfn5end
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x0, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x0, [sp, #184]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
adds x0, x0, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b.vs Lfn5fail280_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x0, [sp, #240]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x8, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x8, [x8, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x9, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x10, [sp, #192]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x11, [sp, #240]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x8, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x9, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x10, [sp, #176]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x11, [sp, #184]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #96]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #112]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #128]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #144]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5loop
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5match228end
Lfn5match228arm9:
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x0, [x0, #8]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x0, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cmp x0, #2
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b.ne Lfn5if288else
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x0, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
eor x0, x0, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5if288done
Lfn5if288else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x0, [x0, #0]
Lfn5if288done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x0, [sp, #248]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x0, [x0, #8]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x0, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cmp x0, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cset x0, eq
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x2, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x2, [x2, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cmp x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b.ne Lfn5if295else
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
mov x0, #6
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
mov x1, #11
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl fen_allocate
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cbz x0, Lfn5fail310_3
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x2, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x2, [x2, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x3, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x3, [x3, #8]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x3, [x3, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
stp x2, x3, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
adrp x2, Lconstant0
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
add x2, x2, :lo12:Lconstant0
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
str x2, [x0, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x0, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
mov x0, #6
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
mov x1, #11
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl fen_allocate
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cbz x0, Lfn5fail307_3
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x2, [sp, #248]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x3, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x3, [x3, #8]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x3, [x3, #8]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
stp x2, x3, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x2, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
str x2, [x0, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x0, [sp, #88]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x8, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x9, [sp, #88]
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl Lfn0fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cbnz x1, Lfn5end
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x0, [sp, #96]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x0, [sp, #184]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
adds x0, x0, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b.vs Lfn5fail317_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x0, [sp, #256]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x8, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x8, [x8, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x9, [sp, #96]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x10, [sp, #192]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x11, [sp, #256]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x8, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x9, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x10, [sp, #176]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x11, [sp, #184]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #96]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #112]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #128]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #144]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5loop
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5if295done
Lfn5if295else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x8, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x9, [sp, #248]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x10, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x10, [x10, #8]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x10, [x10, #8]
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl Lfn1fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cbnz x1, Lfn5end
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x0, [sp, #104]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x0, [sp, #264]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x8, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x8, [x8, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x9, [sp, #104]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x10, [sp, #160]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x11, [sp, #168]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x12, [sp, #192]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x13, [sp, #264]
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl Lfn5fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cbnz x1, Lfn5end
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x0, [sp, #112]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr w0, [x0, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cmp w0, #12
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b.eq Lfn5match334arm12
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cmp w0, #13
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b.eq Lfn5match334arm13
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cmp w0, #14
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b.eq Lfn5match334arm14
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
brk #0
Lfn5match334arm12:
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x8, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x9, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x9, [x9, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x10, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x10, [x10, #8]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x10, [x10, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl Lfn1fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cbnz x1, Lfn5end
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x0, [sp, #120]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x0, [sp, #272]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x8, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x8, [x8, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x9, [sp, #120]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x10, [sp, #160]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x11, [sp, #168]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x12, [sp, #112]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x12, [x12, #8]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x13, [sp, #272]
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl Lfn5fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cbnz x1, Lfn5end
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x0, [sp, #128]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr w0, [x0, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cmp w0, #12
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b.eq Lfn5match352arm12
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cmp w0, #13
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b.eq Lfn5match352arm13
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cmp w0, #14
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b.eq Lfn5match352arm14
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
brk #0
Lfn5match352arm12:
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x0, [sp, #112]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x0, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x2, [sp, #128]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x2, [x2, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
mov x1, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl fen_bytes_concat
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cbz x0, Lfn5fail362_3
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x0, [sp, #136]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
adrp x0, Lconstant11
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lconstant11
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x2, [sp, #136]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
mov x1, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl fen_bytes_concat
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cbz x0, Lfn5fail360_3
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x0, [sp, #144]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x8, [sp, #184]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x9, [sp, #144]
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl Lfn4fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cbnz x1, Lfn5end
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x0, [sp, #152]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
mov x0, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
mov x1, #12
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl fen_allocate
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cbz x0, Lfn5fail356_3
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x2, [sp, #152]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x3, [sp, #128]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x3, [x3, #8]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
stp x2, x3, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5match352end
Lfn5match352arm13:
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x0, [sp, #128]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5match352end
Lfn5match352arm14:
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x0, [sp, #128]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5match352end
Lfn5match352end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5match334end
Lfn5match334arm13:
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x0, [sp, #112]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5match334end
Lfn5match334arm14:
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x0, [sp, #112]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5match334end
Lfn5match334end:
Lfn5if295done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5match228end
Lfn5match228end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5match207end
Lfn5match207end:
Lfn5if197done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5end
Lfn5fail204_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
adrp x0, Lfn5fail204_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn5fail204_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5end
Lfn5fail211_3:
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
adrp x0, Lfn5fail211_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn5fail211_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
mov x1, #3
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5end
Lfn5fail239_3:
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
adrp x0, Lfn5fail239_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn5fail239_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
mov x1, #3
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5end
Lfn5fail264_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
adrp x0, Lfn5fail264_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn5fail264_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5end
Lfn5fail280_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
adrp x0, Lfn5fail280_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn5fail280_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5end
Lfn5fail310_3:
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
adrp x0, Lfn5fail310_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn5fail310_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
mov x1, #3
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5end
Lfn5fail307_3:
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
adrp x0, Lfn5fail307_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn5fail307_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
mov x1, #3
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5end
Lfn5fail317_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
adrp x0, Lfn5fail317_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn5fail317_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5end
Lfn5fail362_3:
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
adrp x0, Lfn5fail362_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn5fail362_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
mov x1, #3
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5end
Lfn5fail360_3:
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
adrp x0, Lfn5fail360_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn5fail360_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
mov x1, #3
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5end
Lfn5fail356_3:
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
adrp x0, Lfn5fail356_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn5fail356_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
mov x1, #3
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5end
Lfn5end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl fen_leave_result
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ret
Lfn6:
stp x16,x17,[sp,#-16]!
adrp x16, cnt18
ldr x17,[x16,:lo12:cnt18]
add x17,x17,#1
str x17,[x16,:lo12:cnt18]
ldp x16,x17,[sp],#16
ldp x8, x9, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt18
ldr x17,[x16,:lo12:cnt18]
add x17,x17,#1
str x17,[x16,:lo12:cnt18]
ldp x16,x17,[sp],#16
ldp x10, x11, [x0, #16]
Lfn6fields:
stp x16,x17,[sp,#-16]!
adrp x16, cnt19
ldr x17,[x16,:lo12:cnt19]
add x17,x17,#1
str x17,[x16,:lo12:cnt19]
ldp x16,x17,[sp],#16
stp x29, x30, [sp, #-16]!
stp x16,x17,[sp,#-16]!
adrp x16, cnt18
ldr x17,[x16,:lo12:cnt18]
add x17,x17,#1
str x17,[x16,:lo12:cnt18]
ldp x16,x17,[sp],#16
mov x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt18
ldr x17,[x16,:lo12:cnt18]
add x17,x17,#1
str x17,[x16,:lo12:cnt18]
ldp x16,x17,[sp],#16
sub sp, sp, #96
stp x16,x17,[sp,#-16]!
adrp x16, cnt19
ldr x17,[x16,:lo12:cnt19]
add x17,x17,#1
str x17,[x16,:lo12:cnt19]
ldp x16,x17,[sp],#16
stp x8, x9, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt19
ldr x17,[x16,:lo12:cnt19]
add x17,x17,#1
str x17,[x16,:lo12:cnt19]
ldp x16,x17,[sp],#16
stp x10, x11, [sp, #64]
Lfn6loop:
stp x16,x17,[sp,#-16]!
adrp x16, cnt18
ldr x17,[x16,:lo12:cnt18]
add x17,x17,#1
str x17,[x16,:lo12:cnt18]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt19
ldr x17,[x16,:lo12:cnt19]
add x17,x17,#1
str x17,[x16,:lo12:cnt19]
ldp x16,x17,[sp],#16
str x0, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt19
ldr x17,[x16,:lo12:cnt19]
add x17,x17,#1
str x17,[x16,:lo12:cnt19]
ldp x16,x17,[sp],#16
ldr x8, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt18
ldr x17,[x16,:lo12:cnt18]
add x17,x17,#1
str x17,[x16,:lo12:cnt18]
ldp x16,x17,[sp],#16
adrp x9, Lconstant0
stp x16,x17,[sp,#-16]!
adrp x16, cnt18
ldr x17,[x16,:lo12:cnt18]
add x17,x17,#1
str x17,[x16,:lo12:cnt18]
ldp x16,x17,[sp],#16
add x9, x9, :lo12:Lconstant0
stp x16,x17,[sp,#-16]!
adrp x16, cnt19
ldr x17,[x16,:lo12:cnt19]
add x17,x17,#1
str x17,[x16,:lo12:cnt19]
ldp x16,x17,[sp],#16
ldr x10, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt19
ldr x17,[x16,:lo12:cnt19]
add x17,x17,#1
str x17,[x16,:lo12:cnt19]
ldp x16,x17,[sp],#16
ldr x11, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt19
ldr x17,[x16,:lo12:cnt19]
add x17,x17,#1
str x17,[x16,:lo12:cnt19]
ldp x16,x17,[sp],#16
ldr x12, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt19
ldr x17,[x16,:lo12:cnt19]
add x17,x17,#1
str x17,[x16,:lo12:cnt19]
ldp x16,x17,[sp],#16
ldr x13, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt18
ldr x17,[x16,:lo12:cnt18]
add x17,x17,#1
str x17,[x16,:lo12:cnt18]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt19
ldr x17,[x16,:lo12:cnt19]
add x17,x17,#1
str x17,[x16,:lo12:cnt19]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt18
ldr x17,[x16,:lo12:cnt18]
add x17,x17,#1
str x17,[x16,:lo12:cnt18]
ldp x16,x17,[sp],#16
b Lfn5fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt18
ldr x17,[x16,:lo12:cnt18]
add x17,x17,#1
str x17,[x16,:lo12:cnt18]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt18
ldr x17,[x16,:lo12:cnt18]
add x17,x17,#1
str x17,[x16,:lo12:cnt18]
ldp x16,x17,[sp],#16
b Lfn6end
Lfn6end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt18
ldr x17,[x16,:lo12:cnt18]
add x17,x17,#1
str x17,[x16,:lo12:cnt18]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt19
ldr x17,[x16,:lo12:cnt19]
add x17,x17,#1
str x17,[x16,:lo12:cnt19]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt18
ldr x17,[x16,:lo12:cnt18]
add x17,x17,#1
str x17,[x16,:lo12:cnt18]
ldp x16,x17,[sp],#16
ret
Lfn7:
stp x16,x17,[sp,#-16]!
adrp x16, cnt20
ldr x17,[x16,:lo12:cnt20]
add x17,x17,#1
str x17,[x16,:lo12:cnt20]
ldp x16,x17,[sp],#16
stp x29, x30, [sp, #-16]!
stp x16,x17,[sp,#-16]!
adrp x16, cnt21
ldr x17,[x16,:lo12:cnt21]
add x17,x17,#1
str x17,[x16,:lo12:cnt21]
ldp x16,x17,[sp],#16
mov x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt21
ldr x17,[x16,:lo12:cnt21]
add x17,x17,#1
str x17,[x16,:lo12:cnt21]
ldp x16,x17,[sp],#16
sub sp, sp, #96
stp x16,x17,[sp,#-16]!
adrp x16, cnt20
ldr x17,[x16,:lo12:cnt20]
add x17,x17,#1
str x17,[x16,:lo12:cnt20]
ldp x16,x17,[sp],#16
str xzr, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt20
ldr x17,[x16,:lo12:cnt20]
add x17,x17,#1
str x17,[x16,:lo12:cnt20]
ldp x16,x17,[sp],#16
str x0, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt21
ldr x17,[x16,:lo12:cnt21]
add x17,x17,#1
str x17,[x16,:lo12:cnt21]
ldp x16,x17,[sp],#16
add x0, sp, #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt21
ldr x17,[x16,:lo12:cnt21]
add x17,x17,#1
str x17,[x16,:lo12:cnt21]
ldp x16,x17,[sp],#16
add x1, sp, #48
stp x16,x17,[sp,#-16]!
adrp x16, cnt21
ldr x17,[x16,:lo12:cnt21]
add x17,x17,#1
str x17,[x16,:lo12:cnt21]
ldp x16,x17,[sp],#16
mov x2, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt22
ldr x17,[x16,:lo12:cnt22]
add x17,x17,#1
str x17,[x16,:lo12:cnt22]
ldp x16,x17,[sp],#16
bl fen_enter
stp x16,x17,[sp,#-16]!
adrp x16, cnt21
ldr x17,[x16,:lo12:cnt21]
add x17,x17,#1
str x17,[x16,:lo12:cnt21]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt20
ldr x17,[x16,:lo12:cnt20]
add x17,x17,#1
str x17,[x16,:lo12:cnt20]
ldp x16,x17,[sp],#16
str x0, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt21
ldr x17,[x16,:lo12:cnt21]
add x17,x17,#1
str x17,[x16,:lo12:cnt21]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt20
ldr x17,[x16,:lo12:cnt20]
add x17,x17,#1
str x17,[x16,:lo12:cnt20]
ldp x16,x17,[sp],#16
str x0, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt21
ldr x17,[x16,:lo12:cnt21]
add x17,x17,#1
str x17,[x16,:lo12:cnt21]
ldp x16,x17,[sp],#16
movz x0, #100, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt20
ldr x17,[x16,:lo12:cnt20]
add x17,x17,#1
str x17,[x16,:lo12:cnt20]
ldp x16,x17,[sp],#16
str x0, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt21
ldr x17,[x16,:lo12:cnt21]
add x17,x17,#1
str x17,[x16,:lo12:cnt21]
ldp x16,x17,[sp],#16
adrp x8, Lconstant14
stp x16,x17,[sp,#-16]!
adrp x16, cnt21
ldr x17,[x16,:lo12:cnt21]
add x17,x17,#1
str x17,[x16,:lo12:cnt21]
ldp x16,x17,[sp],#16
add x8, x8, :lo12:Lconstant14
stp x16,x17,[sp,#-16]!
adrp x16, cnt20
ldr x17,[x16,:lo12:cnt20]
add x17,x17,#1
str x17,[x16,:lo12:cnt20]
ldp x16,x17,[sp],#16
ldr x9, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt20
ldr x17,[x16,:lo12:cnt20]
add x17,x17,#1
str x17,[x16,:lo12:cnt20]
ldp x16,x17,[sp],#16
ldr x10, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt20
ldr x17,[x16,:lo12:cnt20]
add x17,x17,#1
str x17,[x16,:lo12:cnt20]
ldp x16,x17,[sp],#16
ldr x11, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt22
ldr x17,[x16,:lo12:cnt22]
add x17,x17,#1
str x17,[x16,:lo12:cnt22]
ldp x16,x17,[sp],#16
bl Lfn6fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt21
ldr x17,[x16,:lo12:cnt21]
add x17,x17,#1
str x17,[x16,:lo12:cnt21]
ldp x16,x17,[sp],#16
cbnz x1, Lfn7end
stp x16,x17,[sp,#-16]!
adrp x16, cnt20
ldr x17,[x16,:lo12:cnt20]
add x17,x17,#1
str x17,[x16,:lo12:cnt20]
ldp x16,x17,[sp],#16
str x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt21
ldr x17,[x16,:lo12:cnt21]
add x17,x17,#1
str x17,[x16,:lo12:cnt21]
ldp x16,x17,[sp],#16
adrp x2, Lconstant16
stp x16,x17,[sp,#-16]!
adrp x16, cnt21
ldr x17,[x16,:lo12:cnt21]
add x17,x17,#1
str x17,[x16,:lo12:cnt21]
ldp x16,x17,[sp],#16
add x2, x2, :lo12:Lconstant16
stp x16,x17,[sp,#-16]!
adrp x16, cnt21
ldr x17,[x16,:lo12:cnt21]
add x17,x17,#1
str x17,[x16,:lo12:cnt21]
ldp x16,x17,[sp],#16
mov x1, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt22
ldr x17,[x16,:lo12:cnt22]
add x17,x17,#1
str x17,[x16,:lo12:cnt22]
ldp x16,x17,[sp],#16
bl fen_equal
stp x16,x17,[sp,#-16]!
adrp x16, cnt21
ldr x17,[x16,:lo12:cnt21]
add x17,x17,#1
str x17,[x16,:lo12:cnt21]
ldp x16,x17,[sp],#16
cbz x0, Lfn7if402else
stp x16,x17,[sp,#-16]!
adrp x16, cnt21
ldr x17,[x16,:lo12:cnt21]
add x17,x17,#1
str x17,[x16,:lo12:cnt21]
ldp x16,x17,[sp],#16
movz x0, #1, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt21
ldr x17,[x16,:lo12:cnt21]
add x17,x17,#1
str x17,[x16,:lo12:cnt21]
ldp x16,x17,[sp],#16
b Lfn7if402done
Lfn7if402else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt21
ldr x17,[x16,:lo12:cnt21]
add x17,x17,#1
str x17,[x16,:lo12:cnt21]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
Lfn7if402done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt21
ldr x17,[x16,:lo12:cnt21]
add x17,x17,#1
str x17,[x16,:lo12:cnt21]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt21
ldr x17,[x16,:lo12:cnt21]
add x17,x17,#1
str x17,[x16,:lo12:cnt21]
ldp x16,x17,[sp],#16
b Lfn7end
Lfn7end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt22
ldr x17,[x16,:lo12:cnt22]
add x17,x17,#1
str x17,[x16,:lo12:cnt22]
ldp x16,x17,[sp],#16
bl fen_leave_result
stp x16,x17,[sp,#-16]!
adrp x16, cnt21
ldr x17,[x16,:lo12:cnt21]
add x17,x17,#1
str x17,[x16,:lo12:cnt21]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt20
ldr x17,[x16,:lo12:cnt20]
add x17,x17,#1
str x17,[x16,:lo12:cnt20]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt21
ldr x17,[x16,:lo12:cnt21]
add x17,x17,#1
str x17,[x16,:lo12:cnt21]
ldp x16,x17,[sp],#16
ret
Lfn8:
stp x16,x17,[sp,#-16]!
adrp x16, cnt23
ldr x17,[x16,:lo12:cnt23]
add x17,x17,#1
str x17,[x16,:lo12:cnt23]
ldp x16,x17,[sp],#16
stp x29, x30, [sp, #-16]!
stp x16,x17,[sp,#-16]!
adrp x16, cnt24
ldr x17,[x16,:lo12:cnt24]
add x17,x17,#1
str x17,[x16,:lo12:cnt24]
ldp x16,x17,[sp],#16
mov x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt24
ldr x17,[x16,:lo12:cnt24]
add x17,x17,#1
str x17,[x16,:lo12:cnt24]
ldp x16,x17,[sp],#16
sub sp, sp, #96
stp x16,x17,[sp,#-16]!
adrp x16, cnt23
ldr x17,[x16,:lo12:cnt23]
add x17,x17,#1
str x17,[x16,:lo12:cnt23]
ldp x16,x17,[sp],#16
str xzr, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt23
ldr x17,[x16,:lo12:cnt23]
add x17,x17,#1
str x17,[x16,:lo12:cnt23]
ldp x16,x17,[sp],#16
str x0, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt24
ldr x17,[x16,:lo12:cnt24]
add x17,x17,#1
str x17,[x16,:lo12:cnt24]
ldp x16,x17,[sp],#16
add x0, sp, #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt24
ldr x17,[x16,:lo12:cnt24]
add x17,x17,#1
str x17,[x16,:lo12:cnt24]
ldp x16,x17,[sp],#16
add x1, sp, #48
stp x16,x17,[sp,#-16]!
adrp x16, cnt24
ldr x17,[x16,:lo12:cnt24]
add x17,x17,#1
str x17,[x16,:lo12:cnt24]
ldp x16,x17,[sp],#16
mov x2, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt25
ldr x17,[x16,:lo12:cnt25]
add x17,x17,#1
str x17,[x16,:lo12:cnt25]
ldp x16,x17,[sp],#16
bl fen_enter
stp x16,x17,[sp,#-16]!
adrp x16, cnt24
ldr x17,[x16,:lo12:cnt24]
add x17,x17,#1
str x17,[x16,:lo12:cnt24]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt23
ldr x17,[x16,:lo12:cnt23]
add x17,x17,#1
str x17,[x16,:lo12:cnt23]
ldp x16,x17,[sp],#16
str x0, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt24
ldr x17,[x16,:lo12:cnt24]
add x17,x17,#1
str x17,[x16,:lo12:cnt24]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt23
ldr x17,[x16,:lo12:cnt23]
add x17,x17,#1
str x17,[x16,:lo12:cnt23]
ldp x16,x17,[sp],#16
str x0, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt24
ldr x17,[x16,:lo12:cnt24]
add x17,x17,#1
str x17,[x16,:lo12:cnt24]
ldp x16,x17,[sp],#16
movz x0, #100, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt23
ldr x17,[x16,:lo12:cnt23]
add x17,x17,#1
str x17,[x16,:lo12:cnt23]
ldp x16,x17,[sp],#16
str x0, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt24
ldr x17,[x16,:lo12:cnt24]
add x17,x17,#1
str x17,[x16,:lo12:cnt24]
ldp x16,x17,[sp],#16
adrp x8, Lconstant19
stp x16,x17,[sp,#-16]!
adrp x16, cnt24
ldr x17,[x16,:lo12:cnt24]
add x17,x17,#1
str x17,[x16,:lo12:cnt24]
ldp x16,x17,[sp],#16
add x8, x8, :lo12:Lconstant19
stp x16,x17,[sp,#-16]!
adrp x16, cnt23
ldr x17,[x16,:lo12:cnt23]
add x17,x17,#1
str x17,[x16,:lo12:cnt23]
ldp x16,x17,[sp],#16
ldr x9, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt23
ldr x17,[x16,:lo12:cnt23]
add x17,x17,#1
str x17,[x16,:lo12:cnt23]
ldp x16,x17,[sp],#16
ldr x10, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt23
ldr x17,[x16,:lo12:cnt23]
add x17,x17,#1
str x17,[x16,:lo12:cnt23]
ldp x16,x17,[sp],#16
ldr x11, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt25
ldr x17,[x16,:lo12:cnt25]
add x17,x17,#1
str x17,[x16,:lo12:cnt25]
ldp x16,x17,[sp],#16
bl Lfn6fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt24
ldr x17,[x16,:lo12:cnt24]
add x17,x17,#1
str x17,[x16,:lo12:cnt24]
ldp x16,x17,[sp],#16
cbnz x1, Lfn8end
stp x16,x17,[sp,#-16]!
adrp x16, cnt23
ldr x17,[x16,:lo12:cnt23]
add x17,x17,#1
str x17,[x16,:lo12:cnt23]
ldp x16,x17,[sp],#16
str x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt24
ldr x17,[x16,:lo12:cnt24]
add x17,x17,#1
str x17,[x16,:lo12:cnt24]
ldp x16,x17,[sp],#16
adrp x2, Lconstant21
stp x16,x17,[sp,#-16]!
adrp x16, cnt24
ldr x17,[x16,:lo12:cnt24]
add x17,x17,#1
str x17,[x16,:lo12:cnt24]
ldp x16,x17,[sp],#16
add x2, x2, :lo12:Lconstant21
stp x16,x17,[sp,#-16]!
adrp x16, cnt24
ldr x17,[x16,:lo12:cnt24]
add x17,x17,#1
str x17,[x16,:lo12:cnt24]
ldp x16,x17,[sp],#16
mov x1, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt25
ldr x17,[x16,:lo12:cnt25]
add x17,x17,#1
str x17,[x16,:lo12:cnt25]
ldp x16,x17,[sp],#16
bl fen_equal
stp x16,x17,[sp,#-16]!
adrp x16, cnt24
ldr x17,[x16,:lo12:cnt24]
add x17,x17,#1
str x17,[x16,:lo12:cnt24]
ldp x16,x17,[sp],#16
cbz x0, Lfn8if425else
stp x16,x17,[sp,#-16]!
adrp x16, cnt24
ldr x17,[x16,:lo12:cnt24]
add x17,x17,#1
str x17,[x16,:lo12:cnt24]
ldp x16,x17,[sp],#16
movz x0, #1, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt24
ldr x17,[x16,:lo12:cnt24]
add x17,x17,#1
str x17,[x16,:lo12:cnt24]
ldp x16,x17,[sp],#16
b Lfn8if425done
Lfn8if425else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt24
ldr x17,[x16,:lo12:cnt24]
add x17,x17,#1
str x17,[x16,:lo12:cnt24]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
Lfn8if425done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt24
ldr x17,[x16,:lo12:cnt24]
add x17,x17,#1
str x17,[x16,:lo12:cnt24]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt24
ldr x17,[x16,:lo12:cnt24]
add x17,x17,#1
str x17,[x16,:lo12:cnt24]
ldp x16,x17,[sp],#16
b Lfn8end
Lfn8end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt25
ldr x17,[x16,:lo12:cnt25]
add x17,x17,#1
str x17,[x16,:lo12:cnt25]
ldp x16,x17,[sp],#16
bl fen_leave_result
stp x16,x17,[sp,#-16]!
adrp x16, cnt24
ldr x17,[x16,:lo12:cnt24]
add x17,x17,#1
str x17,[x16,:lo12:cnt24]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt23
ldr x17,[x16,:lo12:cnt23]
add x17,x17,#1
str x17,[x16,:lo12:cnt23]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt24
ldr x17,[x16,:lo12:cnt24]
add x17,x17,#1
str x17,[x16,:lo12:cnt24]
ldp x16,x17,[sp],#16
ret
Lfn9:
stp x16,x17,[sp,#-16]!
adrp x16, cnt26
ldr x17,[x16,:lo12:cnt26]
add x17,x17,#1
str x17,[x16,:lo12:cnt26]
ldp x16,x17,[sp],#16
stp x29, x30, [sp, #-16]!
stp x16,x17,[sp,#-16]!
adrp x16, cnt27
ldr x17,[x16,:lo12:cnt27]
add x17,x17,#1
str x17,[x16,:lo12:cnt27]
ldp x16,x17,[sp],#16
mov x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt27
ldr x17,[x16,:lo12:cnt27]
add x17,x17,#1
str x17,[x16,:lo12:cnt27]
ldp x16,x17,[sp],#16
sub sp, sp, #96
stp x16,x17,[sp,#-16]!
adrp x16, cnt26
ldr x17,[x16,:lo12:cnt26]
add x17,x17,#1
str x17,[x16,:lo12:cnt26]
ldp x16,x17,[sp],#16
str xzr, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt26
ldr x17,[x16,:lo12:cnt26]
add x17,x17,#1
str x17,[x16,:lo12:cnt26]
ldp x16,x17,[sp],#16
str x0, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt27
ldr x17,[x16,:lo12:cnt27]
add x17,x17,#1
str x17,[x16,:lo12:cnt27]
ldp x16,x17,[sp],#16
add x0, sp, #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt27
ldr x17,[x16,:lo12:cnt27]
add x17,x17,#1
str x17,[x16,:lo12:cnt27]
ldp x16,x17,[sp],#16
add x1, sp, #48
stp x16,x17,[sp,#-16]!
adrp x16, cnt27
ldr x17,[x16,:lo12:cnt27]
add x17,x17,#1
str x17,[x16,:lo12:cnt27]
ldp x16,x17,[sp],#16
mov x2, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt28
ldr x17,[x16,:lo12:cnt28]
add x17,x17,#1
str x17,[x16,:lo12:cnt28]
ldp x16,x17,[sp],#16
bl fen_enter
stp x16,x17,[sp,#-16]!
adrp x16, cnt27
ldr x17,[x16,:lo12:cnt27]
add x17,x17,#1
str x17,[x16,:lo12:cnt27]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt26
ldr x17,[x16,:lo12:cnt26]
add x17,x17,#1
str x17,[x16,:lo12:cnt26]
ldp x16,x17,[sp],#16
str x0, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt27
ldr x17,[x16,:lo12:cnt27]
add x17,x17,#1
str x17,[x16,:lo12:cnt27]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt26
ldr x17,[x16,:lo12:cnt26]
add x17,x17,#1
str x17,[x16,:lo12:cnt26]
ldp x16,x17,[sp],#16
str x0, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt27
ldr x17,[x16,:lo12:cnt27]
add x17,x17,#1
str x17,[x16,:lo12:cnt27]
ldp x16,x17,[sp],#16
movz x0, #100, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt26
ldr x17,[x16,:lo12:cnt26]
add x17,x17,#1
str x17,[x16,:lo12:cnt26]
ldp x16,x17,[sp],#16
str x0, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt27
ldr x17,[x16,:lo12:cnt27]
add x17,x17,#1
str x17,[x16,:lo12:cnt27]
ldp x16,x17,[sp],#16
adrp x8, Lconstant26
stp x16,x17,[sp,#-16]!
adrp x16, cnt27
ldr x17,[x16,:lo12:cnt27]
add x17,x17,#1
str x17,[x16,:lo12:cnt27]
ldp x16,x17,[sp],#16
add x8, x8, :lo12:Lconstant26
stp x16,x17,[sp,#-16]!
adrp x16, cnt26
ldr x17,[x16,:lo12:cnt26]
add x17,x17,#1
str x17,[x16,:lo12:cnt26]
ldp x16,x17,[sp],#16
ldr x9, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt26
ldr x17,[x16,:lo12:cnt26]
add x17,x17,#1
str x17,[x16,:lo12:cnt26]
ldp x16,x17,[sp],#16
ldr x10, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt26
ldr x17,[x16,:lo12:cnt26]
add x17,x17,#1
str x17,[x16,:lo12:cnt26]
ldp x16,x17,[sp],#16
ldr x11, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt28
ldr x17,[x16,:lo12:cnt28]
add x17,x17,#1
str x17,[x16,:lo12:cnt28]
ldp x16,x17,[sp],#16
bl Lfn6fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt27
ldr x17,[x16,:lo12:cnt27]
add x17,x17,#1
str x17,[x16,:lo12:cnt27]
ldp x16,x17,[sp],#16
cbnz x1, Lfn9end
stp x16,x17,[sp,#-16]!
adrp x16, cnt26
ldr x17,[x16,:lo12:cnt26]
add x17,x17,#1
str x17,[x16,:lo12:cnt26]
ldp x16,x17,[sp],#16
str x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt27
ldr x17,[x16,:lo12:cnt27]
add x17,x17,#1
str x17,[x16,:lo12:cnt27]
ldp x16,x17,[sp],#16
adrp x2, Lconstant28
stp x16,x17,[sp,#-16]!
adrp x16, cnt27
ldr x17,[x16,:lo12:cnt27]
add x17,x17,#1
str x17,[x16,:lo12:cnt27]
ldp x16,x17,[sp],#16
add x2, x2, :lo12:Lconstant28
stp x16,x17,[sp,#-16]!
adrp x16, cnt27
ldr x17,[x16,:lo12:cnt27]
add x17,x17,#1
str x17,[x16,:lo12:cnt27]
ldp x16,x17,[sp],#16
mov x1, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt28
ldr x17,[x16,:lo12:cnt28]
add x17,x17,#1
str x17,[x16,:lo12:cnt28]
ldp x16,x17,[sp],#16
bl fen_equal
stp x16,x17,[sp,#-16]!
adrp x16, cnt27
ldr x17,[x16,:lo12:cnt27]
add x17,x17,#1
str x17,[x16,:lo12:cnt27]
ldp x16,x17,[sp],#16
cbz x0, Lfn9if449else
stp x16,x17,[sp,#-16]!
adrp x16, cnt27
ldr x17,[x16,:lo12:cnt27]
add x17,x17,#1
str x17,[x16,:lo12:cnt27]
ldp x16,x17,[sp],#16
movz x0, #1, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt27
ldr x17,[x16,:lo12:cnt27]
add x17,x17,#1
str x17,[x16,:lo12:cnt27]
ldp x16,x17,[sp],#16
b Lfn9if449done
Lfn9if449else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt27
ldr x17,[x16,:lo12:cnt27]
add x17,x17,#1
str x17,[x16,:lo12:cnt27]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
Lfn9if449done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt27
ldr x17,[x16,:lo12:cnt27]
add x17,x17,#1
str x17,[x16,:lo12:cnt27]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt27
ldr x17,[x16,:lo12:cnt27]
add x17,x17,#1
str x17,[x16,:lo12:cnt27]
ldp x16,x17,[sp],#16
b Lfn9end
Lfn9end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt28
ldr x17,[x16,:lo12:cnt28]
add x17,x17,#1
str x17,[x16,:lo12:cnt28]
ldp x16,x17,[sp],#16
bl fen_leave_result
stp x16,x17,[sp,#-16]!
adrp x16, cnt27
ldr x17,[x16,:lo12:cnt27]
add x17,x17,#1
str x17,[x16,:lo12:cnt27]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt26
ldr x17,[x16,:lo12:cnt26]
add x17,x17,#1
str x17,[x16,:lo12:cnt26]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt27
ldr x17,[x16,:lo12:cnt27]
add x17,x17,#1
str x17,[x16,:lo12:cnt27]
ldp x16,x17,[sp],#16
ret
Lfn10:
stp x16,x17,[sp,#-16]!
adrp x16, cnt29
ldr x17,[x16,:lo12:cnt29]
add x17,x17,#1
str x17,[x16,:lo12:cnt29]
ldp x16,x17,[sp],#16
stp x29, x30, [sp, #-16]!
stp x16,x17,[sp,#-16]!
adrp x16, cnt30
ldr x17,[x16,:lo12:cnt30]
add x17,x17,#1
str x17,[x16,:lo12:cnt30]
ldp x16,x17,[sp],#16
mov x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt30
ldr x17,[x16,:lo12:cnt30]
add x17,x17,#1
str x17,[x16,:lo12:cnt30]
ldp x16,x17,[sp],#16
sub sp, sp, #96
stp x16,x17,[sp,#-16]!
adrp x16, cnt29
ldr x17,[x16,:lo12:cnt29]
add x17,x17,#1
str x17,[x16,:lo12:cnt29]
ldp x16,x17,[sp],#16
str xzr, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt29
ldr x17,[x16,:lo12:cnt29]
add x17,x17,#1
str x17,[x16,:lo12:cnt29]
ldp x16,x17,[sp],#16
str x0, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt30
ldr x17,[x16,:lo12:cnt30]
add x17,x17,#1
str x17,[x16,:lo12:cnt30]
ldp x16,x17,[sp],#16
add x0, sp, #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt30
ldr x17,[x16,:lo12:cnt30]
add x17,x17,#1
str x17,[x16,:lo12:cnt30]
ldp x16,x17,[sp],#16
add x1, sp, #48
stp x16,x17,[sp,#-16]!
adrp x16, cnt30
ldr x17,[x16,:lo12:cnt30]
add x17,x17,#1
str x17,[x16,:lo12:cnt30]
ldp x16,x17,[sp],#16
mov x2, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt31
ldr x17,[x16,:lo12:cnt31]
add x17,x17,#1
str x17,[x16,:lo12:cnt31]
ldp x16,x17,[sp],#16
bl fen_enter
stp x16,x17,[sp,#-16]!
adrp x16, cnt30
ldr x17,[x16,:lo12:cnt30]
add x17,x17,#1
str x17,[x16,:lo12:cnt30]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt29
ldr x17,[x16,:lo12:cnt29]
add x17,x17,#1
str x17,[x16,:lo12:cnt29]
ldp x16,x17,[sp],#16
str x0, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt30
ldr x17,[x16,:lo12:cnt30]
add x17,x17,#1
str x17,[x16,:lo12:cnt30]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt29
ldr x17,[x16,:lo12:cnt29]
add x17,x17,#1
str x17,[x16,:lo12:cnt29]
ldp x16,x17,[sp],#16
str x0, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt30
ldr x17,[x16,:lo12:cnt30]
add x17,x17,#1
str x17,[x16,:lo12:cnt30]
ldp x16,x17,[sp],#16
movz x0, #100, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt29
ldr x17,[x16,:lo12:cnt29]
add x17,x17,#1
str x17,[x16,:lo12:cnt29]
ldp x16,x17,[sp],#16
str x0, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt30
ldr x17,[x16,:lo12:cnt30]
add x17,x17,#1
str x17,[x16,:lo12:cnt30]
ldp x16,x17,[sp],#16
adrp x8, Lconstant36
stp x16,x17,[sp,#-16]!
adrp x16, cnt30
ldr x17,[x16,:lo12:cnt30]
add x17,x17,#1
str x17,[x16,:lo12:cnt30]
ldp x16,x17,[sp],#16
add x8, x8, :lo12:Lconstant36
stp x16,x17,[sp,#-16]!
adrp x16, cnt29
ldr x17,[x16,:lo12:cnt29]
add x17,x17,#1
str x17,[x16,:lo12:cnt29]
ldp x16,x17,[sp],#16
ldr x9, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt29
ldr x17,[x16,:lo12:cnt29]
add x17,x17,#1
str x17,[x16,:lo12:cnt29]
ldp x16,x17,[sp],#16
ldr x10, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt29
ldr x17,[x16,:lo12:cnt29]
add x17,x17,#1
str x17,[x16,:lo12:cnt29]
ldp x16,x17,[sp],#16
ldr x11, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt31
ldr x17,[x16,:lo12:cnt31]
add x17,x17,#1
str x17,[x16,:lo12:cnt31]
ldp x16,x17,[sp],#16
bl Lfn6fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt30
ldr x17,[x16,:lo12:cnt30]
add x17,x17,#1
str x17,[x16,:lo12:cnt30]
ldp x16,x17,[sp],#16
cbnz x1, Lfn10end
stp x16,x17,[sp,#-16]!
adrp x16, cnt29
ldr x17,[x16,:lo12:cnt29]
add x17,x17,#1
str x17,[x16,:lo12:cnt29]
ldp x16,x17,[sp],#16
str x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt30
ldr x17,[x16,:lo12:cnt30]
add x17,x17,#1
str x17,[x16,:lo12:cnt30]
ldp x16,x17,[sp],#16
adrp x2, Lconstant38
stp x16,x17,[sp,#-16]!
adrp x16, cnt30
ldr x17,[x16,:lo12:cnt30]
add x17,x17,#1
str x17,[x16,:lo12:cnt30]
ldp x16,x17,[sp],#16
add x2, x2, :lo12:Lconstant38
stp x16,x17,[sp,#-16]!
adrp x16, cnt30
ldr x17,[x16,:lo12:cnt30]
add x17,x17,#1
str x17,[x16,:lo12:cnt30]
ldp x16,x17,[sp],#16
mov x1, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt31
ldr x17,[x16,:lo12:cnt31]
add x17,x17,#1
str x17,[x16,:lo12:cnt31]
ldp x16,x17,[sp],#16
bl fen_equal
stp x16,x17,[sp,#-16]!
adrp x16, cnt30
ldr x17,[x16,:lo12:cnt30]
add x17,x17,#1
str x17,[x16,:lo12:cnt30]
ldp x16,x17,[sp],#16
cbz x0, Lfn10if480else
stp x16,x17,[sp,#-16]!
adrp x16, cnt30
ldr x17,[x16,:lo12:cnt30]
add x17,x17,#1
str x17,[x16,:lo12:cnt30]
ldp x16,x17,[sp],#16
movz x0, #1, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt30
ldr x17,[x16,:lo12:cnt30]
add x17,x17,#1
str x17,[x16,:lo12:cnt30]
ldp x16,x17,[sp],#16
b Lfn10if480done
Lfn10if480else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt30
ldr x17,[x16,:lo12:cnt30]
add x17,x17,#1
str x17,[x16,:lo12:cnt30]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
Lfn10if480done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt30
ldr x17,[x16,:lo12:cnt30]
add x17,x17,#1
str x17,[x16,:lo12:cnt30]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt30
ldr x17,[x16,:lo12:cnt30]
add x17,x17,#1
str x17,[x16,:lo12:cnt30]
ldp x16,x17,[sp],#16
b Lfn10end
Lfn10end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt31
ldr x17,[x16,:lo12:cnt31]
add x17,x17,#1
str x17,[x16,:lo12:cnt31]
ldp x16,x17,[sp],#16
bl fen_leave_result
stp x16,x17,[sp,#-16]!
adrp x16, cnt30
ldr x17,[x16,:lo12:cnt30]
add x17,x17,#1
str x17,[x16,:lo12:cnt30]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt29
ldr x17,[x16,:lo12:cnt29]
add x17,x17,#1
str x17,[x16,:lo12:cnt29]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt30
ldr x17,[x16,:lo12:cnt30]
add x17,x17,#1
str x17,[x16,:lo12:cnt30]
ldp x16,x17,[sp],#16
ret
Lfn11:
stp x16,x17,[sp,#-16]!
adrp x16, cnt32
ldr x17,[x16,:lo12:cnt32]
add x17,x17,#1
str x17,[x16,:lo12:cnt32]
ldp x16,x17,[sp],#16
stp x29, x30, [sp, #-16]!
stp x16,x17,[sp,#-16]!
adrp x16, cnt33
ldr x17,[x16,:lo12:cnt33]
add x17,x17,#1
str x17,[x16,:lo12:cnt33]
ldp x16,x17,[sp],#16
mov x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt33
ldr x17,[x16,:lo12:cnt33]
add x17,x17,#1
str x17,[x16,:lo12:cnt33]
ldp x16,x17,[sp],#16
sub sp, sp, #96
stp x16,x17,[sp,#-16]!
adrp x16, cnt32
ldr x17,[x16,:lo12:cnt32]
add x17,x17,#1
str x17,[x16,:lo12:cnt32]
ldp x16,x17,[sp],#16
str xzr, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt32
ldr x17,[x16,:lo12:cnt32]
add x17,x17,#1
str x17,[x16,:lo12:cnt32]
ldp x16,x17,[sp],#16
str x0, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt33
ldr x17,[x16,:lo12:cnt33]
add x17,x17,#1
str x17,[x16,:lo12:cnt33]
ldp x16,x17,[sp],#16
add x0, sp, #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt33
ldr x17,[x16,:lo12:cnt33]
add x17,x17,#1
str x17,[x16,:lo12:cnt33]
ldp x16,x17,[sp],#16
add x1, sp, #48
stp x16,x17,[sp,#-16]!
adrp x16, cnt33
ldr x17,[x16,:lo12:cnt33]
add x17,x17,#1
str x17,[x16,:lo12:cnt33]
ldp x16,x17,[sp],#16
mov x2, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt34
ldr x17,[x16,:lo12:cnt34]
add x17,x17,#1
str x17,[x16,:lo12:cnt34]
ldp x16,x17,[sp],#16
bl fen_enter
stp x16,x17,[sp,#-16]!
adrp x16, cnt33
ldr x17,[x16,:lo12:cnt33]
add x17,x17,#1
str x17,[x16,:lo12:cnt33]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt32
ldr x17,[x16,:lo12:cnt32]
add x17,x17,#1
str x17,[x16,:lo12:cnt32]
ldp x16,x17,[sp],#16
str x0, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt33
ldr x17,[x16,:lo12:cnt33]
add x17,x17,#1
str x17,[x16,:lo12:cnt33]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt32
ldr x17,[x16,:lo12:cnt32]
add x17,x17,#1
str x17,[x16,:lo12:cnt32]
ldp x16,x17,[sp],#16
str x0, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt33
ldr x17,[x16,:lo12:cnt33]
add x17,x17,#1
str x17,[x16,:lo12:cnt33]
ldp x16,x17,[sp],#16
movz x0, #200, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt32
ldr x17,[x16,:lo12:cnt32]
add x17,x17,#1
str x17,[x16,:lo12:cnt32]
ldp x16,x17,[sp],#16
str x0, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt33
ldr x17,[x16,:lo12:cnt33]
add x17,x17,#1
str x17,[x16,:lo12:cnt33]
ldp x16,x17,[sp],#16
adrp x8, Lconstant43
stp x16,x17,[sp,#-16]!
adrp x16, cnt33
ldr x17,[x16,:lo12:cnt33]
add x17,x17,#1
str x17,[x16,:lo12:cnt33]
ldp x16,x17,[sp],#16
add x8, x8, :lo12:Lconstant43
stp x16,x17,[sp,#-16]!
adrp x16, cnt32
ldr x17,[x16,:lo12:cnt32]
add x17,x17,#1
str x17,[x16,:lo12:cnt32]
ldp x16,x17,[sp],#16
ldr x9, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt32
ldr x17,[x16,:lo12:cnt32]
add x17,x17,#1
str x17,[x16,:lo12:cnt32]
ldp x16,x17,[sp],#16
ldr x10, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt32
ldr x17,[x16,:lo12:cnt32]
add x17,x17,#1
str x17,[x16,:lo12:cnt32]
ldp x16,x17,[sp],#16
ldr x11, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt34
ldr x17,[x16,:lo12:cnt34]
add x17,x17,#1
str x17,[x16,:lo12:cnt34]
ldp x16,x17,[sp],#16
bl Lfn6fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt33
ldr x17,[x16,:lo12:cnt33]
add x17,x17,#1
str x17,[x16,:lo12:cnt33]
ldp x16,x17,[sp],#16
cbnz x1, Lfn11end
stp x16,x17,[sp,#-16]!
adrp x16, cnt32
ldr x17,[x16,:lo12:cnt32]
add x17,x17,#1
str x17,[x16,:lo12:cnt32]
ldp x16,x17,[sp],#16
str x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt33
ldr x17,[x16,:lo12:cnt33]
add x17,x17,#1
str x17,[x16,:lo12:cnt33]
ldp x16,x17,[sp],#16
adrp x2, Lconstant45
stp x16,x17,[sp,#-16]!
adrp x16, cnt33
ldr x17,[x16,:lo12:cnt33]
add x17,x17,#1
str x17,[x16,:lo12:cnt33]
ldp x16,x17,[sp],#16
add x2, x2, :lo12:Lconstant45
stp x16,x17,[sp,#-16]!
adrp x16, cnt33
ldr x17,[x16,:lo12:cnt33]
add x17,x17,#1
str x17,[x16,:lo12:cnt33]
ldp x16,x17,[sp],#16
mov x1, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt34
ldr x17,[x16,:lo12:cnt34]
add x17,x17,#1
str x17,[x16,:lo12:cnt34]
ldp x16,x17,[sp],#16
bl fen_equal
stp x16,x17,[sp,#-16]!
adrp x16, cnt33
ldr x17,[x16,:lo12:cnt33]
add x17,x17,#1
str x17,[x16,:lo12:cnt33]
ldp x16,x17,[sp],#16
cbz x0, Lfn11if523else
stp x16,x17,[sp,#-16]!
adrp x16, cnt33
ldr x17,[x16,:lo12:cnt33]
add x17,x17,#1
str x17,[x16,:lo12:cnt33]
ldp x16,x17,[sp],#16
movz x0, #1, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt33
ldr x17,[x16,:lo12:cnt33]
add x17,x17,#1
str x17,[x16,:lo12:cnt33]
ldp x16,x17,[sp],#16
b Lfn11if523done
Lfn11if523else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt33
ldr x17,[x16,:lo12:cnt33]
add x17,x17,#1
str x17,[x16,:lo12:cnt33]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
Lfn11if523done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt33
ldr x17,[x16,:lo12:cnt33]
add x17,x17,#1
str x17,[x16,:lo12:cnt33]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt33
ldr x17,[x16,:lo12:cnt33]
add x17,x17,#1
str x17,[x16,:lo12:cnt33]
ldp x16,x17,[sp],#16
b Lfn11end
Lfn11end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt34
ldr x17,[x16,:lo12:cnt34]
add x17,x17,#1
str x17,[x16,:lo12:cnt34]
ldp x16,x17,[sp],#16
bl fen_leave_result
stp x16,x17,[sp,#-16]!
adrp x16, cnt33
ldr x17,[x16,:lo12:cnt33]
add x17,x17,#1
str x17,[x16,:lo12:cnt33]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt32
ldr x17,[x16,:lo12:cnt32]
add x17,x17,#1
str x17,[x16,:lo12:cnt32]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt33
ldr x17,[x16,:lo12:cnt33]
add x17,x17,#1
str x17,[x16,:lo12:cnt33]
ldp x16,x17,[sp],#16
ret
Lfn12:
stp x16,x17,[sp,#-16]!
adrp x16, cnt35
ldr x17,[x16,:lo12:cnt35]
add x17,x17,#1
str x17,[x16,:lo12:cnt35]
ldp x16,x17,[sp],#16
stp x29, x30, [sp, #-16]!
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
mov x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
sub sp, sp, #96
stp x16,x17,[sp,#-16]!
adrp x16, cnt35
ldr x17,[x16,:lo12:cnt35]
add x17,x17,#1
str x17,[x16,:lo12:cnt35]
ldp x16,x17,[sp],#16
str xzr, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt35
ldr x17,[x16,:lo12:cnt35]
add x17,x17,#1
str x17,[x16,:lo12:cnt35]
ldp x16,x17,[sp],#16
str x0, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
add x0, sp, #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
add x1, sp, #48
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
mov x2, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
bl fen_enter
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt35
ldr x17,[x16,:lo12:cnt35]
add x17,x17,#1
str x17,[x16,:lo12:cnt35]
ldp x16,x17,[sp],#16
str x0, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt35
ldr x17,[x16,:lo12:cnt35]
add x17,x17,#1
str x17,[x16,:lo12:cnt35]
ldp x16,x17,[sp],#16
str x0, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
movz x0, #200, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt35
ldr x17,[x16,:lo12:cnt35]
add x17,x17,#1
str x17,[x16,:lo12:cnt35]
ldp x16,x17,[sp],#16
str x0, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
adrp x8, Lconstant48
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
add x8, x8, :lo12:Lconstant48
stp x16,x17,[sp,#-16]!
adrp x16, cnt35
ldr x17,[x16,:lo12:cnt35]
add x17,x17,#1
str x17,[x16,:lo12:cnt35]
ldp x16,x17,[sp],#16
ldr x9, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt35
ldr x17,[x16,:lo12:cnt35]
add x17,x17,#1
str x17,[x16,:lo12:cnt35]
ldp x16,x17,[sp],#16
ldr x10, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt35
ldr x17,[x16,:lo12:cnt35]
add x17,x17,#1
str x17,[x16,:lo12:cnt35]
ldp x16,x17,[sp],#16
ldr x11, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
bl Lfn6fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
cbnz x1, Lfn12end
stp x16,x17,[sp,#-16]!
adrp x16, cnt35
ldr x17,[x16,:lo12:cnt35]
add x17,x17,#1
str x17,[x16,:lo12:cnt35]
ldp x16,x17,[sp],#16
str x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
adrp x2, Lconstant50
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
add x2, x2, :lo12:Lconstant50
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
mov x1, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
bl fen_equal
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
cbz x0, Lfn12if562else
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
movz x0, #1, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
b Lfn12if562done
Lfn12if562else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
Lfn12if562done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
b Lfn12end
Lfn12end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
bl fen_leave_result
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt35
ldr x17,[x16,:lo12:cnt35]
add x17,x17,#1
str x17,[x16,:lo12:cnt35]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
ret
Lfn13:
stp x16,x17,[sp,#-16]!
adrp x16, cnt38
ldr x17,[x16,:lo12:cnt38]
add x17,x17,#1
str x17,[x16,:lo12:cnt38]
ldp x16,x17,[sp],#16
stp x29, x30, [sp, #-16]!
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
mov x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
sub sp, sp, #96
stp x16,x17,[sp,#-16]!
adrp x16, cnt38
ldr x17,[x16,:lo12:cnt38]
add x17,x17,#1
str x17,[x16,:lo12:cnt38]
ldp x16,x17,[sp],#16
str xzr, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt38
ldr x17,[x16,:lo12:cnt38]
add x17,x17,#1
str x17,[x16,:lo12:cnt38]
ldp x16,x17,[sp],#16
str x0, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
add x0, sp, #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
add x1, sp, #48
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
mov x2, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt40
ldr x17,[x16,:lo12:cnt40]
add x17,x17,#1
str x17,[x16,:lo12:cnt40]
ldp x16,x17,[sp],#16
bl fen_enter
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt38
ldr x17,[x16,:lo12:cnt38]
add x17,x17,#1
str x17,[x16,:lo12:cnt38]
ldp x16,x17,[sp],#16
str x0, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt38
ldr x17,[x16,:lo12:cnt38]
add x17,x17,#1
str x17,[x16,:lo12:cnt38]
ldp x16,x17,[sp],#16
str x0, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
movz x0, #100, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt38
ldr x17,[x16,:lo12:cnt38]
add x17,x17,#1
str x17,[x16,:lo12:cnt38]
ldp x16,x17,[sp],#16
str x0, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
adrp x8, Lconstant51
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
add x8, x8, :lo12:Lconstant51
stp x16,x17,[sp,#-16]!
adrp x16, cnt38
ldr x17,[x16,:lo12:cnt38]
add x17,x17,#1
str x17,[x16,:lo12:cnt38]
ldp x16,x17,[sp],#16
ldr x9, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt38
ldr x17,[x16,:lo12:cnt38]
add x17,x17,#1
str x17,[x16,:lo12:cnt38]
ldp x16,x17,[sp],#16
ldr x10, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt38
ldr x17,[x16,:lo12:cnt38]
add x17,x17,#1
str x17,[x16,:lo12:cnt38]
ldp x16,x17,[sp],#16
ldr x11, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt40
ldr x17,[x16,:lo12:cnt40]
add x17,x17,#1
str x17,[x16,:lo12:cnt40]
ldp x16,x17,[sp],#16
bl Lfn6fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
cbnz x1, Lfn13end
stp x16,x17,[sp,#-16]!
adrp x16, cnt38
ldr x17,[x16,:lo12:cnt38]
add x17,x17,#1
str x17,[x16,:lo12:cnt38]
ldp x16,x17,[sp],#16
str x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
adrp x2, Lconstant52
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
add x2, x2, :lo12:Lconstant52
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
mov x1, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt40
ldr x17,[x16,:lo12:cnt40]
add x17,x17,#1
str x17,[x16,:lo12:cnt40]
ldp x16,x17,[sp],#16
bl fen_equal
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
cbz x0, Lfn13if593else
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
movz x0, #1, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
b Lfn13if593done
Lfn13if593else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
Lfn13if593done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
b Lfn13end
Lfn13end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt40
ldr x17,[x16,:lo12:cnt40]
add x17,x17,#1
str x17,[x16,:lo12:cnt40]
ldp x16,x17,[sp],#16
bl fen_leave_result
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt38
ldr x17,[x16,:lo12:cnt38]
add x17,x17,#1
str x17,[x16,:lo12:cnt38]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
ret
Lfn14:
stp x16,x17,[sp,#-16]!
adrp x16, cnt41
ldr x17,[x16,:lo12:cnt41]
add x17,x17,#1
str x17,[x16,:lo12:cnt41]
ldp x16,x17,[sp],#16
stp x29, x30, [sp, #-16]!
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
mov x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
sub sp, sp, #96
stp x16,x17,[sp,#-16]!
adrp x16, cnt41
ldr x17,[x16,:lo12:cnt41]
add x17,x17,#1
str x17,[x16,:lo12:cnt41]
ldp x16,x17,[sp],#16
str xzr, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt41
ldr x17,[x16,:lo12:cnt41]
add x17,x17,#1
str x17,[x16,:lo12:cnt41]
ldp x16,x17,[sp],#16
str x0, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
add x0, sp, #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
add x1, sp, #48
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
mov x2, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
bl fen_enter
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt41
ldr x17,[x16,:lo12:cnt41]
add x17,x17,#1
str x17,[x16,:lo12:cnt41]
ldp x16,x17,[sp],#16
str x0, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt41
ldr x17,[x16,:lo12:cnt41]
add x17,x17,#1
str x17,[x16,:lo12:cnt41]
ldp x16,x17,[sp],#16
str x0, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
movz x0, #100, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt41
ldr x17,[x16,:lo12:cnt41]
add x17,x17,#1
str x17,[x16,:lo12:cnt41]
ldp x16,x17,[sp],#16
str x0, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
adrp x8, Lconstant55
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
add x8, x8, :lo12:Lconstant55
stp x16,x17,[sp,#-16]!
adrp x16, cnt41
ldr x17,[x16,:lo12:cnt41]
add x17,x17,#1
str x17,[x16,:lo12:cnt41]
ldp x16,x17,[sp],#16
ldr x9, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt41
ldr x17,[x16,:lo12:cnt41]
add x17,x17,#1
str x17,[x16,:lo12:cnt41]
ldp x16,x17,[sp],#16
ldr x10, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt41
ldr x17,[x16,:lo12:cnt41]
add x17,x17,#1
str x17,[x16,:lo12:cnt41]
ldp x16,x17,[sp],#16
ldr x11, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
bl Lfn6fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
cbnz x1, Lfn14end
stp x16,x17,[sp,#-16]!
adrp x16, cnt41
ldr x17,[x16,:lo12:cnt41]
add x17,x17,#1
str x17,[x16,:lo12:cnt41]
ldp x16,x17,[sp],#16
str x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
adrp x2, Lconstant56
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
add x2, x2, :lo12:Lconstant56
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
mov x1, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
bl fen_equal
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
cbz x0, Lfn14if616else
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
movz x0, #1, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
b Lfn14if616done
Lfn14if616else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
Lfn14if616done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
b Lfn14end
Lfn14end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
bl fen_leave_result
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt41
ldr x17,[x16,:lo12:cnt41]
add x17,x17,#1
str x17,[x16,:lo12:cnt41]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ret
Lfn15:
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
stp x29, x30, [sp, #-16]!
stp x16,x17,[sp,#-16]!
adrp x16, cnt45
ldr x17,[x16,:lo12:cnt45]
add x17,x17,#1
str x17,[x16,:lo12:cnt45]
ldp x16,x17,[sp],#16
mov x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt45
ldr x17,[x16,:lo12:cnt45]
add x17,x17,#1
str x17,[x16,:lo12:cnt45]
ldp x16,x17,[sp],#16
sub sp, sp, #96
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
str xzr, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
str x0, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt45
ldr x17,[x16,:lo12:cnt45]
add x17,x17,#1
str x17,[x16,:lo12:cnt45]
ldp x16,x17,[sp],#16
add x0, sp, #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt45
ldr x17,[x16,:lo12:cnt45]
add x17,x17,#1
str x17,[x16,:lo12:cnt45]
ldp x16,x17,[sp],#16
add x1, sp, #48
stp x16,x17,[sp,#-16]!
adrp x16, cnt45
ldr x17,[x16,:lo12:cnt45]
add x17,x17,#1
str x17,[x16,:lo12:cnt45]
ldp x16,x17,[sp],#16
mov x2, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt46
ldr x17,[x16,:lo12:cnt46]
add x17,x17,#1
str x17,[x16,:lo12:cnt46]
ldp x16,x17,[sp],#16
bl fen_enter
stp x16,x17,[sp,#-16]!
adrp x16, cnt45
ldr x17,[x16,:lo12:cnt45]
add x17,x17,#1
str x17,[x16,:lo12:cnt45]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
str x0, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt45
ldr x17,[x16,:lo12:cnt45]
add x17,x17,#1
str x17,[x16,:lo12:cnt45]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
str x0, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt45
ldr x17,[x16,:lo12:cnt45]
add x17,x17,#1
str x17,[x16,:lo12:cnt45]
ldp x16,x17,[sp],#16
movz x0, #3, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
str x0, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt45
ldr x17,[x16,:lo12:cnt45]
add x17,x17,#1
str x17,[x16,:lo12:cnt45]
ldp x16,x17,[sp],#16
adrp x8, Lconstant36
stp x16,x17,[sp,#-16]!
adrp x16, cnt45
ldr x17,[x16,:lo12:cnt45]
add x17,x17,#1
str x17,[x16,:lo12:cnt45]
ldp x16,x17,[sp],#16
add x8, x8, :lo12:Lconstant36
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
ldr x9, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
ldr x10, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
ldr x11, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt46
ldr x17,[x16,:lo12:cnt46]
add x17,x17,#1
str x17,[x16,:lo12:cnt46]
ldp x16,x17,[sp],#16
bl Lfn6fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt45
ldr x17,[x16,:lo12:cnt45]
add x17,x17,#1
str x17,[x16,:lo12:cnt45]
ldp x16,x17,[sp],#16
cbnz x1, Lfn15end
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
str x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt45
ldr x17,[x16,:lo12:cnt45]
add x17,x17,#1
str x17,[x16,:lo12:cnt45]
ldp x16,x17,[sp],#16
adrp x2, Lconstant9
stp x16,x17,[sp,#-16]!
adrp x16, cnt45
ldr x17,[x16,:lo12:cnt45]
add x17,x17,#1
str x17,[x16,:lo12:cnt45]
ldp x16,x17,[sp],#16
add x2, x2, :lo12:Lconstant9
stp x16,x17,[sp,#-16]!
adrp x16, cnt45
ldr x17,[x16,:lo12:cnt45]
add x17,x17,#1
str x17,[x16,:lo12:cnt45]
ldp x16,x17,[sp],#16
mov x1, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt46
ldr x17,[x16,:lo12:cnt46]
add x17,x17,#1
str x17,[x16,:lo12:cnt46]
ldp x16,x17,[sp],#16
bl fen_equal
stp x16,x17,[sp,#-16]!
adrp x16, cnt45
ldr x17,[x16,:lo12:cnt45]
add x17,x17,#1
str x17,[x16,:lo12:cnt45]
ldp x16,x17,[sp],#16
cbz x0, Lfn15if647else
stp x16,x17,[sp,#-16]!
adrp x16, cnt45
ldr x17,[x16,:lo12:cnt45]
add x17,x17,#1
str x17,[x16,:lo12:cnt45]
ldp x16,x17,[sp],#16
movz x0, #1, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt45
ldr x17,[x16,:lo12:cnt45]
add x17,x17,#1
str x17,[x16,:lo12:cnt45]
ldp x16,x17,[sp],#16
b Lfn15if647done
Lfn15if647else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt45
ldr x17,[x16,:lo12:cnt45]
add x17,x17,#1
str x17,[x16,:lo12:cnt45]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
Lfn15if647done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt45
ldr x17,[x16,:lo12:cnt45]
add x17,x17,#1
str x17,[x16,:lo12:cnt45]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt45
ldr x17,[x16,:lo12:cnt45]
add x17,x17,#1
str x17,[x16,:lo12:cnt45]
ldp x16,x17,[sp],#16
b Lfn15end
Lfn15end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt46
ldr x17,[x16,:lo12:cnt46]
add x17,x17,#1
str x17,[x16,:lo12:cnt46]
ldp x16,x17,[sp],#16
bl fen_leave_result
stp x16,x17,[sp,#-16]!
adrp x16, cnt45
ldr x17,[x16,:lo12:cnt45]
add x17,x17,#1
str x17,[x16,:lo12:cnt45]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt45
ldr x17,[x16,:lo12:cnt45]
add x17,x17,#1
str x17,[x16,:lo12:cnt45]
ldp x16,x17,[sp],#16
ret
Lfn16:
stp x16,x17,[sp,#-16]!
adrp x16, cnt47
ldr x17,[x16,:lo12:cnt47]
add x17,x17,#1
str x17,[x16,:lo12:cnt47]
ldp x16,x17,[sp],#16
stp x29, x30, [sp, #-16]!
stp x16,x17,[sp,#-16]!
adrp x16, cnt48
ldr x17,[x16,:lo12:cnt48]
add x17,x17,#1
str x17,[x16,:lo12:cnt48]
ldp x16,x17,[sp],#16
mov x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt48
ldr x17,[x16,:lo12:cnt48]
add x17,x17,#1
str x17,[x16,:lo12:cnt48]
ldp x16,x17,[sp],#16
sub sp, sp, #96
stp x16,x17,[sp,#-16]!
adrp x16, cnt47
ldr x17,[x16,:lo12:cnt47]
add x17,x17,#1
str x17,[x16,:lo12:cnt47]
ldp x16,x17,[sp],#16
str xzr, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt47
ldr x17,[x16,:lo12:cnt47]
add x17,x17,#1
str x17,[x16,:lo12:cnt47]
ldp x16,x17,[sp],#16
str x0, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt48
ldr x17,[x16,:lo12:cnt48]
add x17,x17,#1
str x17,[x16,:lo12:cnt48]
ldp x16,x17,[sp],#16
add x0, sp, #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt48
ldr x17,[x16,:lo12:cnt48]
add x17,x17,#1
str x17,[x16,:lo12:cnt48]
ldp x16,x17,[sp],#16
add x1, sp, #48
stp x16,x17,[sp,#-16]!
adrp x16, cnt48
ldr x17,[x16,:lo12:cnt48]
add x17,x17,#1
str x17,[x16,:lo12:cnt48]
ldp x16,x17,[sp],#16
mov x2, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt49
ldr x17,[x16,:lo12:cnt49]
add x17,x17,#1
str x17,[x16,:lo12:cnt49]
ldp x16,x17,[sp],#16
bl fen_enter
stp x16,x17,[sp,#-16]!
adrp x16, cnt48
ldr x17,[x16,:lo12:cnt48]
add x17,x17,#1
str x17,[x16,:lo12:cnt48]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt47
ldr x17,[x16,:lo12:cnt47]
add x17,x17,#1
str x17,[x16,:lo12:cnt47]
ldp x16,x17,[sp],#16
str x0, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt48
ldr x17,[x16,:lo12:cnt48]
add x17,x17,#1
str x17,[x16,:lo12:cnt48]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt47
ldr x17,[x16,:lo12:cnt47]
add x17,x17,#1
str x17,[x16,:lo12:cnt47]
ldp x16,x17,[sp],#16
str x0, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt48
ldr x17,[x16,:lo12:cnt48]
add x17,x17,#1
str x17,[x16,:lo12:cnt48]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt47
ldr x17,[x16,:lo12:cnt47]
add x17,x17,#1
str x17,[x16,:lo12:cnt47]
ldp x16,x17,[sp],#16
str x0, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt48
ldr x17,[x16,:lo12:cnt48]
add x17,x17,#1
str x17,[x16,:lo12:cnt48]
ldp x16,x17,[sp],#16
adrp x8, Lconstant57
stp x16,x17,[sp,#-16]!
adrp x16, cnt48
ldr x17,[x16,:lo12:cnt48]
add x17,x17,#1
str x17,[x16,:lo12:cnt48]
ldp x16,x17,[sp],#16
add x8, x8, :lo12:Lconstant57
stp x16,x17,[sp,#-16]!
adrp x16, cnt47
ldr x17,[x16,:lo12:cnt47]
add x17,x17,#1
str x17,[x16,:lo12:cnt47]
ldp x16,x17,[sp],#16
ldr x9, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt47
ldr x17,[x16,:lo12:cnt47]
add x17,x17,#1
str x17,[x16,:lo12:cnt47]
ldp x16,x17,[sp],#16
ldr x10, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt47
ldr x17,[x16,:lo12:cnt47]
add x17,x17,#1
str x17,[x16,:lo12:cnt47]
ldp x16,x17,[sp],#16
ldr x11, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt49
ldr x17,[x16,:lo12:cnt49]
add x17,x17,#1
str x17,[x16,:lo12:cnt49]
ldp x16,x17,[sp],#16
bl Lfn6fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt48
ldr x17,[x16,:lo12:cnt48]
add x17,x17,#1
str x17,[x16,:lo12:cnt48]
ldp x16,x17,[sp],#16
cbnz x1, Lfn16end
stp x16,x17,[sp,#-16]!
adrp x16, cnt47
ldr x17,[x16,:lo12:cnt47]
add x17,x17,#1
str x17,[x16,:lo12:cnt47]
ldp x16,x17,[sp],#16
str x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt48
ldr x17,[x16,:lo12:cnt48]
add x17,x17,#1
str x17,[x16,:lo12:cnt48]
ldp x16,x17,[sp],#16
adrp x2, Lconstant9
stp x16,x17,[sp,#-16]!
adrp x16, cnt48
ldr x17,[x16,:lo12:cnt48]
add x17,x17,#1
str x17,[x16,:lo12:cnt48]
ldp x16,x17,[sp],#16
add x2, x2, :lo12:Lconstant9
stp x16,x17,[sp,#-16]!
adrp x16, cnt48
ldr x17,[x16,:lo12:cnt48]
add x17,x17,#1
str x17,[x16,:lo12:cnt48]
ldp x16,x17,[sp],#16
mov x1, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt49
ldr x17,[x16,:lo12:cnt49]
add x17,x17,#1
str x17,[x16,:lo12:cnt49]
ldp x16,x17,[sp],#16
bl fen_equal
stp x16,x17,[sp,#-16]!
adrp x16, cnt48
ldr x17,[x16,:lo12:cnt48]
add x17,x17,#1
str x17,[x16,:lo12:cnt48]
ldp x16,x17,[sp],#16
cbz x0, Lfn16if688else
stp x16,x17,[sp,#-16]!
adrp x16, cnt48
ldr x17,[x16,:lo12:cnt48]
add x17,x17,#1
str x17,[x16,:lo12:cnt48]
ldp x16,x17,[sp],#16
movz x0, #1, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt48
ldr x17,[x16,:lo12:cnt48]
add x17,x17,#1
str x17,[x16,:lo12:cnt48]
ldp x16,x17,[sp],#16
b Lfn16if688done
Lfn16if688else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt48
ldr x17,[x16,:lo12:cnt48]
add x17,x17,#1
str x17,[x16,:lo12:cnt48]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
Lfn16if688done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt48
ldr x17,[x16,:lo12:cnt48]
add x17,x17,#1
str x17,[x16,:lo12:cnt48]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt48
ldr x17,[x16,:lo12:cnt48]
add x17,x17,#1
str x17,[x16,:lo12:cnt48]
ldp x16,x17,[sp],#16
b Lfn16end
Lfn16end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt49
ldr x17,[x16,:lo12:cnt49]
add x17,x17,#1
str x17,[x16,:lo12:cnt49]
ldp x16,x17,[sp],#16
bl fen_leave_result
stp x16,x17,[sp,#-16]!
adrp x16, cnt48
ldr x17,[x16,:lo12:cnt48]
add x17,x17,#1
str x17,[x16,:lo12:cnt48]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt47
ldr x17,[x16,:lo12:cnt47]
add x17,x17,#1
str x17,[x16,:lo12:cnt47]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt48
ldr x17,[x16,:lo12:cnt48]
add x17,x17,#1
str x17,[x16,:lo12:cnt48]
ldp x16,x17,[sp],#16
ret
Lfn17:
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
stp x29, x30, [sp, #-16]!
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
mov x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
sub sp, sp, #224
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
str x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
str x0, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt52
ldr x17,[x16,:lo12:cnt52]
add x17,x17,#1
str x17,[x16,:lo12:cnt52]
ldp x16,x17,[sp],#16
bl Lfn7
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
cbnz x1, Lfn17end
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
str x0, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
ldr x0, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
ldr x2, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
b.vs Lfn17fail714_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
str x0, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt52
ldr x17,[x16,:lo12:cnt52]
add x17,x17,#1
str x17,[x16,:lo12:cnt52]
ldp x16,x17,[sp],#16
bl Lfn8
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
cbnz x1, Lfn17end
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
str x0, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
ldr x0, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
ldr x2, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
b.vs Lfn17fail713_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
str x0, [sp, #88]
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt52
ldr x17,[x16,:lo12:cnt52]
add x17,x17,#1
str x17,[x16,:lo12:cnt52]
ldp x16,x17,[sp],#16
bl Lfn9
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
cbnz x1, Lfn17end
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
str x0, [sp, #96]
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
ldr x0, [sp, #88]
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
ldr x2, [sp, #96]
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
b.vs Lfn17fail712_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
str x0, [sp, #104]
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt52
ldr x17,[x16,:lo12:cnt52]
add x17,x17,#1
str x17,[x16,:lo12:cnt52]
ldp x16,x17,[sp],#16
bl Lfn10
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
cbnz x1, Lfn17end
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
str x0, [sp, #112]
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
ldr x0, [sp, #104]
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
ldr x2, [sp, #112]
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
b.vs Lfn17fail711_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
str x0, [sp, #120]
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt52
ldr x17,[x16,:lo12:cnt52]
add x17,x17,#1
str x17,[x16,:lo12:cnt52]
ldp x16,x17,[sp],#16
bl Lfn11
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
cbnz x1, Lfn17end
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
str x0, [sp, #128]
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
ldr x0, [sp, #120]
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
ldr x2, [sp, #128]
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
b.vs Lfn17fail710_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
str x0, [sp, #136]
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt52
ldr x17,[x16,:lo12:cnt52]
add x17,x17,#1
str x17,[x16,:lo12:cnt52]
ldp x16,x17,[sp],#16
bl Lfn12
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
cbnz x1, Lfn17end
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
str x0, [sp, #144]
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
ldr x0, [sp, #136]
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
ldr x2, [sp, #144]
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
b.vs Lfn17fail709_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
str x0, [sp, #152]
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt52
ldr x17,[x16,:lo12:cnt52]
add x17,x17,#1
str x17,[x16,:lo12:cnt52]
ldp x16,x17,[sp],#16
bl Lfn13
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
cbnz x1, Lfn17end
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
str x0, [sp, #160]
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
ldr x0, [sp, #152]
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
ldr x2, [sp, #160]
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
b.vs Lfn17fail708_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
str x0, [sp, #168]
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt52
ldr x17,[x16,:lo12:cnt52]
add x17,x17,#1
str x17,[x16,:lo12:cnt52]
ldp x16,x17,[sp],#16
bl Lfn14
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
cbnz x1, Lfn17end
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
str x0, [sp, #176]
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
ldr x0, [sp, #168]
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
ldr x2, [sp, #176]
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
b.vs Lfn17fail707_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
str x0, [sp, #184]
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt52
ldr x17,[x16,:lo12:cnt52]
add x17,x17,#1
str x17,[x16,:lo12:cnt52]
ldp x16,x17,[sp],#16
bl Lfn15
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
cbnz x1, Lfn17end
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
str x0, [sp, #192]
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
ldr x0, [sp, #184]
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
ldr x2, [sp, #192]
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
b.vs Lfn17fail706_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
str x0, [sp, #200]
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt52
ldr x17,[x16,:lo12:cnt52]
add x17,x17,#1
str x17,[x16,:lo12:cnt52]
ldp x16,x17,[sp],#16
bl Lfn16
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
cbnz x1, Lfn17end
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
str x0, [sp, #208]
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
ldr x0, [sp, #200]
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
ldr x2, [sp, #208]
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
b.vs Lfn17fail705_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
b Lfn17end
Lfn17fail714_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
adrp x0, Lfn17fail714_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn17fail714_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt52
ldr x17,[x16,:lo12:cnt52]
add x17,x17,#1
str x17,[x16,:lo12:cnt52]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
b Lfn17end
Lfn17fail713_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
adrp x0, Lfn17fail713_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn17fail713_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt52
ldr x17,[x16,:lo12:cnt52]
add x17,x17,#1
str x17,[x16,:lo12:cnt52]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
b Lfn17end
Lfn17fail712_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
adrp x0, Lfn17fail712_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn17fail712_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt52
ldr x17,[x16,:lo12:cnt52]
add x17,x17,#1
str x17,[x16,:lo12:cnt52]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
b Lfn17end
Lfn17fail711_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
adrp x0, Lfn17fail711_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn17fail711_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt52
ldr x17,[x16,:lo12:cnt52]
add x17,x17,#1
str x17,[x16,:lo12:cnt52]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
b Lfn17end
Lfn17fail710_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
adrp x0, Lfn17fail710_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn17fail710_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt52
ldr x17,[x16,:lo12:cnt52]
add x17,x17,#1
str x17,[x16,:lo12:cnt52]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
b Lfn17end
Lfn17fail709_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
adrp x0, Lfn17fail709_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn17fail709_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt52
ldr x17,[x16,:lo12:cnt52]
add x17,x17,#1
str x17,[x16,:lo12:cnt52]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
b Lfn17end
Lfn17fail708_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
adrp x0, Lfn17fail708_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn17fail708_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt52
ldr x17,[x16,:lo12:cnt52]
add x17,x17,#1
str x17,[x16,:lo12:cnt52]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
b Lfn17end
Lfn17fail707_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
adrp x0, Lfn17fail707_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn17fail707_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt52
ldr x17,[x16,:lo12:cnt52]
add x17,x17,#1
str x17,[x16,:lo12:cnt52]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
b Lfn17end
Lfn17fail706_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
adrp x0, Lfn17fail706_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn17fail706_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt52
ldr x17,[x16,:lo12:cnt52]
add x17,x17,#1
str x17,[x16,:lo12:cnt52]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
b Lfn17end
Lfn17fail705_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
adrp x0, Lfn17fail705_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn17fail705_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt52
ldr x17,[x16,:lo12:cnt52]
add x17,x17,#1
str x17,[x16,:lo12:cnt52]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
b Lfn17end
Lfn17end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt50
ldr x17,[x16,:lo12:cnt50]
add x17,x17,#1
str x17,[x16,:lo12:cnt50]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt51
ldr x17,[x16,:lo12:cnt51]
add x17,x17,#1
str x17,[x16,:lo12:cnt51]
ldp x16,x17,[sp],#16
ret
Lfn18:
stp x16,x17,[sp,#-16]!
adrp x16, cnt53
ldr x17,[x16,:lo12:cnt53]
add x17,x17,#1
str x17,[x16,:lo12:cnt53]
ldp x16,x17,[sp],#16
ldp x8, x9, [x0, #0]
Lfn18fields:
stp x16,x17,[sp,#-16]!
adrp x16, cnt54
ldr x17,[x16,:lo12:cnt54]
add x17,x17,#1
str x17,[x16,:lo12:cnt54]
ldp x16,x17,[sp],#16
stp x29, x30, [sp, #-16]!
stp x16,x17,[sp,#-16]!
adrp x16, cnt53
ldr x17,[x16,:lo12:cnt53]
add x17,x17,#1
str x17,[x16,:lo12:cnt53]
ldp x16,x17,[sp],#16
mov x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt53
ldr x17,[x16,:lo12:cnt53]
add x17,x17,#1
str x17,[x16,:lo12:cnt53]
ldp x16,x17,[sp],#16
sub sp, sp, #96
stp x16,x17,[sp,#-16]!
adrp x16, cnt54
ldr x17,[x16,:lo12:cnt54]
add x17,x17,#1
str x17,[x16,:lo12:cnt54]
ldp x16,x17,[sp],#16
stp x8, x9, [sp, #48]
Lfn18loop:
stp x16,x17,[sp,#-16]!
adrp x16, cnt54
ldr x17,[x16,:lo12:cnt54]
add x17,x17,#1
str x17,[x16,:lo12:cnt54]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt53
ldr x17,[x16,:lo12:cnt53]
add x17,x17,#1
str x17,[x16,:lo12:cnt53]
ldp x16,x17,[sp],#16
cmp x0, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt53
ldr x17,[x16,:lo12:cnt53]
add x17,x17,#1
str x17,[x16,:lo12:cnt53]
ldp x16,x17,[sp],#16
b.gt Lfn18if746else
stp x16,x17,[sp,#-16]!
adrp x16, cnt54
ldr x17,[x16,:lo12:cnt54]
add x17,x17,#1
str x17,[x16,:lo12:cnt54]
ldp x16,x17,[sp],#16
ldr x0, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt53
ldr x17,[x16,:lo12:cnt53]
add x17,x17,#1
str x17,[x16,:lo12:cnt53]
ldp x16,x17,[sp],#16
b Lfn18if746done
Lfn18if746else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt54
ldr x17,[x16,:lo12:cnt54]
add x17,x17,#1
str x17,[x16,:lo12:cnt54]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt53
ldr x17,[x16,:lo12:cnt53]
add x17,x17,#1
str x17,[x16,:lo12:cnt53]
ldp x16,x17,[sp],#16
subs x0, x0, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt53
ldr x17,[x16,:lo12:cnt53]
add x17,x17,#1
str x17,[x16,:lo12:cnt53]
ldp x16,x17,[sp],#16
b.vs Lfn18fail753_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt54
ldr x17,[x16,:lo12:cnt54]
add x17,x17,#1
str x17,[x16,:lo12:cnt54]
ldp x16,x17,[sp],#16
str x0, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt54
ldr x17,[x16,:lo12:cnt54]
add x17,x17,#1
str x17,[x16,:lo12:cnt54]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt55
ldr x17,[x16,:lo12:cnt55]
add x17,x17,#1
str x17,[x16,:lo12:cnt55]
ldp x16,x17,[sp],#16
bl Lfn17
stp x16,x17,[sp,#-16]!
adrp x16, cnt53
ldr x17,[x16,:lo12:cnt53]
add x17,x17,#1
str x17,[x16,:lo12:cnt53]
ldp x16,x17,[sp],#16
cbnz x1, Lfn18end
stp x16,x17,[sp,#-16]!
adrp x16, cnt54
ldr x17,[x16,:lo12:cnt54]
add x17,x17,#1
str x17,[x16,:lo12:cnt54]
ldp x16,x17,[sp],#16
str x0, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt54
ldr x17,[x16,:lo12:cnt54]
add x17,x17,#1
str x17,[x16,:lo12:cnt54]
ldp x16,x17,[sp],#16
ldr x0, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt54
ldr x17,[x16,:lo12:cnt54]
add x17,x17,#1
str x17,[x16,:lo12:cnt54]
ldp x16,x17,[sp],#16
ldr x2, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt53
ldr x17,[x16,:lo12:cnt53]
add x17,x17,#1
str x17,[x16,:lo12:cnt53]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt53
ldr x17,[x16,:lo12:cnt53]
add x17,x17,#1
str x17,[x16,:lo12:cnt53]
ldp x16,x17,[sp],#16
b.vs Lfn18fail756_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt54
ldr x17,[x16,:lo12:cnt54]
add x17,x17,#1
str x17,[x16,:lo12:cnt54]
ldp x16,x17,[sp],#16
str x0, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt54
ldr x17,[x16,:lo12:cnt54]
add x17,x17,#1
str x17,[x16,:lo12:cnt54]
ldp x16,x17,[sp],#16
ldr x8, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt54
ldr x17,[x16,:lo12:cnt54]
add x17,x17,#1
str x17,[x16,:lo12:cnt54]
ldp x16,x17,[sp],#16
ldr x9, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt54
ldr x17,[x16,:lo12:cnt54]
add x17,x17,#1
str x17,[x16,:lo12:cnt54]
ldp x16,x17,[sp],#16
str x8, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt54
ldr x17,[x16,:lo12:cnt54]
add x17,x17,#1
str x17,[x16,:lo12:cnt54]
ldp x16,x17,[sp],#16
str x9, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt53
ldr x17,[x16,:lo12:cnt53]
add x17,x17,#1
str x17,[x16,:lo12:cnt53]
ldp x16,x17,[sp],#16
b Lfn18loop
Lfn18if746done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt53
ldr x17,[x16,:lo12:cnt53]
add x17,x17,#1
str x17,[x16,:lo12:cnt53]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt53
ldr x17,[x16,:lo12:cnt53]
add x17,x17,#1
str x17,[x16,:lo12:cnt53]
ldp x16,x17,[sp],#16
b Lfn18end
Lfn18fail753_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt53
ldr x17,[x16,:lo12:cnt53]
add x17,x17,#1
str x17,[x16,:lo12:cnt53]
ldp x16,x17,[sp],#16
adrp x0, Lfn18fail753_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt53
ldr x17,[x16,:lo12:cnt53]
add x17,x17,#1
str x17,[x16,:lo12:cnt53]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn18fail753_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt55
ldr x17,[x16,:lo12:cnt55]
add x17,x17,#1
str x17,[x16,:lo12:cnt55]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt53
ldr x17,[x16,:lo12:cnt53]
add x17,x17,#1
str x17,[x16,:lo12:cnt53]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt53
ldr x17,[x16,:lo12:cnt53]
add x17,x17,#1
str x17,[x16,:lo12:cnt53]
ldp x16,x17,[sp],#16
b Lfn18end
Lfn18fail756_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt53
ldr x17,[x16,:lo12:cnt53]
add x17,x17,#1
str x17,[x16,:lo12:cnt53]
ldp x16,x17,[sp],#16
adrp x0, Lfn18fail756_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt53
ldr x17,[x16,:lo12:cnt53]
add x17,x17,#1
str x17,[x16,:lo12:cnt53]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn18fail756_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt55
ldr x17,[x16,:lo12:cnt55]
add x17,x17,#1
str x17,[x16,:lo12:cnt55]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt53
ldr x17,[x16,:lo12:cnt53]
add x17,x17,#1
str x17,[x16,:lo12:cnt53]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt53
ldr x17,[x16,:lo12:cnt53]
add x17,x17,#1
str x17,[x16,:lo12:cnt53]
ldp x16,x17,[sp],#16
b Lfn18end
Lfn18end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt53
ldr x17,[x16,:lo12:cnt53]
add x17,x17,#1
str x17,[x16,:lo12:cnt53]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt54
ldr x17,[x16,:lo12:cnt54]
add x17,x17,#1
str x17,[x16,:lo12:cnt54]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt53
ldr x17,[x16,:lo12:cnt53]
add x17,x17,#1
str x17,[x16,:lo12:cnt53]
ldp x16,x17,[sp],#16
ret
.globl fenrir_entry
fenrir_entry:
Lfn19:
stp x16,x17,[sp,#-16]!
adrp x16, cnt56
ldr x17,[x16,:lo12:cnt56]
add x17,x17,#1
str x17,[x16,:lo12:cnt56]
ldp x16,x17,[sp],#16
stp x29, x30, [sp, #-16]!
stp x16,x17,[sp,#-16]!
adrp x16, cnt57
ldr x17,[x16,:lo12:cnt57]
add x17,x17,#1
str x17,[x16,:lo12:cnt57]
ldp x16,x17,[sp],#16
mov x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt57
ldr x17,[x16,:lo12:cnt57]
add x17,x17,#1
str x17,[x16,:lo12:cnt57]
ldp x16,x17,[sp],#16
sub sp, sp, #64
stp x16,x17,[sp,#-16]!
adrp x16, cnt56
ldr x17,[x16,:lo12:cnt56]
add x17,x17,#1
str x17,[x16,:lo12:cnt56]
ldp x16,x17,[sp],#16
str x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt57
ldr x17,[x16,:lo12:cnt57]
add x17,x17,#1
str x17,[x16,:lo12:cnt57]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt56
ldr x17,[x16,:lo12:cnt56]
add x17,x17,#1
str x17,[x16,:lo12:cnt56]
ldp x16,x17,[sp],#16
str x0, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt56
ldr x17,[x16,:lo12:cnt56]
add x17,x17,#1
str x17,[x16,:lo12:cnt56]
ldp x16,x17,[sp],#16
ldr x8, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt56
ldr x17,[x16,:lo12:cnt56]
add x17,x17,#1
str x17,[x16,:lo12:cnt56]
ldp x16,x17,[sp],#16
ldr x9, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt57
ldr x17,[x16,:lo12:cnt57]
add x17,x17,#1
str x17,[x16,:lo12:cnt57]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt56
ldr x17,[x16,:lo12:cnt56]
add x17,x17,#1
str x17,[x16,:lo12:cnt56]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt57
ldr x17,[x16,:lo12:cnt57]
add x17,x17,#1
str x17,[x16,:lo12:cnt57]
ldp x16,x17,[sp],#16
b Lfn18fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt57
ldr x17,[x16,:lo12:cnt57]
add x17,x17,#1
str x17,[x16,:lo12:cnt57]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt57
ldr x17,[x16,:lo12:cnt57]
add x17,x17,#1
str x17,[x16,:lo12:cnt57]
ldp x16,x17,[sp],#16
b Lfn19end
Lfn19end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt57
ldr x17,[x16,:lo12:cnt57]
add x17,x17,#1
str x17,[x16,:lo12:cnt57]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt56
ldr x17,[x16,:lo12:cnt56]
add x17,x17,#1
str x17,[x16,:lo12:cnt56]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt57
ldr x17,[x16,:lo12:cnt57]
add x17,x17,#1
str x17,[x16,:lo12:cnt57]
ldp x16,x17,[sp],#16
ret
.text
.globl fen_print_result
fen_print_result:
b Lprint0
Lprint0:
b fen_write_i64
Lfn0fail18_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,56,58,49,55,10,0
Lfn0fail28_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,58,52,48,10,0
Lfn0fail25_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,58,50,55,10,0
.p2align 3
Lconstant0:
.zero 72
.long 10
.byte 0,2,0,0
Lfn1fail52_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,49,50,58,51,49,10,0
Lfn2fail73_2location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,49,54,58,51,49,10,0
Lfn2fail73_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,49,54,58,51,49,10,0
Lfn3fail99_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,50,48,58,51,50,10,0
Lfn3fail108_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,50,49,58,52,53,10,0
.p2align 3
Lconstant1:
.quad 8
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,115,115,115,115
.p2align 3
Lconstant2:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115
.p2align 3
Lconstant3:
.quad 2
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115
.p2align 3
Lconstant4:
.quad 3
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115
.p2align 3
Lconstant5:
.quad 4
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115
.p2align 3
Lconstant6:
.quad 5
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,115
.p2align 3
Lconstant7:
.quad 6
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,115,115
.p2align 3
Lconstant8:
.quad 7
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,115,115,115
Lfn4fail127_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,50,54,58,50,48,10,0
Lfn4fail130_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,50,54,58,51,50,10,0
Lfn4fail138_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,50,56,58,55,10,0
.p2align 3
Lconstant9:
.zero 72
.long 14
.byte 0,2,0,0
.p2align 3
Lconstant10:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 120
.p2align 3
Lconstant11:
.quad 1
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 98
Lfn5fail204_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,51,55,58,49,53,10,0
Lfn5fail211_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,51,57,58,52,49,10,0
Lfn5fail239_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,52,52,58,49,57,10,0
Lfn5fail264_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,52,54,58,56,52,10,0
Lfn5fail280_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,52,55,58,57,48,10,0
Lfn5fail310_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,53,49,58,55,52,10,0
Lfn5fail307_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,53,49,58,53,57,10,0
Lfn5fail317_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,53,50,58,53,51,10,0
Lfn5fail362_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,53,56,58,57,56,10,0
Lfn5fail360_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,53,56,58,56,48,10,0
Lfn5fail356_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,53,56,58,53,50,10,0
.p2align 3
Lconstant12:
.quad 1
.zero 64
.long 7
.byte 0,2,0,0
.section .rodata
.p2align 3
Lconstant13:
.quad 2
.quad Lconstant12
.quad Lconstant12
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant14:
.quad 0
.quad Lconstant13
.quad Lconstant0
.zero 48
.long 11
.byte 6,2,0,0
.text
.p2align 3
Lconstant15:
.quad 3
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,120
.section .rodata
.p2align 3
Lconstant16:
.quad Lconstant15
.quad 97
.zero 56
.long 12
.byte 1,2,0,0
.text
.section .rodata
.p2align 3
Lconstant17:
.quad Lconstant12
.zero 64
.long 8
.byte 1,2,0,0
.text
.section .rodata
.p2align 3
Lconstant18:
.quad 1
.quad Lconstant12
.quad Lconstant17
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant19:
.quad 0
.quad Lconstant18
.quad Lconstant0
.zero 48
.long 11
.byte 6,2,0,0
.text
.p2align 3
Lconstant20:
.quad 4
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,120
.section .rodata
.p2align 3
Lconstant21:
.quad Lconstant20
.quad 96
.zero 56
.long 12
.byte 1,2,0,0
.text
.p2align 3
Lconstant22:
.quad 2
.zero 64
.long 7
.byte 0,2,0,0
.section .rodata
.p2align 3
Lconstant23:
.quad 2
.quad Lconstant12
.quad Lconstant22
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant24:
.quad 0
.quad Lconstant12
.quad Lconstant23
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant25:
.quad 2
.quad Lconstant24
.quad Lconstant22
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant26:
.quad 0
.quad Lconstant25
.quad Lconstant0
.zero 48
.long 11
.byte 6,2,0,0
.text
.p2align 3
Lconstant27:
.quad 7
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,98,120,120
.section .rodata
.p2align 3
Lconstant28:
.quad Lconstant27
.quad 93
.zero 56
.long 12
.byte 1,2,0,0
.text
.p2align 3
Lconstant29:
.quad 4
.zero 64
.long 7
.byte 0,2,0,0
.section .rodata
.p2align 3
Lconstant30:
.quad 1
.quad Lconstant22
.quad Lconstant29
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant31:
.quad 0
.quad Lconstant12
.quad Lconstant30
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant32:
.quad 0
.quad Lconstant12
.quad Lconstant22
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant33:
.quad 0
.quad Lconstant12
.quad Lconstant29
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant34:
.quad 1
.quad Lconstant32
.quad Lconstant33
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant35:
.quad 2
.quad Lconstant31
.quad Lconstant34
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant36:
.quad 0
.quad Lconstant35
.quad Lconstant0
.zero 48
.long 11
.byte 6,2,0,0
.text
.p2align 3
Lconstant37:
.quad 29
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,98,98,98,115,120,115,120,98,115,120,115,120,98,98,115,120,115,120,98,115,115,120,115,115,120
.section .rodata
.p2align 3
Lconstant38:
.quad Lconstant37
.quad 71
.zero 56
.long 12
.byte 1,2,0,0
.text
.section .rodata
.p2align 3
Lconstant39:
.quad 2
.quad Lconstant22
.quad Lconstant29
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant40:
.quad 0
.quad Lconstant23
.quad Lconstant39
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant41:
.quad 2
.quad Lconstant12
.quad Lconstant29
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant42:
.quad 2
.quad Lconstant40
.quad Lconstant41
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant43:
.quad 0
.quad Lconstant42
.quad Lconstant0
.zero 48
.long 11
.byte 6,2,0,0
.text
.p2align 3
Lconstant44:
.quad 20
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,98,98,115,115,120,115,115,120,98,115,115,115,120,115,115,115,120
.section .rodata
.p2align 3
Lconstant45:
.quad Lconstant44
.quad 180
.zero 56
.long 12
.byte 1,2,0,0
.text
.section .rodata
.p2align 3
Lconstant46:
.quad 2
.quad Lconstant23
.quad Lconstant12
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant47:
.quad 2
.quad Lconstant46
.quad Lconstant12
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant48:
.quad 0
.quad Lconstant47
.quad Lconstant0
.zero 48
.long 11
.byte 6,2,0,0
.text
.p2align 3
Lconstant49:
.quad 7
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,98,115,115,120,115,120
.section .rodata
.p2align 3
Lconstant50:
.quad Lconstant49
.quad 193
.zero 56
.long 12
.byte 1,2,0,0
.text
.section .rodata
.p2align 3
Lconstant51:
.quad 0
.quad Lconstant32
.quad Lconstant0
.zero 48
.long 11
.byte 6,2,0,0
.text
.p2align 3
Lconstant52:
.quad 0
.quad 97
.zero 56
.long 13
.byte 0,2,0,0
.section .rodata
.p2align 3
Lconstant53:
.quad 2
.quad Lconstant22
.quad Lconstant12
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant54:
.quad 2
.quad Lconstant23
.quad Lconstant53
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant55:
.quad 0
.quad Lconstant54
.quad Lconstant0
.zero 48
.long 11
.byte 6,2,0,0
.text
.p2align 3
Lconstant56:
.quad 2
.quad 93
.zero 56
.long 13
.byte 0,2,0,0
.section .rodata
.p2align 3
Lconstant57:
.quad 0
.quad Lconstant12
.quad Lconstant0
.zero 48
.long 11
.byte 6,2,0,0
.text
Lfn17fail714_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,56,55,58,54,52,10,0
Lfn17fail713_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,56,55,58,54,49,10,0
Lfn17fail712_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,56,55,58,53,56,10,0
Lfn17fail711_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,56,55,58,53,53,10,0
Lfn17fail710_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,56,55,58,53,50,10,0
Lfn17fail709_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,56,55,58,52,57,10,0
Lfn17fail708_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,56,55,58,52,54,10,0
Lfn17fail707_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,56,55,58,52,51,10,0
Lfn17fail706_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,56,55,58,52,48,10,0
Lfn17fail705_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,56,55,58,51,55,10,0
Lfn18fail753_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,56,57,58,52,55,10,0
Lfn18fail756_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,56,57,58,53,53,10,0
.data
.p2align 3
.globl counts
counts:
cnt0:
.quad 0
cnt1:
.quad 0
cnt2:
.quad 0
cnt3:
.quad 0
cnt4:
.quad 0
cnt5:
.quad 0
cnt6:
.quad 0
cnt7:
.quad 0
cnt8:
.quad 0
cnt9:
.quad 0
cnt10:
.quad 0
cnt11:
.quad 0
cnt12:
.quad 0
cnt13:
.quad 0
cnt14:
.quad 0
cnt15:
.quad 0
cnt16:
.quad 0
cnt17:
.quad 0
cnt18:
.quad 0
cnt19:
.quad 0
cnt20:
.quad 0
cnt21:
.quad 0
cnt22:
.quad 0
cnt23:
.quad 0
cnt24:
.quad 0
cnt25:
.quad 0
cnt26:
.quad 0
cnt27:
.quad 0
cnt28:
.quad 0
cnt29:
.quad 0
cnt30:
.quad 0
cnt31:
.quad 0
cnt32:
.quad 0
cnt33:
.quad 0
cnt34:
.quad 0
cnt35:
.quad 0
cnt36:
.quad 0
cnt37:
.quad 0
cnt38:
.quad 0
cnt39:
.quad 0
cnt40:
.quad 0
cnt41:
.quad 0
cnt42:
.quad 0
cnt43:
.quad 0
cnt44:
.quad 0
cnt45:
.quad 0
cnt46:
.quad 0
cnt47:
.quad 0
cnt48:
.quad 0
cnt49:
.quad 0
cnt50:
.quad 0
cnt51:
.quad 0
cnt52:
.quad 0
cnt53:
.quad 0
cnt54:
.quad 0
cnt55:
.quad 0
cnt56:
.quad 0
cnt57:
.quad 0
