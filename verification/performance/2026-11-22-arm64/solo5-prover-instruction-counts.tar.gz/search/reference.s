	.arch armv8-a
	.file	"reference.c"
	.text
	.align	2
	.p2align 5,,15
	.type	visit, %function
visit:
.LFB2:
	.cfi_startproc
	stp	x29, x30, [sp, -256]!
	.cfi_def_cfa_offset 256
	.cfi_offset 29, -256
	.cfi_offset 30, -248
	mov	x29, sp
	stp	x19, x20, [sp, 16]
	.cfi_offset 19, -240
	.cfi_offset 20, -232
	mov	x20, x4
	mov	x19, x1
	stp	x21, x22, [sp, 32]
	.cfi_offset 21, -224
	.cfi_offset 22, -216
	mov	x22, x0
	stp	x23, x24, [sp, 48]
	.cfi_offset 23, -208
	.cfi_offset 24, -200
	mov	w23, w2
	mov	w24, 1
	stp	x25, x26, [sp, 64]
	.cfi_offset 25, -192
	.cfi_offset 26, -184
	mov	w25, 33
	mov	w26, 62
	stp	x27, x28, [sp, 80]
	.cfi_offset 27, -176
	.cfi_offset 28, -168
	mov	w28, 115
	ldr	x21, [x4, 272]
.L23:
	cbz	x21, .L26
.L27:
	ldp	w1, w6, [x19, 128]
	cmp	w1, w6
	beq	.L56
.L4:
	ldrsh	w5, [x19, w1, uxtw 1]
	add	w1, w1, 1
	str	w1, [x19, 128]
	cmp	w5, 0
	ble	.L57
	sub	w1, w5, #1
	sub	w2, w5, #1
	ldrb	w1, [x22, w1, uxtw]
	sub	w4, w1, #97
	and	w0, w4, 255
	cmp	w0, 25
	bhi	.L9
	lsl	w4, w24, w4
	tst	w3, w4
	bne	.L7
	orr	w23, w23, w4
.L14:
	ldr	w1, [x20, 8]
	cmp	w1, 256
	beq	.L36
	cbz	x21, .L24
	ldr	x0, [x20, 280]
	cmp	x0, w1, uxtw
	bls	.L36
	ldrb	w0, [x21, w1, uxtw]
	cmp	w0, 115
	bne	.L36
	add	w1, w1, 1
	str	w1, [x20, 8]
	ldp	w1, w6, [x19, 128]
	cmp	w1, w6
	bne	.L4
	.p2align 5,,15
.L56:
	str	w23, [x20, 4]
	mov	w0, 1
	cbz	x21, .L1
	.p2align 5,,15
.L36:
	mov	w0, 3
.L1:
	ldp	x19, x20, [sp, 16]
	ldp	x21, x22, [sp, 32]
	ldp	x23, x24, [sp, 48]
	ldp	x25, x26, [sp, 64]
	ldp	x27, x28, [sp, 80]
	ldp	x29, x30, [sp], 256
	.cfi_remember_state
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 27
	.cfi_restore 28
	.cfi_restore 25
	.cfi_restore 26
	.cfi_restore 23
	.cfi_restore 24
	.cfi_restore 21
	.cfi_restore 22
	.cfi_restore 19
	.cfi_restore 20
	.cfi_def_cfa_offset 0
	ret
	.p2align 2,,3
.L24:
	.cfi_restore_state
	add	x0, x20, w1, uxtw
	add	w1, w1, 1
	strb	w28, [x0, 12]
	str	w1, [x20, 8]
.L26:
	ldr	w0, [x20]
	cbz	w0, .L32
	sub	w0, w0, #1
	str	w0, [x20]
	b	.L27
	.p2align 2,,3
.L57:
	mvn	w0, w5
	mvn	w2, w5
	ldrb	w1, [x22, w0, uxtw]
	sub	w0, w1, #97
	and	w4, w0, 255
	cmp	w4, 25
	bhi	.L6
	lsl	w0, w24, w0
	tst	w23, w0
	bne	.L7
	orr	w3, w3, w0
	b	.L14
	.p2align 2,,3
.L9:
	cmp	w1, 62
	ccmp	w1, w25, 4, ne
	beq	.L58
	add	x2, x2, 16
	cmp	w1, 38
	add	w8, w5, 1
	cset	w1, eq
	cmp	w5, 0
	ldr	w7, [x22, x2, lsl 2]
	cset	w0, gt
	sxth	w8, w8
	add	w7, w7, 1
	sxth	w27, w7
	cmp	w1, w0
	beq	.L17
.L18:
	ldr	w0, [x20, 8]
	cmp	w0, 256
	beq	.L36
	cbz	x21, .L21
	ldr	x1, [x20, 280]
	cmp	x1, w0, uxtw
	bls	.L36
	ldrb	w1, [x21, w0, uxtw]
	cmp	w1, 98
	bne	.L36
	b	.L22
	.p2align 2,,3
.L6:
	cmp	w1, 33
	ccmp	w1, w26, 4, ne
	beq	.L59
	add	x2, x2, 16
	cmp	w1, 38
	sub	w8, w5, #1
	cset	w1, eq
	cmp	w5, 0
	ldr	w7, [x22, x2, lsl 2]
	cset	w0, gt
	sxth	w8, w8
	mvn	w7, w7
	sxth	w27, w7
	cmp	w1, w0
	bne	.L18
.L17:
	add	w0, w6, 1
	strh	w8, [x19, w6, uxtw 1]
	add	w6, w6, 2
	str	w6, [x19, 132]
	strh	w27, [x19, x0, lsl 1]
	b	.L14
	.p2align 2,,3
.L59:
	neg	w5, w5
	add	w5, w5, 1
	sxth	w8, w5
	cmp	w1, 33
	bne	.L60
.L16:
	add	w0, w6, 1
	str	w0, [x19, 132]
	strh	w8, [x19, w6, uxtw 1]
	b	.L14
	.p2align 2,,3
.L58:
	mvn	w8, w5
	cmp	w1, 33
	beq	.L16
	add	x2, x2, 16
	ldr	w7, [x22, x2, lsl 2]
	add	w7, w7, 1
	sxth	w27, w7
	b	.L18
	.p2align 2,,3
.L60:
	add	x2, x2, 16
	add	w0, w6, 1
	ldr	w7, [x22, x2, lsl 2]
	strh	w8, [x19, w6, uxtw 1]
	add	w6, w6, 2
	mvn	w7, w7
	str	w6, [x19, 132]
	sxth	w27, w7
	strh	w27, [x19, x0, lsl 1]
	b	.L14
	.p2align 2,,3
.L21:
	add	x1, x20, w0, uxtw
	mov	w2, 98
	strb	w2, [x1, 12]
.L22:
	ldp	q30, q29, [x19]
	add	x1, sp, 120
	ldr	q31, [x19, 32]
	add	w0, w0, 1
	str	w0, [x20, 8]
	uxtw	x0, w6
	add	w5, w6, 1
	mov	x4, x20
	stp	q30, q29, [x1]
	mov	w2, w23
	ldp	q30, q29, [x19, 48]
	stp	q31, q30, [x1, 32]
	str	x0, [sp, 96]
	ldr	q30, [x19, 112]
	ldp	q28, q31, [x19, 80]
	stp	q29, q28, [x1, 64]
	str	w3, [sp, 108]
	ldr	x0, [x19, 128]
	stp	q31, q30, [x1, 96]
	str	x0, [x1, 128]
	mov	x0, x22
	strh	w8, [x1, w6, uxtw 1]
	str	w5, [sp, 104]
	str	w5, [sp, 252]
	bl	visit
	cbnz	w0, .L1
	ldr	x0, [sp, 96]
	ldp	w5, w3, [sp, 104]
	str	w5, [x19, 132]
	strh	w27, [x19, x0, lsl 1]
	b	.L23
	.p2align 2,,3
.L7:
	ldr	w0, [x20, 8]
	cmp	w0, 256
	beq	.L36
	cbz	x21, .L12
	ldr	x1, [x20, 280]
	cmp	x1, w0, uxtw
	bls	.L36
	ldrb	w1, [x21, w0, uxtw]
	cmp	w1, 120
	bne	.L36
.L13:
	add	w1, w0, 1
	mov	w0, 0
	str	w1, [x20, 8]
	b	.L1
	.p2align 2,,3
.L32:
	mov	w0, 2
	b	.L1
.L12:
	add	x1, x20, w0, uxtw
	mov	w2, 120
	strb	w2, [x1, 12]
	b	.L13
	.cfi_endproc
.LFE2:
	.size	visit, .-visit
	.align	2
	.p2align 5,,15
	.global	fenrir_entry
	.type	fenrir_entry, %function
fenrir_entry:
.LFB5:
	.cfi_startproc
	stp	x29, x30, [sp, -480]!
	.cfi_def_cfa_offset 480
	.cfi_offset 29, -480
	.cfi_offset 30, -472
	mov	x29, sp
	stp	x19, x20, [sp, 16]
	.cfi_offset 19, -464
	.cfi_offset 20, -456
	mov	x20, 0
	cmp	x0, 0
	ble	.L63
	stp	x21, x22, [sp, 32]
	.cfi_offset 22, -440
	.cfi_offset 21, -448
	mov	x21, x0
	adrp	x0, .LC0
	add	x13, sp, 192
	add	x18, sp, 56
	ldr	d27, [x0, #:lo12:.LC0]
	mov	x19, 0
	mov	x20, 0
	adrp	x22, .LANCHOR0
	mov	w15, -1
	.p2align 5,,15
.L62:
	add	x11, x22, :lo12:.LANCHOR0
	mov	w0, 115
	add	x14, x11, 3440
	.p2align 5,,15
.L72:
	ldr	x10, [x11, 320]
	mov	x9, 0
	cbz	w0, .L71
	.p2align 5,,15
.L64:
	add	x9, x9, 1
	ldrb	w0, [x10, x9]
	cbnz	w0, .L64
.L71:
	ldr	w12, [x11, 328]
	mov	x1, x18
	mov	x4, x13
	mov	x0, x11
	mov	w3, 0
	mov	w2, 0
	strh	w15, [sp, 56]
	str	d27, [sp, 184]
	str	w12, [sp, 192]
	str	wzr, [sp, 200]
	stp	xzr, x9, [sp, 464]
	bl	visit
	ldr	w1, [x11, 340]
	cmp	w1, w0
	bne	.L65
	ldr	w2, [sp, 192]
	ldr	w0, [x11, 332]
	sub	w12, w12, w2
	cmp	w12, w0
	bne	.L65
	cmp	w1, 1
	beq	.L80
	cbnz	w1, .L67
	ldr	w0, [sp, 200]
	cmp	x0, x9
	beq	.L81
	.p2align 5,,15
.L65:
	add	x11, x11, 344
	cmp	x14, x11
	beq	.L70
.L82:
	ldr	x0, [x11, 320]
	ldrb	w0, [x0]
	b	.L72
.L80:
	ldr	w0, [x11, 336]
	ldr	w1, [sp, 196]
	cmp	w1, w0
	bne	.L65
.L67:
	add	x20, x20, 1
.L83:
	add	x11, x11, 344
	cmp	x14, x11
	bne	.L82
	.p2align 5,,15
.L70:
	add	x19, x19, 1
	cmp	x21, x19
	bne	.L62
	ldp	x21, x22, [sp, 32]
	.cfi_restore 22
	.cfi_restore 21
.L63:
	mov	x0, x20
	mov	x1, 0
	ldp	x19, x20, [sp, 16]
	ldp	x29, x30, [sp], 480
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 19
	.cfi_restore 20
	.cfi_def_cfa_offset 0
	ret
.L81:
	.cfi_def_cfa_offset 480
	.cfi_offset 19, -464
	.cfi_offset 20, -456
	.cfi_offset 21, -448
	.cfi_offset 22, -440
	.cfi_offset 29, -480
	.cfi_offset 30, -472
	mov	x0, 0
	cbnz	x9, .L68
	b	.L67
	.p2align 2,,3
.L69:
	add	x0, x0, 1
	cmp	x0, x9
	beq	.L67
.L68:
	add	x1, x13, x0
	ldrb	w2, [x10, x0]
	ldrb	w1, [x1, 12]
	cmp	w1, w2
	beq	.L69
	cmp	x9, x0
	bhi	.L65
	add	x20, x20, 1
	b	.L83
	.cfi_endproc
.LFE5:
	.size	fenrir_entry, .-fenrir_entry
	.section	.rodata.str1.8,"aMS",@progbits,1
	.align	3
.LC1:
	.string	"ssx"
	.align	3
.LC2:
	.string	"sssx"
	.align	3
.LC3:
	.string	"ssssbxx"
	.align	3
.LC4:
	.string	"ssssbbbsxsxbsxsxbbsxsxbssxssx"
	.align	3
.LC5:
	.string	"sssbbssxssxbsssxsssx"
	.align	3
.LC6:
	.string	"sbssxsx"
	.align	3
.LC7:
	.string	""
	.section	.rodata.cst8,"aM",@progbits,8
	.align	3
.LC0:
	.word	0
	.word	1
	.section	.data.rel.ro.local,"aw"
	.align	3
	.set	.LANCHOR0,. + 0
	.type	cases, %object
	.size	cases, 3440
cases:
	.string	">aa"
	.zero	60
	.word	2
	.word	0
	.word	0
	.zero	244
	.xword	.LC1
	.word	100
	.word	3
	.word	0
	.word	0
	.string	"|a!a"
	.zero	59
	.word	2
	.word	0
	.word	0
	.word	0
	.zero	240
	.xword	.LC2
	.word	100
	.word	4
	.word	0
	.word	0
	.string	">&a>abb"
	.zero	56
	.word	6
	.word	3
	.word	0
	.word	5
	.word	0
	.word	0
	.word	0
	.zero	228
	.xword	.LC3
	.word	100
	.word	7
	.word	0
	.word	0
	.string	">&a|bc|&ab&ac"
	.zero	50
	.word	6
	.word	3
	.word	0
	.word	5
	.word	0
	.word	0
	.word	10
	.word	9
	.word	0
	.word	0
	.word	12
	.word	0
	.word	0
	.zero	204
	.xword	.LC4
	.word	100
	.word	29
	.word	0
	.word	0
	.string	">&>ab>bc>ac"
	.zero	52
	.word	8
	.word	5
	.word	4
	.word	0
	.word	0
	.word	7
	.word	0
	.word	0
	.word	10
	.word	0
	.word	0
	.zero	212
	.xword	.LC5
	.word	200
	.word	20
	.word	0
	.word	0
	.string	">>>abaa"
	.zero	56
	.word	6
	.word	5
	.word	4
	.word	0
	.word	0
	.word	0
	.word	0
	.zero	228
	.xword	.LC6
	.word	200
	.word	7
	.word	0
	.word	0
	.string	"&ab"
	.zero	60
	.word	2
	.word	0
	.word	0
	.zero	244
	.xword	.LC7
	.word	100
	.word	3
	.word	0
	.word	1
	.string	">>ab>ba"
	.zero	56
	.word	4
	.word	3
	.word	0
	.word	0
	.word	6
	.word	0
	.word	0
	.zero	228
	.xword	.LC7
	.word	100
	.word	7
	.word	2
	.word	1
	.string	">&a|bc|&ab&ac"
	.zero	50
	.word	6
	.word	3
	.word	0
	.word	5
	.word	0
	.word	0
	.word	10
	.word	9
	.word	0
	.word	0
	.word	12
	.word	0
	.word	0
	.zero	204
	.xword	.LC7
	.word	3
	.word	3
	.word	0
	.word	2
	.string	"a"
	.zero	62
	.word	0
	.zero	252
	.xword	.LC7
	.word	0
	.word	0
	.word	0
	.word	2
	.ident	"GCC: (Alpine 14.2.0) 14.2.0"
	.section	.note.GNU-stack,"",@progbits
