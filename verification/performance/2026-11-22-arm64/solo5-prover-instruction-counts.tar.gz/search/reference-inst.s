	.arch armv8-a
	.file	"reference.c"
	.text
	.align	2
	.p2align 5,,15
	.type	visit, %function
visit:
.LFB2:
	.cfi_startproc
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
	stp	x29, x30, [sp, -256]!
	.cfi_def_cfa_offset 256
	.cfi_offset 29, -256
	.cfi_offset 30, -248
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	mov	x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
	stp	x19, x20, [sp, 16]
	.cfi_offset 19, -240
	.cfi_offset 20, -232
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	mov	x20, x4
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	mov	x19, x1
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
	stp	x21, x22, [sp, 32]
	.cfi_offset 21, -224
	.cfi_offset 22, -216
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	mov	x22, x0
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
	stp	x23, x24, [sp, 48]
	.cfi_offset 23, -208
	.cfi_offset 24, -200
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	mov	w23, w2
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	mov	w24, 1
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
	stp	x25, x26, [sp, 64]
	.cfi_offset 25, -192
	.cfi_offset 26, -184
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	mov	w25, 33
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	mov	w26, 62
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
	stp	x27, x28, [sp, 80]
	.cfi_offset 27, -176
	.cfi_offset 28, -168
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	mov	w28, 115
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	ldr	x21, [x4, 272]
.L23:
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	cbz	x21, .L26
.L27:
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	ldp	w1, w6, [x19, 128]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	cmp	w1, w6
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	beq	.L56
.L4:
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	ldrsh	w5, [x19, w1, uxtw 1]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	add	w1, w1, 1
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	str	w1, [x19, 128]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	cmp	w5, 0
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	ble	.L57
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	sub	w1, w5, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	sub	w2, w5, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	ldrb	w1, [x22, w1, uxtw]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	sub	w4, w1, #97
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	and	w0, w4, 255
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	cmp	w0, 25
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	bhi	.L9
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	lsl	w4, w24, w4
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	tst	w3, w4
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	bne	.L7
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	orr	w23, w23, w4
.L14:
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	ldr	w1, [x20, 8]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	cmp	w1, 256
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	beq	.L36
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	cbz	x21, .L24
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	ldr	x0, [x20, 280]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	cmp	x0, w1, uxtw
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	bls	.L36
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	ldrb	w0, [x21, w1, uxtw]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	cmp	w0, 115
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	bne	.L36
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	add	w1, w1, 1
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	str	w1, [x20, 8]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	ldp	w1, w6, [x19, 128]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	cmp	w1, w6
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	bne	.L4
	.p2align 5,,15
.L56:
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	str	w23, [x20, 4]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	mov	w0, 1
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	cbz	x21, .L1
	.p2align 5,,15
.L36:
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	mov	w0, 3
.L1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
	ldp	x19, x20, [sp, 16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
	ldp	x21, x22, [sp, 32]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
	ldp	x23, x24, [sp, 48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
	ldp	x25, x26, [sp, 64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
	ldp	x27, x28, [sp, 80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
	ldp	x29, x30, [sp], 256
	.cfi_remember_state
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 27
	.cfi_restore 28
	.cfi_restore 25
	.cfi_restore 26
	.cfi_restore 23
	.cfi_restore 24
	.cfi_restore 21
	.cfi_restore 22
	.cfi_restore 19
	.cfi_restore 20
	.cfi_def_cfa_offset 0
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	ret
	.p2align 2,,3
.L24:
	.cfi_restore_state
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	add	x0, x20, w1, uxtw
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	add	w1, w1, 1
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	strb	w28, [x0, 12]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	str	w1, [x20, 8]
.L26:
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	ldr	w0, [x20]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	cbz	w0, .L32
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	sub	w0, w0, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	str	w0, [x20]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	b	.L27
	.p2align 2,,3
.L57:
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	mvn	w0, w5
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	mvn	w2, w5
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	ldrb	w1, [x22, w0, uxtw]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	sub	w0, w1, #97
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	and	w4, w0, 255
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	cmp	w4, 25
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	bhi	.L6
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	lsl	w0, w24, w0
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	tst	w23, w0
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	bne	.L7
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	orr	w3, w3, w0
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	b	.L14
	.p2align 2,,3
.L9:
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	cmp	w1, 62
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	ccmp	w1, w25, 4, ne
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	beq	.L58
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	add	x2, x2, 16
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	cmp	w1, 38
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	add	w8, w5, 1
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	cset	w1, eq
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	cmp	w5, 0
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	ldr	w7, [x22, x2, lsl 2]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	cset	w0, gt
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	sxth	w8, w8
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	add	w7, w7, 1
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	sxth	w27, w7
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	cmp	w1, w0
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	beq	.L17
.L18:
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	ldr	w0, [x20, 8]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	cmp	w0, 256
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	beq	.L36
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	cbz	x21, .L21
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	ldr	x1, [x20, 280]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	cmp	x1, w0, uxtw
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	bls	.L36
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	ldrb	w1, [x21, w0, uxtw]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	cmp	w1, 98
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	bne	.L36
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	b	.L22
	.p2align 2,,3
.L6:
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	cmp	w1, 33
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	ccmp	w1, w26, 4, ne
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	beq	.L59
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	add	x2, x2, 16
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	cmp	w1, 38
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	sub	w8, w5, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	cset	w1, eq
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	cmp	w5, 0
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	ldr	w7, [x22, x2, lsl 2]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	cset	w0, gt
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	sxth	w8, w8
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	mvn	w7, w7
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	sxth	w27, w7
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	cmp	w1, w0
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	bne	.L18
.L17:
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	add	w0, w6, 1
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	strh	w8, [x19, w6, uxtw 1]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	add	w6, w6, 2
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	str	w6, [x19, 132]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	strh	w27, [x19, x0, lsl 1]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	b	.L14
	.p2align 2,,3
.L59:
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	neg	w5, w5
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	add	w5, w5, 1
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	sxth	w8, w5
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	cmp	w1, 33
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	bne	.L60
.L16:
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	add	w0, w6, 1
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	str	w0, [x19, 132]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	strh	w8, [x19, w6, uxtw 1]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	b	.L14
	.p2align 2,,3
.L58:
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	mvn	w8, w5
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	cmp	w1, 33
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	beq	.L16
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	add	x2, x2, 16
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	ldr	w7, [x22, x2, lsl 2]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	add	w7, w7, 1
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	sxth	w27, w7
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	b	.L18
	.p2align 2,,3
.L60:
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	add	x2, x2, 16
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	add	w0, w6, 1
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	ldr	w7, [x22, x2, lsl 2]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	strh	w8, [x19, w6, uxtw 1]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	add	w6, w6, 2
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	mvn	w7, w7
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	str	w6, [x19, 132]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	sxth	w27, w7
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	strh	w27, [x19, x0, lsl 1]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	b	.L14
	.p2align 2,,3
.L21:
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	add	x1, x20, w0, uxtw
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	mov	w2, 98
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	strb	w2, [x1, 12]
.L22:
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	ldp	q30, q29, [x19]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	add	x1, sp, 120
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	ldr	q31, [x19, 32]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	add	w0, w0, 1
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	str	w0, [x20, 8]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	uxtw	x0, w6
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	add	w5, w6, 1
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	mov	x4, x20
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	stp	q30, q29, [x1]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	mov	w2, w23
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	ldp	q30, q29, [x19, 48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	stp	q31, q30, [x1, 32]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
	str	x0, [sp, 96]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	ldr	q30, [x19, 112]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	ldp	q28, q31, [x19, 80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	stp	q29, q28, [x1, 64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
	str	w3, [sp, 108]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	ldr	x0, [x19, 128]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	stp	q31, q30, [x1, 96]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	str	x0, [x1, 128]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	mov	x0, x22
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	strh	w8, [x1, w6, uxtw 1]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
	str	w5, [sp, 104]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
	str	w5, [sp, 252]
stp x16,x17,[sp,#-16]!
adrp x16, cnt2
ldr x17,[x16,:lo12:cnt2]
add x17,x17,#1
str x17,[x16,:lo12:cnt2]
ldp x16,x17,[sp],#16
	bl	visit
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	cbnz	w0, .L1
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
	ldr	x0, [sp, 96]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
	ldp	w5, w3, [sp, 104]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	str	w5, [x19, 132]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	strh	w27, [x19, x0, lsl 1]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	b	.L23
	.p2align 2,,3
.L7:
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	ldr	w0, [x20, 8]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	cmp	w0, 256
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	beq	.L36
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	cbz	x21, .L12
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	ldr	x1, [x20, 280]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	cmp	x1, w0, uxtw
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	bls	.L36
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	ldrb	w1, [x21, w0, uxtw]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	cmp	w1, 120
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	bne	.L36
.L13:
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	add	w1, w0, 1
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	mov	w0, 0
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	str	w1, [x20, 8]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	b	.L1
	.p2align 2,,3
.L32:
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	mov	w0, 2
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	b	.L1
.L12:
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	add	x1, x20, w0, uxtw
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	mov	w2, 120
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	strb	w2, [x1, 12]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
	b	.L13
	.cfi_endproc
.LFE2:
	.size	visit, .-visit
	.align	2
	.p2align 5,,15
	.global	fenrir_entry
	.type	fenrir_entry, %function
fenrir_entry:
.LFB5:
	.cfi_startproc
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
	stp	x29, x30, [sp, -480]!
	.cfi_def_cfa_offset 480
	.cfi_offset 29, -480
	.cfi_offset 30, -472
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	mov	x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
	stp	x19, x20, [sp, 16]
	.cfi_offset 19, -464
	.cfi_offset 20, -456
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	mov	x20, 0
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	cmp	x0, 0
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	ble	.L63
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
	stp	x21, x22, [sp, 32]
	.cfi_offset 22, -440
	.cfi_offset 21, -448
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	mov	x21, x0
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	adrp	x0, .LC0
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	add	x13, sp, 192
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	add	x18, sp, 56
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	ldr	d27, [x0, #:lo12:.LC0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	mov	x19, 0
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	mov	x20, 0
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	adrp	x22, .LANCHOR0
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	mov	w15, -1
	.p2align 5,,15
.L62:
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	add	x11, x22, :lo12:.LANCHOR0
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	mov	w0, 115
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	add	x14, x11, 3440
	.p2align 5,,15
.L72:
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	ldr	x10, [x11, 320]
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	mov	x9, 0
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	cbz	w0, .L71
	.p2align 5,,15
.L64:
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	add	x9, x9, 1
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	ldrb	w0, [x10, x9]
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	cbnz	w0, .L64
.L71:
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	ldr	w12, [x11, 328]
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	mov	x1, x18
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	mov	x4, x13
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	mov	x0, x11
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	mov	w3, 0
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	mov	w2, 0
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
	strh	w15, [sp, 56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
	str	d27, [sp, 184]
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
	str	w12, [sp, 192]
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
	str	wzr, [sp, 200]
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
	stp	xzr, x9, [sp, 464]
stp x16,x17,[sp,#-16]!
adrp x16, cnt5
ldr x17,[x16,:lo12:cnt5]
add x17,x17,#1
str x17,[x16,:lo12:cnt5]
ldp x16,x17,[sp],#16
	bl	visit
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	ldr	w1, [x11, 340]
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	cmp	w1, w0
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	bne	.L65
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
	ldr	w2, [sp, 192]
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	ldr	w0, [x11, 332]
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	sub	w12, w12, w2
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	cmp	w12, w0
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	bne	.L65
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	cmp	w1, 1
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	beq	.L80
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	cbnz	w1, .L67
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
	ldr	w0, [sp, 200]
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	cmp	x0, x9
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	beq	.L81
	.p2align 5,,15
.L65:
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	add	x11, x11, 344
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	cmp	x14, x11
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	beq	.L70
.L82:
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	ldr	x0, [x11, 320]
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	ldrb	w0, [x0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	b	.L72
.L80:
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	ldr	w0, [x11, 336]
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
	ldr	w1, [sp, 196]
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	cmp	w1, w0
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	bne	.L65
.L67:
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	add	x20, x20, 1
.L83:
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	add	x11, x11, 344
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	cmp	x14, x11
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	bne	.L82
	.p2align 5,,15
.L70:
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	add	x19, x19, 1
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	cmp	x21, x19
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	bne	.L62
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
	ldp	x21, x22, [sp, 32]
	.cfi_restore 22
	.cfi_restore 21
.L63:
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	mov	x0, x20
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	mov	x1, 0
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
	ldp	x19, x20, [sp, 16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
	ldp	x29, x30, [sp], 480
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 19
	.cfi_restore 20
	.cfi_def_cfa_offset 0
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	ret
.L81:
	.cfi_def_cfa_offset 480
	.cfi_offset 19, -464
	.cfi_offset 20, -456
	.cfi_offset 21, -448
	.cfi_offset 22, -440
	.cfi_offset 29, -480
	.cfi_offset 30, -472
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	mov	x0, 0
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	cbnz	x9, .L68
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	b	.L67
	.p2align 2,,3
.L69:
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	add	x0, x0, 1
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	cmp	x0, x9
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	beq	.L67
.L68:
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	add	x1, x13, x0
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	ldrb	w2, [x10, x0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	ldrb	w1, [x1, 12]
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	cmp	w1, w2
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	beq	.L69
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	cmp	x9, x0
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	bhi	.L65
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	add	x20, x20, 1
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
	b	.L83
	.cfi_endproc
.LFE5:
	.size	fenrir_entry, .-fenrir_entry
	.section	.rodata.str1.8,"aMS",@progbits,1
	.align	3
.LC1:
	.string	"ssx"
	.align	3
.LC2:
	.string	"sssx"
	.align	3
.LC3:
	.string	"ssssbxx"
	.align	3
.LC4:
	.string	"ssssbbbsxsxbsxsxbbsxsxbssxssx"
	.align	3
.LC5:
	.string	"sssbbssxssxbsssxsssx"
	.align	3
.LC6:
	.string	"sbssxsx"
	.align	3
.LC7:
	.string	""
	.section	.rodata.cst8,"aM",@progbits,8
	.align	3
.LC0:
	.word	0
	.word	1
	.section	.data.rel.ro.local,"aw"
	.align	3
	.set	.LANCHOR0,. + 0
	.type	cases, %object
	.size	cases, 3440
cases:
	.string	">aa"
	.zero	60
	.word	2
	.word	0
	.word	0
	.zero	244
	.xword	.LC1
	.word	100
	.word	3
	.word	0
	.word	0
	.string	"|a!a"
	.zero	59
	.word	2
	.word	0
	.word	0
	.word	0
	.zero	240
	.xword	.LC2
	.word	100
	.word	4
	.word	0
	.word	0
	.string	">&a>abb"
	.zero	56
	.word	6
	.word	3
	.word	0
	.word	5
	.word	0
	.word	0
	.word	0
	.zero	228
	.xword	.LC3
	.word	100
	.word	7
	.word	0
	.word	0
	.string	">&a|bc|&ab&ac"
	.zero	50
	.word	6
	.word	3
	.word	0
	.word	5
	.word	0
	.word	0
	.word	10
	.word	9
	.word	0
	.word	0
	.word	12
	.word	0
	.word	0
	.zero	204
	.xword	.LC4
	.word	100
	.word	29
	.word	0
	.word	0
	.string	">&>ab>bc>ac"
	.zero	52
	.word	8
	.word	5
	.word	4
	.word	0
	.word	0
	.word	7
	.word	0
	.word	0
	.word	10
	.word	0
	.word	0
	.zero	212
	.xword	.LC5
	.word	200
	.word	20
	.word	0
	.word	0
	.string	">>>abaa"
	.zero	56
	.word	6
	.word	5
	.word	4
	.word	0
	.word	0
	.word	0
	.word	0
	.zero	228
	.xword	.LC6
	.word	200
	.word	7
	.word	0
	.word	0
	.string	"&ab"
	.zero	60
	.word	2
	.word	0
	.word	0
	.zero	244
	.xword	.LC7
	.word	100
	.word	3
	.word	0
	.word	1
	.string	">>ab>ba"
	.zero	56
	.word	4
	.word	3
	.word	0
	.word	0
	.word	6
	.word	0
	.word	0
	.zero	228
	.xword	.LC7
	.word	100
	.word	7
	.word	2
	.word	1
	.string	">&a|bc|&ab&ac"
	.zero	50
	.word	6
	.word	3
	.word	0
	.word	5
	.word	0
	.word	0
	.word	10
	.word	9
	.word	0
	.word	0
	.word	12
	.word	0
	.word	0
	.zero	204
	.xword	.LC7
	.word	3
	.word	3
	.word	0
	.word	2
	.string	"a"
	.zero	62
	.word	0
	.zero	252
	.xword	.LC7
	.word	0
	.word	0
	.word	0
	.word	2
	.ident	"GCC: (Alpine 14.2.0) 14.2.0"
	.section	.note.GNU-stack,"",@progbits
.data
.p2align 3
.globl counts
counts:
cnt0:
.quad 0
cnt1:
.quad 0
cnt2:
.quad 0
cnt3:
.quad 0
cnt4:
.quad 0
cnt5:
.quad 0
