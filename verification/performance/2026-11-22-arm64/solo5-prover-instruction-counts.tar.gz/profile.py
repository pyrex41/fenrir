from pathlib import Path
import collections,json,re
root=Path(__file__).resolve().parent
for lane in ('search','check'):
    work=root/lane
    names=[f['name'] for f in json.loads((work/'artifact').read_text())['functions']]
    for impl in ('reference','program'):
        owner=None
        keys={}
        lines=[]
        for line in (work/(impl+'.s')).read_text().splitlines():
            ins=line.strip()
            if impl=='reference':
                if m:=re.fullmatch(r'\.type\s+([^,]+), %function',ins): owner=m[1]
                if ins.startswith('.size'): owner=None
            else:
                if m:=re.fullmatch(r'Lfn(\d+):',ins): owner=names[int(m[1])]
                if ins=='.globl fen_print_result': owner=None
            if owner and ins and not ins.startswith(('.','//')) and not ins.endswith(':'):
                op=ins.split()[0]
                group='stack' if '[sp' in ins else 'call' if op=='bl' else 'other'
                i=keys.setdefault((owner,group),len(keys))
                lines.extend(['stp x16,x17,[sp,#-16]!',f'adrp x16, cnt{i}',f'ldr x17,[x16,:lo12:cnt{i}]','add x17,x17,#1',f'str x17,[x16,:lo12:cnt{i}]','ldp x16,x17,[sp],#16'])
            lines.append(line)
        lines.extend(['.data','.p2align 3','.globl counts','counts:'])
        for i in range(len(keys)): lines.extend([f'cnt{i}:','.quad 0'])
        (work/(impl+'-inst.s')).write_text('\n'.join(lines)+'\n')
        (work/(impl+'-keys.json')).write_text(json.dumps(list(keys)))
        caller=(Path('benchmarks/prover/timed-spt.c')).read_text()
        caller=caller.replace('return SOLO5_EXIT_SUCCESS;',f'extern uint64_t counts[]; for (int i=0;i<{len(keys)};i++) {{ fen_write_i64(counts[i]); fen_write("\\n",1); }} return SOLO5_EXIT_SUCCESS;')
        (work/(impl+'-main.c')).write_text(caller)
