.text
.p2align 2
Lfn0:
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
ldp x8, x9, [x0, #0]
Lfn0fields:
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
ldr w2, [x8, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
cmp w2, #10
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
b.ne Lfn0frame
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
mov x0, x9
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
ret
Lfn0frame:
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
stp x29, x30, [sp, #-16]!
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
mov x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
sub sp, sp, #80
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
stp x8, x9, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
add x0, sp, #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
add x1, sp, #48
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
mov x2, #4
stp x16,x17,[sp,#-16]!
adrp x16, cnt2
ldr x17,[x16,:lo12:cnt2]
add x17,x17,#1
str x17,[x16,:lo12:cnt2]
ldp x16,x17,[sp],#16
bl fen_enter
Lfn0loop:
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
ldr w0, [x0, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
cmp w0, #10
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
b.eq Lfn0match10arm10
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
cmp w0, #11
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
b.eq Lfn0match10arm11
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
brk #0
Lfn0match10arm10:
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
ldr x0, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
b Lfn0match10end
Lfn0match10arm11:
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
ldr x0, [x0, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
ldr w0, [x0, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
cmp w0, #10
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
b.eq Lfn0match16arm10
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
cmp w0, #11
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
b.eq Lfn0match16arm11
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
brk #0
Lfn0match16arm10:
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
mov x0, #6
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
mov x1, #11
stp x16,x17,[sp,#-16]!
adrp x16, cnt2
ldr x17,[x16,:lo12:cnt2]
add x17,x17,#1
str x17,[x16,:lo12:cnt2]
ldp x16,x17,[sp],#16
bl fen_allocate
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
cbz x0, Lfn0fail18_3
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
ldr x4, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
ldp x2, x3, [x4, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
stp x2, x3, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
ldr x2, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
str x2, [x0, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
b Lfn0match16end
Lfn0match16arm11:
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
ldr x8, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
ldr x8, [x8, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
ldr x8, [x8, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
ldr x9, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt2
ldr x17,[x16,:lo12:cnt2]
add x17,x17,#1
str x17,[x16,:lo12:cnt2]
ldp x16,x17,[sp],#16
bl Lfn0fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
cbnz x1, Lfn0end
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
str x0, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
mov x0, #6
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
mov x1, #11
stp x16,x17,[sp,#-16]!
adrp x16, cnt2
ldr x17,[x16,:lo12:cnt2]
add x17,x17,#1
str x17,[x16,:lo12:cnt2]
ldp x16,x17,[sp],#16
bl fen_allocate
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
cbz x0, Lfn0fail28_3
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
ldr x4, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
ldr x4, [x4, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
ldp x2, x3, [x4, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
stp x2, x3, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
ldr x2, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
str x2, [x0, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
str x0, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
mov x0, #6
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
mov x1, #11
stp x16,x17,[sp,#-16]!
adrp x16, cnt2
ldr x17,[x16,:lo12:cnt2]
add x17,x17,#1
str x17,[x16,:lo12:cnt2]
ldp x16,x17,[sp],#16
bl fen_allocate
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
cbz x0, Lfn0fail25_3
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
ldr x4, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
ldp x2, x3, [x4, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
stp x2, x3, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
ldr x2, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
str x2, [x0, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
b Lfn0match16end
Lfn0match16end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
b Lfn0match10end
Lfn0match10end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
b Lfn0end
Lfn0fail18_3:
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
adrp x0, Lfn0fail18_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn0fail18_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt2
ldr x17,[x16,:lo12:cnt2]
add x17,x17,#1
str x17,[x16,:lo12:cnt2]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
mov x1, #3
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
b Lfn0end
Lfn0fail28_3:
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
adrp x0, Lfn0fail28_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn0fail28_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt2
ldr x17,[x16,:lo12:cnt2]
add x17,x17,#1
str x17,[x16,:lo12:cnt2]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
mov x1, #3
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
b Lfn0end
Lfn0fail25_3:
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
adrp x0, Lfn0fail25_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn0fail25_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt2
ldr x17,[x16,:lo12:cnt2]
add x17,x17,#1
str x17,[x16,:lo12:cnt2]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
mov x1, #3
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
b Lfn0end
Lfn0end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt2
ldr x17,[x16,:lo12:cnt2]
add x17,x17,#1
str x17,[x16,:lo12:cnt2]
ldp x16,x17,[sp],#16
bl fen_leave_result
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt1
ldr x17,[x16,:lo12:cnt1]
add x17,x17,#1
str x17,[x16,:lo12:cnt1]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt0
ldr x17,[x16,:lo12:cnt0]
add x17,x17,#1
str x17,[x16,:lo12:cnt0]
ldp x16,x17,[sp],#16
ret
Lfn1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
ldp x8, x9, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
ldr x10, [x0, #16]
Lfn1fields:
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
stp x29, x30, [sp, #-16]!
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
mov x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
sub sp, sp, #80
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
str xzr, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
str x8, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
str x9, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
str x10, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
add x0, sp, #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
add x1, sp, #48
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
mov x2, #3
stp x16,x17,[sp,#-16]!
adrp x16, cnt5
ldr x17,[x16,:lo12:cnt5]
add x17,x17,#1
str x17,[x16,:lo12:cnt5]
ldp x16,x17,[sp],#16
bl fen_enter
Lfn1loop:
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
mov x0, #6
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
mov x1, #11
stp x16,x17,[sp,#-16]!
adrp x16, cnt5
ldr x17,[x16,:lo12:cnt5]
add x17,x17,#1
str x17,[x16,:lo12:cnt5]
ldp x16,x17,[sp],#16
bl fen_allocate
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
cbz x0, Lfn1fail52_3
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
ldr x2, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
ldr x3, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
stp x2, x3, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
adrp x2, Lconstant0
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
add x2, x2, :lo12:Lconstant0
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
str x2, [x0, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
str x0, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt5
ldr x17,[x16,:lo12:cnt5]
add x17,x17,#1
str x17,[x16,:lo12:cnt5]
ldp x16,x17,[sp],#16
bl fen_leave_result
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
ldr x8, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
ldr x9, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
b Lfn0fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
b Lfn1end
Lfn1fail52_3:
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
adrp x0, Lfn1fail52_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn1fail52_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt5
ldr x17,[x16,:lo12:cnt5]
add x17,x17,#1
str x17,[x16,:lo12:cnt5]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
mov x1, #3
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
b Lfn1end
Lfn1end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt5
ldr x17,[x16,:lo12:cnt5]
add x17,x17,#1
str x17,[x16,:lo12:cnt5]
ldp x16,x17,[sp],#16
bl fen_leave_result
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt4
ldr x17,[x16,:lo12:cnt4]
add x17,x17,#1
str x17,[x16,:lo12:cnt4]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt3
ldr x17,[x16,:lo12:cnt3]
add x17,x17,#1
str x17,[x16,:lo12:cnt3]
ldp x16,x17,[sp],#16
ret
Lfn2:
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
ldp x8, x9, [x0, #0]
Lfn2fields:
stp x16,x17,[sp,#-16]!
adrp x16, cnt7
ldr x17,[x16,:lo12:cnt7]
add x17,x17,#1
str x17,[x16,:lo12:cnt7]
ldp x16,x17,[sp],#16
stp x29, x30, [sp, #-16]!
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
mov x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
sub sp, sp, #64
stp x16,x17,[sp,#-16]!
adrp x16, cnt7
ldr x17,[x16,:lo12:cnt7]
add x17,x17,#1
str x17,[x16,:lo12:cnt7]
ldp x16,x17,[sp],#16
stp x8, x9, [sp, #48]
Lfn2loop:
stp x16,x17,[sp,#-16]!
adrp x16, cnt7
ldr x17,[x16,:lo12:cnt7]
add x17,x17,#1
str x17,[x16,:lo12:cnt7]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt7
ldr x17,[x16,:lo12:cnt7]
add x17,x17,#1
str x17,[x16,:lo12:cnt7]
ldp x16,x17,[sp],#16
ldr x2, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
cmp x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
b.ge Lfn2if66else
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
b Lfn2if66done
Lfn2if66else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt7
ldr x17,[x16,:lo12:cnt7]
add x17,x17,#1
str x17,[x16,:lo12:cnt7]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt7
ldr x17,[x16,:lo12:cnt7]
add x17,x17,#1
str x17,[x16,:lo12:cnt7]
ldp x16,x17,[sp],#16
ldr x2, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
cbz x2, Lfn2fail73_2
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
cmn x2, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
b.ne 1f
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
negs x3, x0
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
b.vs Lfn2fail73_1
1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
sdiv x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
cmp x0, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
neg x2, x0
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
and x2, x2, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
and x0, x0, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
csneg x0, x0, x2, ge
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
cmp x0, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
cset x0, eq
Lfn2if66done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
b Lfn2end
Lfn2fail73_2:
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
adrp x0, Lfn2fail73_2location
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn2fail73_2location
stp x16,x17,[sp,#-16]!
adrp x16, cnt8
ldr x17,[x16,:lo12:cnt8]
add x17,x17,#1
str x17,[x16,:lo12:cnt8]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
mov x1, #2
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
b Lfn2end
Lfn2fail73_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
adrp x0, Lfn2fail73_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn2fail73_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt8
ldr x17,[x16,:lo12:cnt8]
add x17,x17,#1
str x17,[x16,:lo12:cnt8]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
b Lfn2end
Lfn2end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt7
ldr x17,[x16,:lo12:cnt7]
add x17,x17,#1
str x17,[x16,:lo12:cnt7]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt6
ldr x17,[x16,:lo12:cnt6]
add x17,x17,#1
str x17,[x16,:lo12:cnt6]
ldp x16,x17,[sp],#16
ret
Lfn3:
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
ldp x8, x9, [x0, #0]
Lfn3fields:
stp x16,x17,[sp,#-16]!
adrp x16, cnt10
ldr x17,[x16,:lo12:cnt10]
add x17,x17,#1
str x17,[x16,:lo12:cnt10]
ldp x16,x17,[sp],#16
stp x29, x30, [sp, #-16]!
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
mov x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
sub sp, sp, #64
stp x16,x17,[sp,#-16]!
adrp x16, cnt10
ldr x17,[x16,:lo12:cnt10]
add x17,x17,#1
str x17,[x16,:lo12:cnt10]
ldp x16,x17,[sp],#16
stp x8, x9, [sp, #48]
Lfn3loop:
stp x16,x17,[sp,#-16]!
adrp x16, cnt10
ldr x17,[x16,:lo12:cnt10]
add x17,x17,#1
str x17,[x16,:lo12:cnt10]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt10
ldr x17,[x16,:lo12:cnt10]
add x17,x17,#1
str x17,[x16,:lo12:cnt10]
ldp x16,x17,[sp],#16
ldr x2, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
cmp x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
b.ge Lfn3if95else
stp x16,x17,[sp,#-16]!
adrp x16, cnt10
ldr x17,[x16,:lo12:cnt10]
add x17,x17,#1
str x17,[x16,:lo12:cnt10]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt10
ldr x17,[x16,:lo12:cnt10]
add x17,x17,#1
str x17,[x16,:lo12:cnt10]
ldp x16,x17,[sp],#16
ldr x2, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
b.vs Lfn3fail99_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
b Lfn3if95done
Lfn3if95else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt10
ldr x17,[x16,:lo12:cnt10]
add x17,x17,#1
str x17,[x16,:lo12:cnt10]
ldp x16,x17,[sp],#16
ldr x8, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt10
ldr x17,[x16,:lo12:cnt10]
add x17,x17,#1
str x17,[x16,:lo12:cnt10]
ldp x16,x17,[sp],#16
ldr x9, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt11
ldr x17,[x16,:lo12:cnt11]
add x17,x17,#1
str x17,[x16,:lo12:cnt11]
ldp x16,x17,[sp],#16
bl Lfn2fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
cbnz x1, Lfn3end
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
cbz x0, Lfn3if102else
stp x16,x17,[sp,#-16]!
adrp x16, cnt10
ldr x17,[x16,:lo12:cnt10]
add x17,x17,#1
str x17,[x16,:lo12:cnt10]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
b Lfn3if102done
Lfn3if102else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt10
ldr x17,[x16,:lo12:cnt10]
add x17,x17,#1
str x17,[x16,:lo12:cnt10]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt10
ldr x17,[x16,:lo12:cnt10]
add x17,x17,#1
str x17,[x16,:lo12:cnt10]
ldp x16,x17,[sp],#16
ldr x2, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
b.vs Lfn3fail108_1
Lfn3if102done:
Lfn3if95done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
b Lfn3end
Lfn3fail99_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
adrp x0, Lfn3fail99_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn3fail99_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt11
ldr x17,[x16,:lo12:cnt11]
add x17,x17,#1
str x17,[x16,:lo12:cnt11]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
b Lfn3end
Lfn3fail108_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
adrp x0, Lfn3fail108_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn3fail108_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt11
ldr x17,[x16,:lo12:cnt11]
add x17,x17,#1
str x17,[x16,:lo12:cnt11]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
b Lfn3end
Lfn3end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt10
ldr x17,[x16,:lo12:cnt10]
add x17,x17,#1
str x17,[x16,:lo12:cnt10]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt9
ldr x17,[x16,:lo12:cnt9]
add x17,x17,#1
str x17,[x16,:lo12:cnt9]
ldp x16,x17,[sp],#16
ret
Lfn4:
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldp x8, x9, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldp x10, x11, [x0, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldp x12, x13, [x0, #32]
Lfn4fields:
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
stp x29, x30, [sp, #-16]!
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
mov x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
sub sp, sp, #224
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #88]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #104]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
stp x8, x9, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
stp x10, x11, [sp, #120]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x12, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x13, [sp, #136]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
add x0, sp, #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
add x1, sp, #48
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
mov x2, #9
stp x16,x17,[sp,#-16]!
adrp x16, cnt14
ldr x17,[x16,:lo12:cnt14]
add x17,x17,#1
str x17,[x16,:lo12:cnt14]
ldp x16,x17,[sp],#16
bl fen_enter
Lfn4loop:
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr w0, [x0, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cmp w0, #10
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b.eq Lfn4match137arm10
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cmp w0, #11
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b.eq Lfn4match137arm11
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
brk #0
Lfn4match137arm10:
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr w0, [x0, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cmp w0, #10
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b.eq Lfn4match139arm10
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cmp w0, #11
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b.eq Lfn4match139arm11
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
brk #0
Lfn4match139arm10:
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
movn x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4match139end
Lfn4match139arm11:
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x8, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
adrp x9, Lconstant0
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
add x9, x9, :lo12:Lconstant0
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x8, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x9, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #88]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #104]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4loop
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4match139end
Lfn4match139end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4match137end
Lfn4match137arm11:
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #136]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cmp x0, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b.ge Lfn4if156else
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
movn x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4if156done
Lfn4if156else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x0, [x0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x0, [sp, #144]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #136]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x2, [sp, #144]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cmp x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b.lt Lfn4if161else
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
movn x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4if161done
Lfn4if161else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x2, [sp, #136]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x3, [x0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cmp x2, x3
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b.hs Lfn4fail169_4
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr w3, [x0, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cmn w3, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b.ne 1f
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
add x0, x0, #80
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldrb w0, [x0, x2]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b 2f
1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
mov x1, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt14
ldr x17,[x16,:lo12:cnt14]
add x17,x17,#1
str x17,[x16,:lo12:cnt14]
ldp x16,x17,[sp],#16
bl fen_bytes_index
2:
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x0, [sp, #152]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #136]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
adds x0, x0, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b.vs Lfn4fail174_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x0, [sp, #160]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x0, [x0, #8]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr w0, [x0, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cmp w0, #7
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b.eq Lfn4match177arm7
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cmp w0, #8
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b.eq Lfn4match177arm8
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cmp w0, #9
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b.eq Lfn4match177arm9
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
brk #0
Lfn4match177arm7:
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x0, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cbz x0, Lfn4if183else
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #128]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4if183done
Lfn4if183else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #120]
Lfn4if183done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x0, [sp, #168]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x8, [sp, #168]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x9, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x9, [x9, #8]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x9, [x9, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt14
ldr x17,[x16,:lo12:cnt14]
add x17,x17,#1
str x17,[x16,:lo12:cnt14]
ldp x16,x17,[sp],#16
bl Lfn2fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cbnz x1, Lfn4end
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cbz x0, Lfn4if180else
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #152]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cmp x0, #120
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b.ne Lfn4if188else
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #160]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4if188done
Lfn4if188else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
movn x0, #0, lsl #0
Lfn4if188done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4if180done
Lfn4if180else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #152]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cmp x0, #115
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b.ne Lfn4if194else
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x0, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cbz x0, Lfn4if202else
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x8, [sp, #120]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x9, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x9, [x9, #8]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x9, [x9, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt14
ldr x17,[x16,:lo12:cnt14]
add x17,x17,#1
str x17,[x16,:lo12:cnt14]
ldp x16,x17,[sp],#16
bl Lfn3fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cbnz x1, Lfn4end
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4if202done
Lfn4if202else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #120]
Lfn4if202done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x0, [sp, #176]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x0, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cbz x0, Lfn4if209else
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #128]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4if209done
Lfn4if209else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x8, [sp, #128]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x9, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x9, [x9, #8]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x9, [x9, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt14
ldr x17,[x16,:lo12:cnt14]
add x17,x17,#1
str x17,[x16,:lo12:cnt14]
ldp x16,x17,[sp],#16
bl Lfn3fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cbnz x1, Lfn4end
Lfn4if209done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x0, [sp, #184]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x8, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x8, [x8, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x9, [sp, #176]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x10, [sp, #184]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x11, [sp, #160]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x8, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x9, [sp, #120]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x10, [sp, #128]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x11, [sp, #136]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #88]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #104]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4loop
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4if194done
Lfn4if194else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
movn x0, #0, lsl #0
Lfn4if194done:
Lfn4if180done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4match177end
Lfn4match177arm8:
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #152]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cmp x0, #115
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b.ne Lfn4if220else
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x0, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
eor x0, x0, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x0, [sp, #192]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x8, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x9, [sp, #192]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x10, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x10, [x10, #8]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x10, [x10, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt14
ldr x17,[x16,:lo12:cnt14]
add x17,x17,#1
str x17,[x16,:lo12:cnt14]
ldp x16,x17,[sp],#16
bl Lfn1fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cbnz x1, Lfn4end
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x0, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x8, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x8, [x8, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x9, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x10, [sp, #160]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x8, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x9, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x10, [sp, #136]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #88]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #104]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4loop
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4if220done
Lfn4if220else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
movn x0, #0, lsl #0
Lfn4if220done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4match177end
Lfn4match177arm9:
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x0, [x0, #8]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x0, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cmp x0, #2
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b.ne Lfn4if243else
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x0, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
eor x0, x0, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4if243done
Lfn4if243else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x0, [x0, #0]
Lfn4if243done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x0, [sp, #200]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x0, [x0, #8]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x0, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cmp x0, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cset x0, eq
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x0, [sp, #208]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x0, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x2, [sp, #208]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cmp x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b.ne Lfn4if250else
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #152]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cmp x0, #115
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b.ne Lfn4if256else
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
mov x0, #6
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
mov x1, #11
stp x16,x17,[sp,#-16]!
adrp x16, cnt14
ldr x17,[x16,:lo12:cnt14]
add x17,x17,#1
str x17,[x16,:lo12:cnt14]
ldp x16,x17,[sp],#16
bl fen_allocate
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cbz x0, Lfn4fail269_3
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x2, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x2, [x2, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x3, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x3, [x3, #8]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x3, [x3, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
stp x2, x3, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
adrp x2, Lconstant0
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
add x2, x2, :lo12:Lconstant0
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
str x2, [x0, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x0, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
mov x0, #6
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
mov x1, #11
stp x16,x17,[sp,#-16]!
adrp x16, cnt14
ldr x17,[x16,:lo12:cnt14]
add x17,x17,#1
str x17,[x16,:lo12:cnt14]
ldp x16,x17,[sp],#16
bl fen_allocate
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cbz x0, Lfn4fail266_3
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x2, [sp, #200]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x3, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x3, [x3, #8]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x3, [x3, #8]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
stp x2, x3, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x2, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
str x2, [x0, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x0, [sp, #88]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x8, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x9, [sp, #88]
stp x16,x17,[sp,#-16]!
adrp x16, cnt14
ldr x17,[x16,:lo12:cnt14]
add x17,x17,#1
str x17,[x16,:lo12:cnt14]
ldp x16,x17,[sp],#16
bl Lfn0fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cbnz x1, Lfn4end
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x0, [sp, #96]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x8, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x8, [x8, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x9, [sp, #96]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x10, [sp, #160]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x8, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x9, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x10, [sp, #136]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #88]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #104]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4loop
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4if256done
Lfn4if256else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
movn x0, #0, lsl #0
Lfn4if256done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4if250done
Lfn4if250else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x0, [sp, #152]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cmp x0, #98
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b.ne Lfn4if278else
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x8, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x9, [sp, #200]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x10, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x10, [x10, #8]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x10, [x10, #8]
stp x16,x17,[sp,#-16]!
adrp x16, cnt14
ldr x17,[x16,:lo12:cnt14]
add x17,x17,#1
str x17,[x16,:lo12:cnt14]
ldp x16,x17,[sp],#16
bl Lfn1fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cbnz x1, Lfn4end
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x0, [sp, #104]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x8, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x8, [x8, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x9, [sp, #104]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x10, [sp, #120]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x11, [sp, #128]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x12, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x13, [sp, #160]
stp x16,x17,[sp,#-16]!
adrp x16, cnt14
ldr x17,[x16,:lo12:cnt14]
add x17,x17,#1
str x17,[x16,:lo12:cnt14]
ldp x16,x17,[sp],#16
bl Lfn4fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cbnz x1, Lfn4end
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x0, [sp, #216]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x8, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x9, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x9, [x9, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x10, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x10, [x10, #8]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x10, [x10, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt14
ldr x17,[x16,:lo12:cnt14]
add x17,x17,#1
str x17,[x16,:lo12:cnt14]
ldp x16,x17,[sp],#16
bl Lfn1fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
cbnz x1, Lfn4end
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x0, [sp, #112]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x8, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ldr x8, [x8, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x9, [sp, #112]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldr x10, [sp, #216]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x8, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x9, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
str x10, [sp, #136]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #88]
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
stp xzr, xzr, [sp, #104]
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4loop
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4if278done
Lfn4if278else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
movn x0, #0, lsl #0
Lfn4if278done:
Lfn4if250done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4match177end
Lfn4match177end:
Lfn4if161done:
Lfn4if156done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4match137end
Lfn4match137end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4end
Lfn4fail169_4:
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
adrp x0, Lfn4fail169_4location
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn4fail169_4location
stp x16,x17,[sp,#-16]!
adrp x16, cnt14
ldr x17,[x16,:lo12:cnt14]
add x17,x17,#1
str x17,[x16,:lo12:cnt14]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
mov x1, #4
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4end
Lfn4fail174_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
adrp x0, Lfn4fail174_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn4fail174_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt14
ldr x17,[x16,:lo12:cnt14]
add x17,x17,#1
str x17,[x16,:lo12:cnt14]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4end
Lfn4fail269_3:
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
adrp x0, Lfn4fail269_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn4fail269_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt14
ldr x17,[x16,:lo12:cnt14]
add x17,x17,#1
str x17,[x16,:lo12:cnt14]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
mov x1, #3
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4end
Lfn4fail266_3:
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
adrp x0, Lfn4fail266_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn4fail266_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt14
ldr x17,[x16,:lo12:cnt14]
add x17,x17,#1
str x17,[x16,:lo12:cnt14]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
mov x1, #3
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
b Lfn4end
Lfn4end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt14
ldr x17,[x16,:lo12:cnt14]
add x17,x17,#1
str x17,[x16,:lo12:cnt14]
ldp x16,x17,[sp],#16
bl fen_leave_result
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt13
ldr x17,[x16,:lo12:cnt13]
add x17,x17,#1
str x17,[x16,:lo12:cnt13]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt12
ldr x17,[x16,:lo12:cnt12]
add x17,x17,#1
str x17,[x16,:lo12:cnt12]
ldp x16,x17,[sp],#16
ret
Lfn5:
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldp x8, x9, [x0, #0]
Lfn5fields:
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp x29, x30, [sp, #-16]!
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
mov x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
sub sp, sp, #128
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str xzr, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
stp x8, x9, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
add x0, sp, #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
add x1, sp, #48
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
mov x2, #3
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl fen_enter
Lfn5loop:
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x0, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
mov x0, #6
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
mov x1, #11
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl fen_allocate
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cbz x0, Lfn5fail322_3
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x2, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x3, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
stp x2, x3, [x0, #0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
adrp x2, Lconstant0
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
add x2, x2, :lo12:Lconstant0
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
str x2, [x0, #16]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x0, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x0, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x0, [sp, #88]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x0, [sp, #96]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x8, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
adrp x9, Lconstant0
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
add x9, x9, :lo12:Lconstant0
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x10, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x11, [sp, #88]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x12, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x13, [sp, #96]
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl Lfn4fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cbnz x1, Lfn5end
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x0, [sp, #104]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x0, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ldr x0, [x0]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
str x0, [sp, #112]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x0, [sp, #104]
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldr x2, [sp, #112]
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cmp x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
cset x0, eq
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5end
Lfn5fail322_3:
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
adrp x0, Lfn5fail322_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn5fail322_3location
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
mov x1, #3
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
b Lfn5end
Lfn5end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt17
ldr x17,[x16,:lo12:cnt17]
add x17,x17,#1
str x17,[x16,:lo12:cnt17]
ldp x16,x17,[sp],#16
bl fen_leave_result
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt16
ldr x17,[x16,:lo12:cnt16]
add x17,x17,#1
str x17,[x16,:lo12:cnt16]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt15
ldr x17,[x16,:lo12:cnt15]
add x17,x17,#1
str x17,[x16,:lo12:cnt15]
ldp x16,x17,[sp],#16
ret
Lfn6:
stp x16,x17,[sp,#-16]!
adrp x16, cnt18
ldr x17,[x16,:lo12:cnt18]
add x17,x17,#1
str x17,[x16,:lo12:cnt18]
ldp x16,x17,[sp],#16
stp x29, x30, [sp, #-16]!
stp x16,x17,[sp,#-16]!
adrp x16, cnt19
ldr x17,[x16,:lo12:cnt19]
add x17,x17,#1
str x17,[x16,:lo12:cnt19]
ldp x16,x17,[sp],#16
mov x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt19
ldr x17,[x16,:lo12:cnt19]
add x17,x17,#1
str x17,[x16,:lo12:cnt19]
ldp x16,x17,[sp],#16
sub sp, sp, #64
stp x16,x17,[sp,#-16]!
adrp x16, cnt18
ldr x17,[x16,:lo12:cnt18]
add x17,x17,#1
str x17,[x16,:lo12:cnt18]
ldp x16,x17,[sp],#16
str x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt19
ldr x17,[x16,:lo12:cnt19]
add x17,x17,#1
str x17,[x16,:lo12:cnt19]
ldp x16,x17,[sp],#16
adrp x8, Lconstant2
stp x16,x17,[sp,#-16]!
adrp x16, cnt19
ldr x17,[x16,:lo12:cnt19]
add x17,x17,#1
str x17,[x16,:lo12:cnt19]
ldp x16,x17,[sp],#16
add x8, x8, :lo12:Lconstant2
stp x16,x17,[sp,#-16]!
adrp x16, cnt19
ldr x17,[x16,:lo12:cnt19]
add x17,x17,#1
str x17,[x16,:lo12:cnt19]
ldp x16,x17,[sp],#16
adrp x9, Lconstant3
stp x16,x17,[sp,#-16]!
adrp x16, cnt19
ldr x17,[x16,:lo12:cnt19]
add x17,x17,#1
str x17,[x16,:lo12:cnt19]
ldp x16,x17,[sp],#16
add x9, x9, :lo12:Lconstant3
stp x16,x17,[sp,#-16]!
adrp x16, cnt20
ldr x17,[x16,:lo12:cnt20]
add x17,x17,#1
str x17,[x16,:lo12:cnt20]
ldp x16,x17,[sp],#16
bl Lfn5fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt19
ldr x17,[x16,:lo12:cnt19]
add x17,x17,#1
str x17,[x16,:lo12:cnt19]
ldp x16,x17,[sp],#16
cbnz x1, Lfn6end
stp x16,x17,[sp,#-16]!
adrp x16, cnt19
ldr x17,[x16,:lo12:cnt19]
add x17,x17,#1
str x17,[x16,:lo12:cnt19]
ldp x16,x17,[sp],#16
cbz x0, Lfn6if335else
stp x16,x17,[sp,#-16]!
adrp x16, cnt19
ldr x17,[x16,:lo12:cnt19]
add x17,x17,#1
str x17,[x16,:lo12:cnt19]
ldp x16,x17,[sp],#16
movz x0, #1, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt19
ldr x17,[x16,:lo12:cnt19]
add x17,x17,#1
str x17,[x16,:lo12:cnt19]
ldp x16,x17,[sp],#16
b Lfn6if335done
Lfn6if335else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt19
ldr x17,[x16,:lo12:cnt19]
add x17,x17,#1
str x17,[x16,:lo12:cnt19]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
Lfn6if335done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt19
ldr x17,[x16,:lo12:cnt19]
add x17,x17,#1
str x17,[x16,:lo12:cnt19]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt19
ldr x17,[x16,:lo12:cnt19]
add x17,x17,#1
str x17,[x16,:lo12:cnt19]
ldp x16,x17,[sp],#16
b Lfn6end
Lfn6end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt19
ldr x17,[x16,:lo12:cnt19]
add x17,x17,#1
str x17,[x16,:lo12:cnt19]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt18
ldr x17,[x16,:lo12:cnt18]
add x17,x17,#1
str x17,[x16,:lo12:cnt18]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt19
ldr x17,[x16,:lo12:cnt19]
add x17,x17,#1
str x17,[x16,:lo12:cnt19]
ldp x16,x17,[sp],#16
ret
Lfn7:
stp x16,x17,[sp,#-16]!
adrp x16, cnt21
ldr x17,[x16,:lo12:cnt21]
add x17,x17,#1
str x17,[x16,:lo12:cnt21]
ldp x16,x17,[sp],#16
stp x29, x30, [sp, #-16]!
stp x16,x17,[sp,#-16]!
adrp x16, cnt22
ldr x17,[x16,:lo12:cnt22]
add x17,x17,#1
str x17,[x16,:lo12:cnt22]
ldp x16,x17,[sp],#16
mov x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt22
ldr x17,[x16,:lo12:cnt22]
add x17,x17,#1
str x17,[x16,:lo12:cnt22]
ldp x16,x17,[sp],#16
sub sp, sp, #64
stp x16,x17,[sp,#-16]!
adrp x16, cnt21
ldr x17,[x16,:lo12:cnt21]
add x17,x17,#1
str x17,[x16,:lo12:cnt21]
ldp x16,x17,[sp],#16
str x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt22
ldr x17,[x16,:lo12:cnt22]
add x17,x17,#1
str x17,[x16,:lo12:cnt22]
ldp x16,x17,[sp],#16
adrp x8, Lconstant5
stp x16,x17,[sp,#-16]!
adrp x16, cnt22
ldr x17,[x16,:lo12:cnt22]
add x17,x17,#1
str x17,[x16,:lo12:cnt22]
ldp x16,x17,[sp],#16
add x8, x8, :lo12:Lconstant5
stp x16,x17,[sp,#-16]!
adrp x16, cnt22
ldr x17,[x16,:lo12:cnt22]
add x17,x17,#1
str x17,[x16,:lo12:cnt22]
ldp x16,x17,[sp],#16
adrp x9, Lconstant6
stp x16,x17,[sp,#-16]!
adrp x16, cnt22
ldr x17,[x16,:lo12:cnt22]
add x17,x17,#1
str x17,[x16,:lo12:cnt22]
ldp x16,x17,[sp],#16
add x9, x9, :lo12:Lconstant6
stp x16,x17,[sp,#-16]!
adrp x16, cnt23
ldr x17,[x16,:lo12:cnt23]
add x17,x17,#1
str x17,[x16,:lo12:cnt23]
ldp x16,x17,[sp],#16
bl Lfn5fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt22
ldr x17,[x16,:lo12:cnt22]
add x17,x17,#1
str x17,[x16,:lo12:cnt22]
ldp x16,x17,[sp],#16
cbnz x1, Lfn7end
stp x16,x17,[sp,#-16]!
adrp x16, cnt22
ldr x17,[x16,:lo12:cnt22]
add x17,x17,#1
str x17,[x16,:lo12:cnt22]
ldp x16,x17,[sp],#16
cbz x0, Lfn7if349else
stp x16,x17,[sp,#-16]!
adrp x16, cnt22
ldr x17,[x16,:lo12:cnt22]
add x17,x17,#1
str x17,[x16,:lo12:cnt22]
ldp x16,x17,[sp],#16
movz x0, #1, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt22
ldr x17,[x16,:lo12:cnt22]
add x17,x17,#1
str x17,[x16,:lo12:cnt22]
ldp x16,x17,[sp],#16
b Lfn7if349done
Lfn7if349else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt22
ldr x17,[x16,:lo12:cnt22]
add x17,x17,#1
str x17,[x16,:lo12:cnt22]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
Lfn7if349done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt22
ldr x17,[x16,:lo12:cnt22]
add x17,x17,#1
str x17,[x16,:lo12:cnt22]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt22
ldr x17,[x16,:lo12:cnt22]
add x17,x17,#1
str x17,[x16,:lo12:cnt22]
ldp x16,x17,[sp],#16
b Lfn7end
Lfn7end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt22
ldr x17,[x16,:lo12:cnt22]
add x17,x17,#1
str x17,[x16,:lo12:cnt22]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt21
ldr x17,[x16,:lo12:cnt21]
add x17,x17,#1
str x17,[x16,:lo12:cnt21]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt22
ldr x17,[x16,:lo12:cnt22]
add x17,x17,#1
str x17,[x16,:lo12:cnt22]
ldp x16,x17,[sp],#16
ret
Lfn8:
stp x16,x17,[sp,#-16]!
adrp x16, cnt24
ldr x17,[x16,:lo12:cnt24]
add x17,x17,#1
str x17,[x16,:lo12:cnt24]
ldp x16,x17,[sp],#16
stp x29, x30, [sp, #-16]!
stp x16,x17,[sp,#-16]!
adrp x16, cnt25
ldr x17,[x16,:lo12:cnt25]
add x17,x17,#1
str x17,[x16,:lo12:cnt25]
ldp x16,x17,[sp],#16
mov x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt25
ldr x17,[x16,:lo12:cnt25]
add x17,x17,#1
str x17,[x16,:lo12:cnt25]
ldp x16,x17,[sp],#16
sub sp, sp, #64
stp x16,x17,[sp,#-16]!
adrp x16, cnt24
ldr x17,[x16,:lo12:cnt24]
add x17,x17,#1
str x17,[x16,:lo12:cnt24]
ldp x16,x17,[sp],#16
str x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt25
ldr x17,[x16,:lo12:cnt25]
add x17,x17,#1
str x17,[x16,:lo12:cnt25]
ldp x16,x17,[sp],#16
adrp x8, Lconstant10
stp x16,x17,[sp,#-16]!
adrp x16, cnt25
ldr x17,[x16,:lo12:cnt25]
add x17,x17,#1
str x17,[x16,:lo12:cnt25]
ldp x16,x17,[sp],#16
add x8, x8, :lo12:Lconstant10
stp x16,x17,[sp,#-16]!
adrp x16, cnt25
ldr x17,[x16,:lo12:cnt25]
add x17,x17,#1
str x17,[x16,:lo12:cnt25]
ldp x16,x17,[sp],#16
adrp x9, Lconstant11
stp x16,x17,[sp,#-16]!
adrp x16, cnt25
ldr x17,[x16,:lo12:cnt25]
add x17,x17,#1
str x17,[x16,:lo12:cnt25]
ldp x16,x17,[sp],#16
add x9, x9, :lo12:Lconstant11
stp x16,x17,[sp,#-16]!
adrp x16, cnt26
ldr x17,[x16,:lo12:cnt26]
add x17,x17,#1
str x17,[x16,:lo12:cnt26]
ldp x16,x17,[sp],#16
bl Lfn5fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt25
ldr x17,[x16,:lo12:cnt25]
add x17,x17,#1
str x17,[x16,:lo12:cnt25]
ldp x16,x17,[sp],#16
cbnz x1, Lfn8end
stp x16,x17,[sp,#-16]!
adrp x16, cnt25
ldr x17,[x16,:lo12:cnt25]
add x17,x17,#1
str x17,[x16,:lo12:cnt25]
ldp x16,x17,[sp],#16
cbz x0, Lfn8if364else
stp x16,x17,[sp,#-16]!
adrp x16, cnt25
ldr x17,[x16,:lo12:cnt25]
add x17,x17,#1
str x17,[x16,:lo12:cnt25]
ldp x16,x17,[sp],#16
movz x0, #1, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt25
ldr x17,[x16,:lo12:cnt25]
add x17,x17,#1
str x17,[x16,:lo12:cnt25]
ldp x16,x17,[sp],#16
b Lfn8if364done
Lfn8if364else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt25
ldr x17,[x16,:lo12:cnt25]
add x17,x17,#1
str x17,[x16,:lo12:cnt25]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
Lfn8if364done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt25
ldr x17,[x16,:lo12:cnt25]
add x17,x17,#1
str x17,[x16,:lo12:cnt25]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt25
ldr x17,[x16,:lo12:cnt25]
add x17,x17,#1
str x17,[x16,:lo12:cnt25]
ldp x16,x17,[sp],#16
b Lfn8end
Lfn8end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt25
ldr x17,[x16,:lo12:cnt25]
add x17,x17,#1
str x17,[x16,:lo12:cnt25]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt24
ldr x17,[x16,:lo12:cnt24]
add x17,x17,#1
str x17,[x16,:lo12:cnt24]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt25
ldr x17,[x16,:lo12:cnt25]
add x17,x17,#1
str x17,[x16,:lo12:cnt25]
ldp x16,x17,[sp],#16
ret
Lfn9:
stp x16,x17,[sp,#-16]!
adrp x16, cnt27
ldr x17,[x16,:lo12:cnt27]
add x17,x17,#1
str x17,[x16,:lo12:cnt27]
ldp x16,x17,[sp],#16
stp x29, x30, [sp, #-16]!
stp x16,x17,[sp,#-16]!
adrp x16, cnt28
ldr x17,[x16,:lo12:cnt28]
add x17,x17,#1
str x17,[x16,:lo12:cnt28]
ldp x16,x17,[sp],#16
mov x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt28
ldr x17,[x16,:lo12:cnt28]
add x17,x17,#1
str x17,[x16,:lo12:cnt28]
ldp x16,x17,[sp],#16
sub sp, sp, #64
stp x16,x17,[sp,#-16]!
adrp x16, cnt27
ldr x17,[x16,:lo12:cnt27]
add x17,x17,#1
str x17,[x16,:lo12:cnt27]
ldp x16,x17,[sp],#16
str x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt28
ldr x17,[x16,:lo12:cnt28]
add x17,x17,#1
str x17,[x16,:lo12:cnt28]
ldp x16,x17,[sp],#16
adrp x8, Lconstant18
stp x16,x17,[sp,#-16]!
adrp x16, cnt28
ldr x17,[x16,:lo12:cnt28]
add x17,x17,#1
str x17,[x16,:lo12:cnt28]
ldp x16,x17,[sp],#16
add x8, x8, :lo12:Lconstant18
stp x16,x17,[sp,#-16]!
adrp x16, cnt28
ldr x17,[x16,:lo12:cnt28]
add x17,x17,#1
str x17,[x16,:lo12:cnt28]
ldp x16,x17,[sp],#16
adrp x9, Lconstant19
stp x16,x17,[sp,#-16]!
adrp x16, cnt28
ldr x17,[x16,:lo12:cnt28]
add x17,x17,#1
str x17,[x16,:lo12:cnt28]
ldp x16,x17,[sp],#16
add x9, x9, :lo12:Lconstant19
stp x16,x17,[sp,#-16]!
adrp x16, cnt29
ldr x17,[x16,:lo12:cnt29]
add x17,x17,#1
str x17,[x16,:lo12:cnt29]
ldp x16,x17,[sp],#16
bl Lfn5fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt28
ldr x17,[x16,:lo12:cnt28]
add x17,x17,#1
str x17,[x16,:lo12:cnt28]
ldp x16,x17,[sp],#16
cbnz x1, Lfn9end
stp x16,x17,[sp,#-16]!
adrp x16, cnt28
ldr x17,[x16,:lo12:cnt28]
add x17,x17,#1
str x17,[x16,:lo12:cnt28]
ldp x16,x17,[sp],#16
cbz x0, Lfn9if386else
stp x16,x17,[sp,#-16]!
adrp x16, cnt28
ldr x17,[x16,:lo12:cnt28]
add x17,x17,#1
str x17,[x16,:lo12:cnt28]
ldp x16,x17,[sp],#16
movz x0, #1, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt28
ldr x17,[x16,:lo12:cnt28]
add x17,x17,#1
str x17,[x16,:lo12:cnt28]
ldp x16,x17,[sp],#16
b Lfn9if386done
Lfn9if386else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt28
ldr x17,[x16,:lo12:cnt28]
add x17,x17,#1
str x17,[x16,:lo12:cnt28]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
Lfn9if386done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt28
ldr x17,[x16,:lo12:cnt28]
add x17,x17,#1
str x17,[x16,:lo12:cnt28]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt28
ldr x17,[x16,:lo12:cnt28]
add x17,x17,#1
str x17,[x16,:lo12:cnt28]
ldp x16,x17,[sp],#16
b Lfn9end
Lfn9end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt28
ldr x17,[x16,:lo12:cnt28]
add x17,x17,#1
str x17,[x16,:lo12:cnt28]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt27
ldr x17,[x16,:lo12:cnt27]
add x17,x17,#1
str x17,[x16,:lo12:cnt27]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt28
ldr x17,[x16,:lo12:cnt28]
add x17,x17,#1
str x17,[x16,:lo12:cnt28]
ldp x16,x17,[sp],#16
ret
Lfn10:
stp x16,x17,[sp,#-16]!
adrp x16, cnt30
ldr x17,[x16,:lo12:cnt30]
add x17,x17,#1
str x17,[x16,:lo12:cnt30]
ldp x16,x17,[sp],#16
stp x29, x30, [sp, #-16]!
stp x16,x17,[sp,#-16]!
adrp x16, cnt31
ldr x17,[x16,:lo12:cnt31]
add x17,x17,#1
str x17,[x16,:lo12:cnt31]
ldp x16,x17,[sp],#16
mov x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt31
ldr x17,[x16,:lo12:cnt31]
add x17,x17,#1
str x17,[x16,:lo12:cnt31]
ldp x16,x17,[sp],#16
sub sp, sp, #64
stp x16,x17,[sp,#-16]!
adrp x16, cnt30
ldr x17,[x16,:lo12:cnt30]
add x17,x17,#1
str x17,[x16,:lo12:cnt30]
ldp x16,x17,[sp],#16
str x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt31
ldr x17,[x16,:lo12:cnt31]
add x17,x17,#1
str x17,[x16,:lo12:cnt31]
ldp x16,x17,[sp],#16
adrp x8, Lconstant23
stp x16,x17,[sp,#-16]!
adrp x16, cnt31
ldr x17,[x16,:lo12:cnt31]
add x17,x17,#1
str x17,[x16,:lo12:cnt31]
ldp x16,x17,[sp],#16
add x8, x8, :lo12:Lconstant23
stp x16,x17,[sp,#-16]!
adrp x16, cnt31
ldr x17,[x16,:lo12:cnt31]
add x17,x17,#1
str x17,[x16,:lo12:cnt31]
ldp x16,x17,[sp],#16
adrp x9, Lconstant24
stp x16,x17,[sp,#-16]!
adrp x16, cnt31
ldr x17,[x16,:lo12:cnt31]
add x17,x17,#1
str x17,[x16,:lo12:cnt31]
ldp x16,x17,[sp],#16
add x9, x9, :lo12:Lconstant24
stp x16,x17,[sp,#-16]!
adrp x16, cnt32
ldr x17,[x16,:lo12:cnt32]
add x17,x17,#1
str x17,[x16,:lo12:cnt32]
ldp x16,x17,[sp],#16
bl Lfn5fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt31
ldr x17,[x16,:lo12:cnt31]
add x17,x17,#1
str x17,[x16,:lo12:cnt31]
ldp x16,x17,[sp],#16
cbnz x1, Lfn10end
stp x16,x17,[sp,#-16]!
adrp x16, cnt31
ldr x17,[x16,:lo12:cnt31]
add x17,x17,#1
str x17,[x16,:lo12:cnt31]
ldp x16,x17,[sp],#16
cbz x0, Lfn10if420else
stp x16,x17,[sp,#-16]!
adrp x16, cnt31
ldr x17,[x16,:lo12:cnt31]
add x17,x17,#1
str x17,[x16,:lo12:cnt31]
ldp x16,x17,[sp],#16
movz x0, #1, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt31
ldr x17,[x16,:lo12:cnt31]
add x17,x17,#1
str x17,[x16,:lo12:cnt31]
ldp x16,x17,[sp],#16
b Lfn10if420done
Lfn10if420else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt31
ldr x17,[x16,:lo12:cnt31]
add x17,x17,#1
str x17,[x16,:lo12:cnt31]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
Lfn10if420done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt31
ldr x17,[x16,:lo12:cnt31]
add x17,x17,#1
str x17,[x16,:lo12:cnt31]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt31
ldr x17,[x16,:lo12:cnt31]
add x17,x17,#1
str x17,[x16,:lo12:cnt31]
ldp x16,x17,[sp],#16
b Lfn10end
Lfn10end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt31
ldr x17,[x16,:lo12:cnt31]
add x17,x17,#1
str x17,[x16,:lo12:cnt31]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt30
ldr x17,[x16,:lo12:cnt30]
add x17,x17,#1
str x17,[x16,:lo12:cnt30]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt31
ldr x17,[x16,:lo12:cnt31]
add x17,x17,#1
str x17,[x16,:lo12:cnt31]
ldp x16,x17,[sp],#16
ret
Lfn11:
stp x16,x17,[sp,#-16]!
adrp x16, cnt33
ldr x17,[x16,:lo12:cnt33]
add x17,x17,#1
str x17,[x16,:lo12:cnt33]
ldp x16,x17,[sp],#16
stp x29, x30, [sp, #-16]!
stp x16,x17,[sp,#-16]!
adrp x16, cnt34
ldr x17,[x16,:lo12:cnt34]
add x17,x17,#1
str x17,[x16,:lo12:cnt34]
ldp x16,x17,[sp],#16
mov x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt34
ldr x17,[x16,:lo12:cnt34]
add x17,x17,#1
str x17,[x16,:lo12:cnt34]
ldp x16,x17,[sp],#16
sub sp, sp, #64
stp x16,x17,[sp,#-16]!
adrp x16, cnt33
ldr x17,[x16,:lo12:cnt33]
add x17,x17,#1
str x17,[x16,:lo12:cnt33]
ldp x16,x17,[sp],#16
str x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt34
ldr x17,[x16,:lo12:cnt34]
add x17,x17,#1
str x17,[x16,:lo12:cnt34]
ldp x16,x17,[sp],#16
adrp x8, Lconstant26
stp x16,x17,[sp,#-16]!
adrp x16, cnt34
ldr x17,[x16,:lo12:cnt34]
add x17,x17,#1
str x17,[x16,:lo12:cnt34]
ldp x16,x17,[sp],#16
add x8, x8, :lo12:Lconstant26
stp x16,x17,[sp,#-16]!
adrp x16, cnt34
ldr x17,[x16,:lo12:cnt34]
add x17,x17,#1
str x17,[x16,:lo12:cnt34]
ldp x16,x17,[sp],#16
adrp x9, Lconstant27
stp x16,x17,[sp,#-16]!
adrp x16, cnt34
ldr x17,[x16,:lo12:cnt34]
add x17,x17,#1
str x17,[x16,:lo12:cnt34]
ldp x16,x17,[sp],#16
add x9, x9, :lo12:Lconstant27
stp x16,x17,[sp,#-16]!
adrp x16, cnt35
ldr x17,[x16,:lo12:cnt35]
add x17,x17,#1
str x17,[x16,:lo12:cnt35]
ldp x16,x17,[sp],#16
bl Lfn5fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt34
ldr x17,[x16,:lo12:cnt34]
add x17,x17,#1
str x17,[x16,:lo12:cnt34]
ldp x16,x17,[sp],#16
cbnz x1, Lfn11end
stp x16,x17,[sp,#-16]!
adrp x16, cnt34
ldr x17,[x16,:lo12:cnt34]
add x17,x17,#1
str x17,[x16,:lo12:cnt34]
ldp x16,x17,[sp],#16
cbz x0, Lfn11if450else
stp x16,x17,[sp,#-16]!
adrp x16, cnt34
ldr x17,[x16,:lo12:cnt34]
add x17,x17,#1
str x17,[x16,:lo12:cnt34]
ldp x16,x17,[sp],#16
movz x0, #1, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt34
ldr x17,[x16,:lo12:cnt34]
add x17,x17,#1
str x17,[x16,:lo12:cnt34]
ldp x16,x17,[sp],#16
b Lfn11if450done
Lfn11if450else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt34
ldr x17,[x16,:lo12:cnt34]
add x17,x17,#1
str x17,[x16,:lo12:cnt34]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
Lfn11if450done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt34
ldr x17,[x16,:lo12:cnt34]
add x17,x17,#1
str x17,[x16,:lo12:cnt34]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt34
ldr x17,[x16,:lo12:cnt34]
add x17,x17,#1
str x17,[x16,:lo12:cnt34]
ldp x16,x17,[sp],#16
b Lfn11end
Lfn11end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt34
ldr x17,[x16,:lo12:cnt34]
add x17,x17,#1
str x17,[x16,:lo12:cnt34]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt33
ldr x17,[x16,:lo12:cnt33]
add x17,x17,#1
str x17,[x16,:lo12:cnt33]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt34
ldr x17,[x16,:lo12:cnt34]
add x17,x17,#1
str x17,[x16,:lo12:cnt34]
ldp x16,x17,[sp],#16
ret
Lfn12:
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
stp x29, x30, [sp, #-16]!
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
mov x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
sub sp, sp, #160
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
str x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
str x0, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt38
ldr x17,[x16,:lo12:cnt38]
add x17,x17,#1
str x17,[x16,:lo12:cnt38]
ldp x16,x17,[sp],#16
bl Lfn6
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
cbnz x1, Lfn12end
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
str x0, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
ldr x0, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
ldr x2, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
b.vs Lfn12fail477_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
str x0, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt38
ldr x17,[x16,:lo12:cnt38]
add x17,x17,#1
str x17,[x16,:lo12:cnt38]
ldp x16,x17,[sp],#16
bl Lfn7
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
cbnz x1, Lfn12end
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
str x0, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
ldr x0, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
ldr x2, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
b.vs Lfn12fail476_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
str x0, [sp, #88]
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt38
ldr x17,[x16,:lo12:cnt38]
add x17,x17,#1
str x17,[x16,:lo12:cnt38]
ldp x16,x17,[sp],#16
bl Lfn8
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
cbnz x1, Lfn12end
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
str x0, [sp, #96]
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
ldr x0, [sp, #88]
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
ldr x2, [sp, #96]
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
b.vs Lfn12fail475_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
str x0, [sp, #104]
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt38
ldr x17,[x16,:lo12:cnt38]
add x17,x17,#1
str x17,[x16,:lo12:cnt38]
ldp x16,x17,[sp],#16
bl Lfn9
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
cbnz x1, Lfn12end
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
str x0, [sp, #112]
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
ldr x0, [sp, #104]
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
ldr x2, [sp, #112]
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
b.vs Lfn12fail474_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
str x0, [sp, #120]
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt38
ldr x17,[x16,:lo12:cnt38]
add x17,x17,#1
str x17,[x16,:lo12:cnt38]
ldp x16,x17,[sp],#16
bl Lfn10
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
cbnz x1, Lfn12end
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
str x0, [sp, #128]
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
ldr x0, [sp, #120]
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
ldr x2, [sp, #128]
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
b.vs Lfn12fail473_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
str x0, [sp, #136]
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt38
ldr x17,[x16,:lo12:cnt38]
add x17,x17,#1
str x17,[x16,:lo12:cnt38]
ldp x16,x17,[sp],#16
bl Lfn11
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
cbnz x1, Lfn12end
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
str x0, [sp, #144]
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
ldr x0, [sp, #136]
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
ldr x2, [sp, #144]
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
b.vs Lfn12fail472_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
b Lfn12end
Lfn12fail477_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
adrp x0, Lfn12fail477_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn12fail477_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt38
ldr x17,[x16,:lo12:cnt38]
add x17,x17,#1
str x17,[x16,:lo12:cnt38]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
b Lfn12end
Lfn12fail476_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
adrp x0, Lfn12fail476_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn12fail476_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt38
ldr x17,[x16,:lo12:cnt38]
add x17,x17,#1
str x17,[x16,:lo12:cnt38]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
b Lfn12end
Lfn12fail475_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
adrp x0, Lfn12fail475_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn12fail475_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt38
ldr x17,[x16,:lo12:cnt38]
add x17,x17,#1
str x17,[x16,:lo12:cnt38]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
b Lfn12end
Lfn12fail474_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
adrp x0, Lfn12fail474_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn12fail474_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt38
ldr x17,[x16,:lo12:cnt38]
add x17,x17,#1
str x17,[x16,:lo12:cnt38]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
b Lfn12end
Lfn12fail473_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
adrp x0, Lfn12fail473_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn12fail473_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt38
ldr x17,[x16,:lo12:cnt38]
add x17,x17,#1
str x17,[x16,:lo12:cnt38]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
b Lfn12end
Lfn12fail472_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
adrp x0, Lfn12fail472_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn12fail472_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt38
ldr x17,[x16,:lo12:cnt38]
add x17,x17,#1
str x17,[x16,:lo12:cnt38]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
b Lfn12end
Lfn12end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt36
ldr x17,[x16,:lo12:cnt36]
add x17,x17,#1
str x17,[x16,:lo12:cnt36]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt37
ldr x17,[x16,:lo12:cnt37]
add x17,x17,#1
str x17,[x16,:lo12:cnt37]
ldp x16,x17,[sp],#16
ret
Lfn13:
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
ldp x8, x9, [x0, #0]
Lfn13fields:
stp x16,x17,[sp,#-16]!
adrp x16, cnt40
ldr x17,[x16,:lo12:cnt40]
add x17,x17,#1
str x17,[x16,:lo12:cnt40]
ldp x16,x17,[sp],#16
stp x29, x30, [sp, #-16]!
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
mov x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
sub sp, sp, #96
stp x16,x17,[sp,#-16]!
adrp x16, cnt40
ldr x17,[x16,:lo12:cnt40]
add x17,x17,#1
str x17,[x16,:lo12:cnt40]
ldp x16,x17,[sp],#16
stp x8, x9, [sp, #48]
Lfn13loop:
stp x16,x17,[sp,#-16]!
adrp x16, cnt40
ldr x17,[x16,:lo12:cnt40]
add x17,x17,#1
str x17,[x16,:lo12:cnt40]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
cmp x0, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
b.gt Lfn13if501else
stp x16,x17,[sp,#-16]!
adrp x16, cnt40
ldr x17,[x16,:lo12:cnt40]
add x17,x17,#1
str x17,[x16,:lo12:cnt40]
ldp x16,x17,[sp],#16
ldr x0, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
b Lfn13if501done
Lfn13if501else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt40
ldr x17,[x16,:lo12:cnt40]
add x17,x17,#1
str x17,[x16,:lo12:cnt40]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
subs x0, x0, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
b.vs Lfn13fail508_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt40
ldr x17,[x16,:lo12:cnt40]
add x17,x17,#1
str x17,[x16,:lo12:cnt40]
ldp x16,x17,[sp],#16
str x0, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt40
ldr x17,[x16,:lo12:cnt40]
add x17,x17,#1
str x17,[x16,:lo12:cnt40]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt41
ldr x17,[x16,:lo12:cnt41]
add x17,x17,#1
str x17,[x16,:lo12:cnt41]
ldp x16,x17,[sp],#16
bl Lfn12
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
cbnz x1, Lfn13end
stp x16,x17,[sp,#-16]!
adrp x16, cnt40
ldr x17,[x16,:lo12:cnt40]
add x17,x17,#1
str x17,[x16,:lo12:cnt40]
ldp x16,x17,[sp],#16
str x0, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt40
ldr x17,[x16,:lo12:cnt40]
add x17,x17,#1
str x17,[x16,:lo12:cnt40]
ldp x16,x17,[sp],#16
ldr x0, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt40
ldr x17,[x16,:lo12:cnt40]
add x17,x17,#1
str x17,[x16,:lo12:cnt40]
ldp x16,x17,[sp],#16
ldr x2, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
b.vs Lfn13fail511_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt40
ldr x17,[x16,:lo12:cnt40]
add x17,x17,#1
str x17,[x16,:lo12:cnt40]
ldp x16,x17,[sp],#16
str x0, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt40
ldr x17,[x16,:lo12:cnt40]
add x17,x17,#1
str x17,[x16,:lo12:cnt40]
ldp x16,x17,[sp],#16
ldr x8, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt40
ldr x17,[x16,:lo12:cnt40]
add x17,x17,#1
str x17,[x16,:lo12:cnt40]
ldp x16,x17,[sp],#16
ldr x9, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt40
ldr x17,[x16,:lo12:cnt40]
add x17,x17,#1
str x17,[x16,:lo12:cnt40]
ldp x16,x17,[sp],#16
str x8, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt40
ldr x17,[x16,:lo12:cnt40]
add x17,x17,#1
str x17,[x16,:lo12:cnt40]
ldp x16,x17,[sp],#16
str x9, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
b Lfn13loop
Lfn13if501done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
b Lfn13end
Lfn13fail508_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
adrp x0, Lfn13fail508_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn13fail508_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt41
ldr x17,[x16,:lo12:cnt41]
add x17,x17,#1
str x17,[x16,:lo12:cnt41]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
b Lfn13end
Lfn13fail511_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
adrp x0, Lfn13fail511_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn13fail511_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt41
ldr x17,[x16,:lo12:cnt41]
add x17,x17,#1
str x17,[x16,:lo12:cnt41]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
b Lfn13end
Lfn13end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt40
ldr x17,[x16,:lo12:cnt40]
add x17,x17,#1
str x17,[x16,:lo12:cnt40]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt39
ldr x17,[x16,:lo12:cnt39]
add x17,x17,#1
str x17,[x16,:lo12:cnt39]
ldp x16,x17,[sp],#16
ret
.globl fenrir_entry
fenrir_entry:
Lfn14:
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
stp x29, x30, [sp, #-16]!
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
mov x29, sp
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
sub sp, sp, #352
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x0, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cmp x0, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b.ne Lfn14if517else
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x8, Lconstant2
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x8, x8, :lo12:Lconstant2
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x9, Lconstant28
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x9, x9, :lo12:Lconstant28
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl Lfn5fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbnz x1, Lfn14end
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbz x0, Lfn14if540else
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14if540done
Lfn14if540else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #1, lsl #0
Lfn14if540done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x0, [sp, #56]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x2, [sp, #64]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b.vs Lfn14fail538_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x8, Lconstant2
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x8, x8, :lo12:Lconstant2
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x9, Lconstant29
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x9, x9, :lo12:Lconstant29
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl Lfn5fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbnz x1, Lfn14end
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbz x0, Lfn14if552else
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14if552done
Lfn14if552else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #1, lsl #0
Lfn14if552done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x0, [sp, #72]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x2, [sp, #80]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b.vs Lfn14fail537_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #88]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x8, Lconstant2
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x8, x8, :lo12:Lconstant2
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x9, Lconstant30
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x9, x9, :lo12:Lconstant30
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl Lfn5fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbnz x1, Lfn14end
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbz x0, Lfn14if564else
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14if564done
Lfn14if564else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #1, lsl #0
Lfn14if564done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #96]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x0, [sp, #88]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x2, [sp, #96]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b.vs Lfn14fail536_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #104]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x8, Lconstant5
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x8, x8, :lo12:Lconstant5
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x9, Lconstant31
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x9, x9, :lo12:Lconstant31
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl Lfn5fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbnz x1, Lfn14end
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbz x0, Lfn14if576else
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14if576done
Lfn14if576else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #1, lsl #0
Lfn14if576done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #112]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x0, [sp, #104]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x2, [sp, #112]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b.vs Lfn14fail535_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #120]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x8, Lconstant5
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x8, x8, :lo12:Lconstant5
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x9, Lconstant32
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x9, x9, :lo12:Lconstant32
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl Lfn5fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbnz x1, Lfn14end
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbz x0, Lfn14if589else
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14if589done
Lfn14if589else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #1, lsl #0
Lfn14if589done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #128]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x0, [sp, #120]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x2, [sp, #128]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b.vs Lfn14fail534_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #136]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x8, Lconstant5
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x8, x8, :lo12:Lconstant5
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x9, Lconstant33
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x9, x9, :lo12:Lconstant33
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl Lfn5fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbnz x1, Lfn14end
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbz x0, Lfn14if602else
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14if602done
Lfn14if602else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #1, lsl #0
Lfn14if602done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #144]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x0, [sp, #136]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x2, [sp, #144]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b.vs Lfn14fail533_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #152]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x8, Lconstant10
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x8, x8, :lo12:Lconstant10
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x9, Lconstant34
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x9, x9, :lo12:Lconstant34
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl Lfn5fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbnz x1, Lfn14end
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbz x0, Lfn14if615else
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14if615done
Lfn14if615else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #1, lsl #0
Lfn14if615done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #160]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x0, [sp, #152]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x2, [sp, #160]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b.vs Lfn14fail532_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #168]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x8, Lconstant10
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x8, x8, :lo12:Lconstant10
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x9, Lconstant35
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x9, x9, :lo12:Lconstant35
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl Lfn5fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbnz x1, Lfn14end
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbz x0, Lfn14if635else
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14if635done
Lfn14if635else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #1, lsl #0
Lfn14if635done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #176]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x0, [sp, #168]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x2, [sp, #176]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b.vs Lfn14fail531_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #184]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x8, Lconstant10
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x8, x8, :lo12:Lconstant10
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x9, Lconstant36
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x9, x9, :lo12:Lconstant36
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl Lfn5fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbnz x1, Lfn14end
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbz x0, Lfn14if655else
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14if655done
Lfn14if655else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #1, lsl #0
Lfn14if655done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #192]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x0, [sp, #184]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x2, [sp, #192]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b.vs Lfn14fail530_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #200]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x8, Lconstant18
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x8, x8, :lo12:Lconstant18
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x9, Lconstant37
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x9, x9, :lo12:Lconstant37
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl Lfn5fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbnz x1, Lfn14end
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbz x0, Lfn14if675else
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14if675done
Lfn14if675else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #1, lsl #0
Lfn14if675done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #208]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x0, [sp, #200]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x2, [sp, #208]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b.vs Lfn14fail529_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #216]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x8, Lconstant18
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x8, x8, :lo12:Lconstant18
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x9, Lconstant38
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x9, x9, :lo12:Lconstant38
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl Lfn5fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbnz x1, Lfn14end
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbz x0, Lfn14if707else
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14if707done
Lfn14if707else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #1, lsl #0
Lfn14if707done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #224]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x0, [sp, #216]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x2, [sp, #224]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b.vs Lfn14fail528_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #232]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x8, Lconstant18
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x8, x8, :lo12:Lconstant18
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x9, Lconstant39
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x9, x9, :lo12:Lconstant39
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl Lfn5fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbnz x1, Lfn14end
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbz x0, Lfn14if739else
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14if739done
Lfn14if739else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #1, lsl #0
Lfn14if739done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #240]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x0, [sp, #232]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x2, [sp, #240]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b.vs Lfn14fail527_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #248]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x8, Lconstant23
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x8, x8, :lo12:Lconstant23
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x9, Lconstant40
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x9, x9, :lo12:Lconstant40
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl Lfn5fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbnz x1, Lfn14end
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbz x0, Lfn14if771else
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14if771done
Lfn14if771else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #1, lsl #0
Lfn14if771done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #256]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x0, [sp, #248]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x2, [sp, #256]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b.vs Lfn14fail526_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #264]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x8, Lconstant23
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x8, x8, :lo12:Lconstant23
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x9, Lconstant41
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x9, x9, :lo12:Lconstant41
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl Lfn5fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbnz x1, Lfn14end
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbz x0, Lfn14if799else
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14if799done
Lfn14if799else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #1, lsl #0
Lfn14if799done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #272]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x0, [sp, #264]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x2, [sp, #272]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b.vs Lfn14fail525_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #280]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x8, Lconstant23
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x8, x8, :lo12:Lconstant23
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x9, Lconstant42
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x9, x9, :lo12:Lconstant42
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl Lfn5fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbnz x1, Lfn14end
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbz x0, Lfn14if827else
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14if827done
Lfn14if827else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #1, lsl #0
Lfn14if827done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #288]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x0, [sp, #280]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x2, [sp, #288]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b.vs Lfn14fail524_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #296]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x8, Lconstant26
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x8, x8, :lo12:Lconstant26
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x9, Lconstant43
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x9, x9, :lo12:Lconstant43
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl Lfn5fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbnz x1, Lfn14end
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbz x0, Lfn14if855else
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14if855done
Lfn14if855else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #1, lsl #0
Lfn14if855done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #304]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x0, [sp, #296]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x2, [sp, #304]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b.vs Lfn14fail523_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #312]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x8, Lconstant26
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x8, x8, :lo12:Lconstant26
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x9, Lconstant44
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x9, x9, :lo12:Lconstant44
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl Lfn5fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbnz x1, Lfn14end
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbz x0, Lfn14if875else
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14if875done
Lfn14if875else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #1, lsl #0
Lfn14if875done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #320]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x0, [sp, #312]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x2, [sp, #320]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b.vs Lfn14fail522_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #328]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x8, Lconstant26
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x8, x8, :lo12:Lconstant26
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x9, Lconstant45
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x9, x9, :lo12:Lconstant45
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl Lfn5fields
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbnz x1, Lfn14end
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
cbz x0, Lfn14if895else
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14if895done
Lfn14if895else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #1, lsl #0
Lfn14if895done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #336]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x0, [sp, #328]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x2, [sp, #336]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adds x0, x0, x2
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b.vs Lfn14fail521_1
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14if517done
Lfn14if517else:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
movz x0, #0, lsl #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
str x0, [sp, #344]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x8, [sp, #48]
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldr x9, [sp, #344]
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn13fields
Lfn14if517done:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
mov x1, #0
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14end
Lfn14fail538_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x0, Lfn14fail538_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn14fail538_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14end
Lfn14fail537_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x0, Lfn14fail537_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn14fail537_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14end
Lfn14fail536_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x0, Lfn14fail536_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn14fail536_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14end
Lfn14fail535_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x0, Lfn14fail535_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn14fail535_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14end
Lfn14fail534_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x0, Lfn14fail534_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn14fail534_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14end
Lfn14fail533_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x0, Lfn14fail533_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn14fail533_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14end
Lfn14fail532_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x0, Lfn14fail532_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn14fail532_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14end
Lfn14fail531_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x0, Lfn14fail531_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn14fail531_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14end
Lfn14fail530_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x0, Lfn14fail530_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn14fail530_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14end
Lfn14fail529_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x0, Lfn14fail529_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn14fail529_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14end
Lfn14fail528_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x0, Lfn14fail528_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn14fail528_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14end
Lfn14fail527_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x0, Lfn14fail527_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn14fail527_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14end
Lfn14fail526_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x0, Lfn14fail526_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn14fail526_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14end
Lfn14fail525_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x0, Lfn14fail525_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn14fail525_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14end
Lfn14fail524_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x0, Lfn14fail524_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn14fail524_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14end
Lfn14fail523_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x0, Lfn14fail523_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn14fail523_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14end
Lfn14fail522_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x0, Lfn14fail522_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn14fail522_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14end
Lfn14fail521_1:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
adrp x0, Lfn14fail521_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
add x0, x0, :lo12:Lfn14fail521_1location
stp x16,x17,[sp,#-16]!
adrp x16, cnt44
ldr x17,[x16,:lo12:cnt44]
add x17,x17,#1
str x17,[x16,:lo12:cnt44]
ldp x16,x17,[sp],#16
bl fen_set_location
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
mov x1, #1
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
b Lfn14end
Lfn14end:
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
mov sp, x29
stp x16,x17,[sp,#-16]!
adrp x16, cnt42
ldr x17,[x16,:lo12:cnt42]
add x17,x17,#1
str x17,[x16,:lo12:cnt42]
ldp x16,x17,[sp],#16
ldp x29, x30, [sp], #16
stp x16,x17,[sp,#-16]!
adrp x16, cnt43
ldr x17,[x16,:lo12:cnt43]
add x17,x17,#1
str x17,[x16,:lo12:cnt43]
ldp x16,x17,[sp],#16
ret
.text
.globl fen_print_result
fen_print_result:
b Lprint0
Lprint0:
b fen_write_i64
Lfn0fail18_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,56,58,49,55,10,0
Lfn0fail28_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,58,52,48,10,0
Lfn0fail25_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,58,50,55,10,0
.p2align 3
Lconstant0:
.zero 72
.long 10
.byte 0,2,0,0
Lfn1fail52_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,49,50,58,51,49,10,0
Lfn2fail73_2location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,49,54,58,51,49,10,0
Lfn2fail73_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,49,54,58,51,49,10,0
Lfn3fail99_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,50,48,58,51,50,10,0
Lfn3fail108_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,50,49,58,52,53,10,0
Lfn4fail169_4location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,50,57,58,50,51,10,0
Lfn4fail174_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,50,57,58,53,52,10,0
Lfn4fail269_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,52,54,58,56,49,10,0
Lfn4fail266_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,52,54,58,54,54,10,0
Lfn5fail322_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,53,52,58,51,50,10,0
.p2align 3
Lconstant1:
.quad 1
.zero 64
.long 7
.byte 0,2,0,0
.section .rodata
.p2align 3
Lconstant2:
.quad 2
.quad Lconstant1
.quad Lconstant1
.zero 48
.long 9
.byte 6,2,0,0
.text
.p2align 3
Lconstant3:
.quad 3
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,120
.section .rodata
.p2align 3
Lconstant4:
.quad Lconstant1
.zero 64
.long 8
.byte 1,2,0,0
.text
.section .rodata
.p2align 3
Lconstant5:
.quad 1
.quad Lconstant1
.quad Lconstant4
.zero 48
.long 9
.byte 6,2,0,0
.text
.p2align 3
Lconstant6:
.quad 4
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,120
.p2align 3
Lconstant7:
.quad 2
.zero 64
.long 7
.byte 0,2,0,0
.section .rodata
.p2align 3
Lconstant8:
.quad 2
.quad Lconstant1
.quad Lconstant7
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant9:
.quad 0
.quad Lconstant1
.quad Lconstant8
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant10:
.quad 2
.quad Lconstant9
.quad Lconstant7
.zero 48
.long 9
.byte 6,2,0,0
.text
.p2align 3
Lconstant11:
.quad 7
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,98,120,120
.p2align 3
Lconstant12:
.quad 4
.zero 64
.long 7
.byte 0,2,0,0
.section .rodata
.p2align 3
Lconstant13:
.quad 1
.quad Lconstant7
.quad Lconstant12
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant14:
.quad 0
.quad Lconstant1
.quad Lconstant13
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant15:
.quad 0
.quad Lconstant1
.quad Lconstant7
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant16:
.quad 0
.quad Lconstant1
.quad Lconstant12
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant17:
.quad 1
.quad Lconstant15
.quad Lconstant16
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant18:
.quad 2
.quad Lconstant14
.quad Lconstant17
.zero 48
.long 9
.byte 6,2,0,0
.text
.p2align 3
Lconstant19:
.quad 29
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,98,98,98,115,120,115,120,98,115,120,115,120,98,98,115,120,115,120,98,115,115,120,115,115,120
.section .rodata
.p2align 3
Lconstant20:
.quad 2
.quad Lconstant7
.quad Lconstant12
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant21:
.quad 0
.quad Lconstant8
.quad Lconstant20
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant22:
.quad 2
.quad Lconstant1
.quad Lconstant12
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant23:
.quad 2
.quad Lconstant21
.quad Lconstant22
.zero 48
.long 9
.byte 6,2,0,0
.text
.p2align 3
Lconstant24:
.quad 20
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,98,98,115,115,120,115,115,120,98,115,115,115,120,115,115,115,120
.section .rodata
.p2align 3
Lconstant25:
.quad 2
.quad Lconstant8
.quad Lconstant1
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant26:
.quad 2
.quad Lconstant25
.quad Lconstant1
.zero 48
.long 9
.byte 6,2,0,0
.text
.p2align 3
Lconstant27:
.quad 7
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,98,115,115,120,115,120
Lfn12fail477_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,54,57,58,53,50,10,0
Lfn12fail476_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,54,57,58,52,57,10,0
Lfn12fail475_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,54,57,58,52,54,10,0
Lfn12fail474_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,54,57,58,52,51,10,0
Lfn12fail473_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,54,57,58,52,48,10,0
Lfn12fail472_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,54,57,58,51,55,10,0
Lfn13fail508_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,55,49,58,52,55,10,0
Lfn13fail511_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,55,49,58,53,53,10,0
.p2align 3
Lconstant28:
.quad 2
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115
.p2align 3
Lconstant29:
.quad 4
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,120,120
.p2align 3
Lconstant30:
.quad 3
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,63
.p2align 3
Lconstant31:
.quad 3
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115
.p2align 3
Lconstant32:
.quad 5
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,120,120
.p2align 3
Lconstant33:
.quad 4
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,63
.p2align 3
Lconstant34:
.quad 6
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,98,120
.p2align 3
Lconstant35:
.quad 8
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,98,120,120,120
.p2align 3
Lconstant36:
.quad 7
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,98,120,63
.p2align 3
Lconstant37:
.quad 28
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,98,98,98,115,120,115,120,98,115,120,115,120,98,98,115,120,115,120,98,115,115,120,115,115
.p2align 3
Lconstant38:
.quad 30
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,98,98,98,115,120,115,120,98,115,120,115,120,98,98,115,120,115,120,98,115,115,120,115,115,120,120
.p2align 3
Lconstant39:
.quad 29
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,98,98,98,115,120,115,120,98,115,120,115,120,98,98,115,120,115,120,98,115,115,120,115,115,63
.p2align 3
Lconstant40:
.quad 19
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,98,98,115,115,120,115,115,120,98,115,115,115,120,115,115,115
.p2align 3
Lconstant41:
.quad 21
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,98,98,115,115,120,115,115,120,98,115,115,115,120,115,115,115,120,120
.p2align 3
Lconstant42:
.quad 20
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,98,98,115,115,120,115,115,120,98,115,115,115,120,115,115,115,63
.p2align 3
Lconstant43:
.quad 6
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,98,115,115,120,115
.p2align 3
Lconstant44:
.quad 8
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,98,115,115,120,115,120,120
.p2align 3
Lconstant45:
.quad 7
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,98,115,115,120,115,63
Lfn14fail538_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,55,50,58,49,48,48,10,0
Lfn14fail537_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,55,50,58,57,55,10,0
Lfn14fail536_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,55,50,58,57,52,10,0
Lfn14fail535_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,55,50,58,57,49,10,0
Lfn14fail534_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,55,50,58,56,56,10,0
Lfn14fail533_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,55,50,58,56,53,10,0
Lfn14fail532_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,55,50,58,56,50,10,0
Lfn14fail531_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,55,50,58,55,57,10,0
Lfn14fail530_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,55,50,58,55,54,10,0
Lfn14fail529_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,55,50,58,55,51,10,0
Lfn14fail528_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,55,50,58,55,48,10,0
Lfn14fail527_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,55,50,58,54,55,10,0
Lfn14fail526_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,55,50,58,54,52,10,0
Lfn14fail525_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,55,50,58,54,49,10,0
Lfn14fail524_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,55,50,58,53,56,10,0
Lfn14fail523_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,55,50,58,53,53,10,0
Lfn14fail522_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,55,50,58,53,50,10,0
Lfn14fail521_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,55,50,58,52,57,10,0
.data
.p2align 3
.globl counts
counts:
cnt0:
.quad 0
cnt1:
.quad 0
cnt2:
.quad 0
cnt3:
.quad 0
cnt4:
.quad 0
cnt5:
.quad 0
cnt6:
.quad 0
cnt7:
.quad 0
cnt8:
.quad 0
cnt9:
.quad 0
cnt10:
.quad 0
cnt11:
.quad 0
cnt12:
.quad 0
cnt13:
.quad 0
cnt14:
.quad 0
cnt15:
.quad 0
cnt16:
.quad 0
cnt17:
.quad 0
cnt18:
.quad 0
cnt19:
.quad 0
cnt20:
.quad 0
cnt21:
.quad 0
cnt22:
.quad 0
cnt23:
.quad 0
cnt24:
.quad 0
cnt25:
.quad 0
cnt26:
.quad 0
cnt27:
.quad 0
cnt28:
.quad 0
cnt29:
.quad 0
cnt30:
.quad 0
cnt31:
.quad 0
cnt32:
.quad 0
cnt33:
.quad 0
cnt34:
.quad 0
cnt35:
.quad 0
cnt36:
.quad 0
cnt37:
.quad 0
cnt38:
.quad 0
cnt39:
.quad 0
cnt40:
.quad 0
cnt41:
.quad 0
cnt42:
.quad 0
cnt43:
.quad 0
cnt44:
.quad 0
