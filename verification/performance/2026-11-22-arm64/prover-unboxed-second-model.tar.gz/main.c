#include <solo5.h>
struct outcome { int64_t value; uint64_t status; };
extern struct outcome fenrir_entry(int64_t argument);
void fen_write(const char *s, size_t n) { solo5_console_write(s, n); }
void fen_write_i64(int64_t value) {
    char digits[20];
    unsigned start = sizeof digits;
    uint64_t magnitude = value < 0 ? 0 - (uint64_t)value : (uint64_t)value;
    do {
        digits[--start] = '0' + magnitude % 10;
        magnitude /= 10;
    } while (magnitude);
    if (value < 0) digits[--start] = '-';
    fen_write(digits + start, sizeof digits - start);
}

#include "heap.h"
extern struct outcome cutoff_search(int64_t fuel,const fen_object *queue);
static fen_object a={.fields={1},.tag=7,.live=2}, b={.fields={2},.tag=7,.live=2};
static fen_object id={.fields={2,(uintptr_t)&a,(uintptr_t)&a},.tag=9,.pointer_mask=6,.live=2};
static fen_object neg={.fields={(uintptr_t)&b},.tag=8,.pointer_mask=1,.live=2};
static fen_object goal={.fields={0,(uintptr_t)&id,(uintptr_t)&neg},.tag=9,.pointer_mask=6,.live=2};
static fen_object empty={.tag=10,.live=2};
static fen_object q={.fields={0,(uintptr_t)&goal,(uintptr_t)&empty},.tag=11,.pointer_mask=6,.live=2};
extern uint64_t exhausted_paths[];
extern int64_t fen_bytes_index(const void *, uintptr_t);
int solo5_app_main(const struct solo5_start_info *info) {
    (void)info;
    for (int i=0;i<=32;i++) {
        struct outcome r=cutoff_search(i,&q);
        if (r.status) return SOLO5_EXIT_FAILURE;
        uintptr_t *o=(uintptr_t *)r.value;
        unsigned tag=*(uint32_t *)((char *)o+72);
        fen_write_i64(i); fen_write(" ",1); fen_write_i64(tag);
        if(tag==13){fen_write(" ",1);fen_write_i64(o[0]);fen_write(" ",1);fen_write_i64(o[1]);}
        if(tag==12){
            uintptr_t *bytes=(uintptr_t *)o[0];
            fen_write(" ",1); fen_write_i64(o[1]); fen_write(" ",1);
            for(uintptr_t j=0;j<bytes[0];j++){char b=fen_bytes_index(bytes,j);fen_write(&b,1);}
        }
        fen_write("\n",1);
    }
    fen_write_i64(exhausted_paths[0]); fen_write(" ",1); fen_write_i64(exhausted_paths[1]);fen_write("\n",1);
    return SOLO5_EXIT_SUCCESS;
}
