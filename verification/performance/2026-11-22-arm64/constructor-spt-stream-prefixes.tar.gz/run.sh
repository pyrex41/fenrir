set -eu
for guest in fenrir c; do
 for n in $(seq 0 38); do
  cp disk-"$n" /tmp/input
  status=0
  /opt/solo5-install/bin/solo5-spt --block:input=/tmp/input "$guest.spt" --solo5:quiet "$n" > /tmp/out 2>/tmp/err || status=$?
  test ! -s /tmp/err
  test "$status" = "$(cat status-"$n")"
  cmp /tmp/out want-"$n"
  echo "$guest $n $status"
 done
done
