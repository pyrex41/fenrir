import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {managedImage as baseline} from './tools/aarch64/baseline.mjs';
import {managedImage as candidate} from './tools/aarch64/managed-image.mjs';
import {validatePureCallArtifact} from './tools/tc0/pure-call-artifact.mjs';
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const input = readFileSync('search.json');
const {artifact,codes} = validatePureCallArtifact(input,['int','0'],{maxNodes:2000});
const expected = baseline(artifact,'',codes);
const variants = {baseline,candidate};
const samples = [];
for (let block = 0; block < 34; block++) {
  const ns = {};
  for (const name of block%2 ? ['candidate','baseline'] : ['baseline','candidate']) {
    const start = process.hrtime.bigint();
    const assembly = variants[name](artifact,'',codes);
    ns[name] = Number(process.hrtime.bigint() - start);
    if (assembly !== expected) throw Error('assembly differs');
  }
  samples.push({block,ns});
}
console.log(JSON.stringify({node:process.version,input_sha256:sha(input),assembly_sha256:sha(expected),
  baseline_sha256:sha(readFileSync('tools/aarch64/baseline.mjs')),candidate_sha256:sha(readFileSync('tools/aarch64/managed-image.mjs')),
  scope:'warm Node process, managedImage only, Solo5 assembly, Mac host during a concurrent HTTP trial',warmup:samples.slice(0,10),samples:samples.slice(10)},null,2));
