import collections,re,sys,json
from pathlib import Path
out=Path(__file__).resolve().parent
root=Path.cwd()
for lane,fn in [('search','search-steps'),('check','verify-step')]:
 p=root/'build/prover-updated-score-wBFz0kTQ/solo5-arm64-spt/prover'/lane
 w=out/lane
 w.mkdir()
 (w/'baseline.spt').write_bytes((p/'program.spt').read_bytes())
 source=(p/'program.s').read_text()
 names=[f['name'] for f in json.loads((p/'artifact').read_text())['functions']]
 i=names.index(fn)
 left,body=source.split(f'Lfn{i}fields:\n')
 body,right=body.split(f'Lfn{i+1}:\n')
 assert not re.search(r'\bx(?:19|2[0-8])\b',body)
 start,count=map(int,re.search(r'add x1, sp, #(\d+)\nmov x2, #(\d+)\nbl fen_enter',body).groups())
 floor=start+count*8
 expr=re.compile(r'(ldr|str|ldp|stp) (x\d+|xzr)(?:, (x\d+|xzr))?, \[sp, #(\d+)\]')
 freq=collections.Counter()
 for m in expr.finditer(body):
  off=int(m[4])
  if off>=floor:
   freq[off]+=1
   if m[3]:freq[off+8]+=1
 regs={k:'x'+str(19+j) for j,(k,n) in enumerate(freq.most_common(8))}
 def replace(m):
  op,r,s,o=m.groups()
  o=int(o)
  pairs=[(r,o)]+([(s,o+8)] if s else [])
  if all(off not in regs for _,off in pairs):return m[0]
  parts=[]
  for reg,off in pairs:
   if off in regs:
    dest,src=(reg,regs[off]) if op.startswith('ld') else (regs[off],reg)
    parts.append(f'mov {dest}, {src}')
   else: parts.append(f'{"ldr" if op.startswith("ld") else "str"} {reg}, [sp, #{off}]')
  return '\n'.join(parts)
 body=expr.sub(replace,body)
 save=[f'stp x{k}, x{k+1}, [sp, #-16]!' for k in (19,21,23,25)]
 restore=[f'ldp x{k}, x{k+1}, [sp], #16' for k in (25,23,21,19)]
 body=body.replace('stp x29, x30, [sp, #-16]!', '\n'.join(save+['stp x29, x30, [sp, #-16]!'])).replace('ldp x29, x30, [sp], #16','\n'.join(['ldp x29, x30, [sp], #16']+restore))
 (w/'variant.s').write_text(left+f'Lfn{i}fields:\n'+body+f'Lfn{i+1}:\n'+right)
 print(lane,regs)
