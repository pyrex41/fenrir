set -eu
export PATH=/opt/solo5-install/bin:$PATH FENRIR_SOLO5_MAIN=/src/benchmarks/prover/timed-spt.c
for lane in search check; do
 (cd "$lane"
 for v in base compact; do sh /src/tools/aarch64/link-spt.sh "$v.s" "$v.spt"
 solo5-spt "$v.spt" --solo5:quiet 0 > "$v.zero"
 solo5-spt "$v.spt" --solo5:quiet 50000 > "$v.warm"; done
 for i in $(seq 0 23); do
 if [ $((i%2)) = 0 ]; then order="base compact"; else order="compact base"; fi
 for v in $order; do result=$(solo5-spt "$v.spt" --solo5:quiet 50000); echo "$i $v $result"; done
 done > timings)
done
