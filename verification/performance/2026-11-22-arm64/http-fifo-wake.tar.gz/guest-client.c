// The guest returns one decision for each complete request frame in FIFO order.
#include "heap.h"
#include <errno.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>

typedef struct { fen_object *result; uintptr_t status; } outcome;
static void transfer(int writing, void *buffer, size_t n) {
    char *p = buffer;
    while (n) {
        ssize_t count = writing ? write(STDOUT_FILENO, p, n) : read(STDIN_FILENO, p, n);
        if (count < 0 && errno == EINTR) continue;
        if (count <= 0) _Exit(2);
        p += count;
        n -= (size_t)count;
    }
}
outcome http_response(fen_object *args) {
    static _Thread_local fen_object reply;
    static pthread_mutex_t writer = PTHREAD_MUTEX_INITIALIZER;
    static pthread_mutex_t reader = PTHREAD_MUTEX_INITIALIZER;
    struct waiter { pthread_cond_t ready; struct waiter *next; };
    static struct waiter *first, *last;
    struct waiter self = {.ready = PTHREAD_COND_INITIALIZER};
    fen_object *head = (fen_object *)args->fields[0];
    uint32_t frame[] = {(uint32_t)head->fields[0], (uint32_t)args->fields[1]};
    pthread_mutex_lock(&writer);
    pthread_mutex_lock(&reader);
    if (last) last->next = &self;
    else first = &self;
    last = &self;
    pthread_mutex_unlock(&reader);
    transfer(1, frame, sizeof frame);
    transfer(1, head + 1, frame[0]);
    pthread_mutex_unlock(&writer);
    pthread_mutex_lock(&reader);
    while (first != &self) pthread_cond_wait(&self.ready, &reader);
    pthread_mutex_unlock(&reader);
    transfer(0, reply.fields, 4*sizeof(uint64_t));
    pthread_mutex_lock(&reader);
    first = self.next;
    if (first) pthread_cond_signal(&first->ready);
    else last = NULL;
    pthread_mutex_unlock(&reader);
    pthread_cond_destroy(&self.ready);
    return (outcome){&reply, 0};
}
