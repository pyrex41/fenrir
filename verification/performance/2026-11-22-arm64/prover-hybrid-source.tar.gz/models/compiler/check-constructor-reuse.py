"""Compare the immutable and heap observations for each bounded alias shape."""
from pathlib import Path
import re
import subprocess
import sys

model = Path(__file__).with_name("constructor-reuse.maude")
for policy in ("checked", "parentOnly"):
    query = (f"search start({policy}) =>! result(Q:Parent,H:Parents,K:Children,"
             "S:Observation,T:Observation) .\nquit\n")
    run = subprocess.run([sys.argv[1] if len(sys.argv) > 1 else "maude",
                          "-no-banner", "-no-advise", str(model)],
                         input=query, text=True, capture_output=True, check=True, timeout=30)
    if run.stderr.strip() or "No more solutions." not in run.stdout:
        raise RuntimeError(run.stderr + run.stdout)
    blocks = re.split(r"Solution \d+ \(state \d+\)", run.stdout)[1:]
    seen = {}
    for block in blocks:
        fields = dict(re.findall(r"^([QHKST])(?::\w+)? --> (.+)$", block, re.MULTILINE))
        key = (fields["Q"], fields["H"].replace(" ", ""))
        observed = tuple(fields[k].replace(" ", "") for k in ("S", "T"))
        if key in seen or fields["K"].replace(" ", "") != "pairs(false,false,false)":
            raise ValueError(block)
        seen[key] = observed
    expected = {("p0", "branches(c0,c1,cf)"), ("p1", "branches(c0,c0,cf)"),
                ("p1", "branches(c0,c1,cf)")}
    if set(seen) != expected:
        raise ValueError(seen)
    for key, (source, lowered) in seen.items():
        corrupts = policy == "parentOnly" and key == ("p1", "branches(c0,c0,cf)")
        if source != "observed(true,false)" or lowered != ("observed(true,true)" if corrupts else source):
            raise ValueError((policy, key, source, lowered))
        print(policy, *key, source, lowered)
