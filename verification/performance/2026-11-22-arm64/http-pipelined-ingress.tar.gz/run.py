import json,subprocess,sys
from pathlib import Path
from runpy import run_path
d,q,root=map(Path,sys.argv[1:])
wire=run_path(str(root/'benchmarks/http/check-service.py'))
for i,(kind,k) in enumerate([('current','spt'),('candidate','spt'),('candidate','spt-c'),('current','spt-c'),
                              ('current','spt-c'),('candidate','spt-c'),('candidate','spt'),('current','spt')]):
    folder=(d if kind=='candidate' else q/'bin')/k
    with wire['server']([sys.executable,root/'benchmarks/http/run-spt.py',folder,'0','--guest-cpu','4']) as addr:
        wire['check'](addr)
        trial=subprocess.run([q/'grid/load','-addr','%s:%s'%addr,'-rate','5000','-seconds','10','-connections','16'],capture_output=True,timeout=35)
        data=json.loads(trial.stdout)
        assert trial.returncode in (0,1) and data['Errors']==data['Invalid']==0
        (d/f'{i}-{kind}-{k}.json').write_bytes(trial.stdout)
        print(i,kind,k,data['Valid'],data['Missed'],data['P99ns']/1e6,flush=True)
