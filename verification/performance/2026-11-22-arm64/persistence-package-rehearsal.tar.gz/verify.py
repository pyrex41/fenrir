from pathlib import Path
import json,hashlib
root=Path(__file__).resolve().parent
apps=root/'apps'
summary=json.loads((apps/'summary.json').read_text())
assert summary['package']==(root/'identity').read_text().strip()
for name,digest in summary['files'].items():
    assert hashlib.sha256((apps/name).read_bytes()).hexdigest()==digest,name
for target in ('macos-arm64','solo5-arm64-spt'):
    key=f'persistent-counts-{target}.log'
    assert key in summary['files'] and (apps/key).read_bytes()==b'(tuple true true true)\n'
assert set(summary['recovery'])=={'mac','spt'}
for sample in summary['recovery'].values():
    assert sample['verdict']['verdict']=='accepted' and sample['verdict']['events']==18
print('Verified',len(summary['files']),'file hashes, both persistent aggregate checks and two accepted recovery histories.')
