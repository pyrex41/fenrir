import hashlib,json,runpy,statistics,tarfile
from pathlib import Path
out=Path(__file__).resolve().parent
resource=runpy.run_path('benchmarks/durable/paired-recovery.py')['service_resources']
paired=json.loads((out/'fresh/paired.json').read_bytes())
assert paired['blocks']==10 and paired['history_event_count']==129
builds=[Path(b) for b in (out/'builds').read_text().splitlines()]
names=[json.loads((b/'history.json').read_text())['worker_implementation'] for b in builds]
assert len(set(names))==5
samples={name:[] for name in names}
with tarfile.open('verification/performance/2026-11-22-arm64/durable-five-worker-resources.tar.gz','x:gz') as t:
 for field in ['builds','fresh/paired.json','finish.py']:
  t.add(out/field,arcname=field)
 for block in range(10):
  order=names[block%5:]+names[:block%5]
  assert list(paired["samples_us"][block]) == order
  for name in order:
   p=out/'fresh'/str(block)/name/'0'
   verdict=json.loads((p/'check/verdicts.jsonl').read_text())
   assert verdict['verdict']=='accepted' and verdict['events']==129
   h=json.loads((p/'history.json').read_text())
   assert h['worker_implementation']==name
   digest=hashlib.sha256()
   for e in h['events']:digest.update((json.dumps(e,sort_keys=True,separators=(',',':'))+'\n').encode())
   assert digest.hexdigest()==paired['history_events_sha256']
   assert json.loads((p/'store-check.json').read_text())['tenant_counts']==[64,64]
   r=resource(p)
   samples[name].append(r['after_load'])
   for file in ['resources.json','history.json','timings.json','check/verdicts.jsonl','store-check.json']:
    t.add(p/file,arcname=str((p/file).relative_to(out)))
 summary={name:{key:statistics.median(s[key] for s in rows) for key in rows[0] if not key.endswith('_pid')} for name,rows in samples.items()}
 (out/'median-after.json').write_text(json.dumps(summary,indent=2)+'\n')
 t.add(out/'median-after.json',arcname='median-after.json')
 print(summary)
