.text
.p2align 2
Lfn0:
ldp x8, x9, [x0, #0]
Lfn0fields:
ldr w2, [x8, #72]
cmp w2, #10
b.ne Lfn0frame
mov x0, x9
mov x1, #0
ret
Lfn0frame:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #80
stp xzr, xzr, [sp, #64]
stp x8, x9, [sp, #48]
add x0, sp, #16
add x1, sp, #48
mov x2, #4
bl fen_enter
Lfn0loop:
ldr x0, [sp, #48]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn0match10arm10
cmp w0, #11
b.eq Lfn0match10arm11
brk #0
Lfn0match10arm10:
ldr x0, [sp, #56]
b Lfn0match10end
Lfn0match10arm11:
ldr x0, [sp, #48]
ldr x0, [x0, #16]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn0match16arm10
cmp w0, #11
b.eq Lfn0match16arm11
brk #0
Lfn0match16arm10:
mov x0, #6
mov x1, #11
bl fen_allocate_full
cbz x0, Lfn0fail18_3
ldr x4, [sp, #48]
ldp x2, x3, [x4, #0]
stp x2, x3, [x0, #0]
ldr x2, [sp, #56]
str x2, [x0, #16]
b Lfn0match16end
Lfn0match16arm11:
ldr x8, [sp, #48]
ldr x8, [x8, #16]
ldr x8, [x8, #16]
ldr x9, [sp, #56]
bl Lfn0fields
cbnz x1, Lfn0end
str x0, [sp, #64]
mov x0, #6
mov x1, #11
bl fen_allocate_full
cbz x0, Lfn0fail28_3
ldr x4, [sp, #48]
ldr x4, [x4, #16]
ldp x2, x3, [x4, #0]
stp x2, x3, [x0, #0]
ldr x2, [sp, #64]
str x2, [x0, #16]
str x0, [sp, #72]
mov x0, #6
mov x1, #11
bl fen_allocate_full
cbz x0, Lfn0fail25_3
ldr x4, [sp, #48]
ldp x2, x3, [x4, #0]
stp x2, x3, [x0, #0]
ldr x2, [sp, #72]
str x2, [x0, #16]
b Lfn0match16end
Lfn0match16end:
b Lfn0match10end
Lfn0match10end:
mov x1, #0
b Lfn0end
Lfn0fail18_3:
adrp x0, Lfn0fail18_3location
add x0, x0, :lo12:Lfn0fail18_3location
bl fen_set_location
mov x1, #3
b Lfn0end
Lfn0fail28_3:
adrp x0, Lfn0fail28_3location
add x0, x0, :lo12:Lfn0fail28_3location
bl fen_set_location
mov x1, #3
b Lfn0end
Lfn0fail25_3:
adrp x0, Lfn0fail25_3location
add x0, x0, :lo12:Lfn0fail25_3location
bl fen_set_location
mov x1, #3
b Lfn0end
Lfn0end:
bl fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn1:
ldp x8, x9, [x0, #0]
ldr x10, [x0, #16]
Lfn1fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #80
str xzr, [sp, #64]
str x8, [sp, #48]
str x9, [sp, #72]
str x10, [sp, #56]
add x0, sp, #16
add x1, sp, #48
mov x2, #3
bl fen_enter
Lfn1loop:
mov x0, #6
mov x1, #11
bl fen_allocate_full
cbz x0, Lfn1fail52_3
ldr x2, [sp, #72]
ldr x3, [sp, #56]
stp x2, x3, [x0, #0]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
str x2, [x0, #16]
str x0, [sp, #64]
bl fen_leave_result
ldr x8, [sp, #48]
ldr x9, [sp, #64]
mov sp, x29
ldp x29, x30, [sp], #16
b Lfn0fields
mov x1, #0
b Lfn1end
Lfn1fail52_3:
adrp x0, Lfn1fail52_3location
add x0, x0, :lo12:Lfn1fail52_3location
bl fen_set_location
mov x1, #3
b Lfn1end
Lfn1end:
bl fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn2:
ldp x8, x9, [x0, #0]
Lfn2fields:
tbnz x8, #63, Lfn2arithmetic
cmp x9, #0
b.le Lfn2arithmetic
sub x2, x9, #1
tst x2, x9
b.ne Lfn2arithmetic
tst x8, x9
cset x0, ne
mov x1, #0
ret
Lfn2arithmetic:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
stp x8, x9, [sp, #48]
Lfn2loop:
ldr x0, [sp, #48]
ldr x2, [sp, #56]
cmp x0, x2
b.ge Lfn2if66else
movz x0, #0, lsl #0
b Lfn2if66done
Lfn2if66else:
ldr x0, [sp, #48]
ldr x2, [sp, #56]
cbz x2, Lfn2fail73_2
cmn x2, #1
b.ne 1f
negs x3, x0
b.vs Lfn2fail73_1
1:
sdiv x0, x0, x2
cmp x0, #0
neg x2, x0
and x2, x2, #1
and x0, x0, #1
csneg x0, x0, x2, ge
cmp x0, #1
cset x0, eq
Lfn2if66done:
mov x1, #0
b Lfn2end
Lfn2fail73_2:
adrp x0, Lfn2fail73_2location
add x0, x0, :lo12:Lfn2fail73_2location
bl fen_set_location
mov x1, #2
b Lfn2end
Lfn2fail73_1:
adrp x0, Lfn2fail73_1location
add x0, x0, :lo12:Lfn2fail73_1location
bl fen_set_location
mov x1, #1
b Lfn2end
Lfn2end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn3:
ldp x8, x9, [x0, #0]
Lfn3fields:
tbnz x8, #63, Lfn3arithmetic
cmp x9, #0
b.le Lfn3arithmetic
sub x2, x9, #1
tst x2, x9
b.ne Lfn3arithmetic
orr x0, x8, x9
mov x1, #0
ret
Lfn3arithmetic:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
stp x8, x9, [sp, #48]
Lfn3loop:
ldr x0, [sp, #48]
ldr x2, [sp, #56]
cmp x0, x2
b.ge Lfn3if95else
ldr x0, [sp, #48]
ldr x2, [sp, #56]
adds x0, x0, x2
b.vs Lfn3fail99_1
b Lfn3if95done
Lfn3if95else:
ldr x8, [sp, #48]
ldr x9, [sp, #56]
bl Lfn2fields
cbnz x1, Lfn3end
cbz x0, Lfn3if102else
ldr x0, [sp, #48]
b Lfn3if102done
Lfn3if102else:
ldr x0, [sp, #48]
ldr x2, [sp, #56]
adds x0, x0, x2
b.vs Lfn3fail108_1
Lfn3if102done:
Lfn3if95done:
mov x1, #0
b Lfn3end
Lfn3fail99_1:
adrp x0, Lfn3fail99_1location
add x0, x0, :lo12:Lfn3fail99_1location
bl fen_set_location
mov x1, #1
b Lfn3end
Lfn3fail108_1:
adrp x0, Lfn3fail108_1location
add x0, x0, :lo12:Lfn3fail108_1location
bl fen_set_location
mov x1, #1
b Lfn3end
Lfn3end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn4:
ldp x8, x9, [x0, #0]
ldp x10, x11, [x0, #16]
ldp x12, x13, [x0, #32]
Lfn4fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
stp x19, x20, [sp, #-16]!
stp x21, x22, [sp, #-16]!
stp x23, x24, [sp, #-16]!
stp x25, x26, [sp, #-16]!
sub sp, sp, #192
stp xzr, xzr, [sp, #72]
str xzr, [sp, #88]
stp x8, x9, [sp, #48]
mov x22, x10
mov x21, x11
str x12, [sp, #64]
mov x19, x13
add x0, sp, #16
add x1, sp, #48
mov x2, #6
bl fen_enter
Lfn4loop:
ldr x0, [sp, #48]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn4match137arm10
cmp w0, #11
b.eq Lfn4match137arm11
brk #0
Lfn4match137arm10:
ldr x0, [sp, #56]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn4match139arm10
cmp w0, #11
b.eq Lfn4match139arm11
brk #0
Lfn4match139arm10:
movn x0, #0, lsl #0
b Lfn4match139end
Lfn4match139arm11:
ldr x8, [sp, #56]
adrp x9, Lconstant0
add x9, x9, :lo12:Lconstant0
str x8, [sp, #48]
str x9, [sp, #56]
stp xzr, xzr, [sp, #72]
str xzr, [sp, #88]
b Lfn4loop
b Lfn4match139end
Lfn4match139end:
b Lfn4match137end
Lfn4match137arm11:
mov x0, x19
cmp x0, #0
b.ge Lfn4if156else
movn x0, #0, lsl #0
b Lfn4if156done
Lfn4if156else:
ldr x0, [sp, #64]
ldr x0, [x0]
str x0, [sp, #96]
mov x0, x19
ldr x2, [sp, #96]
cmp x0, x2
b.lt Lfn4if161else
movn x0, #0, lsl #0
b Lfn4if161done
Lfn4if161else:
ldr x0, [sp, #64]
mov x2, x19
ldr x3, [x0]
cmp x2, x3
b.hs Lfn4fail169_4
ldr w3, [x0, #72]
cmn w3, #1
b.ne 1f
add x0, x0, #80
ldrb w0, [x0, x2]
b 2f
1:
mov x1, x2
bl fen_bytes_index
2:
mov x24, x0
mov x0, x19
adds x0, x0, #1
b.vs Lfn4fail174_1
mov x20, x0
ldr x0, [sp, #48]
ldr x0, [x0, #8]
ldr w0, [x0, #72]
cmp w0, #7
b.eq Lfn4match177arm7
cmp w0, #8
b.eq Lfn4match177arm8
cmp w0, #9
b.eq Lfn4match177arm9
brk #0
Lfn4match177arm7:
ldr x0, [sp, #48]
ldr x0, [x0, #0]
cbz x0, Lfn4if183else
mov x0, x21
b Lfn4if183done
Lfn4if183else:
mov x0, x22
Lfn4if183done:
str x0, [sp, #104]
ldr x8, [sp, #104]
ldr x9, [sp, #48]
ldr x9, [x9, #8]
ldr x9, [x9, #0]
bl Lfn2fields
cbnz x1, Lfn4end
cbz x0, Lfn4if180else
mov x0, x24
cmp x0, #120
b.ne Lfn4if188else
mov x0, x20
b Lfn4if188done
Lfn4if188else:
movn x0, #0, lsl #0
Lfn4if188done:
b Lfn4if180done
Lfn4if180else:
mov x0, x24
cmp x0, #115
b.ne Lfn4if194else
ldr x0, [sp, #48]
ldr x0, [x0, #0]
cbz x0, Lfn4if202else
mov x8, x22
ldr x9, [sp, #48]
ldr x9, [x9, #8]
ldr x9, [x9, #0]
bl Lfn3fields
cbnz x1, Lfn4end
b Lfn4if202done
Lfn4if202else:
mov x0, x22
Lfn4if202done:
str x0, [sp, #112]
ldr x0, [sp, #48]
ldr x0, [x0, #0]
cbz x0, Lfn4if209else
mov x0, x21
b Lfn4if209done
Lfn4if209else:
mov x8, x21
ldr x9, [sp, #48]
ldr x9, [x9, #8]
ldr x9, [x9, #0]
bl Lfn3fields
cbnz x1, Lfn4end
Lfn4if209done:
str x0, [sp, #120]
ldr x8, [sp, #48]
ldr x8, [x8, #16]
ldr x9, [sp, #112]
ldr x10, [sp, #120]
mov x11, x20
str x8, [sp, #48]
mov x22, x9
mov x21, x10
mov x19, x11
stp xzr, xzr, [sp, #72]
str xzr, [sp, #88]
b Lfn4loop
b Lfn4if194done
Lfn4if194else:
movn x0, #0, lsl #0
Lfn4if194done:
Lfn4if180done:
b Lfn4match177end
Lfn4match177arm8:
mov x0, x24
cmp x0, #115
b.ne Lfn4if220else
ldr x0, [sp, #48]
ldr x0, [x0, #16]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn4match224arm10
cmp w0, #11
b.eq Lfn4match224arm11
brk #0
Lfn4match224arm10:
ldr x0, [sp, #48]
ldr x0, [x0, #0]
eor x0, x0, #1
str x0, [sp, #128]
mov x0, #6
mov x1, #11
bl fen_allocate_full
cbz x0, Lfn4fail229_3
ldr x2, [sp, #128]
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #0]
stp x2, x3, [x0, #0]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
str x2, [x0, #16]
str x0, [sp, #72]
ldr x8, [sp, #56]
ldr x9, [sp, #72]
mov x10, x20
str x8, [sp, #48]
str x9, [sp, #56]
mov x19, x10
stp xzr, xzr, [sp, #72]
str xzr, [sp, #88]
b Lfn4loop
b Lfn4match224end
Lfn4match224arm11:
ldr x0, [sp, #48]
ldr x0, [x0, #0]
eor x0, x0, #1
str x0, [sp, #136]
ldr x8, [sp, #56]
ldr x9, [sp, #136]
ldr x10, [sp, #48]
ldr x10, [x10, #8]
ldr x10, [x10, #0]
bl Lfn1fields
cbnz x1, Lfn4end
str x0, [sp, #72]
ldr x8, [sp, #48]
ldr x8, [x8, #16]
ldr x9, [sp, #72]
mov x10, x20
str x8, [sp, #48]
str x9, [sp, #56]
mov x19, x10
stp xzr, xzr, [sp, #72]
str xzr, [sp, #88]
b Lfn4loop
b Lfn4match224end
Lfn4match224end:
b Lfn4if220done
Lfn4if220else:
movn x0, #0, lsl #0
Lfn4if220done:
b Lfn4match177end
Lfn4match177arm9:
ldr x0, [sp, #48]
ldr x0, [x0, #8]
ldr x0, [x0, #0]
cmp x0, #2
b.ne Lfn4if260else
ldr x0, [sp, #48]
ldr x0, [x0, #0]
eor x0, x0, #1
b Lfn4if260done
Lfn4if260else:
ldr x0, [sp, #48]
ldr x0, [x0, #0]
Lfn4if260done:
mov x23, x0
ldr x0, [sp, #48]
ldr x0, [x0, #8]
ldr x0, [x0, #0]
cmp x0, #0
cset x0, eq
str x0, [sp, #144]
ldr x0, [sp, #48]
ldr x0, [x0, #0]
ldr x2, [sp, #144]
cmp x0, x2
b.ne Lfn4if267else
mov x0, x24
cmp x0, #115
b.ne Lfn4if273else
ldr x0, [sp, #48]
ldr x0, [x0, #16]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn4match277arm10
cmp w0, #11
b.eq Lfn4match277arm11
brk #0
Lfn4match277arm10:
ldr x0, [sp, #56]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn4match279arm10
cmp w0, #11
b.eq Lfn4match279arm11
brk #0
Lfn4match279arm10:
ldr x0, [sp, #48]
ldr x0, [x0, #8]
ldr x0, [x0, #8]
ldr w0, [x0, #72]
cmp w0, #7
b.eq Lfn4match281arm7
cmp w0, #8
b.eq Lfn4match281arm8
cmp w0, #9
b.eq Lfn4match281arm9
brk #0
Lfn4match281arm7:
ldr x0, [sp, #64]
ldr x0, [x0]
str x0, [sp, #152]
mov x0, x20
ldr x2, [sp, #152]
cmp x0, x2
b.lt Lfn4if284else
movn x0, #0, lsl #0
b Lfn4if284done
Lfn4if284else:
ldr x0, [sp, #64]
mov x2, x20
ldr x3, [x0]
cmp x2, x3
b.hs Lfn4fail292_4
ldr w3, [x0, #72]
cmn w3, #1
b.ne 1f
add x0, x0, #80
ldrb w0, [x0, x2]
b 2f
1:
mov x1, x2
bl fen_bytes_index
2:
mov x25, x0
mov x0, x20
adds x0, x0, #1
b.vs Lfn4fail297_1
mov x26, x0
mov x0, x23
cbz x0, Lfn4if303else
mov x0, x21
b Lfn4if303done
Lfn4if303else:
mov x0, x22
Lfn4if303done:
str x0, [sp, #160]
ldr x8, [sp, #160]
ldr x9, [sp, #48]
ldr x9, [x9, #8]
ldr x9, [x9, #8]
ldr x9, [x9, #0]
bl Lfn2fields
cbnz x1, Lfn4end
cbz x0, Lfn4if300else
mov x0, x25
cmp x0, #120
b.ne Lfn4if308else
mov x0, x26
b Lfn4if308done
Lfn4if308else:
movn x0, #0, lsl #0
Lfn4if308done:
b Lfn4if300done
Lfn4if300else:
mov x0, x25
cmp x0, #115
b.ne Lfn4if314else
mov x0, #6
mov x1, #11
bl fen_allocate_full
cbz x0, Lfn4fail320_3
ldr x2, [sp, #48]
ldr x2, [x2, #0]
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #16]
stp x2, x3, [x0, #0]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
str x2, [x0, #16]
str x0, [sp, #72]
mov x0, x23
cbz x0, Lfn4if325else
mov x8, x22
ldr x9, [sp, #48]
ldr x9, [x9, #8]
ldr x9, [x9, #8]
ldr x9, [x9, #0]
bl Lfn3fields
cbnz x1, Lfn4end
b Lfn4if325done
Lfn4if325else:
mov x0, x22
Lfn4if325done:
str x0, [sp, #168]
mov x0, x23
cbz x0, Lfn4if332else
mov x0, x21
b Lfn4if332done
Lfn4if332else:
mov x8, x21
ldr x9, [sp, #48]
ldr x9, [x9, #8]
ldr x9, [x9, #8]
ldr x9, [x9, #0]
bl Lfn3fields
cbnz x1, Lfn4end
Lfn4if332done:
str x0, [sp, #176]
ldr x8, [sp, #72]
adrp x9, Lconstant0
add x9, x9, :lo12:Lconstant0
ldr x10, [sp, #168]
ldr x11, [sp, #176]
mov x12, x26
str x8, [sp, #48]
str x9, [sp, #56]
mov x22, x10
mov x21, x11
mov x19, x12
stp xzr, xzr, [sp, #72]
str xzr, [sp, #88]
b Lfn4loop
b Lfn4if314done
Lfn4if314else:
movn x0, #0, lsl #0
Lfn4if314done:
Lfn4if300done:
Lfn4if284done:
b Lfn4match281end
Lfn4match281arm8:
mov x0, #6
mov x1, #11
bl fen_allocate_full
cbz x0, Lfn4fail349_3
ldr x2, [sp, #48]
ldr x2, [x2, #0]
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #16]
stp x2, x3, [x0, #0]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
str x2, [x0, #16]
str x0, [sp, #72]
mov x0, #6
mov x1, #11
bl fen_allocate_full
cbz x0, Lfn4fail346_3
mov x2, x23
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #8]
stp x2, x3, [x0, #0]
ldr x2, [sp, #72]
str x2, [x0, #16]
str x0, [sp, #80]
ldr x8, [sp, #56]
ldr x9, [sp, #80]
mov x10, x20
str x8, [sp, #48]
str x9, [sp, #56]
mov x19, x10
stp xzr, xzr, [sp, #72]
str xzr, [sp, #88]
b Lfn4loop
b Lfn4match281end
Lfn4match281arm9:
mov x0, #6
mov x1, #11
bl fen_allocate_full
cbz x0, Lfn4fail366_3
ldr x2, [sp, #48]
ldr x2, [x2, #0]
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #16]
stp x2, x3, [x0, #0]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
str x2, [x0, #16]
str x0, [sp, #72]
mov x0, #6
mov x1, #11
bl fen_allocate_full
cbz x0, Lfn4fail363_3
mov x2, x23
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #8]
stp x2, x3, [x0, #0]
ldr x2, [sp, #72]
str x2, [x0, #16]
str x0, [sp, #80]
ldr x8, [sp, #56]
ldr x9, [sp, #80]
mov x10, x20
str x8, [sp, #48]
str x9, [sp, #56]
mov x19, x10
stp xzr, xzr, [sp, #72]
str xzr, [sp, #88]
b Lfn4loop
b Lfn4match281end
Lfn4match281end:
b Lfn4match279end
Lfn4match279arm11:
mov x0, #6
mov x1, #11
bl fen_allocate_full
cbz x0, Lfn4fail383_3
ldr x2, [sp, #48]
ldr x2, [x2, #0]
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #16]
stp x2, x3, [x0, #0]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
str x2, [x0, #16]
str x0, [sp, #72]
mov x0, #6
mov x1, #11
bl fen_allocate_full
cbz x0, Lfn4fail380_3
mov x2, x23
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #8]
stp x2, x3, [x0, #0]
ldr x2, [sp, #72]
str x2, [x0, #16]
str x0, [sp, #80]
ldr x8, [sp, #56]
ldr x9, [sp, #80]
mov x10, x20
str x8, [sp, #48]
str x9, [sp, #56]
mov x19, x10
stp xzr, xzr, [sp, #72]
str xzr, [sp, #88]
b Lfn4loop
b Lfn4match279end
Lfn4match279end:
b Lfn4match277end
Lfn4match277arm11:
mov x0, #6
mov x1, #11
bl fen_allocate_full
cbz x0, Lfn4fail403_3
ldr x2, [sp, #48]
ldr x2, [x2, #0]
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #16]
stp x2, x3, [x0, #0]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
str x2, [x0, #16]
str x0, [sp, #72]
mov x0, #6
mov x1, #11
bl fen_allocate_full
cbz x0, Lfn4fail400_3
mov x2, x23
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #8]
stp x2, x3, [x0, #0]
ldr x2, [sp, #72]
str x2, [x0, #16]
str x0, [sp, #80]
ldr x8, [sp, #56]
ldr x9, [sp, #80]
bl Lfn0fields
cbnz x1, Lfn4end
str x0, [sp, #88]
ldr x8, [sp, #48]
ldr x8, [x8, #16]
ldr x9, [sp, #88]
mov x10, x20
str x8, [sp, #48]
str x9, [sp, #56]
mov x19, x10
stp xzr, xzr, [sp, #72]
str xzr, [sp, #88]
b Lfn4loop
b Lfn4match277end
Lfn4match277end:
b Lfn4if273done
Lfn4if273else:
movn x0, #0, lsl #0
Lfn4if273done:
b Lfn4if267done
Lfn4if267else:
mov x0, x24
cmp x0, #98
b.ne Lfn4if412else
ldr x0, [sp, #48]
ldr x0, [x0, #16]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn4match418arm10
cmp w0, #11
b.eq Lfn4match418arm11
brk #0
Lfn4match418arm10:
mov x0, #6
mov x1, #11
bl fen_allocate_full
cbz x0, Lfn4fail423_3
mov x2, x23
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #8]
stp x2, x3, [x0, #0]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
str x2, [x0, #16]
str x0, [sp, #72]
ldr x8, [sp, #56]
ldr x9, [sp, #72]
mov x10, x22
mov x11, x21
ldr x12, [sp, #64]
mov x13, x20
bl Lfn4fields
cbnz x1, Lfn4end
b Lfn4match418end
Lfn4match418arm11:
ldr x8, [sp, #56]
mov x9, x23
ldr x10, [sp, #48]
ldr x10, [x10, #8]
ldr x10, [x10, #8]
bl Lfn1fields
cbnz x1, Lfn4end
str x0, [sp, #72]
ldr x8, [sp, #48]
ldr x8, [x8, #16]
ldr x9, [sp, #72]
mov x10, x22
mov x11, x21
ldr x12, [sp, #64]
mov x13, x20
bl Lfn4fields
cbnz x1, Lfn4end
b Lfn4match418end
Lfn4match418end:
str x0, [sp, #184]
ldr x0, [sp, #48]
ldr x0, [x0, #16]
ldr w0, [x0, #72]
cmp w0, #10
b.eq Lfn4match446arm10
cmp w0, #11
b.eq Lfn4match446arm11
brk #0
Lfn4match446arm10:
mov x0, #6
mov x1, #11
bl fen_allocate_full
cbz x0, Lfn4fail451_3
ldr x2, [sp, #48]
ldr x2, [x2, #0]
ldr x3, [sp, #48]
ldr x3, [x3, #8]
ldr x3, [x3, #16]
stp x2, x3, [x0, #0]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
str x2, [x0, #16]
str x0, [sp, #80]
ldr x8, [sp, #56]
ldr x9, [sp, #80]
ldr x10, [sp, #184]
str x8, [sp, #48]
str x9, [sp, #56]
mov x19, x10
stp xzr, xzr, [sp, #72]
str xzr, [sp, #88]
b Lfn4loop
b Lfn4match446end
Lfn4match446arm11:
ldr x8, [sp, #56]
ldr x9, [sp, #48]
ldr x9, [x9, #0]
ldr x10, [sp, #48]
ldr x10, [x10, #8]
ldr x10, [x10, #16]
bl Lfn1fields
cbnz x1, Lfn4end
str x0, [sp, #80]
ldr x8, [sp, #48]
ldr x8, [x8, #16]
ldr x9, [sp, #80]
ldr x10, [sp, #184]
str x8, [sp, #48]
str x9, [sp, #56]
mov x19, x10
stp xzr, xzr, [sp, #72]
str xzr, [sp, #88]
b Lfn4loop
b Lfn4match446end
Lfn4match446end:
b Lfn4if412done
Lfn4if412else:
movn x0, #0, lsl #0
Lfn4if412done:
Lfn4if267done:
b Lfn4match177end
Lfn4match177end:
Lfn4if161done:
Lfn4if156done:
b Lfn4match137end
Lfn4match137end:
mov x1, #0
b Lfn4end
Lfn4fail169_4:
adrp x0, Lfn4fail169_4location
add x0, x0, :lo12:Lfn4fail169_4location
bl fen_set_location
mov x1, #4
b Lfn4end
Lfn4fail174_1:
adrp x0, Lfn4fail174_1location
add x0, x0, :lo12:Lfn4fail174_1location
bl fen_set_location
mov x1, #1
b Lfn4end
Lfn4fail229_3:
adrp x0, Lfn4fail229_3location
add x0, x0, :lo12:Lfn4fail229_3location
bl fen_set_location
mov x1, #3
b Lfn4end
Lfn4fail292_4:
adrp x0, Lfn4fail292_4location
add x0, x0, :lo12:Lfn4fail292_4location
bl fen_set_location
mov x1, #4
b Lfn4end
Lfn4fail297_1:
adrp x0, Lfn4fail297_1location
add x0, x0, :lo12:Lfn4fail297_1location
bl fen_set_location
mov x1, #1
b Lfn4end
Lfn4fail320_3:
adrp x0, Lfn4fail320_3location
add x0, x0, :lo12:Lfn4fail320_3location
bl fen_set_location
mov x1, #3
b Lfn4end
Lfn4fail349_3:
adrp x0, Lfn4fail349_3location
add x0, x0, :lo12:Lfn4fail349_3location
bl fen_set_location
mov x1, #3
b Lfn4end
Lfn4fail346_3:
adrp x0, Lfn4fail346_3location
add x0, x0, :lo12:Lfn4fail346_3location
bl fen_set_location
mov x1, #3
b Lfn4end
Lfn4fail366_3:
adrp x0, Lfn4fail366_3location
add x0, x0, :lo12:Lfn4fail366_3location
bl fen_set_location
mov x1, #3
b Lfn4end
Lfn4fail363_3:
adrp x0, Lfn4fail363_3location
add x0, x0, :lo12:Lfn4fail363_3location
bl fen_set_location
mov x1, #3
b Lfn4end
Lfn4fail383_3:
adrp x0, Lfn4fail383_3location
add x0, x0, :lo12:Lfn4fail383_3location
bl fen_set_location
mov x1, #3
b Lfn4end
Lfn4fail380_3:
adrp x0, Lfn4fail380_3location
add x0, x0, :lo12:Lfn4fail380_3location
bl fen_set_location
mov x1, #3
b Lfn4end
Lfn4fail403_3:
adrp x0, Lfn4fail403_3location
add x0, x0, :lo12:Lfn4fail403_3location
bl fen_set_location
mov x1, #3
b Lfn4end
Lfn4fail400_3:
adrp x0, Lfn4fail400_3location
add x0, x0, :lo12:Lfn4fail400_3location
bl fen_set_location
mov x1, #3
b Lfn4end
Lfn4fail423_3:
adrp x0, Lfn4fail423_3location
add x0, x0, :lo12:Lfn4fail423_3location
bl fen_set_location
mov x1, #3
b Lfn4end
Lfn4fail451_3:
adrp x0, Lfn4fail451_3location
add x0, x0, :lo12:Lfn4fail451_3location
bl fen_set_location
mov x1, #3
b Lfn4end
Lfn4end:
bl fen_leave_result
ldp x19, x20, [x29, #-16]
ldp x21, x22, [x29, #-32]
ldp x23, x24, [x29, #-48]
ldp x25, x26, [x29, #-64]
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn5:
ldp x8, x9, [x0, #0]
Lfn5fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #128
str xzr, [sp, #64]
stp x8, x9, [sp, #48]
add x0, sp, #16
add x1, sp, #48
mov x2, #3
bl fen_enter
Lfn5loop:
movz x0, #0, lsl #0
str x0, [sp, #72]
mov x0, #6
mov x1, #11
bl fen_allocate_full
cbz x0, Lfn5fail488_3
ldr x2, [sp, #72]
ldr x3, [sp, #48]
stp x2, x3, [x0, #0]
adrp x2, Lconstant0
add x2, x2, :lo12:Lconstant0
str x2, [x0, #16]
str x0, [sp, #64]
movz x0, #0, lsl #0
str x0, [sp, #80]
movz x0, #0, lsl #0
str x0, [sp, #88]
movz x0, #0, lsl #0
str x0, [sp, #96]
ldr x8, [sp, #64]
adrp x9, Lconstant0
add x9, x9, :lo12:Lconstant0
ldr x10, [sp, #80]
ldr x11, [sp, #88]
ldr x12, [sp, #56]
ldr x13, [sp, #96]
bl Lfn4fields
cbnz x1, Lfn5end
str x0, [sp, #104]
ldr x0, [sp, #56]
ldr x0, [x0]
str x0, [sp, #112]
ldr x0, [sp, #104]
ldr x2, [sp, #112]
cmp x0, x2
cset x0, eq
mov x1, #0
b Lfn5end
Lfn5fail488_3:
adrp x0, Lfn5fail488_3location
add x0, x0, :lo12:Lfn5fail488_3location
bl fen_set_location
mov x1, #3
b Lfn5end
Lfn5end:
bl fen_leave_result
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn6:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
str x0, [sp, #48]
adrp x8, Lconstant2
add x8, x8, :lo12:Lconstant2
adrp x9, Lconstant3
add x9, x9, :lo12:Lconstant3
bl Lfn5fields
cbnz x1, Lfn6end
cbz x0, Lfn6if501else
movz x0, #1, lsl #0
b Lfn6if501done
Lfn6if501else:
movz x0, #0, lsl #0
Lfn6if501done:
mov x1, #0
b Lfn6end
Lfn6end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn7:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
str x0, [sp, #48]
adrp x8, Lconstant5
add x8, x8, :lo12:Lconstant5
adrp x9, Lconstant6
add x9, x9, :lo12:Lconstant6
bl Lfn5fields
cbnz x1, Lfn7end
cbz x0, Lfn7if515else
movz x0, #1, lsl #0
b Lfn7if515done
Lfn7if515else:
movz x0, #0, lsl #0
Lfn7if515done:
mov x1, #0
b Lfn7end
Lfn7end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn8:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
str x0, [sp, #48]
adrp x8, Lconstant10
add x8, x8, :lo12:Lconstant10
adrp x9, Lconstant11
add x9, x9, :lo12:Lconstant11
bl Lfn5fields
cbnz x1, Lfn8end
cbz x0, Lfn8if530else
movz x0, #1, lsl #0
b Lfn8if530done
Lfn8if530else:
movz x0, #0, lsl #0
Lfn8if530done:
mov x1, #0
b Lfn8end
Lfn8end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn9:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
str x0, [sp, #48]
adrp x8, Lconstant18
add x8, x8, :lo12:Lconstant18
adrp x9, Lconstant19
add x9, x9, :lo12:Lconstant19
bl Lfn5fields
cbnz x1, Lfn9end
cbz x0, Lfn9if552else
movz x0, #1, lsl #0
b Lfn9if552done
Lfn9if552else:
movz x0, #0, lsl #0
Lfn9if552done:
mov x1, #0
b Lfn9end
Lfn9end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn10:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
str x0, [sp, #48]
adrp x8, Lconstant23
add x8, x8, :lo12:Lconstant23
adrp x9, Lconstant24
add x9, x9, :lo12:Lconstant24
bl Lfn5fields
cbnz x1, Lfn10end
cbz x0, Lfn10if586else
movz x0, #1, lsl #0
b Lfn10if586done
Lfn10if586else:
movz x0, #0, lsl #0
Lfn10if586done:
mov x1, #0
b Lfn10end
Lfn10end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn11:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #64
str x0, [sp, #48]
adrp x8, Lconstant26
add x8, x8, :lo12:Lconstant26
adrp x9, Lconstant27
add x9, x9, :lo12:Lconstant27
bl Lfn5fields
cbnz x1, Lfn11end
cbz x0, Lfn11if616else
movz x0, #1, lsl #0
b Lfn11if616done
Lfn11if616else:
movz x0, #0, lsl #0
Lfn11if616done:
mov x1, #0
b Lfn11end
Lfn11end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn12:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #160
str x0, [sp, #48]
movz x0, #0, lsl #0
str x0, [sp, #56]
ldr x0, [sp, #48]
bl Lfn6
cbnz x1, Lfn12end
str x0, [sp, #64]
ldr x0, [sp, #56]
ldr x2, [sp, #64]
adds x0, x0, x2
b.vs Lfn12fail643_1
str x0, [sp, #72]
ldr x0, [sp, #48]
bl Lfn7
cbnz x1, Lfn12end
str x0, [sp, #80]
ldr x0, [sp, #72]
ldr x2, [sp, #80]
adds x0, x0, x2
b.vs Lfn12fail642_1
str x0, [sp, #88]
ldr x0, [sp, #48]
bl Lfn8
cbnz x1, Lfn12end
str x0, [sp, #96]
ldr x0, [sp, #88]
ldr x2, [sp, #96]
adds x0, x0, x2
b.vs Lfn12fail641_1
str x0, [sp, #104]
ldr x0, [sp, #48]
bl Lfn9
cbnz x1, Lfn12end
str x0, [sp, #112]
ldr x0, [sp, #104]
ldr x2, [sp, #112]
adds x0, x0, x2
b.vs Lfn12fail640_1
str x0, [sp, #120]
ldr x0, [sp, #48]
bl Lfn10
cbnz x1, Lfn12end
str x0, [sp, #128]
ldr x0, [sp, #120]
ldr x2, [sp, #128]
adds x0, x0, x2
b.vs Lfn12fail639_1
str x0, [sp, #136]
ldr x0, [sp, #48]
bl Lfn11
cbnz x1, Lfn12end
str x0, [sp, #144]
ldr x0, [sp, #136]
ldr x2, [sp, #144]
adds x0, x0, x2
b.vs Lfn12fail638_1
mov x1, #0
b Lfn12end
Lfn12fail643_1:
adrp x0, Lfn12fail643_1location
add x0, x0, :lo12:Lfn12fail643_1location
bl fen_set_location
mov x1, #1
b Lfn12end
Lfn12fail642_1:
adrp x0, Lfn12fail642_1location
add x0, x0, :lo12:Lfn12fail642_1location
bl fen_set_location
mov x1, #1
b Lfn12end
Lfn12fail641_1:
adrp x0, Lfn12fail641_1location
add x0, x0, :lo12:Lfn12fail641_1location
bl fen_set_location
mov x1, #1
b Lfn12end
Lfn12fail640_1:
adrp x0, Lfn12fail640_1location
add x0, x0, :lo12:Lfn12fail640_1location
bl fen_set_location
mov x1, #1
b Lfn12end
Lfn12fail639_1:
adrp x0, Lfn12fail639_1location
add x0, x0, :lo12:Lfn12fail639_1location
bl fen_set_location
mov x1, #1
b Lfn12end
Lfn12fail638_1:
adrp x0, Lfn12fail638_1location
add x0, x0, :lo12:Lfn12fail638_1location
bl fen_set_location
mov x1, #1
b Lfn12end
Lfn12end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
Lfn13:
ldp x8, x9, [x0, #0]
Lfn13fields:
stp x29, x30, [sp, #-16]!
mov x29, sp
stp x19, x20, [sp, #-16]!
sub sp, sp, #80
mov x19, x8
mov x20, x9
Lfn13loop:
mov x0, x19
cmp x0, #0
b.gt Lfn13if667else
mov x0, x20
b Lfn13if667done
Lfn13if667else:
mov x0, x19
subs x0, x0, #1
b.vs Lfn13fail674_1
str x0, [sp, #48]
mov x0, x19
bl Lfn12
cbnz x1, Lfn13end
str x0, [sp, #56]
mov x0, x20
ldr x2, [sp, #56]
adds x0, x0, x2
b.vs Lfn13fail677_1
str x0, [sp, #64]
ldr x8, [sp, #48]
ldr x9, [sp, #64]
mov x19, x8
mov x20, x9
b Lfn13loop
Lfn13if667done:
mov x1, #0
b Lfn13end
Lfn13fail674_1:
adrp x0, Lfn13fail674_1location
add x0, x0, :lo12:Lfn13fail674_1location
bl fen_set_location
mov x1, #1
b Lfn13end
Lfn13fail677_1:
adrp x0, Lfn13fail677_1location
add x0, x0, :lo12:Lfn13fail677_1location
bl fen_set_location
mov x1, #1
b Lfn13end
Lfn13end:
ldp x19, x20, [x29, #-16]
mov sp, x29
ldp x29, x30, [sp], #16
ret
.globl fenrir_entry
fenrir_entry:
Lfn14:
stp x29, x30, [sp, #-16]!
mov x29, sp
sub sp, sp, #352
str x0, [sp, #48]
ldr x0, [sp, #48]
cmp x0, #0
b.ne Lfn14if683else
movz x0, #0, lsl #0
str x0, [sp, #56]
adrp x8, Lconstant2
add x8, x8, :lo12:Lconstant2
adrp x9, Lconstant28
add x9, x9, :lo12:Lconstant28
bl Lfn5fields
cbnz x1, Lfn14end
cbz x0, Lfn14if706else
movz x0, #0, lsl #0
b Lfn14if706done
Lfn14if706else:
movz x0, #1, lsl #0
Lfn14if706done:
str x0, [sp, #64]
ldr x0, [sp, #56]
ldr x2, [sp, #64]
adds x0, x0, x2
b.vs Lfn14fail704_1
str x0, [sp, #72]
adrp x8, Lconstant2
add x8, x8, :lo12:Lconstant2
adrp x9, Lconstant29
add x9, x9, :lo12:Lconstant29
bl Lfn5fields
cbnz x1, Lfn14end
cbz x0, Lfn14if718else
movz x0, #0, lsl #0
b Lfn14if718done
Lfn14if718else:
movz x0, #1, lsl #0
Lfn14if718done:
str x0, [sp, #80]
ldr x0, [sp, #72]
ldr x2, [sp, #80]
adds x0, x0, x2
b.vs Lfn14fail703_1
str x0, [sp, #88]
adrp x8, Lconstant2
add x8, x8, :lo12:Lconstant2
adrp x9, Lconstant30
add x9, x9, :lo12:Lconstant30
bl Lfn5fields
cbnz x1, Lfn14end
cbz x0, Lfn14if730else
movz x0, #0, lsl #0
b Lfn14if730done
Lfn14if730else:
movz x0, #1, lsl #0
Lfn14if730done:
str x0, [sp, #96]
ldr x0, [sp, #88]
ldr x2, [sp, #96]
adds x0, x0, x2
b.vs Lfn14fail702_1
str x0, [sp, #104]
adrp x8, Lconstant5
add x8, x8, :lo12:Lconstant5
adrp x9, Lconstant31
add x9, x9, :lo12:Lconstant31
bl Lfn5fields
cbnz x1, Lfn14end
cbz x0, Lfn14if742else
movz x0, #0, lsl #0
b Lfn14if742done
Lfn14if742else:
movz x0, #1, lsl #0
Lfn14if742done:
str x0, [sp, #112]
ldr x0, [sp, #104]
ldr x2, [sp, #112]
adds x0, x0, x2
b.vs Lfn14fail701_1
str x0, [sp, #120]
adrp x8, Lconstant5
add x8, x8, :lo12:Lconstant5
adrp x9, Lconstant32
add x9, x9, :lo12:Lconstant32
bl Lfn5fields
cbnz x1, Lfn14end
cbz x0, Lfn14if755else
movz x0, #0, lsl #0
b Lfn14if755done
Lfn14if755else:
movz x0, #1, lsl #0
Lfn14if755done:
str x0, [sp, #128]
ldr x0, [sp, #120]
ldr x2, [sp, #128]
adds x0, x0, x2
b.vs Lfn14fail700_1
str x0, [sp, #136]
adrp x8, Lconstant5
add x8, x8, :lo12:Lconstant5
adrp x9, Lconstant33
add x9, x9, :lo12:Lconstant33
bl Lfn5fields
cbnz x1, Lfn14end
cbz x0, Lfn14if768else
movz x0, #0, lsl #0
b Lfn14if768done
Lfn14if768else:
movz x0, #1, lsl #0
Lfn14if768done:
str x0, [sp, #144]
ldr x0, [sp, #136]
ldr x2, [sp, #144]
adds x0, x0, x2
b.vs Lfn14fail699_1
str x0, [sp, #152]
adrp x8, Lconstant10
add x8, x8, :lo12:Lconstant10
adrp x9, Lconstant34
add x9, x9, :lo12:Lconstant34
bl Lfn5fields
cbnz x1, Lfn14end
cbz x0, Lfn14if781else
movz x0, #0, lsl #0
b Lfn14if781done
Lfn14if781else:
movz x0, #1, lsl #0
Lfn14if781done:
str x0, [sp, #160]
ldr x0, [sp, #152]
ldr x2, [sp, #160]
adds x0, x0, x2
b.vs Lfn14fail698_1
str x0, [sp, #168]
adrp x8, Lconstant10
add x8, x8, :lo12:Lconstant10
adrp x9, Lconstant35
add x9, x9, :lo12:Lconstant35
bl Lfn5fields
cbnz x1, Lfn14end
cbz x0, Lfn14if801else
movz x0, #0, lsl #0
b Lfn14if801done
Lfn14if801else:
movz x0, #1, lsl #0
Lfn14if801done:
str x0, [sp, #176]
ldr x0, [sp, #168]
ldr x2, [sp, #176]
adds x0, x0, x2
b.vs Lfn14fail697_1
str x0, [sp, #184]
adrp x8, Lconstant10
add x8, x8, :lo12:Lconstant10
adrp x9, Lconstant36
add x9, x9, :lo12:Lconstant36
bl Lfn5fields
cbnz x1, Lfn14end
cbz x0, Lfn14if821else
movz x0, #0, lsl #0
b Lfn14if821done
Lfn14if821else:
movz x0, #1, lsl #0
Lfn14if821done:
str x0, [sp, #192]
ldr x0, [sp, #184]
ldr x2, [sp, #192]
adds x0, x0, x2
b.vs Lfn14fail696_1
str x0, [sp, #200]
adrp x8, Lconstant18
add x8, x8, :lo12:Lconstant18
adrp x9, Lconstant37
add x9, x9, :lo12:Lconstant37
bl Lfn5fields
cbnz x1, Lfn14end
cbz x0, Lfn14if841else
movz x0, #0, lsl #0
b Lfn14if841done
Lfn14if841else:
movz x0, #1, lsl #0
Lfn14if841done:
str x0, [sp, #208]
ldr x0, [sp, #200]
ldr x2, [sp, #208]
adds x0, x0, x2
b.vs Lfn14fail695_1
str x0, [sp, #216]
adrp x8, Lconstant18
add x8, x8, :lo12:Lconstant18
adrp x9, Lconstant38
add x9, x9, :lo12:Lconstant38
bl Lfn5fields
cbnz x1, Lfn14end
cbz x0, Lfn14if873else
movz x0, #0, lsl #0
b Lfn14if873done
Lfn14if873else:
movz x0, #1, lsl #0
Lfn14if873done:
str x0, [sp, #224]
ldr x0, [sp, #216]
ldr x2, [sp, #224]
adds x0, x0, x2
b.vs Lfn14fail694_1
str x0, [sp, #232]
adrp x8, Lconstant18
add x8, x8, :lo12:Lconstant18
adrp x9, Lconstant39
add x9, x9, :lo12:Lconstant39
bl Lfn5fields
cbnz x1, Lfn14end
cbz x0, Lfn14if905else
movz x0, #0, lsl #0
b Lfn14if905done
Lfn14if905else:
movz x0, #1, lsl #0
Lfn14if905done:
str x0, [sp, #240]
ldr x0, [sp, #232]
ldr x2, [sp, #240]
adds x0, x0, x2
b.vs Lfn14fail693_1
str x0, [sp, #248]
adrp x8, Lconstant23
add x8, x8, :lo12:Lconstant23
adrp x9, Lconstant40
add x9, x9, :lo12:Lconstant40
bl Lfn5fields
cbnz x1, Lfn14end
cbz x0, Lfn14if937else
movz x0, #0, lsl #0
b Lfn14if937done
Lfn14if937else:
movz x0, #1, lsl #0
Lfn14if937done:
str x0, [sp, #256]
ldr x0, [sp, #248]
ldr x2, [sp, #256]
adds x0, x0, x2
b.vs Lfn14fail692_1
str x0, [sp, #264]
adrp x8, Lconstant23
add x8, x8, :lo12:Lconstant23
adrp x9, Lconstant41
add x9, x9, :lo12:Lconstant41
bl Lfn5fields
cbnz x1, Lfn14end
cbz x0, Lfn14if965else
movz x0, #0, lsl #0
b Lfn14if965done
Lfn14if965else:
movz x0, #1, lsl #0
Lfn14if965done:
str x0, [sp, #272]
ldr x0, [sp, #264]
ldr x2, [sp, #272]
adds x0, x0, x2
b.vs Lfn14fail691_1
str x0, [sp, #280]
adrp x8, Lconstant23
add x8, x8, :lo12:Lconstant23
adrp x9, Lconstant42
add x9, x9, :lo12:Lconstant42
bl Lfn5fields
cbnz x1, Lfn14end
cbz x0, Lfn14if993else
movz x0, #0, lsl #0
b Lfn14if993done
Lfn14if993else:
movz x0, #1, lsl #0
Lfn14if993done:
str x0, [sp, #288]
ldr x0, [sp, #280]
ldr x2, [sp, #288]
adds x0, x0, x2
b.vs Lfn14fail690_1
str x0, [sp, #296]
adrp x8, Lconstant26
add x8, x8, :lo12:Lconstant26
adrp x9, Lconstant43
add x9, x9, :lo12:Lconstant43
bl Lfn5fields
cbnz x1, Lfn14end
cbz x0, Lfn14if1021else
movz x0, #0, lsl #0
b Lfn14if1021done
Lfn14if1021else:
movz x0, #1, lsl #0
Lfn14if1021done:
str x0, [sp, #304]
ldr x0, [sp, #296]
ldr x2, [sp, #304]
adds x0, x0, x2
b.vs Lfn14fail689_1
str x0, [sp, #312]
adrp x8, Lconstant26
add x8, x8, :lo12:Lconstant26
adrp x9, Lconstant44
add x9, x9, :lo12:Lconstant44
bl Lfn5fields
cbnz x1, Lfn14end
cbz x0, Lfn14if1041else
movz x0, #0, lsl #0
b Lfn14if1041done
Lfn14if1041else:
movz x0, #1, lsl #0
Lfn14if1041done:
str x0, [sp, #320]
ldr x0, [sp, #312]
ldr x2, [sp, #320]
adds x0, x0, x2
b.vs Lfn14fail688_1
str x0, [sp, #328]
adrp x8, Lconstant26
add x8, x8, :lo12:Lconstant26
adrp x9, Lconstant45
add x9, x9, :lo12:Lconstant45
bl Lfn5fields
cbnz x1, Lfn14end
cbz x0, Lfn14if1061else
movz x0, #0, lsl #0
b Lfn14if1061done
Lfn14if1061else:
movz x0, #1, lsl #0
Lfn14if1061done:
str x0, [sp, #336]
ldr x0, [sp, #328]
ldr x2, [sp, #336]
adds x0, x0, x2
b.vs Lfn14fail687_1
b Lfn14if683done
Lfn14if683else:
movz x0, #0, lsl #0
str x0, [sp, #344]
ldr x8, [sp, #48]
ldr x9, [sp, #344]
mov sp, x29
ldp x29, x30, [sp], #16
b Lfn13fields
Lfn14if683done:
mov x1, #0
b Lfn14end
Lfn14fail704_1:
adrp x0, Lfn14fail704_1location
add x0, x0, :lo12:Lfn14fail704_1location
bl fen_set_location
mov x1, #1
b Lfn14end
Lfn14fail703_1:
adrp x0, Lfn14fail703_1location
add x0, x0, :lo12:Lfn14fail703_1location
bl fen_set_location
mov x1, #1
b Lfn14end
Lfn14fail702_1:
adrp x0, Lfn14fail702_1location
add x0, x0, :lo12:Lfn14fail702_1location
bl fen_set_location
mov x1, #1
b Lfn14end
Lfn14fail701_1:
adrp x0, Lfn14fail701_1location
add x0, x0, :lo12:Lfn14fail701_1location
bl fen_set_location
mov x1, #1
b Lfn14end
Lfn14fail700_1:
adrp x0, Lfn14fail700_1location
add x0, x0, :lo12:Lfn14fail700_1location
bl fen_set_location
mov x1, #1
b Lfn14end
Lfn14fail699_1:
adrp x0, Lfn14fail699_1location
add x0, x0, :lo12:Lfn14fail699_1location
bl fen_set_location
mov x1, #1
b Lfn14end
Lfn14fail698_1:
adrp x0, Lfn14fail698_1location
add x0, x0, :lo12:Lfn14fail698_1location
bl fen_set_location
mov x1, #1
b Lfn14end
Lfn14fail697_1:
adrp x0, Lfn14fail697_1location
add x0, x0, :lo12:Lfn14fail697_1location
bl fen_set_location
mov x1, #1
b Lfn14end
Lfn14fail696_1:
adrp x0, Lfn14fail696_1location
add x0, x0, :lo12:Lfn14fail696_1location
bl fen_set_location
mov x1, #1
b Lfn14end
Lfn14fail695_1:
adrp x0, Lfn14fail695_1location
add x0, x0, :lo12:Lfn14fail695_1location
bl fen_set_location
mov x1, #1
b Lfn14end
Lfn14fail694_1:
adrp x0, Lfn14fail694_1location
add x0, x0, :lo12:Lfn14fail694_1location
bl fen_set_location
mov x1, #1
b Lfn14end
Lfn14fail693_1:
adrp x0, Lfn14fail693_1location
add x0, x0, :lo12:Lfn14fail693_1location
bl fen_set_location
mov x1, #1
b Lfn14end
Lfn14fail692_1:
adrp x0, Lfn14fail692_1location
add x0, x0, :lo12:Lfn14fail692_1location
bl fen_set_location
mov x1, #1
b Lfn14end
Lfn14fail691_1:
adrp x0, Lfn14fail691_1location
add x0, x0, :lo12:Lfn14fail691_1location
bl fen_set_location
mov x1, #1
b Lfn14end
Lfn14fail690_1:
adrp x0, Lfn14fail690_1location
add x0, x0, :lo12:Lfn14fail690_1location
bl fen_set_location
mov x1, #1
b Lfn14end
Lfn14fail689_1:
adrp x0, Lfn14fail689_1location
add x0, x0, :lo12:Lfn14fail689_1location
bl fen_set_location
mov x1, #1
b Lfn14end
Lfn14fail688_1:
adrp x0, Lfn14fail688_1location
add x0, x0, :lo12:Lfn14fail688_1location
bl fen_set_location
mov x1, #1
b Lfn14end
Lfn14fail687_1:
adrp x0, Lfn14fail687_1location
add x0, x0, :lo12:Lfn14fail687_1location
bl fen_set_location
mov x1, #1
b Lfn14end
Lfn14end:
mov sp, x29
ldp x29, x30, [sp], #16
ret
.text
.globl fen_print_result
fen_print_result:
b Lprint0
Lprint0:
b fen_write_i64
Lfn0fail18_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,56,58,49,55,10,0
Lfn0fail28_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,58,52,48,10,0
Lfn0fail25_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,58,50,55,10,0
.p2align 3
Lconstant0:
.zero 72
.long 10
.byte 0,2,0,0
Lfn1fail52_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,49,50,58,51,49,10,0
Lfn2fail73_2location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,49,54,58,51,49,10,0
Lfn2fail73_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,49,54,58,51,49,10,0
Lfn3fail99_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,50,48,58,51,50,10,0
Lfn3fail108_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,50,49,58,52,53,10,0
Lfn4fail169_4location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,50,57,58,50,51,10,0
Lfn4fail174_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,50,57,58,53,52,10,0
Lfn4fail229_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,52,49,58,53,51,10,0
Lfn4fail292_4location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,53,50,58,49,54,10,0
Lfn4fail297_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,53,50,58,52,56,10,0
Lfn4fail320_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,53,54,58,51,48,10,0
Lfn4fail349_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,54,48,58,53,52,10,0
Lfn4fail346_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,54,48,58,51,57,10,0
Lfn4fail366_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,54,49,58,54,49,10,0
Lfn4fail363_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,54,49,58,52,54,10,0
Lfn4fail383_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,54,50,58,53,54,10,0
Lfn4fail380_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,54,50,58,52,49,10,0
Lfn4fail403_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,54,51,58,49,48,51,10,0
Lfn4fail400_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,54,51,58,56,56,10,0
Lfn4fail423_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,54,55,58,55,48,10,0
Lfn4fail451_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,55,48,58,54,49,10,0
Lfn5fail488_3location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,55,53,58,51,50,10,0
.p2align 3
Lconstant1:
.quad 1
.zero 64
.long 7
.byte 0,2,0,0
.section .rodata
.p2align 3
Lconstant2:
.quad 2
.quad Lconstant1
.quad Lconstant1
.zero 48
.long 9
.byte 6,2,0,0
.text
.p2align 3
Lconstant3:
.quad 3
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,120
.section .rodata
.p2align 3
Lconstant4:
.quad Lconstant1
.zero 64
.long 8
.byte 1,2,0,0
.text
.section .rodata
.p2align 3
Lconstant5:
.quad 1
.quad Lconstant1
.quad Lconstant4
.zero 48
.long 9
.byte 6,2,0,0
.text
.p2align 3
Lconstant6:
.quad 4
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,120
.p2align 3
Lconstant7:
.quad 2
.zero 64
.long 7
.byte 0,2,0,0
.section .rodata
.p2align 3
Lconstant8:
.quad 2
.quad Lconstant1
.quad Lconstant7
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant9:
.quad 0
.quad Lconstant1
.quad Lconstant8
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant10:
.quad 2
.quad Lconstant9
.quad Lconstant7
.zero 48
.long 9
.byte 6,2,0,0
.text
.p2align 3
Lconstant11:
.quad 7
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,98,120,120
.p2align 3
Lconstant12:
.quad 4
.zero 64
.long 7
.byte 0,2,0,0
.section .rodata
.p2align 3
Lconstant13:
.quad 1
.quad Lconstant7
.quad Lconstant12
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant14:
.quad 0
.quad Lconstant1
.quad Lconstant13
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant15:
.quad 0
.quad Lconstant1
.quad Lconstant7
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant16:
.quad 0
.quad Lconstant1
.quad Lconstant12
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant17:
.quad 1
.quad Lconstant15
.quad Lconstant16
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant18:
.quad 2
.quad Lconstant14
.quad Lconstant17
.zero 48
.long 9
.byte 6,2,0,0
.text
.p2align 3
Lconstant19:
.quad 29
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,98,98,98,115,120,115,120,98,115,120,115,120,98,98,115,120,115,120,98,115,115,120,115,115,120
.section .rodata
.p2align 3
Lconstant20:
.quad 2
.quad Lconstant7
.quad Lconstant12
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant21:
.quad 0
.quad Lconstant8
.quad Lconstant20
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant22:
.quad 2
.quad Lconstant1
.quad Lconstant12
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant23:
.quad 2
.quad Lconstant21
.quad Lconstant22
.zero 48
.long 9
.byte 6,2,0,0
.text
.p2align 3
Lconstant24:
.quad 20
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,98,98,115,115,120,115,115,120,98,115,115,115,120,115,115,115,120
.section .rodata
.p2align 3
Lconstant25:
.quad 2
.quad Lconstant8
.quad Lconstant1
.zero 48
.long 9
.byte 6,2,0,0
.text
.section .rodata
.p2align 3
Lconstant26:
.quad 2
.quad Lconstant25
.quad Lconstant1
.zero 48
.long 9
.byte 6,2,0,0
.text
.p2align 3
Lconstant27:
.quad 7
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,98,115,115,120,115,120
Lfn12fail643_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,48,58,53,50,10,0
Lfn12fail642_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,48,58,52,57,10,0
Lfn12fail641_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,48,58,52,54,10,0
Lfn12fail640_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,48,58,52,51,10,0
Lfn12fail639_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,48,58,52,48,10,0
Lfn12fail638_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,48,58,51,55,10,0
Lfn13fail674_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,50,58,52,55,10,0
Lfn13fail677_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,50,58,53,53,10,0
.p2align 3
Lconstant28:
.quad 2
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115
.p2align 3
Lconstant29:
.quad 4
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,120,120
.p2align 3
Lconstant30:
.quad 3
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,63
.p2align 3
Lconstant31:
.quad 3
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115
.p2align 3
Lconstant32:
.quad 5
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,120,120
.p2align 3
Lconstant33:
.quad 4
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,63
.p2align 3
Lconstant34:
.quad 6
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,98,120
.p2align 3
Lconstant35:
.quad 8
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,98,120,120,120
.p2align 3
Lconstant36:
.quad 7
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,98,120,63
.p2align 3
Lconstant37:
.quad 28
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,98,98,98,115,120,115,120,98,115,120,115,120,98,98,115,120,115,120,98,115,115,120,115,115
.p2align 3
Lconstant38:
.quad 30
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,98,98,98,115,120,115,120,98,115,120,115,120,98,98,115,120,115,120,98,115,115,120,115,115,120,120
.p2align 3
Lconstant39:
.quad 29
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,115,98,98,98,115,120,115,120,98,115,120,115,120,98,98,115,120,115,120,98,115,115,120,115,115,63
.p2align 3
Lconstant40:
.quad 19
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,98,98,115,115,120,115,115,120,98,115,115,115,120,115,115,115
.p2align 3
Lconstant41:
.quad 21
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,98,98,115,115,120,115,115,120,98,115,115,115,120,115,115,115,120,120
.p2align 3
Lconstant42:
.quad 20
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,115,115,98,98,115,115,120,115,115,120,98,115,115,115,120,115,115,115,63
.p2align 3
Lconstant43:
.quad 6
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,98,115,115,120,115
.p2align 3
Lconstant44:
.quad 8
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,98,115,115,120,115,120,120
.p2align 3
Lconstant45:
.quad 7
.zero 64
.long 4294967295
.byte 0,2,0,0
.byte 115,98,115,115,120,115,63
Lfn14fail704_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,51,58,49,48,48,10,0
Lfn14fail703_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,51,58,57,55,10,0
Lfn14fail702_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,51,58,57,52,10,0
Lfn14fail701_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,51,58,57,49,10,0
Lfn14fail700_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,51,58,56,56,10,0
Lfn14fail699_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,51,58,56,53,10,0
Lfn14fail698_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,51,58,56,50,10,0
Lfn14fail697_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,51,58,55,57,10,0
Lfn14fail696_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,51,58,55,54,10,0
Lfn14fail695_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,51,58,55,51,10,0
Lfn14fail694_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,51,58,55,48,10,0
Lfn14fail693_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,51,58,54,55,10,0
Lfn14fail692_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,51,58,54,52,10,0
Lfn14fail691_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,51,58,54,49,10,0
Lfn14fail690_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,51,58,53,56,10,0
Lfn14fail689_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,51,58,53,53,10,0
Lfn14fail688_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,51,58,53,50,10,0
Lfn14fail687_1location:
.byte 116,114,97,112,32,97,116,58,32,98,101,110,99,104,109,97,114,107,46,102,101,110,58,57,51,58,52,57,10,0
