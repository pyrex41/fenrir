#include <stdio.h>
unsigned long long counts[8];
__attribute__((destructor)) static void report(void) {
 for(int i=0;i<8;i++) fprintf(stderr,"%llu%c",counts[i],i==7?'\n':' ');
}
