#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
typedef struct { int64_t value; uint64_t status; } result;
extern result probe2(int64_t, int64_t), probe3(int64_t, int64_t);
extern const char *fen_trap_location;
void fen_write(const char *s, size_t n) { fwrite(s, 1, n, stdout); }
void fen_write_i64(int64_t n) { printf("%" PRId64, n); }
int main(void) {
    int64_t x, y;
    while (scanf("%" SCNd64 " %" SCNd64, &x, &y) == 2) {
        for (int i = 2; i <= 3; ++i) {
            fen_trap_location = NULL;
            result r = i == 2 ? probe2(x,y) : probe3(x,y);
            if (r.status) printf("trap %" PRIu64 " %s",r.status,fen_trap_location);
            else printf("ok %" PRId64 "\n",r.value);
        }
    }
}
