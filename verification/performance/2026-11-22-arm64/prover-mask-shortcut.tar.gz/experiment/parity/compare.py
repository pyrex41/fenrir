import random,subprocess,hashlib,json
from pathlib import Path
lo=-(1<<63);hi=(1<<63)-1
vals=sorted({lo,lo+1,-9,-3,-2,-1,0,1,2,3,5,hi-1,hi}|{(1<<n)+off for n in range(63) for off in (-1,0,1)})
pairs=[(x,y) for x in vals for y in vals];rng=random.Random(1147);pairs.extend((rng.randint(lo,hi),rng.randint(lo,hi)) for _ in range(10000))
data=''.join(f'{x} {y}\n' for x,y in pairs).encode();a,b=[subprocess.check_output(['./'+v],input=data) for v in ('base','candidate')];assert a==b;rows=a.splitlines();assert len(rows)==2*len(pairs);counts={k:sum(x.startswith(k.encode()) for x in rows) for k in ('ok','trap 1 ','trap 2 ')};assert sum(counts.values())==len(rows) and all(counts.values())
r=dict(pairs=len(pairs),calls=len(rows),counts=counts,input_sha256=hashlib.sha256(data).hexdigest(),output_sha256=hashlib.sha256(a).hexdigest());print(r);Path('summary.json').write_text(json.dumps(r,indent=2)+'\n')
