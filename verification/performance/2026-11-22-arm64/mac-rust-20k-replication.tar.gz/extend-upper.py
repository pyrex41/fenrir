import json
import os
from pathlib import Path
from runpy import run_path
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
suite = root / "benchmarks/http"
summarize = run_path(str(suite / "capacity.py"))["summarize"]
deadline = time.monotonic() + 3 * 3600
while not (root / "scout-capacity.json").exists():
    os.kill(int(sys.argv[1]), 0)
    if time.monotonic() > deadline:
        raise TimeoutError("waiting for the existing capacity grid")
    time.sleep(15)

folders = [root / "sweep", root / "extension"]
result = summarize(*folders)
if json.loads(json.dumps(result)) != json.loads((root / "scout-capacity.json").read_text()):
    raise ValueError("completed grid does not match replay")
for worker in result["observations"].values():
    for samples in worker.values():
        if any(v in {"invalid-response", "excluded", "missing"} for v in samples):
            raise ValueError("incomplete capacity grid or invalid response")

if any(result["capacity_bounds"][name]["failed"] is None for name in ("fenrir", "rust")):
    upper = root / "upper-100000"
    subprocess.run([sys.executable, str(suite / "sweep.py"), sys.argv[2], str(upper),
                    "--target", "mac", "--driver-from", str(root / "sweep"),
                    "--seconds", "600", "--blocks", "2", "--rates", "100000"],
                   check=True, timeout=2*3600)
    folders.append(upper)
result = summarize(*folders)
(root / "upper-capacity.json").write_text(json.dumps(result, indent=2) + "\n")
