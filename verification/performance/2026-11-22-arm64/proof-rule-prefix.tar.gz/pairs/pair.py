import json, statistics, random, subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
image=json.loads((root/'score/report.json').read_text())['container']
for lane,cases in [('search',10)]:
    order=['baseline','program','program','baseline']*13
    result=subprocess.check_output(['docker','run','--rm','--network','none','--platform','linux/arm64','--cpuset-cpus','1','-v',f'{root}/score/{lane}:/work:ro','-w','/work','--entrypoint','sh',image,'-ec','for n do /opt/solo5-install/bin/solo5-spt "$n.spt" --solo5:quiet 50000; done','sh',*order],text=True,timeout=180)
    rows=[list(map(int,line.split())) for line in result.splitlines()]
    assert len(rows)==len(order) and all(count==cases*50000 and ns>0 for count,ns in rows)
    pairs=[dict(zip(order[i:i+2],[r[1] for r in rows[i:i+2]])) for i in range(0,len(order),2)]
    ratios=[p['program']/p['baseline'] for p in pairs[2:]]
    rng=random.Random(1147)
    boot=sorted(statistics.median(rng.choices(ratios,k=len(ratios))) for _ in range(10000))
    report=dict(lane=lane,order=order,rows=rows,rounds=50000,warmup_pairs=2,median=statistics.median(ratios),interval=[boot[249],boot[9749]])
    (root/(lane+'.json')).write_text(json.dumps(report,indent=2))
    print(lane,report['median'],report['interval'],flush=True)
