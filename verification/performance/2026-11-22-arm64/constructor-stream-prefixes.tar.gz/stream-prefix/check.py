"""Check every EOF position in one mixed framed log against its construction."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

workers = [Path(arg).resolve() for arg in sys.argv[1:]]
stream = bytearray()
boundaries = {0: b""}
totals = {}
for key, payload in [(63, b""), (2, b"abc"), (63, b"\xff"), (0, bytes(range(17))), (2, b"\x00\xff")]:
    stream.extend((len(payload) + 1).to_bytes(2, "big") + bytes([key]) + payload)
    n, size, checksum = totals.get(key, (0, 0, 0))
    totals[key] = n + 1, size + len(payload), checksum + sum(payload)
    boundaries[len(stream)] = "".join(
        f"{k} {v[0]} {v[1]} {v[2]}\n" for k, v in sorted(totals.items())
    ).encode()

for worker in workers:
    for cut in range(len(stream) + 1):
        expected = (0, boundaries[cut], b"") if cut in boundaries else (1, b"", f"reject {cut}\n".encode())
        for chunk in (1, 7, 8192):
            r = subprocess.run([worker, str(chunk)], input=stream[:cut], capture_output=True, timeout=20)
            assert (r.returncode, r.stdout, r.stderr) == expected, (worker, cut, chunk, r)
    print(json.dumps(dict(worker=worker.name, sha256=hashlib.sha256(worker.read_bytes()).hexdigest(),
                          cuts=len(stream)+1, valid=len(boundaries), chunk_sizes=[1,7,8192])))
