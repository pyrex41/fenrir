import hashlib,json,pathlib,random,statistics,subprocess,sys
d=pathlib.Path(__file__).parent
r=json.loads(pathlib.Path(sys.argv[1]).read_bytes())
assert hashlib.sha256((d/'corpus').read_bytes()).hexdigest()==r['input_sha256']
order=[('baseline','candidate') if i%2==0 else ('candidate','baseline') for i in range(26)]
cmd=['docker','run','--rm','--platform','linux/arm64','--network','none','--cpuset-cpus','4','-v',f'{d}:/bench:ro','--entrypoint','sh',r['container'],'-ec','cp /bench/corpus /tmp/input; for n do /opt/solo5-install/bin/solo5-spt --block:input=/tmp/input /bench/$n.spt --solo5:quiet t1048576; done','sh',*[v for pair in order for v in pair]]
raw=subprocess.check_output(cmd,timeout=180);(d/'console.txt').write_bytes(raw);lines=iter(raw.splitlines(keepends=True));samples=[]
for pair in order:
 row={}
 for n in pair:
  assert hashlib.sha256(b''.join(next(lines) for _ in range(64))).hexdigest()==r['expected_output_sha256']
  key,ns=next(lines).split();assert key==b'elapsed_ns' and int(ns)>0;row[n]=int(ns)
 samples.append(row)
assert next(lines,None) is None
vals=[s['candidate']/s['baseline'] for s in samples[2:]]
rng=random.Random(1147);boot=sorted(statistics.median(rng.choices(vals,k=len(vals))) for _ in range(10000))
out=dict(median=statistics.median(vals),interval=[boot[249],boot[9749]],samples=samples);(d/'result.json').write_text(json.dumps(out,indent=2));print(out['median'],out['interval'])
