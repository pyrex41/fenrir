# Constructor reuse contract

Run the bounded comparison on the development host with Maude 3.5.1.

```sh
python3 models/compiler/check-constructor-reuse.py "$(command -v maude)"
```

The model consumes the first root, keeps the second root live, flips the selected Boolean and observes both the result and the surviving root. It searches three initial heap shapes up to address renaming. The roots may refer to the same parent, to distinct parents pointing at one child, or to disjoint parents and children. Both initial payloads are false. The source observation follows immutable value semantics. The lowered observation reads from the updated heap.

The checked rule may overwrite a parent only when the other root refers to a different parent. It may overwrite the selected child only when that parent is exclusive and the surviving parent reaches a different child. The parent-only mutation omits the second condition. Its shortest failing path is `shared-child` followed by `lower`: the expected observation is `observed(true,false)`, and the mutated heap produces `observed(true,true)`. To inspect the path interactively, run the following commands in Maude.

```maude
load models/compiler/constructor-reuse.maude
search start(parentOnly) =>! result(Q,H,K,S:Observation,T:Observation) such that S:Observation =/= T:Observation .
show path labels 5 .
```

Use the state number printed by the search for the final command. The executable source witness is `shared-child.fen`. For input zero, Shen and both native backends should return the pair `true false`.

```sh
sh frontend/fenrir.sh run models/compiler/shared-child.fen
bin/fenrir run --target macos-arm64 models/compiler/shared-child.fen 0
bin/fenrir run --target solo5-arm64-spt models/compiler/shared-child.fen 0
```

The bounds cover one update, two roots, one selected child field per parent and one Boolean field per child. A compiler verifier must also account for other fields, captured references, static objects, roots across collecting calls and external callers.
